﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTargetingTypes.generated.h"

UENUM()
enum class ECombatTargetingRelationFilter : uint8
{
	Any,
	Friendly,
	Enemy,
	Team,
	Champion,
};

USTRUCT()
struct COMBATTARGETING_API FCombatTargetingParam
{
	GENERATED_BODY()

	UPROPERTY()
	float Range;
};


UINTERFACE()
class COMBATTARGETING_API UCombatTargetInterface : public UInterface
{
	GENERATED_BODY()
};

/**
 * 可以被战斗系统选作目标的Actor, 都需要实现这个interface
 */
class COMBATTARGETING_API ICombatTargetInterface
{
	GENERATED_BODY()

public:
	virtual bool IsAlive() const = 0;
	virtual bool IsEnemy(const ICombatTargetInterface* Target) const = 0;
	virtual bool IsFriend(const ICombatTargetInterface* Target) const = 0;
};

UCLASS(Config=Game, DefaultConfig, meta=(DisplayName="TargetingSetting"))
class UCombatTargetingSetting : public UDeveloperSettings
{
	GENERATED_BODY()

public:
	virtual FName GetCategoryName() const override { return TEXT("TargetingSystem"); }
	
	UPROPERTY(EditAnywhere, Config)
	TEnumAsByte<ECollisionChannel> TargetCollisionChannel;

	UPROPERTY(EditAnywhere, Config)
	TEnumAsByte<ECollisionChannel> GroundCollisionChannel;

	UPROPERTY(EditAnywhere, Config)
	float MaxGroundCheckDistance = 5000.0f;
};
