﻿#include "CombatTargetingModule.h"

#include "Kismet/KismetSystemLibrary.h"


IMPLEMENT_MODULE(FCombatTargetingModule, CombatTargeting)

COMBATTARGETING_API TAutoConsoleVariable<bool> CVarEnableCombatTargetingDebug(
	TEXT("CombatTargeting.DebugEnable"),
	false,
	TEXT("Enable combat targeting debug info")
);

ICombatTargetingSystem& ICombatTargetingSystem::Get()
{
	static ICombatTargetingSystem* Implementation = nullptr;
	if (!Implementation)
	{
		FCombatTargetingModule& Module = FModuleManager::GetModuleChecked<FCombatTargetingModule>(UE_MODULE_NAME);
		Implementation = Module.GetExternalTargetingSystem();
		if (!Implementation)
		{
			Implementation = StaticCast<ICombatTargetingSystem*>(&Module);
		}
	}

	check(Implementation)
	return *Implementation;
}

void FCombatTargetingModule::RegisterExternalTargetingSystem(TDelegate<TUniquePtr<ICombatTargetingSystem>()> Register)
{
	if (!ensureMsgf(!GetTargetingSystemRegistration().IsBound(), TEXT("ExternalTargetingSystem只能注册一次")))
	{
		return;
	}

	GetTargetingSystemRegistration() = MoveTemp(Register);
}

ICombatTargetingSystem* FCombatTargetingModule::GetExternalTargetingSystem()
{
	if (GetTargetingSystemRegistration().IsBound())
	{
		ExternalTargetingSystem = GetTargetingSystemRegistration().Execute();
		GetTargetingSystemRegistration().Unbind();
	}

	return ExternalTargetingSystem.Get();
}

TDelegate<TUniquePtr<ICombatTargetingSystem>()>& FCombatTargetingModule::GetTargetingSystemRegistration()
{
	static TDelegate<TUniquePtr<ICombatTargetingSystem>()> Registration;
	return Registration;
}

bool FCombatTargetingModule::ScanTargets(const AActor* Instigator, const FTransform OriginTransform, float Radius, TArray<FCombatTarget>& OutTargets, FCombatTargetFilter* Filter) const
{
	OutTargets.Empty();

	const EObjectTypeQuery ObjectType = UEngineTypes::ConvertToObjectType(ECC_Pawn);
	UClass* ActorClassFilter = Filter ? Filter->ActorClassFilter.Get() : AActor::StaticClass();
	static TArray<AActor*> EmptyActorsToIgnore;
	const TArray<AActor*>& ActorsToIgnore = Filter ? Filter->ActorsToIgnore : EmptyActorsToIgnore;

	TArray<AActor*> OutActors;
	if (!UKismetSystemLibrary::SphereOverlapActors(Instigator, OriginTransform.GetLocation(), Radius, {ObjectType}, ActorClassFilter, ActorsToIgnore, OutActors))
	{
		return false;
	}

	for (AActor* TargetActor : OutActors)
	{
		if (TargetActor == Instigator)
		{
			continue;
		}

		OutTargets.Add(FCombatTarget::MakeFromActor(TargetActor));
	}

	return !OutTargets.IsEmpty();
}

FVector FCombatTargetingModule::GetMovementInputDirection(AController* SourceController, FCombatTargetingSession* Session) const
{
	check(SourceController)

	if (const APawn* ControlledPawn = SourceController->GetPawn())
	{
		return ControlledPawn->GetLastMovementInputVector().GetSafeNormal(SMALL_NUMBER, ControlledPawn->GetActorForwardVector());
	}

	return FVector::ForwardVector;
}
