﻿#pragma once

#include "CoreMinimal.h"
#include "CombatTarget.h"
#include "Modules/ModuleManager.h"

COMBATTARGETING_API extern TAutoConsoleVariable<bool> CVarEnableCombatTargetingDebug;

struct FCombatTargetingSession
{
};

struct FCombatTargetFilter
{
	TSubclassOf<AActor> ActorClassFilter;
	TArray<AActor*> ActorsToIgnore;
};

/**
 * 索敌系统实现, 保持系统是无状态的(Stateless)，这样多个模块可以同时使用。
 * 如果需要维护某个模块的索敌状态(如: 历史目标选取高优先, 不选取重复目标等), 通过自定义的ICombatTargetingSystem实现并传入自定义的TargetingSession来实现
 */
class COMBATTARGETING_API ICombatTargetingSystem
{
public:
	static ICombatTargetingSystem& Get();
	
	virtual ~ICombatTargetingSystem() = default;

	virtual bool ScanTargets(const AActor* Instigator, const FTransform OriginTransform, float Radius, TArray<FCombatTarget>& OutTargets, FCombatTargetFilter* Filter = nullptr) const = 0;
	virtual FVector GetMovementInputDirection(AController* SourceController, FCombatTargetingSession* Session = nullptr) const = 0;
};

class COMBATTARGETING_API FCombatTargetingModule : public IModuleInterface, public ICombatTargetingSystem
{
public:
	FCombatTargetingModule() = default;

	static void RegisterExternalTargetingSystem(TDelegate<TUniquePtr<ICombatTargetingSystem>()> Register);

private:
	friend class ICombatTargetingSystem;
	ICombatTargetingSystem* GetExternalTargetingSystem();
	static TDelegate<TUniquePtr<ICombatTargetingSystem>()>& GetTargetingSystemRegistration();

	TUniquePtr<ICombatTargetingSystem> ExternalTargetingSystem;


#pragma region ICombatTargetingImplementation

public:
	virtual bool ScanTargets(const AActor* Instigator, const FTransform OriginTransform, float Radius, TArray<FCombatTarget>& OutTargets, FCombatTargetFilter* Filter) const override;
	virtual FVector GetMovementInputDirection(AController* SourceController, FCombatTargetingSession* Session) const override;

#pragma endregion
};
