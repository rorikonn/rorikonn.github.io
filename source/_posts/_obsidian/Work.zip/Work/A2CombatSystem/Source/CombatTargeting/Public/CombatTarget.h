﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTarget.generated.h"

UENUM()
enum class ECombatTargetResultType : uint8
{
	/** 无效的目标 */
	None,
	/** 目标对象, 位置, 旋转可用 */
	Actor,
	/** 目标点, 位置, 旋转可用 */
	Point,
	/** 目标方向, 位置不可用, 旋转可用 */
	Direction,
};

/**
 * 战斗系统中, 目标概念的抽象, 用于将多种类型的目标统一为一个结构描述
 * 包括目标对象(Actor), 点(Point), 方向(Direction)等
 * 支持网络同步和值拷贝
 */
USTRUCT()
struct COMBATTARGETING_API FCombatTarget
{
	GENERATED_BODY()

	FORCEINLINE bool IsValid() const { return Type != ECombatTargetResultType::None; }

	FCombatTarget() = default;
	static FCombatTarget MakeFromActor(AActor* Actor);
	static FCombatTarget MakeFromPoint(const FTransform& Point);
	static FCombatTarget MakeFromDirection(const FVector& Direction);
	static FCombatTarget MakeFromDirection(const FRotator& Rotation);
	static FCombatTarget MakeFromHitResult(const FHitResult& HitResult);

	FString ToString() const;

	AActor* GetActor() const;
	FTransform GetInitialTransform() const;

	bool HasLocation() const;
	FVector GetLocation() const;

	bool HasDirection() const;
	FVector GetDirection() const;
	
	void SetProjectToGround(bool Enable);
	void PerformGroundProjection() const;

	UPROPERTY()
	uint8 bProjectToGround : 1;

	UPROPERTY()
	ECombatTargetResultType Type;

	mutable uint32 ProjectedFrame;

	// 对于点类型, 这里就是存储的最终结果, 对于Actor类型, 这里存的是最开始的目标位置快照
	UPROPERTY()
	FVector InitialLocation;
	mutable FVector ProjectedLocation;

	// 对于方向类型, 这里就是存储的最终结果, 对于Actor类型, 这里存的是最开始的目标位置快照
	UPROPERTY()
	FQuat InitialRotation;
	mutable FQuat ProjectedRotation;

	// 目标Actor, 可能为空(点和方向类型)
	UPROPERTY()
	TWeakObjectPtr<AActor> TargetActor;

	bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess);

	COMBATTARGETING_API friend FArchive& operator <<(FArchive& Ar, FCombatTarget& Value)
	{
		bool Success;
		Value.NetSerialize(Ar, nullptr, Success);
		return Ar;
	}
};

template <>
struct TStructOpsTypeTraits<FCombatTarget> : TStructOpsTypeTraitsBase2<FCombatTarget>
{
	enum
	{
		WithNetSerializer = true,
	};
};
