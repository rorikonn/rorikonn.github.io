﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTarget.h"
#include "CombatTargetingWorld.generated.h"

/**
 * 将索敌的逻辑封装到这个WorldSubsystem中, 方便一些通用的逻辑统一处理(部位, 权重, 空间加速等)
 * 
 */
UCLASS()
class COMBATTARGETING_API UCombatTargetingWorld : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	FCombatTarget SearchTarget(AController* SourceController);
};
