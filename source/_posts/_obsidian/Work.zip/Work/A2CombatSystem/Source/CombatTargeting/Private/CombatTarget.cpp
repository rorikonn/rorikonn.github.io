﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "CombatTarget.h"

#include "CombatTargetingTypes.h"

FCombatTarget FCombatTarget::MakeFromActor(AActor* Actor)
{
	FCombatTarget Result{};
	Result.Type = ECombatTargetResultType::Actor;
	Result.TargetActor = Actor;

	// 创建目标Actor当前Transform的快照
	if (Actor)
	{
		Result.InitialLocation = Actor->GetActorLocation();
		Result.InitialRotation = Actor->GetActorQuat();
	}

	return Result;
}

FCombatTarget FCombatTarget::MakeFromPoint(const FTransform& Point)
{
	FCombatTarget Result{};
	Result.Type = ECombatTargetResultType::Point;
	Result.InitialLocation = Point.GetLocation();
	Result.InitialRotation = Point.GetRotation();
	return Result;
}

FCombatTarget FCombatTarget::MakeFromDirection(const FVector& Direction)
{
	FCombatTarget Result{};
	Result.Type = ECombatTargetResultType::Direction;
	Result.InitialRotation = Direction.ToOrientationQuat();
	return Result;
}

FCombatTarget FCombatTarget::MakeFromDirection(const FRotator& Rotation)
{
	FCombatTarget Result{};
	Result.Type = ECombatTargetResultType::Direction;
	Result.InitialRotation = Rotation.Quaternion();
	return Result;
}

FCombatTarget FCombatTarget::MakeFromHitResult(const FHitResult& HitResult)
{
	if (AActor* HitActor = HitResult.GetActor())
	{
		return MakeFromActor(HitActor);
	}

	return MakeFromPoint(FTransform(HitResult.ImpactPoint));
}

FString FCombatTarget::ToString() const
{
	switch (Type)
	{
	case ECombatTargetResultType::Actor:
		return FString::Printf(TEXT("Actor%s-%s"), bProjectToGround ? TEXT("[Ground]") : TEXT(""), *GetNameSafe(GetActor()));
	case ECombatTargetResultType::Point:
		return FString::Printf(TEXT("Point-%s"), *GetInitialTransform().ToString());
	case ECombatTargetResultType::Direction:
		return FString::Printf(TEXT("Direction-%s"), *GetDirection().ToString());
	default:
		return TEXT("Invalid");
	}
}

AActor* FCombatTarget::GetActor() const
{
	if (Type == ECombatTargetResultType::Actor && TargetActor.IsValid())
	{
		return TargetActor.Get();
	}

	return nullptr;
}

FTransform FCombatTarget::GetInitialTransform() const
{
	// Actor类型返回的时这个Target结构体创建时目标Actor的Transform快照
	// Point类型返回的就是这个点的位置
	// Direction类型返回的是零位置处的朝向Transform
	return FTransform(InitialRotation, InitialLocation);
}

bool FCombatTarget::HasLocation() const
{
	switch (Type)
	{
	case ECombatTargetResultType::Actor:
		return TargetActor.IsValid();
	case ECombatTargetResultType::Point:
		return true;
	default:
		return false;
	}
}

FVector FCombatTarget::GetLocation() const
{
	if (!HasLocation())
	{
		return FVector::ZeroVector;
	}

	switch (Type)
	{
	case ECombatTargetResultType::Actor:
		if (bProjectToGround)
		{
			PerformGroundProjection();
			return ProjectedLocation;
		}

		return TargetActor.IsValid() ? TargetActor->GetActorLocation() : FVector::ZeroVector;
	case ECombatTargetResultType::Point:
		return InitialLocation;
	default:
		return FVector::ZeroVector;
	}
}

bool FCombatTarget::HasDirection() const
{
	return IsValid();
}

FVector FCombatTarget::GetDirection() const
{
	if (!HasDirection())
	{
		return FVector::ZeroVector;
	}

	switch (Type)
	{
	case ECombatTargetResultType::Actor:
		if (bProjectToGround)
		{
			PerformGroundProjection();
			return ProjectedRotation.GetForwardVector();
		}

		return TargetActor.IsValid() ? TargetActor->GetActorForwardVector() : FVector::ZeroVector;
	case ECombatTargetResultType::Point:
	case ECombatTargetResultType::Direction:
		return InitialRotation.RotateVector(FVector::ForwardVector);
	default:
		return FVector::ZeroVector;
	}
}

void FCombatTarget::SetProjectToGround(bool Enable)
{
	if (Type != ECombatTargetResultType::Actor)
	{
		return;
	}

	bProjectToGround = Enable;
	PerformGroundProjection();
}

void FCombatTarget::PerformGroundProjection() const
{
	if (ProjectedFrame == GFrameNumber)
	{
		return;
	}

	ProjectedFrame = GFrameNumber;
	if (!TargetActor.IsValid())
	{
		return;
	}

	// 默认数据
	ProjectedLocation = TargetActor->GetActorLocation();
	ProjectedRotation = TargetActor->GetActorQuat();

	const UWorld* World = TargetActor->GetWorld();
	if (!World)
	{
		return;
	}

	const UCombatTargetingSetting* Config = GetDefault<UCombatTargetingSetting>();

	FHitResult Hit;
	const FVector TraceStartLocation = TargetActor->GetActorLocation();
	const FVector TraceEndLocation = TraceStartLocation - FVector::UpVector * Config->MaxGroundCheckDistance;
	if (World->LineTraceSingleByChannel(Hit, TraceStartLocation, TraceEndLocation, Config->GroundCollisionChannel))
	{
		ProjectedLocation = Hit.ImpactPoint;

		FVector ProjectedDirection = TargetActor->GetActorForwardVector();
		ProjectedDirection -= (ProjectedDirection | Hit.ImpactNormal) * Hit.ImpactNormal;
		ProjectedRotation = FRotationMatrix::MakeFromX(ProjectedDirection).ToQuat();
	}
}

bool FCombatTarget::NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess)
{
	uint8 ProjectToGroundValue = !!bProjectToGround;
	Ar.SerializeBits(&ProjectToGroundValue, 1);
	bProjectToGround = ProjectToGroundValue;

	Ar << InitialLocation;
	Ar << InitialRotation;

	uint8 HasValidActor = TargetActor != nullptr ? 1 : 0;
	Ar.SerializeBits(&HasValidActor, 1);
	if (HasValidActor & 1)
	{
		Ar << TargetActor;
	}

	uint8 TypeValue = StaticCast<uint8>(Type);
	// 现在只有4个枚举, 后续扩展数量不大的话, 用3个Bit就够了(最多支持8个枚举)
	Ar.SerializeBits(&TypeValue, 3);
	if (Ar.IsLoading())
	{
		Type = StaticCast<ECombatTargetResultType>(TypeValue);
	}

	bOutSuccess = true;
	return true;
}
