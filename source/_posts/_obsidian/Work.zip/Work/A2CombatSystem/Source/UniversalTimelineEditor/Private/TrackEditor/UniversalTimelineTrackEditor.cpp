// Fill out your copyright notice in the Description page of Project Settings.


#include "TrackEditor/UniversalTimelineTrackEditor.h"

#include "SequencerSectionPainter.h"
#include "SequencerUtilities.h"
#include "UniversalTimelineEditor.h"
#include "LevelSequence/UniversalTimelineSection.h"
#include "LevelSequence/UniversalTimelineTrack.h"
#include "GameDefine.h"

FUniversalTimelineTrackEditor::FUniversalTimelineTrackEditor(const TSharedRef<ISequencer>& InSequencer)
	: FMovieSceneTrackEditor(InSequencer)
{
}

FUniversalTimelineTrackEditor::~FUniversalTimelineTrackEditor()
{
}

bool FUniversalTimelineTrackEditor::SupportsType(TSubclassOf<UMovieSceneTrack> Type) const
{
	return Type == UUniversalTimelineTrack::StaticClass();
}

void FUniversalTimelineTrackEditor::BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	TMap<FString, TArray<UClass*>> SectionEntryMap;
	for (TObjectIterator<UClass> ClassIter; ClassIter; ++ClassIter)
	{
		if (!ClassIter->IsChildOf(UUniversalTimelineSection::StaticClass()) ||
			ClassIter->HasAnyClassFlags(CLASS_Abstract | CLASS_Deprecated))
		{
			continue;
		}

		if (!CheckSectionObjectBindingRequirements(*ClassIter, ObjectBindings, ObjectClass))
		{
			continue;
		}

		FString Category = GetSectionCategory(*ClassIter);
		TArray<UClass*>& CategoryEntry = SectionEntryMap.FindOrAdd(Category);
		CategoryEntry.Add(*ClassIter);
	}

	for (const auto& Pair : SectionEntryMap)
	{
		const FString& Category = Pair.Key;
		const TArray<UClass*>& Entries = Pair.Value;

		MenuBuilder.AddSubMenu(
			FText::FromString(Category),
			FText::FromString(Category),
			FNewMenuDelegate::CreateRaw(this, &FUniversalTimelineTrackEditor::BuildObjectBindingTrackSubMenu, Entries, ObjectBindings, ObjectClass),
			false,
			FUniversalTimelineEditorModule::Get().GetTrackSubMenuIcon(Category)
		);
	}
}

void FUniversalTimelineTrackEditor::BuildAddTrackMenu(FMenuBuilder& MenuBuilder)
{
	TMap<FString, TArray<UClass*>> SectionEntryMap;

	for (TObjectIterator<UClass> ClassIter; ClassIter; ++ClassIter)
	{
		if (!ClassIter->IsChildOf(UUniversalTimelineSection::StaticClass()) ||
			ClassIter->HasAnyClassFlags(CLASS_Abstract | CLASS_Deprecated))
		{
			continue;
		}

		if (IsSectionRequiresObjectBinding(*ClassIter))
		{
			continue;
		}

		FString Category = GetSectionCategory(*ClassIter);
		TArray<UClass*>& CategoryEntry = SectionEntryMap.FindOrAdd(Category);
		CategoryEntry.Add(*ClassIter);
	}

	for (const auto& Pair : SectionEntryMap)
	{
		const FString& Category = Pair.Key;
		const TArray<UClass*>& Entries = Pair.Value;

		MenuBuilder.AddSubMenu(
			FText::FromString(Category),
			FText::FromString(Category),
			FNewMenuDelegate::CreateRaw(this, &FUniversalTimelineTrackEditor::BuildAddTrackSubMenu, Entries),
			false,
			FUniversalTimelineEditorModule::Get().GetTrackSubMenuIcon(Category)
		);
	}
}

TSharedPtr<SWidget> FUniversalTimelineTrackEditor::BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params)
{
	UUniversalTimelineTrack* TimelineTrack = Cast<UUniversalTimelineTrack>(Track);
	if (!TimelineTrack)
	{
		return nullptr;
	}

	TSubclassOf<UUniversalTimelineSection> MainSectionClass = TimelineTrack->GetMainSectionClass();
	if (!MainSectionClass || MainSectionClass->HasAnyClassFlags(CLASS_Abstract | CLASS_Deprecated))
	{
		return nullptr;
	}

	FUniversalTimelineSectionEditorCustomization* EditorCustomization = FUniversalTimelineEditorModule::Get().GetSectionCustomization(TimelineTrack->GetMainSectionClass());
	if (EditorCustomization)
	{
		return EditorCustomization->BuildOutlinerEditWidget(this, ObjectBinding, Track, Params);
	}

	// 没有自定义的WidgetBuilder返回默认的
	const TArray<UMovieSceneSection*>& AllSections = TimelineTrack->GetAllSections();
	const bool ContainsMainSection = AllSections.ContainsByPredicate([MainSectionClass](const UMovieSceneSection* Section)
	{
		return Section->IsA(MainSectionClass);
	});

	if (!ContainsMainSection || !TimelineTrack->HasSubSection())
	{
		return SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			.AutoWidth()
			.VAlign(VAlign_Center)
			[
				FSequencerUtilities::MakeAddButton(
					FText::FromString("Add Section"),
					FOnClicked::CreateRaw(this, &FUniversalTimelineTrackEditor::OnCreateNewSection, Track),
					Params.NodeIsHovered,
					GetSequencer())
			];
	}

	return SNew(SHorizontalBox)
		+ SHorizontalBox::Slot()
		.AutoWidth()
		.VAlign(VAlign_Center)
		[
			FSequencerUtilities::MakeAddButton(
				FText::FromString("Add Sub Section"),
				FOnGetContent::CreateLambda([this, TimelineTrack]()
				{
					FMenuBuilder MenuBuilder(true, nullptr);
					BuildAddSubSectionMenu(MenuBuilder, TimelineTrack);
					return MenuBuilder.MakeWidget();
				}),
				Params.NodeIsHovered,
				GetSequencer())
		];
}

TSharedRef<ISequencerSection> FUniversalTimelineTrackEditor::MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding)
{
	const UUniversalTimelineTrack* TimelineTrack = Cast<UUniversalTimelineTrack>(&Track);
	if (TimelineTrack && TimelineTrack->GetMainSectionClass())
	{
		FUniversalTimelineSectionEditorCustomization* EditorCustomization = FUniversalTimelineEditorModule::Get().GetSectionCustomization(TimelineTrack->GetMainSectionClass());
		if (EditorCustomization)
		{
			return EditorCustomization->MakeSectionInterface(this, SectionObject, Track, ObjectBinding);
		}
	}

	return MakeShared<FEnhancedAbilityEditorSection>(SectionObject, GetSequencer());
}

TSharedRef<ISequencerTrackEditor> FUniversalTimelineTrackEditor::CreateTrackEditor(TSharedRef<ISequencer> OwningSequencer)
{
	return MakeShared<FUniversalTimelineTrackEditor>(OwningSequencer);
}

uint32 FUniversalTimelineTrackEditor::GetSequencerTrackEditorType() const
{
	return (uint32)SequencerTrackEditorType_Behavior;
}

void FUniversalTimelineTrackEditor::BuildAddTrackSubMenu(FMenuBuilder& MenuBuilder, TArray<UClass*> Entries)
{
	for (UClass* Entry : Entries)
	{
		if (!Entry->IsChildOf(UUniversalTimelineSection::StaticClass()) || Entry->HasAnyClassFlags(CLASS_Abstract | CLASS_Deprecated))
		{
			continue;
		}

		const FText MenuLabel = Entry->GetDisplayNameText();
		const FText MenuToolTip = Entry->GetToolTipText();

		MenuBuilder.AddMenuEntry(
			MenuLabel,
			MenuToolTip,
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateRaw(this, &FUniversalTimelineTrackEditor::OnCreateNewTrack, Entry),
				FCanExecuteAction::CreateRaw(this, &FUniversalTimelineTrackEditor::CanCreateNewTrack, Entry)
			)
		);
	}
}

void FUniversalTimelineTrackEditor::BuildAddSubSectionMenu(FMenuBuilder& MenuBuilder, UUniversalTimelineTrack* TimelineTrack)
{
	if (!TimelineTrack)
	{
		return;
	}

	TArray<TSubclassOf<UUniversalTimelineSubSection>> SubSectionClasses = TimelineTrack->GetSubSectionClasses();
	for (TSubclassOf<UUniversalTimelineSubSection> Entry : SubSectionClasses)
	{
		const FText MenuLabel = Entry->GetDisplayNameText();
		const FText MenuToolTip = Entry->GetToolTipText();

		MenuBuilder.AddMenuEntry(
			MenuLabel,
			MenuToolTip,
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateRaw(this, &FUniversalTimelineTrackEditor::OnAddSubSectionToTrack, Entry, TimelineTrack)
			)
		);
	}
}

// ReSharper disable once CppMemberFunctionMayBeConst
// ReSharper disable once CppParameterMayBeConstPtrOrRef
bool FUniversalTimelineTrackEditor::CanCreateNewTrack(UClass* SectionClass)
{
	if (!ensure(SectionClass->IsChildOf(UUniversalTimelineSection::StaticClass())))
	{
		return false;
	}

	const UMovieScene* FocusedMovieScene = GetFocusedMovieScene();
	if (!FocusedMovieScene)
	{
		return false;
	}

	return true;
}

// ReSharper disable once CppMemberFunctionMayBeConst
void FUniversalTimelineTrackEditor::OnCreateNewTrack(UClass* SectionClass)
{
	UMovieScene* FocusedMovieScene = GetFocusedMovieScene();
	check(FocusedMovieScene);

	FocusedMovieScene->Modify();

	const FScopedTransaction Transaction(SectionClass->GetDisplayNameText());

	// ReSharper disable once CppLocalVariableMayBeConst

	UUniversalTimelineTrack* NewTrack = NewObject<UUniversalTimelineTrack>(FocusedMovieScene, NAME_None, RF_Transactional);
	check(NewTrack);

	NewTrack->Setup(SectionClass);

#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >= 2
	FocusedMovieScene->AddGivenTrack(NewTrack);
#else
	FocusedMovieScene->AddGivenMasterTrack(NewTrack);
#endif

	GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
}

void FUniversalTimelineTrackEditor::OnAddSubSectionToTrack(TSubclassOf<UUniversalTimelineSubSection> SubSectionClass, UUniversalTimelineTrack* TimelineTrack)
{
	if (ensure(TimelineTrack))
	{
		AnimatablePropertyChanged(FOnKeyProperty::CreateRaw(this, &FUniversalTimelineTrackEditor::AddSubSectionInternal, TimelineTrack, SubSectionClass));
	}
}

// ReSharper disable once CppPassValueParameterByConstReference
void FUniversalTimelineTrackEditor::BuildObjectBindingTrackSubMenu(FMenuBuilder& MenuBuilder, TArray<UClass*> Entries, TArray<FGuid> ObjectBindings, const UClass* ObjectClass)
{
	for (UClass* Entry : Entries)
	{
		if (!Entry->IsChildOf(UUniversalTimelineSection::StaticClass()) ||
			Entry->HasAnyClassFlags(CLASS_Abstract | CLASS_Deprecated))
		{
			continue;
		}

		const FText MenuLabel = Entry->GetDisplayNameText();
		const FText MenuToolTip = Entry->GetToolTipText();
		MenuBuilder.AddMenuEntry(
			MenuLabel,
			MenuToolTip,
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateRaw(this, &FUniversalTimelineTrackEditor::OnCreateObjectBindingTrack, Entry, ObjectBindings, ObjectClass),
				FCanExecuteAction::CreateRaw(this, &FUniversalTimelineTrackEditor::CanCreateObjectBindingTrack, Entry, ObjectBindings, ObjectClass)
			)
		);
	}
}

// ReSharper disable once CppMemberFunctionMayBeConst
// ReSharper disable once CppPassValueParameterByConstReference
bool FUniversalTimelineTrackEditor::CanCreateObjectBindingTrack(UClass* SectionClass, TArray<FGuid> ObjectBindings, const UClass* ObjectClass)
{
	if (ObjectBindings.IsEmpty())
	{
		return false;
	}

	if (!ensure(SectionClass->IsChildOf(UUniversalTimelineSection::StaticClass())))
	{
		return false;
	}

	const UMovieScene* FocusedMovieScene = GetFocusedMovieScene();
	if (!FocusedMovieScene)
	{
		return false;
	}

#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >= 2
	UMovieSceneTrack* const* MovieSceneTrack = FocusedMovieScene->GetTracks().FindByPredicate(
#else
	UMovieSceneTrack* const* MovieSceneTrack = FocusedMovieScene->GetMasterTracks().FindByPredicate(
#endif
		[SectionClass](UMovieSceneTrack* Track)
		{
			const UUniversalTimelineTrack* SkillActionTrack = Cast<UUniversalTimelineTrack>(Track);
			return SkillActionTrack && SkillActionTrack->GetMainSectionClass() == SectionClass;
		});

	if (MovieSceneTrack && *MovieSceneTrack)
	{
		return false;
	}

	return true;
}

// ReSharper disable once CppMemberFunctionMayBeConst
void FUniversalTimelineTrackEditor::OnCreateObjectBindingTrack(UClass* SectionClass, TArray<FGuid> ObjectBindings, const UClass* ObjectClass)
{
	UMovieScene* FocusedMovieScene = GetFocusedMovieScene();
	check(FocusedMovieScene);

	FocusedMovieScene->Modify();

	const FScopedTransaction Transaction(SectionClass->GetDisplayNameText());

	// ReSharper disable once CppLocalVariableMayBeConst

	UUniversalTimelineTrack* NewTrack = NewObject<UUniversalTimelineTrack>(FocusedMovieScene, NAME_None, RF_Transactional);
	check(NewTrack);

	NewTrack->Setup(SectionClass);

#if ENGINE_MAJOR_VERSION >= 5 && ENGINE_MINOR_VERSION >= 2
	FocusedMovieScene->AddGivenTrack(NewTrack);
#else
	FocusedMovieScene->AddGivenTrack(NewTrack, ObjectBindings[0]);
#endif

	GetSequencer()->NotifyMovieSceneDataChanged(EMovieSceneDataChangeType::MovieSceneStructureItemAdded);
}

FString FUniversalTimelineTrackEditor::GetSectionCategory(const UClass* SectionClass)
{
	FString Category = TEXT("Universal Track");

	while (SectionClass->IsChildOf(UUniversalTimelineSection::StaticClass()))
	{
		if (SectionClass->HasMetaData(TEXT("Category")))
		{
			Category = SectionClass->GetMetaData(TEXT("Category"));
			break;
		}

		SectionClass = SectionClass->GetSuperClass();
	}

	return Category;
}

bool FUniversalTimelineTrackEditor::IsSectionRequiresObjectBinding(const UClass* SectionClass)
{
	return false;
}

bool FUniversalTimelineTrackEditor::CheckSectionObjectBindingRequirements(const UClass* SectionClass, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass)
{
	return true;
}

FReply FUniversalTimelineTrackEditor::OnCreateNewSection(UMovieSceneTrack* Track)
{
	UUniversalTimelineTrack* UniversalTimelineTrack = Cast<UUniversalTimelineTrack>(Track);
	if (ensure(UniversalTimelineTrack))
	{
		AnimatablePropertyChanged(FOnKeyProperty::CreateRaw(this, &FUniversalTimelineTrackEditor::AddMasterSectionInternal, UniversalTimelineTrack));
	}

	return FReply::Handled();
}

FKeyPropertyResult FUniversalTimelineTrackEditor::AddMasterSectionInternal(FFrameNumber KeyTime, UUniversalTimelineTrack* Track)
{
	Track->Modify();

	FKeyPropertyResult KeyPropertyResult;

	if (UMovieSceneSection* NewSection = Track->AddNewSection(KeyTime))
	{
		KeyPropertyResult.bTrackModified = true;
		KeyPropertyResult.SectionsCreated.Add(NewSection);
	}

	return KeyPropertyResult;
}

FKeyPropertyResult FUniversalTimelineTrackEditor::AddSubSectionInternal(FFrameNumber KeyTime, UUniversalTimelineTrack* Track, TSubclassOf<UUniversalTimelineSubSection> SubSectionClass)
{
	Track->Modify();

	FKeyPropertyResult KeyPropertyResult;

	if (UMovieSceneSection* NewSection = Track->AddSubSection(KeyTime, SubSectionClass))
	{
		KeyPropertyResult.bTrackModified = true;
		KeyPropertyResult.SectionsCreated.Add(NewSection);
	}

	return KeyPropertyResult;
}

FEnhancedAbilityEditorSection::FEnhancedAbilityEditorSection(UMovieSceneSection& InSection, const TWeakPtr<ISequencer>& InSequencer)
{
	Sequencer = InSequencer;
	Section = Cast<UUniversalTimelineSection>(&InSection);

	if (Section && Section->GetClass()->HasMetaData(TEXT("SectionHeight")))
	{
		const FString SectionHeightStr = Section->GetClass()->GetMetaData(TEXT("SectionHeight"));
		SectionHeight = FCString::Atof(*SectionHeightStr);
	}
}

FEnhancedAbilityEditorSection::~FEnhancedAbilityEditorSection()
{
}

UMovieSceneSection* FEnhancedAbilityEditorSection::GetSectionObject()
{
	return Section;
}

int32 FEnhancedAbilityEditorSection::OnPaintSection(FSequencerSectionPainter& Painter) const
{
	return Painter.PaintSectionBackground();
}

float FEnhancedAbilityEditorSection::GetSectionHeight() const
{
	return SectionHeight.IsSet() ? SectionHeight.GetValue() : ISequencerSection::GetSectionHeight();
}

FText FEnhancedAbilityEditorSection::GetSectionTitle() const
{
	return Section ? Section->GetSectionTitle() : FText();
}
