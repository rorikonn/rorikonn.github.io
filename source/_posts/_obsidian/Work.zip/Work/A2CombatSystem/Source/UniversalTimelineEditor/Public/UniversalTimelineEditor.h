﻿#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"
#include "TrackEditor/UniversalTimelineTrackEditor.h"


class IAssetTypeActions;
class UMovieSceneSection;
class ISequencerSection;
class FMovieSceneTrackEditor;
class ISequencer;
class UMovieSceneTrack;
struct FBuildEditWidgetParams;
struct FUniversalTimelineSectionEditorCustomization;

class UNIVERSALTIMELINEEDITOR_API FUniversalTimelineEditorModule : public IModuleInterface, public FNoncopyable
{
public:
	static FUniversalTimelineEditorModule& Get();

	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	void RegisterTrackSubMenuIcon(const FString& Category, const FSlateIcon& Icon);
	void UnregisterTrackSubMenuIcon(const FString& Category);

	FUniversalTimelineSectionEditorCustomization* GetSectionCustomization(const UClass* SectionClass);

	FSlateIcon GetTrackSubMenuIcon(const FString& Category) const;

private:
	void RegisterSlateStyles();
	void UnRegisterSlateStyles();
	
	void RegisterAssetTypes();
	void UnregisterAssetTypes();
	
	void RegisterSequencerTrackEditor();
	void UnregisterSequencerTrackEditor();

	void RegisterSectionCustomizations();
	void UnregisterSectionCustomizations();

	FDelegateHandle TrackEditorHandle;
	TMap<FString, FSlateIcon> TrackSubMenuIcons;

	bool bSectionCustomizationsRegistered = false;
	TArray<TUniquePtr<FUniversalTimelineSectionEditorCustomization>> SectionCustomizations;
	TArray<TSharedPtr<IAssetTypeActions>> RegisteredAssetTypeActions;
};

struct UNIVERSALTIMELINEEDITOR_API FUniversalTimelineSectionEditorCustomization
{
	UClass* SupportClass = nullptr;

	virtual ~FUniversalTimelineSectionEditorCustomization() = default;

	virtual TSharedPtr<SWidget> BuildOutlinerEditWidget(FMovieSceneTrackEditor* TrackEditor, const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params)
	{
		return TSharedPtr<SWidget>();
	}

	virtual TSharedRef<ISequencerSection> MakeSectionInterface(FMovieSceneTrackEditor* TrackEditor, UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding)
	{
		check(TrackEditor)
		return MakeShared<FEnhancedAbilityEditorSection>(SectionObject, TrackEditor->GetSequencer());
	}

protected:
	USkeleton* AcquireSkeletonFromObjectGuid(const FGuid& Guid, const TSharedPtr<ISequencer>& SequencerPtr);

public:
	struct UNIVERSALTIMELINEEDITOR_API FRegister
	{
		DECLARE_DELEGATE_RetVal(TUniquePtr<FUniversalTimelineSectionEditorCustomization>, FDelegate);

		FRegister(FDelegate Delegate);

		static TArray<FDelegate>& GetAll();
		static void RegisterAll(TArray<TUniquePtr<FUniversalTimelineSectionEditorCustomization>>& OutCustomizations);
	};
};

#define REGISTER_UNIVERSAL_TIMELINE_SECTION_WIDGET_CUSTOMIZATION(SectionClass, CustomizationClass) \
	static FUniversalTimelineSectionEditorCustomization::FRegister SectionClass##Customization(FUniversalTimelineSectionEditorCustomization::FRegister::FDelegate::CreateLambda( \
	[](){ \
		TUniquePtr<CustomizationClass> NewCustomization = MakeUnique<CustomizationClass>(); \
		NewCustomization->SupportClass = SectionClass::StaticClass(); \
		return MoveTemp(NewCustomization); \
	}))
