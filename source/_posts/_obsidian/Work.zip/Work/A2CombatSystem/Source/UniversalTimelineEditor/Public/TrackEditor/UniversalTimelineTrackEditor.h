// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "MovieSceneTrackEditor.h"

class UUniversalTimelineSubSection;
class UUniversalTimelineSection;
class UUniversalTimelineTrack;
/**
 * 
 */
class FUniversalTimelineTrackEditor : public FMovieSceneTrackEditor
{
public:
	FUniversalTimelineTrackEditor(const TSharedRef<ISequencer>& InSequencer);
	virtual ~FUniversalTimelineTrackEditor() override;

	virtual bool SupportsType(TSubclassOf<UMovieSceneTrack> Type) const override;
	virtual void BuildObjectBindingTrackMenu(FMenuBuilder& MenuBuilder, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass) override;
	virtual void BuildAddTrackMenu(FMenuBuilder& MenuBuilder) override;
	virtual TSharedPtr<SWidget> BuildOutlinerEditWidget(const FGuid& ObjectBinding, UMovieSceneTrack* Track, const FBuildEditWidgetParams& Params) override;
	virtual TSharedRef<ISequencerSection> MakeSectionInterface(UMovieSceneSection& SectionObject, UMovieSceneTrack& Track, FGuid ObjectBinding) override;
	
	static TSharedRef<ISequencerTrackEditor> CreateTrackEditor(TSharedRef<ISequencer> OwningSequencer);

	virtual uint32 GetSequencerTrackEditorType() const override;

private:
	void BuildAddTrackSubMenu(FMenuBuilder& MenuBuilder, TArray<UClass*> Entries);
	void BuildAddSubSectionMenu(FMenuBuilder& MenuBuilder, UUniversalTimelineTrack* TimelineTrack);
	bool CanCreateNewTrack(UClass* SectionClass);
	void OnCreateNewTrack(UClass* SectionClass);
	void OnAddSubSectionToTrack(TSubclassOf<UUniversalTimelineSubSection> SubSectionClass, UUniversalTimelineTrack* TimelineTrack);
	void BuildObjectBindingTrackSubMenu(FMenuBuilder& MenuBuilder, TArray<UClass*> Entries, TArray<FGuid> ObjectBindings, const UClass* ObjectClass);
	bool CanCreateObjectBindingTrack(UClass* SectionClass, TArray<FGuid> ObjectBindings, const UClass* ObjectClass);
	void OnCreateObjectBindingTrack(UClass* SectionClass, TArray<FGuid> ObjectBindings, const UClass* ObjectClass);

	FString GetSectionCategory(const UClass* SectionClass);

	bool IsSectionRequiresObjectBinding(const UClass* SectionClass);
	bool CheckSectionObjectBindingRequirements(const UClass* SectionClass, const TArray<FGuid>& ObjectBindings, const UClass* ObjectClass);

	FReply OnCreateNewSection(UMovieSceneTrack* Track);
	FKeyPropertyResult AddMasterSectionInternal(FFrameNumber KeyTime, UUniversalTimelineTrack* Track);
	FKeyPropertyResult AddSubSectionInternal(FFrameNumber KeyTime, UUniversalTimelineTrack* Track, TSubclassOf<UUniversalTimelineSubSection> SubSectionClass);
};

class FEnhancedAbilityEditorSection : public ISequencerSection, public TSharedFromThis<FEnhancedAbilityEditorSection>
{
public:
	FEnhancedAbilityEditorSection(UMovieSceneSection& InSection, const TWeakPtr<ISequencer>& InSequencer);
	virtual ~FEnhancedAbilityEditorSection() override;

	virtual UMovieSceneSection* GetSectionObject() override;
	virtual int32 OnPaintSection(FSequencerSectionPainter& Painter) const override;
	virtual float GetSectionHeight() const override;
	virtual FText GetSectionTitle() const override;

private:
	TWeakPtr<ISequencer> Sequencer;
	UUniversalTimelineSection* Section;
	TOptional<float> SectionHeight;
};
