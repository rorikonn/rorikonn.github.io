﻿using UnrealBuildTool;

public class UniversalTimelineEditor : ModuleRules
{
	public UniversalTimelineEditor(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"UniversalTimeline",
				"LevelSequence",
				"LevelSequenceEditor"
			}
		);

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"Slate",
				"UnrealEd",
				"SlateCore",
				"Sequencer",
				"MovieScene",
				"Projects",
			}
		);
	}
}