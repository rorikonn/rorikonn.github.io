﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "UniversalTimelineEditorStyle.h"

#include "Styling/SlateStyleRegistry.h"
#include "Framework/Application/SlateApplication.h"
#include "Slate/SlateGameResources.h"
#include "Interfaces/IPluginManager.h"


#define DEFAULT_FONT(...) FCoreStyle::GetDefaultFontStyle(__VA_ARGS__)
#define IMAGE_BRUSH( RelativePath, ... ) FSlateImageBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )

#if ENGINE_MAJOR_VERSION == 5
#define IMAGE_BRUSH_SVG( RelativePath, ... ) FSlateVectorImageBrush( Style->RootToContentDir( RelativePath, TEXT(".svg") ), __VA_ARGS__ )
#else
#define IMAGE_BRUSH_SVG( RelativePath, ... ) FSlateImageBrush( Style->RootToContentDir( RelativePath, TEXT(".svg") ), __VA_ARGS__ )
#endif

#define BOX_BRUSH( RelativePath, ... ) FSlateBoxBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define BORDER_BRUSH( RelativePath, ... ) FSlateBorderBrush( Style->RootToContentDir( RelativePath, TEXT(".png") ), __VA_ARGS__ )
#define TTF_FONT( RelativePath, ... ) FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".ttf") ), __VA_ARGS__ )
#define OTF_FONT( RelativePath, ... ) FSlateFontInfo( Style->RootToContentDir( RelativePath, TEXT(".otf") ), __VA_ARGS__ )

const FVector2D Icon16x16(16.0f, 16.0f);
const FVector2D Icon20x20(20.0f, 20.0f);
const FVector2D Icon40x40(40.0f, 40.0f);

TSharedPtr<FSlateStyleSet> FUniversalTimelineEditorStyle::StyleInstance = nullptr;

void FUniversalTimelineEditorStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FUniversalTimelineEditorStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

void FUniversalTimelineEditorStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

FName FUniversalTimelineEditorStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("UniversalTimelineEditorStyle"));
	return StyleSetName;
}

const ISlateStyle& FUniversalTimelineEditorStyle::Get()
{
	return *StyleInstance;
}

TSharedRef<FSlateStyleSet> FUniversalTimelineEditorStyle::Create()
{
	TSharedRef<FSlateStyleSet> Style = MakeShared<FSlateStyleSet>(GetStyleSetName());
	Style->SetContentRoot(IPluginManager::Get().FindPlugin(UE_PLUGIN_NAME)->GetBaseDir() / TEXT("Resources"));
	

	return Style;
}


TSharedPtr<FSlateStyleSet> FUniversalTimelineSequenceEditorStyle::StyleInstance = nullptr;

void FUniversalTimelineSequenceEditorStyle::Initialize()
{
	if (!StyleInstance.IsValid())
	{
		StyleInstance = Create();
		FSlateStyleRegistry::RegisterSlateStyle(*StyleInstance);
	}
}

void FUniversalTimelineSequenceEditorStyle::Shutdown()
{
	FSlateStyleRegistry::UnRegisterSlateStyle(*StyleInstance);
	ensure(StyleInstance.IsUnique());
	StyleInstance.Reset();
}

void FUniversalTimelineSequenceEditorStyle::ReloadTextures()
{
	if (FSlateApplication::IsInitialized())
	{
		FSlateApplication::Get().GetRenderer()->ReloadTextureResources();
	}
}

FName FUniversalTimelineSequenceEditorStyle::GetStyleSetName()
{
	static FName StyleSetName(TEXT("UniversalTimelineSequenceEditorStyle"));
	return StyleSetName;
}

const ISlateStyle& FUniversalTimelineSequenceEditorStyle::Get()
{
	return *StyleInstance;
}

TSharedPtr<FSlateStyleSet> FUniversalTimelineSequenceEditorStyle::GetInstance()
{
	return StyleInstance;
}

TSharedRef<FSlateStyleSet> FUniversalTimelineSequenceEditorStyle::Create()
{
	TSharedRef<FSlateStyleSet> Style = MakeShared<FSlateStyleSet>(GetStyleSetName());
	
	Style->SetContentRoot(FPaths::EnginePluginsDir() / TEXT("MovieScene/LevelSequenceEditor/Content"));
	Style->SetCoreContentRoot(FPaths::EngineContentDir() / TEXT("Slate"));

	// tab icons
	Style->Set("LevelSequenceEditor.Tabs.Sequencer", new IMAGE_BRUSH("icon_tab_sequencer_16x", Icon16x16));

	Style->Set("LevelSequenceEditor.PossessNewActor", new IMAGE_BRUSH_SVG("ActorToSequencer", Icon16x16));
	Style->Set("LevelSequenceEditor.PossessNewActor.Small", new IMAGE_BRUSH_SVG("ActorToSequencer", Icon16x16));

	Style->Set("LevelSequenceEditor.CreateNewLevelSequenceInLevel", new IMAGE_BRUSH_SVG("LevelSequence", Icon16x16));
	Style->Set("LevelSequenceEditor.CreateNewLevelSequenceInLevel.Small", new IMAGE_BRUSH_SVG("LevelSequence", Icon16x16));

	Style->Set("LevelSequenceEditor.CreateNewMasterSequenceInLevel", new IMAGE_BRUSH_SVG("MasterSequence", Icon16x16));
	Style->Set("LevelSequenceEditor.CreateNewMasterSequenceInLevel.Small", new IMAGE_BRUSH_SVG("MasterSequence", Icon16x16));

	Style->Set("LevelSequenceEditor.CinematicViewportPlayMarker", new IMAGE_BRUSH("CinematicViewportPlayMarker", FVector2D(11, 6)));
	Style->Set("LevelSequenceEditor.CinematicViewportRangeStart", new BORDER_BRUSH("CinematicViewportRangeStart", FMargin(1.f,.3f,0.f,.6f)));
	Style->Set("LevelSequenceEditor.CinematicViewportRangeEnd", new BORDER_BRUSH("CinematicViewportRangeEnd", FMargin(0.f,.3f,1.f,.6f)));

	Style->Set("LevelSequenceEditor.CinematicViewportTransportRangeKey", new IMAGE_BRUSH("CinematicViewportTransportRangeKey", FVector2D(7.f, 7.f)));

	Style->Set("FilmOverlay.DefaultThumbnail", new IMAGE_BRUSH("DefaultFilmOverlayThumbnail", FVector2D(36, 24)));

	Style->Set("FilmOverlay.Disabled", new IMAGE_BRUSH("FilmOverlay.Disabled", FVector2D(36, 24)));
	Style->Set("FilmOverlay.2x2Grid", new IMAGE_BRUSH("FilmOverlay.2x2Grid", FVector2D(36, 24)));
	Style->Set("FilmOverlay.3x3Grid", new IMAGE_BRUSH("FilmOverlay.3x3Grid", FVector2D(36, 24)));
	Style->Set("FilmOverlay.Crosshair", new IMAGE_BRUSH("FilmOverlay.Crosshair", FVector2D(36, 24)));
	Style->Set("FilmOverlay.Rabatment", new IMAGE_BRUSH("FilmOverlay.Rabatment", FVector2D(36, 24)));

	return Style;
}

#undef IMAGE_BRUSH
#undef IMAGE_BRUSH_SVG
#undef BOX_BRUSH
#undef BORDER_BRUSH
#undef TTF_FONT
#undef OTF_FONT
