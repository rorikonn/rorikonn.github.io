﻿#include "UniversalTimelineEditor.h"

#include "AssetToolsModule.h"
#include "IAssetTools.h"
#include "ISequencerModule.h"
#include "UniversalTimelineAssetTypes.h"
#include "UniversalTimelineEditorStyle.h"
#include "CustomSpawn/CustomSpawn.h"
#include "GameFramework/Character.h"
#include "TrackEditor/UniversalTimelineTrackEditor.h"

#define LOCTEXT_NAMESPACE "FUniversalTimelineEditorModule"

FUniversalTimelineEditorModule& FUniversalTimelineEditorModule::Get()
{
	return FModuleManager::LoadModuleChecked<FUniversalTimelineEditorModule>(UE_MODULE_NAME);
}

void FUniversalTimelineEditorModule::StartupModule()
{
	RegisterSlateStyles();
	RegisterAssetTypes();
	RegisterSequencerTrackEditor();
}

void FUniversalTimelineEditorModule::ShutdownModule()
{
	UnRegisterSlateStyles();
	UnregisterAssetTypes();
	UnregisterSequencerTrackEditor();
	UnregisterSectionCustomizations();
}

void FUniversalTimelineEditorModule::RegisterTrackSubMenuIcon(const FString& Category, const FSlateIcon& Icon)
{
	TrackSubMenuIcons.FindOrAdd(Category) = Icon;
}

void FUniversalTimelineEditorModule::UnregisterTrackSubMenuIcon(const FString& Category)
{
	TrackSubMenuIcons.Remove(Category);
}

FUniversalTimelineSectionEditorCustomization* FUniversalTimelineEditorModule::GetSectionCustomization(const UClass* SectionClass)
{
	if (!bSectionCustomizationsRegistered)
	{
		RegisterSectionCustomizations();
	}

	if (!SectionClass)
	{
		return nullptr;
	}

	FUniversalTimelineSectionEditorCustomization* OutCustomization = nullptr;
	for (const TUniquePtr<FUniversalTimelineSectionEditorCustomization>& Customization : SectionCustomizations)
	{
		if (!SectionClass->IsChildOf(Customization->SupportClass))
		{
			continue;
		}

		// 记录最接近SectionClass的子类
		if (!OutCustomization || Customization->SupportClass->IsChildOf(OutCustomization->SupportClass))
		{
			OutCustomization = Customization.Get();
		}
	}

	return OutCustomization;
}

FSlateIcon FUniversalTimelineEditorModule::GetTrackSubMenuIcon(const FString& Category) const
{
	if (const FSlateIcon* FoundIcon = TrackSubMenuIcons.Find(Category))
	{
		return *FoundIcon;
	}

	return FSlateIcon();
}

void FUniversalTimelineEditorModule::RegisterSlateStyles()
{
	FUniversalTimelineEditorStyle::Initialize();
	FUniversalTimelineSequenceEditorStyle::Initialize();
}

void FUniversalTimelineEditorModule::UnRegisterSlateStyles()
{
	FUniversalTimelineEditorStyle::Shutdown();
	FUniversalTimelineSequenceEditorStyle::Shutdown();
}

void FUniversalTimelineEditorModule::RegisterAssetTypes()
{
	IAssetTools& AssetTools = FModuleManager::LoadModuleChecked<FAssetToolsModule>("AssetTools").Get();
	TSharedPtr<IAssetTypeActions> UniversalTimelineAssetTypeAction = MakeShared<FUniversalTimelineSequenceAssetType>();
	AssetTools.RegisterAssetTypeActions(UniversalTimelineAssetTypeAction.ToSharedRef());
	RegisteredAssetTypeActions.Add(UniversalTimelineAssetTypeAction);
}

void FUniversalTimelineEditorModule::UnregisterAssetTypes()
{
	if (FAssetToolsModule* AssetTools = StaticCast<FAssetToolsModule*>(FModuleManager::Get().GetModule("AssetTools")))
	{
		for (const TSharedPtr<IAssetTypeActions>& AssetTypeAction : RegisteredAssetTypeActions)
		{
			AssetTools->Get().UnregisterAssetTypeActions(AssetTypeAction.ToSharedRef());
		}
	}
}

void FUniversalTimelineEditorModule::RegisterSequencerTrackEditor()
{
	ISequencerModule& SequencerModule = FModuleManager::LoadModuleChecked<ISequencerModule>(TEXT("Sequencer"));
	TrackEditorHandle = SequencerModule.RegisterTrackEditor(FOnCreateTrackEditor::CreateStatic(&FUniversalTimelineTrackEditor::CreateTrackEditor));
}

void FUniversalTimelineEditorModule::UnregisterSequencerTrackEditor()
{
	if (ISequencerModule* SequencerModule = StaticCast<ISequencerModule*>(FModuleManager::Get().GetModule("Sequencer")))
	{
		SequencerModule->UnRegisterTrackEditor(TrackEditorHandle);
		TrackEditorHandle.Reset();
	}
}

void FUniversalTimelineEditorModule::RegisterSectionCustomizations()
{
	bSectionCustomizationsRegistered = true;
	FUniversalTimelineSectionEditorCustomization::FRegister::RegisterAll(SectionCustomizations);
}

void FUniversalTimelineEditorModule::UnregisterSectionCustomizations()
{
	bSectionCustomizationsRegistered = false;
	SectionCustomizations.Empty();
}

USkeleton* FUniversalTimelineSectionEditorCustomization::AcquireSkeletonFromObjectGuid(const FGuid& Guid, const TSharedPtr<ISequencer>& SequencerPtr)
{
	UObject* BoundObject = nullptr;
	if (SequencerPtr.IsValid())
	{
		FMovieSceneSequenceIDRef TemplateID = SequencerPtr->GetFocusedTemplateID();
		const FMovieSceneEvaluationOperand Operand(TemplateID, Guid);
		const TSharedPtr<FCustomSpawn> FoundCustomSpawn = SequencerPtr->FindCustomSpawn(Operand);
		if (FoundCustomSpawn.IsValid())
		{
			AActor* RealBindActor = FoundCustomSpawn->GetRealBindActor();
			BoundObject = RealBindActor;
		}
	}

	if (BoundObject == nullptr)
	{
		BoundObject = SequencerPtr.IsValid() ? SequencerPtr->FindSpawnedObjectOrTemplate(Guid) : nullptr;
	}

	const USkeletalMeshComponent* MeshComponent = nullptr;
	if (const ACharacter* BoundCharacter = Cast<ACharacter>(BoundObject))
	{
		MeshComponent = BoundCharacter->GetMesh();
	}
	else if (const AActor* BoundActor = Cast<AActor>(BoundObject))
	{
		MeshComponent = BoundActor->FindComponentByClass<USkeletalMeshComponent>();
	}

	if (MeshComponent && MeshComponent->GetSkeletalMeshAsset())
	{
		return MeshComponent->GetSkeletalMeshAsset()->GetSkeleton();
	}

	return nullptr;
}

FUniversalTimelineSectionEditorCustomization::FRegister::FRegister(FDelegate Delegate)
{
	GetAll().Emplace(MoveTemp(Delegate));
}

TArray<FUniversalTimelineSectionEditorCustomization::FRegister::FDelegate>& FUniversalTimelineSectionEditorCustomization::FRegister::GetAll()
{
	static TArray<FDelegate> GRegisters;
	return GRegisters;
}

void FUniversalTimelineSectionEditorCustomization::FRegister::RegisterAll(TArray<TUniquePtr<FUniversalTimelineSectionEditorCustomization>>& OutCustomizations)
{
	OutCustomizations.Empty();
	const TArray<FDelegate>& AllRegisters = GetAll();
	for (const FDelegate& Register : AllRegisters)
	{
		OutCustomizations.Emplace(Register.Execute());
	}
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FUniversalTimelineEditorModule, UniversalTimelineEditor)
