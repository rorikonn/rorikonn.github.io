﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "UniversalTimelineAssetTypes.h"

#include "LevelSequenceEditorToolkit.h"
#include "UniversalTimelineEditorStyle.h"
#include "LevelSequence/UniversalTimelineSequence.h"

FText FUniversalTimelineSequenceAssetType::GetName() const
{
	return NSLOCTEXT("UniversalTimelineEditor", "AssetTypeName", "Universal Timeline");
}

UClass* FUniversalTimelineSequenceAssetType::GetSupportedClass() const
{
	return UUniversalTimelineSequence::StaticClass();
}

FColor FUniversalTimelineSequenceAssetType::GetTypeColor() const
{
	return FColor::White;
}

uint32 FUniversalTimelineSequenceAssetType::GetCategories()
{
	return EAssetTypeCategories::Gameplay;
}

const TArray<FText>& FUniversalTimelineSequenceAssetType::GetSubMenus() const
{
	static TArray<FText> SubMenus =
	{
		NSLOCTEXT("UniversalTimelineEditor", "SubMenu", "UniversalTimelineSequence"),
	};

	return SubMenus;
}

void FUniversalTimelineSequenceAssetType::OpenAssetEditor(const TArray<UObject*>& InObjects, TSharedPtr<IToolkitHost> EditWithinLevelEditor)
{
	UWorld* WorldContext = nullptr;
	for (const FWorldContext& Context : GEngine->GetWorldContexts())
	{
		if (Context.WorldType == EWorldType::Editor)
		{
			WorldContext = Context.World();
			break;
		}
	}

	if (!ensure(WorldContext))
	{
		return;
	}

	EToolkitMode::Type Mode = EditWithinLevelEditor.IsValid() ? EToolkitMode::WorldCentric : EToolkitMode::Standalone;
	for (auto ObjIt = InObjects.CreateConstIterator(); ObjIt; ++ObjIt)
	{
		ULevelSequence* LevelSequence = Cast<ULevelSequence>(*ObjIt);

		if (LevelSequence != nullptr)
		{
			// Legacy upgrade
			LevelSequence->ConvertPersistentBindingsToDefault(WorldContext);

			TSharedRef<FLevelSequenceEditorToolkit> Toolkit = MakeShared<FLevelSequenceEditorToolkit>(FUniversalTimelineSequenceEditorStyle::GetInstance().ToSharedRef());
			Toolkit->Initialize(Mode, EditWithinLevelEditor, LevelSequence);
		}
	}
}

UUniversalTimelineSequenceAssetFactory::UUniversalTimelineSequenceAssetFactory()
	: Super()
{
	bCreateNew = true;
	bEditAfterNew = true;
	SupportedClass = UUniversalTimelineSequence::StaticClass();
}

UObject* UUniversalTimelineSequenceAssetFactory::FactoryCreateNew(UClass* InClass, UObject* InParent, FName InName, EObjectFlags Flags, UObject* Context, FFeedbackContext* Warn)
{
	UUniversalTimelineSequence* SequenceAsset = NewObject<UUniversalTimelineSequence>(InParent, InName, Flags | RF_Transactional);
	SequenceAsset->Initialize();

	return SequenceAsset;
}
