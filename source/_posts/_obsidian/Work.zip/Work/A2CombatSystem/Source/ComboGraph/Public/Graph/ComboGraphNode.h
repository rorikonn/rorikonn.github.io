﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphNodeBase.h"
#include "ComboGraphRuntimeTypes.h"
#include "Engine/StreamableManager.h"
#include "ComboGraphNode.generated.h"

struct FComboGraphContext;
class UAnimationAsset;
class UAnimNotify;
class UAnimNotifyState;
class UComboGraphNode;
struct FAnimNotifyEvent;

/**
 *  Base Class for all Anim related Combo Graph nodes (montage or sequence)
 *
 *  Holds runtime properties for animation and effects / cues containers.
 */
UCLASS(Abstract)
class COMBOGRAPH_API UComboGraphNodeData : public UComboGraphNodeDataBase
{
	GENERATED_BODY()

public:
	/** Anim montage play rate */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Animation", meta = (ClampMin = "0.0"))
	float MontagePlayRate = 1.f;

	virtual UComboGraphNode* MakeRuntimeNode(TSharedPtr<FComboGraphContext> Context) const;

	/** Returns Montage property or a dynamically created Montage from Sequence */
	virtual UAnimMontage* GetMontage() const { return nullptr; }

	/** Returns underlying Anim Asset (either Montage or Sequence) */
	virtual UAnimSequenceBase* GetAnimationAsset() const { return nullptr; }

	/** Returns underlying Anim Asset Length (PlayLength) */
	virtual float GetAnimationLength() const { return -1.f; }

	/** Simple getter to return StartSection Name property on montage node (sequences will always return None) */
	virtual FName GetAnimationStartSection() const { return NAME_None; }

	/** Returns play time for a given section on a node montage (sequence will always return -1.0) */
	virtual float GetSectionLength(FName SectionName) const { return -1.f; }

	/** Returns total animation play time and subtract provided section time from the result (sequence will always return -1.0) */
	virtual float GetAnimationLengthMinusSection(FName SectionName) const { return -1.f; }

	/** Returns total animation play time and subtract section defined by StartSection name property if it is defined (sequence will always return sequence length) */
	virtual float GetAnimationLengthMinusStartSection() const { return -1.f; }

	/** Meant to be overriden by child class to update their AnimationAsset reference */
	virtual void SetAnimationAsset(UAnimationAsset* Asset)
	{
		check(false); /*Base function called*/
	}

	virtual bool SupportsAssetClass(UClass* AssetClass) { return false; }

#if WITH_EDITOR
	// These gets called from the Slate SGraphNode Widget in graphs
	virtual FText GetAnimAssetLabel() const { return FText::FromString(""); };
	virtual FText GetAnimAssetLabelTooltip() const { return FText::FromString(""); };
	virtual FText GetAnimAssetText() const { return FText::FromString(""); };
#endif
};

DECLARE_MULTICAST_DELEGATE(FComboGraphNodeEvent)

UCLASS()
class COMBOGRAPH_API UComboGraphNode : public UObject
{
	GENERATED_BODY()

public:
	virtual void Initialize(const UComboGraphNodeData* Data, TSharedPtr<FComboGraphContext> GraphContext);

	virtual bool PreActivation();
	virtual bool CommitNodeCost();

	virtual bool OnActivated();
	virtual void OnDeactivated();

	virtual void TickNode(float DeltaTime);

	template <typename T = UComboGraphNodeData>
	const T* GetData() const
	{
		return Cast<T>(ReferenceData.Get());
	}

	template <typename T = UComboGraphNodeData>
	const T& GetDataChecked() const
	{
		return *CastChecked<T>(ReferenceData.Get());
	}

	FORCEINLINE float GetRelevantTime() const
	{
		return RelevantTime;
	}

	/** 默认实现是ComboWindow结束之后可以打断, 子类可以重写 */
	virtual bool CanInterruptBy(const UComboGraphNodeData* NextNode);
	TArray<UComboGraphEdge*> GetAllEdges() const;

	void UnbindAllEvents();

	FComboGraphNodeEvent OnCompleteEvent;
	FComboGraphNodeEvent OnInterruptedEvent;
	FComboGraphNodeEvent OnCanceledEvent;

protected:
	UPROPERTY(Transient)
	TObjectPtr<const UComboGraphNodeData> ReferenceData;

	TSharedPtr<FComboGraphContext> Context;
	float RelevantTime;
};
