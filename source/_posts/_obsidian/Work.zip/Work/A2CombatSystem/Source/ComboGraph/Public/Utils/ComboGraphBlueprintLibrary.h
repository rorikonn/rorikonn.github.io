// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/BlueprintFunctionLibrary.h"
#include "ComboGraphBlueprintLibrary.generated.h"

/**
 *
 */
UCLASS()
class COMBOGRAPH_API UComboGraphBlueprintLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()
};
