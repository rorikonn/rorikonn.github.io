// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Graph/ComboGraphNodeMontage.h"

#include "ComboGraphLog.h"
#include "Animation/AnimMontage.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "AnimNotifies/ComboGraphANS_ComboWindow.h"
#include "AnimNotifies/ComboGraphAN_ComboTrigger.h"
#include "Graph/ComboGraphContext.h"
#include "Components/ComboGraphSystemComponent.h"
#include "Utils/ComboGraphUtils.h"

#define LOCTEXT_NAMESPACE "ComboGraphNodeMontage"

UComboGraphNode* UComboGraphNodeMontageData::MakeRuntimeNode(TSharedPtr<FComboGraphContext> Context) const
{
	check(Context);

	UComboGraphNode* RuntimeNode = NewObject<UComboGraphNodeMontage>(Context->GetOwner(), NAME_None, RF_Transient);
	RuntimeNode->Initialize(this, Context);

	return RuntimeNode;
}

UAnimMontage* UComboGraphNodeMontageData::GetMontage() const
{
	if (!Montage.IsValid())
	{
		Montage.LoadSynchronous();
	}

	return Montage.Get();
}

UAnimSequenceBase* UComboGraphNodeMontageData::GetAnimationAsset() const
{
	if (!Montage.IsValid())
	{
		Montage.LoadSynchronous();
	}

	return Montage.Get();
}

float UComboGraphNodeMontageData::GetAnimationLength() const
{
	if (const UAnimMontage* AnimMontage = GetMontage())
	{
		return AnimMontage->GetPlayLength();
	}

	return -1.f;
}

FName UComboGraphNodeMontageData::GetAnimationStartSection() const
{
	return StartSection;
}

float UComboGraphNodeMontageData::GetSectionLength(const FName SectionName) const
{
	const UAnimMontage* AnimMontage = GetMontage();
	if (!AnimMontage)
	{
		return -1.f;
	}

	const int32 SectionIndex = AnimMontage->GetSectionIndex(SectionName);
	if (SectionIndex == INDEX_NONE)
	{
		return -1.f;
	}

	return AnimMontage->GetSectionLength(SectionIndex);
}

float UComboGraphNodeMontageData::GetAnimationLengthMinusSection(const FName SectionName) const
{
	const float AnimationLength = GetAnimationLength();
	const float SectionLength = GetSectionLength(SectionName);
	if (SectionLength == -1.f || AnimationLength == -1.f)
	{
		return -1.f;
	}

	return AnimationLength - SectionLength;
}

float UComboGraphNodeMontageData::GetAnimationLengthMinusStartSection() const
{
	if (StartSection == NAME_None)
	{
		return GetAnimationLength();
	}

	return GetAnimationLengthMinusSection(StartSection);
}

void UComboGraphNodeMontageData::SetAnimationAsset(UAnimationAsset* Asset)
{
	if (const UAnimMontage* MontageAsset = Cast<UAnimMontage>(Asset))
	{
		Montage = MontageAsset;
	}
}

bool UComboGraphNodeMontageData::SupportsAssetClass(UClass* AssetClass)
{
	return AssetClass->IsChildOf(UAnimMontage::StaticClass());
}

FText UComboGraphNodeMontageData::GetNodeTitle() const
{
	if (!NodeTitle.IsEmpty())
	{
		return NodeTitle;
	}

	const UAnimationAsset* AnimationAsset = GetAnimationAsset();
	FText DefaultText = LOCTEXT("DefaultNodeTitle", "Combo Graph Node (Montage)");
	return AnimationAsset ? FText::FromString(AnimationAsset->GetName()) : DefaultText;
}

#if WITH_EDITOR
FText UComboGraphNodeMontageData::GetAnimAssetLabel() const
{
	return LOCTEXT("AnimAssetLabel", "Montage");
}

FText UComboGraphNodeMontageData::GetAnimAssetLabelTooltip() const
{
	return LOCTEXT("AnimAssetLabelTooltip", "Montage");
}

FText UComboGraphNodeMontageData::GetAnimAssetText() const
{
	return FText::FromString(Montage ? Montage->GetName() : TEXT("NONE"));
}

FLinearColor UComboGraphNodeMontageData::GetBackgroundColor() const
{
	return FComboGraphUtils::GetPluginProjectSettings()->MontageNodeColor;
}
#endif

bool UComboGraphNodeMontage::OnActivated()
{
	Super::OnActivated();

	check(Context.IsValid());
	check(ReferenceData);

	UAnimMontage* MontageToPlay = ReferenceData->GetMontage();
	UAnimInstance* AnimInstance = Context->GetAnimInstance();
	if (!MontageToPlay || !AnimInstance)
	{
		return false;
	}

	AnimInstance->Montage_Play(MontageToPlay, ReferenceData->MontagePlayRate);
	FAnimMontageInstance* ActivatingMontageInstance = AnimInstance->GetActiveInstanceForMontage(MontageToPlay);
	if (!ActivatingMontageInstance)
	{
		return false;
	}

	float StartTime = 0.0f;
	const float PlayLength = MontageToPlay->GetPlayLength();
	const FName StartSection = ReferenceData->GetAnimationStartSection();
	const int32 StartSectionIndex = MontageToPlay->GetSectionIndex(StartSection);
	if (MontageToPlay->IsValidSectionIndex(StartSectionIndex))
	{
		float EndTime;
		MontageToPlay->GetSectionStartAndEndTime(StartSectionIndex, StartTime, EndTime);

		ActivatingMontageInstance->SetPosition(StartTime);
	}

	FOnMontageBlendingOutStarted BlendingOutDelegate = FOnMontageBlendingOutStarted::CreateUObject(this, &ThisClass::OnMontageBlendingOut);
	ActivatingMontageInstance->OnMontageBlendingOutStarted = MoveTemp(BlendingOutDelegate);

	FOnMontageEnded MontageEndedDelegate = FOnMontageEnded::CreateUObject(this, &ThisClass::OnMontageEnded);
	ActivatingMontageInstance->OnMontageEnded = MoveTemp(MontageEndedDelegate);

	bMontageContainsComboWindowSetup = false;
	for (const FAnimNotifyEvent& NotifyEvent : MontageToPlay->Notifies)
	{
		if (NotifyEvent.NotifyStateClass && NotifyEvent.NotifyStateClass->GetClass() == UComboGraphANS_ComboWindow::StaticClass())
		{
			ComboStartTime = NotifyEvent.GetTriggerTime();
			ComboEndTime = NotifyEvent.GetEndTriggerTime();
			bMontageContainsComboWindowSetup = true;
			break;
		}
	}

	ElapsedTime = StartTime;

	CG_RUNTIME_LOG(VeryVerbose, TEXT("UComboGraphNodeMontage::OnActivate with Montage: %s, ComboWindow: %f - %f, Elapsed: %f at Frame: %u"),
	               *GetNameSafe(MontageToPlay), ComboStartTime, ComboEndTime, ElapsedTime, GFrameNumber);

	if (!bMontageContainsComboWindowSetup)
	{
		ComboStartTime = PlayLength * 0.25f;
		ComboEndTime = PlayLength * 0.75f;
		CheckComboWindow(-1.0f, ElapsedTime);
	}

	return true;
}

void UComboGraphNodeMontage::OnDeactivated()
{
	Super::OnDeactivated();

	check(Context.IsValid());
	check(ReferenceData);

	const UAnimMontage* MontageToPlay = ReferenceData->GetMontage();
	if (UAnimInstance* AnimInstance = Context->GetAnimInstance())
	{
		FAnimMontageInstance* MontageInstance = AnimInstance->GetActiveInstanceForMontage(MontageToPlay);
		if (MontageInstance)
		{
			if (MontageInstance->OnMontageBlendingOutStarted.IsBoundToObject(this))
			{
				MontageInstance->OnMontageBlendingOutStarted.Unbind();
			}

			if (MontageInstance->OnMontageEnded.IsBoundToObject(this))
			{
				MontageInstance->OnMontageEnded.Unbind();
			}

			AnimInstance->Montage_Stop(MontageToPlay->BlendOut.GetBlendTime(), MontageToPlay);
		}
	}
}

void UComboGraphNodeMontage::TickNode(float DeltaTime)
{
	Super::TickNode(DeltaTime);

	const float LastElapsedTime = ElapsedTime;
	ElapsedTime += DeltaTime;

	if (!bMontageContainsComboWindowSetup)
	{
		CheckComboWindow(LastElapsedTime, ElapsedTime);
	}
}

// ReSharper disable once CppParameterMayBeConstPtrOrRef
void UComboGraphNodeMontage::OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted) const
{
	check(ReferenceData);
	const UAnimMontage* MontageToPlay = ReferenceData->GetMontage();
	if (!MontageToPlay || Montage != MontageToPlay)
	{
		return;
	}

	const UAnimInstance* AnimInstance = Context->GetAnimInstance();
	if (!AnimInstance)
	{
		return;
	}

	if (AnimInstance->GetCurrentActiveMontage() != MontageToPlay)
	{
		return;
	}

	if (bInterrupted)
	{
		OnInterruptedEvent.Broadcast();
	}
}

// ReSharper disable once CppParameterMayBeConstPtrOrRef
void UComboGraphNodeMontage::OnMontageEnded(UAnimMontage* Montage, bool bInterrupted) const
{
	check(ReferenceData);
	const UAnimMontage* MontageToPlay = ReferenceData->GetMontage();
	if (!MontageToPlay || Montage != MontageToPlay)
	{
		return;
	}

	if (bInterrupted)
	{
		OnInterruptedEvent.Broadcast();
	}
	else
	{
		OnCompleteEvent.Broadcast();
	}
}

void UComboGraphNodeMontage::CheckComboWindow(float StartTime, float EndTime) const
{
	if (!Context->GetOwner())
	{
		return;
	}

	if (StartTime < ComboStartTime && EndTime >= ComboStartTime && EndTime < ComboEndTime)
	{
		FComboGraphEventPayload_ComboWindow Payload;
		Payload.RelevantSequence = ReferenceData->GetMontage();

		Context->GetOwner()->HandleComboGraphEvent(FComboGraphNativeTags::ComboBeginEvent, &Payload);
	}
	else if (StartTime >= ComboStartTime && StartTime < ComboEndTime && EndTime >= ComboEndTime)
	{
		FComboGraphEventPayload_ComboWindow Payload;
		Payload.RelevantSequence = ReferenceData->GetMontage();

		Context->GetOwner()->HandleComboGraphEvent(FComboGraphNativeTags::ComboEndEvent, &Payload);
	}
}

#undef LOCTEXT_NAMESPACE
