// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraph.h"
#include "ComboGraphNodeBase.generated.h"

class UInputAction;
class UComboGraphEdge;

/**
 *  Base Class for all Combo Graph nodes (Edges, Anim based and conduit)
 *
 *  Holds information and API related to debug states.
 */
UCLASS()
class COMBOGRAPH_API UComboGraphNodeDataBase : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "Combo Graph")
	FComboGraphNodeID ID;

	/** When not empty, will draw title with specified value instead of using Animation Asset name (Montage or Sequence) */
	UPROPERTY(EditDefaultsOnly, Category = "Combo Graph")
	FText NodeTitle;

	UPROPERTY()
	TArray<FComboGraphNodeReference> ChildrenNodes;

	UPROPERTY()
	TArray<FComboGraphNodeReference> ParentNodes;

	UPROPERTY(Instanced, EditDefaultsOnly, Category = "Combo Graph")
	TMap<FComboGraphNodeID, TObjectPtr<UComboGraphEdge>> Edges;

	/** Simply returns the value of NodeTitle, and is overridden in child classes to fallback to animation asset name if NodeTitle is empty. */
	virtual FText GetNodeTitle() const;

	virtual TArray<UComboGraphEdge*> GetAllEdges() const;
	virtual UComboGraphEdge* GetEdge(FComboGraphNodeID ChildNodeID) const;
	UComboGraphEdge* GetEdge(const UComboGraphNodeDataBase* ChildNode) const;

	UFUNCTION(BlueprintCallable, Category = "Combo Graph")
	virtual bool IsLeafNode() const;

	/** Checks all child nodes and the edge they're connected with and return the */
	virtual bool GetEdgeWithInput(const FComboGraphInput& Input, TArray<const UComboGraphEdge*>& OutEdges) const;

	/** Returns whether the class is not a direct descendant of native node classes, indicating it's implemented in BP */
	bool IsComboSubclassedInBlueprint() const;

#if WITH_EDITORONLY_DATA
	/**
	 * ContextMenuName is used in Combo Graph to generate context menu items (upon right click in the graph to add new nodes)
	 *
	 * Split up ContextMenuName by "|" to create a top category if there is more than one level.
	 *
	 * You can leave this empty to exclude this class from being considered when Combo Graph generates a context menu.
	 */
	UPROPERTY(EditDefaultsOnly, Category = "Combo Graph", meta = (HideInComboGraphDetailsPanel))
	FText ContextMenuName;

	/** Set it to false to prevent context menu in graph to include the BP Class name */
	UPROPERTY(EditDefaultsOnly, Category = "Combo Graph", meta = (HideInComboGraphDetailsPanel))
	bool bIncludeClassNameInContextMenu = true;
#endif

#if WITH_EDITOR
	virtual bool IsNameEditable() const;

	virtual void SetNodeTitle(const FText& NewTitle);

	virtual FLinearColor GetBackgroundColor() const;

	virtual bool CanCreateConnection(UComboGraphNodeDataBase* Other, FText& ErrorMessage);
	virtual bool CanCreateConnectionTo(UComboGraphNodeDataBase* Other, int32 NumberOfChildrenNodes, FText& ErrorMessage);
	virtual bool CanCreateConnectionFrom(UComboGraphNodeDataBase* Other, int32 NumberOfParentNodes, FText& ErrorMessage);
#endif
};


template<>
struct TDataArchiveInfo<UComboGraphNodeDataBase> : TDataArchiveInfoBase<UComboGraphNodeDataBase>
{
	static FComboGraphNodeID& GetKeyFromData(UComboGraphNodeDataBase* Data)
	{
		static FComboGraphNodeID InvalidKey;
		return Data ? Data->ID : InvalidKey;
	}

	static FString GetArchiveTableName()
	{
		return TEXT("GraphNode");
	}

	static FString GetArchiveCategory(const UComboGraphNodeDataBase* Data)
	{
		return Data ? Data->ID.Owner.ToString() : TEXT("Invalid");
	}
};

