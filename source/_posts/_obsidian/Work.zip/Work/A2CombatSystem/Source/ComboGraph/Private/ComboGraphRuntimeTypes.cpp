﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#include "ComboGraphRuntimeTypes.h"

#include "Graph/ComboGraphNodeBase.h"

UE_DEFINE_GAMEPLAY_TAG(FComboGraphNativeTags::ComboBeginEvent, TEXT("ComboGraph.Event.ComboBegin"))
UE_DEFINE_GAMEPLAY_TAG(FComboGraphNativeTags::ComboEndEvent, TEXT("ComboGraph.Event.ComboEnd"))
UE_DEFINE_GAMEPLAY_TAG(FComboGraphNativeTags::ComboTriggerEvent, TEXT("ComboGraph.Event.ComboTrigger"))
UE_DEFINE_GAMEPLAY_TAG(FComboGraphNativeTags::ComboTriggerEndEvent, TEXT("ComboGraph.Event.ComboTriggerEnd"))
UE_DEFINE_GAMEPLAY_TAG(FComboGraphNativeTags::BecomeInterruptableEvent, TEXT("ComboGraph.Event.BecomeInterruptable"))

UE_DEFINE_GAMEPLAY_TAG(FComboGraphNativeTags::DefaultComboTrigger, TEXT("ComboGraph.Trigger.Default"))


FComboGraphID::FComboGraphID()
	: ID(0)
{
}

FComboGraphID::FComboGraphID(int32 ID)
	: ID(ID)
{
}

FComboGraphNodeID::FComboGraphNodeID()
	: ID(0)
{
}

FComboGraphNodeID::FComboGraphNodeID(FComboGraphID Owner, int32 Index)
	: Owner(Owner),
	  ID(Index)
{
}

FComboGraphNodeReference::FComboGraphNodeReference(const UComboGraphNodeDataBase* Data)
{
	ID = Data ? Data->ID : FComboGraphNodeID();
}

UComboGraphNodeDataBase* FComboGraphNodeReference::Get()
{
#if UE_BUILD_SHIPPING || UE_BUILD_TEST
	if (Object.IsValid())
	{
		return Object.Get();
	}
#endif


	Object = FDataArchiveManager::Find<UComboGraphNodeDataBase>(ID);
	return Object.Get();
}

const UComboGraphNodeDataBase* FComboGraphNodeReference::Get() const
{
#if UE_BUILD_SHIPPING || UE_BUILD_TEST
	if (Object.IsValid())
	{
		return Object.Get();
	}
#endif

	Object = FDataArchiveManager::Find<UComboGraphNodeDataBase>(ID);
	return Object.Get();
}

FComboGraphNodeReference& FComboGraphNodeReference::operator=(const FComboGraphNodeID& Other)
{
	if (ID != Other)
	{
		Object.Reset();
		ID = Other;
	}

	return *this;
}

FComboGraphNodeReference& FComboGraphNodeReference::operator=(const UComboGraphNodeDataBase* OtherData)
{
	if (!OtherData)
	{
		return *this;
	}

	const FComboGraphNodeID Other = OtherData->ID;
	if (ID != Other)
	{
		Object.Reset();
		ID = Other;
	}

	return *this;
}

UComboGraphNodeDataBase* FComboGraphNodeReference::operator->()
{
	return Get();
}

const UComboGraphNodeDataBase* FComboGraphNodeReference::operator->() const
{
	return Get();
}

UComboGraphNodeDataBase* FComboGraphNodeReference::operator*()
{
	return Get();
}

const UComboGraphNodeDataBase* FComboGraphNodeReference::operator*() const
{
	return Get();
}

FComboGraphNodeReference::operator bool() const
{
	return Get() != nullptr;
}

bool FComboGraphNodeReference::operator!() const
{
	return Get() == nullptr;
}
