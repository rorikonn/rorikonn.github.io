﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Graph/ComboGraphNode.h"

#include "Animation/AnimSequenceBase.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "Components/ComboGraphSystemComponent.h"
#include "Graph/ComboGraphContext.h"
#include "Graph/ComboGraphEdge.h"
#include "Sound/SoundBase.h"

UComboGraphNode* UComboGraphNodeData::MakeRuntimeNode(TSharedPtr<FComboGraphContext> Context) const
{
	check(Context);

	UComboGraphNode* RuntimeNode = NewObject<UComboGraphNode>(Context->GetOwner(), NAME_None, RF_Transient);
	RuntimeNode->Initialize(this, Context);

	return RuntimeNode;
}

void UComboGraphNode::Initialize(const UComboGraphNodeData* Data, TSharedPtr<FComboGraphContext> GraphContext)
{
	ReferenceData = Data;
	Context = MoveTemp(GraphContext);
}

bool UComboGraphNode::PreActivation()
{
	return true;
}

bool UComboGraphNode::CommitNodeCost()
{
	return true;
}

bool UComboGraphNode::OnActivated()
{
	RelevantTime = 0.0f;
	return true;
}

void UComboGraphNode::OnDeactivated()
{
}

void UComboGraphNode::TickNode(float DeltaTime)
{
	RelevantTime += DeltaTime;
}

bool UComboGraphNode::CanInterruptBy(const UComboGraphNodeData* NextNode)
{
	return Context->IsComboWindowFinished();
}

TArray<UComboGraphEdge*> UComboGraphNode::GetAllEdges() const
{
	return ReferenceData ? ReferenceData->GetAllEdges() : TArray<UComboGraphEdge*>();
}

void UComboGraphNode::UnbindAllEvents()
{
	OnCompleteEvent.Clear();
	OnInterruptedEvent.Clear();
	OnCanceledEvent.Clear();
}
