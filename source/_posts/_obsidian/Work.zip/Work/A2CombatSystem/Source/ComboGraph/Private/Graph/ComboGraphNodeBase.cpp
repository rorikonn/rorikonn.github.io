// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Graph/ComboGraphNodeBase.h"
#include "Graph/ComboGraphEdge.h"
#include "Utils/ComboGraphUtils.h"


#define LOCTEXT_NAMESPACE "ComboGraphNode"

FText UComboGraphNodeDataBase::GetNodeTitle() const
{
	FText DefaultText = LOCTEXT("DefaultNodeTitle", "Combo Graph Node");
	return NodeTitle.IsEmpty() ? DefaultText : NodeTitle;
}

TArray<UComboGraphEdge*> UComboGraphNodeDataBase::GetAllEdges() const
{
	TArray<TObjectPtr<UComboGraphEdge>> AllEdges;
	Edges.GenerateValueArray(AllEdges);

	return AllEdges;
}

UComboGraphEdge* UComboGraphNodeDataBase::GetEdge(FComboGraphNodeID ChildNodeID) const
{
	if (const TObjectPtr<UComboGraphEdge>* FoundEdge = Edges.Find(ChildNodeID))
	{
		return FoundEdge->Get();
	}

	return nullptr;
}

UComboGraphEdge* UComboGraphNodeDataBase::GetEdge(const UComboGraphNodeDataBase* ChildNode) const
{
	if (!ChildNode)
	{
		return nullptr;
	}

	return GetEdge(ChildNode->ID);
}

bool UComboGraphNodeDataBase::IsLeafNode() const
{
	return ChildrenNodes.Num() == 0;
}

bool UComboGraphNodeDataBase::GetEdgeWithInput(const FComboGraphInput& Input, TArray<const UComboGraphEdge*>& OutEdges) const
{
	OutEdges.Empty();
	
	for (const FComboGraphNodeReference& ChildNode : ChildrenNodes)
	{
		UComboGraphEdge* Edge = GetEdge(ChildNode.Get());
		if (Edge && Edge->IsInputMatch(Input))
		{
			OutEdges.Emplace(Edge);
		}
	}

	return !OutEdges.IsEmpty();
}

bool UComboGraphNodeDataBase::IsComboSubclassedInBlueprint() const
{
	const UClass* NodeClass = GetClass();
	if (!NodeClass)
	{
		return false;
	}

	return !NodeClass->IsNative();
}

#if WITH_EDITOR
bool UComboGraphNodeDataBase::IsNameEditable() const
{
	return true;
}

void UComboGraphNodeDataBase::SetNodeTitle(const FText& NewTitle)
{
	NodeTitle = NewTitle;
}

FLinearColor UComboGraphNodeDataBase::GetBackgroundColor() const
{
	if (const UClass* Class = GetClass())
	{
		const FString ColorString = Class->GetMetaDataText(TEXT("DisplayColor")).ToString();
	
		if (!ColorString.IsEmpty())
		{
			const FRegexPattern RegexPattern(TEXT(R"(^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*$)"));
			FRegexMatcher RegexMatcher(RegexPattern, ColorString);
			if (RegexMatcher.FindNext())
			{
				const FString R = RegexMatcher.GetCaptureGroup(1);
				const FString G = RegexMatcher.GetCaptureGroup(2);
				const FString B = RegexMatcher.GetCaptureGroup(3);
				return FColor(FCString::Atoi(*R), FCString::Atoi(*G), FCString::Atoi(*B));
			}
		
			if (ColorString.Equals(TEXT("White"), ESearchCase::IgnoreCase))
				return FColor::White;
			if (ColorString.Equals(TEXT("Black"), ESearchCase::IgnoreCase))
				return FColor::Black;
			if (ColorString.Equals(TEXT("Transparent"), ESearchCase::IgnoreCase))
				return FColor::Transparent;
			if (ColorString.Equals(TEXT("Red"), ESearchCase::IgnoreCase))
				return FColor::Red;
			if (ColorString.Equals(TEXT("Green"), ESearchCase::IgnoreCase))
				return FColor::Green;
			if (ColorString.Equals(TEXT("Blue"), ESearchCase::IgnoreCase))
				return FColor::Blue;
			if (ColorString.Equals(TEXT("Yellow"), ESearchCase::IgnoreCase))
				return FColor::Yellow;
			if (ColorString.Equals(TEXT("Cyan"), ESearchCase::IgnoreCase))
				return FColor::Cyan;
			if (ColorString.Equals(TEXT("Magenta"), ESearchCase::IgnoreCase))
				return FColor::Magenta;
			if (ColorString.Equals(TEXT("Orange"), ESearchCase::IgnoreCase))
				return FColor::Orange;
			if (ColorString.Equals(TEXT("Purple"), ESearchCase::IgnoreCase))
				return FColor::Purple;
			if (ColorString.Equals(TEXT("Turquoise"), ESearchCase::IgnoreCase))
				return FColor::Turquoise;
			if (ColorString.Equals(TEXT("Silver"), ESearchCase::IgnoreCase))
				return FColor::Silver;
			if (ColorString.Equals(TEXT("Emerald"), ESearchCase::IgnoreCase))
				return FColor::Emerald;
		}
	}

	return FComboGraphUtils::GetPluginProjectSettings()->DefaultNodeColor;
}

bool UComboGraphNodeDataBase::CanCreateConnection(UComboGraphNodeDataBase* Other, FText& ErrorMessage)
{
	return true;
}

bool UComboGraphNodeDataBase::CanCreateConnectionTo(UComboGraphNodeDataBase* Other, const int32 NumberOfChildrenNodes, FText& ErrorMessage)
{
	return CanCreateConnection(Other, ErrorMessage);
}

bool UComboGraphNodeDataBase::CanCreateConnectionFrom(UComboGraphNodeDataBase* Other, const int32 NumberOfParentNodes, FText& ErrorMessage)
{
	return true;
}

#endif

#undef LOCTEXT_NAMESPACE
