// Copyright 2022 Mickael Daniel. All Rights Reserved.

#include "ComboGraphDelegates.h"

FComboGraphDelegates::FOnComboGraphStarted FComboGraphDelegates::OnComboGraphStarted;
FComboGraphDelegates::FOnComboGraphStarted FComboGraphDelegates::OnComboGraphEnded;
