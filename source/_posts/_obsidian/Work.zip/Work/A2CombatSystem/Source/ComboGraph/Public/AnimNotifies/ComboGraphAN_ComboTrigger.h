﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphRuntimeTypes.h"
#include "Animation/AnimNotifies/AnimNotify.h"
#include "ComboGraphAN_ComboTrigger.generated.h"

/** Anim notifies that sends relevant Gameplay Events on begin / end */
UCLASS(NotBlueprintable, meta = (DisplayName = "Combo Graph: Combo Trigger"))
class COMBOGRAPH_API UComboGraphAN_ComboTrigger : public UAnimNotify
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere, meta=(Categories="ComboGraph.Trigger"))
	FGameplayTag Trigger = FComboGraphNativeTags::DefaultComboTrigger;

	virtual void Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference) override;
};
