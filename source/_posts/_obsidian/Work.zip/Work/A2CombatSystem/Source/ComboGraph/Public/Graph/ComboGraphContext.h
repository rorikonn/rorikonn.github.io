﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphRuntimeTypes.h"
#include "EnhancedInputComponent.h"
#include "GameplayTagContainer.h"
#include "ComboGraphContext.generated.h"

class IGameplayTagAssetInterface;
class UComboGraphEdge;
class UComboGraphNodeEntryData;
class UComboGraphSystemComponent;
class UComboGraphData;

DECLARE_MULTICAST_DELEGATE_TwoParams(FOnReceiveInputEvent, FGameplayTag, ETriggerEvent);

/**
 * 
 */
USTRUCT()
struct COMBOGRAPH_API FComboGraphContext
{
	GENERATED_BODY()

	FComboGraphContext() = default;
	explicit FComboGraphContext(UComboGraphSystemComponent* Owner);
	~FComboGraphContext();

	UComboGraphSystemComponent* GetOwner() const;
	AActor* GetOwnerActor() const;
	UAnimInstance* GetAnimInstance() const;
	APlayerController* GetPlayerController() const;
	IGameplayTagAssetInterface* GetTagContainer() const;

	FORCEINLINE void Terminate() { bTerminated = true; }
	FORCEINLINE bool IsTerminated() const { return bTerminated; }

	void OpenComboWindow();
	void CloseComboWindow();
	void ResetComboState();
	FORCEINLINE bool IsComboWindowOpened() const { return bComboWindowOpened; }
	FORCEINLINE bool IsComboWindowFinished() const { return bComboWindowFinished; }


	template <typename... ArgTypes>
	uint32 BindInputAction(const UInputAction* InputAction, ETriggerEvent TriggerEvent, ArgTypes&&... Args)
	{
		if (InputComponent)
		{
			return InputComponent->BindAction(InputAction, TriggerEvent, Forward<ArgTypes>(Args)...).GetHandle();
		}

		return 0;
	}

	void RemoveInputBindingByHandle(uint32 Handle) const;

	template <typename... ArgTypes>
	FDelegateHandle AddComboGraphEventHandler(FGameplayTag Event, ArgTypes&&... Args)
	{
		return AddComboGraphEventHandler(Event, FComboGraphEventHandler::CreateUObject(Forward<ArgTypes>(Args)...));
	}

	FDelegateHandle AddComboGraphEventHandler(FGameplayTag Event, FComboGraphEventHandler Handler);
	void RemoveComboGraphEventHandler(FGameplayTag Event, FDelegateHandle Handle);
	void RemoveComboGraphEventHandler(FGameplayTag Event, const void* UserObject);
	void RemoveComboGraphEventHandler(const void* UserObject);

private:
	UPROPERTY(Transient)
	TObjectPtr<UComboGraphSystemComponent> Owner;

	UPROPERTY(Transient)
	TObjectPtr<UEnhancedInputComponent> InputComponent;

	UPROPERTY(Transient)
	TObjectPtr<UAnimInstance> AnimInstance;

	uint8 bTerminated : 1;

	// ComboWindow是否开启, 只有在开启时才会接收玩家输入
	uint8 bComboWindowOpened : 1;
	// 这个变量标记了ComboWindow是否从开启状态进入了关闭状态, 注意: 并不是ComboWindowOpened是false这里就是true, 如果ComboWindow从来没开启过, 那这个地方也是false)
	uint8 bComboWindowFinished : 1;
};
