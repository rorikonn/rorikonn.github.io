﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Graph/ComboGraph.h"

#include "ComboGraphDelegates.h"
#include "ComboGraphLog.h"
#include "Graph/ComboGraphEdge.h"
#include "Graph/ComboGraphNode.h"
#include "Graph/ComboGraphNodeBase.h"
#include "Graph/ComboGraphNodeEntry.h"
#include "Graph/ComboGraphContext.h"
#include "Utils/ComboGraphUtils.h"

UComboGraphData::UComboGraphData()
{
#if WITH_EDITORONLY_DATA
	IconPreference = FComboGraphUtils::GetPluginProjectSettings()->IconPreference;
#endif
}

bool UComboGraphData::GetEntryTransition(const FComboGraphInput& InitialInput, TArray<const UComboGraphEdge*>& OutEdges) const
{
	const UComboGraphNodeEntryData* EntryData = EntryNode.Get<UComboGraphNodeEntryData>();
	if (!EntryData)
	{
		return false;
	}

	return EntryData->GetEdgeWithInput(InitialInput, OutEdges);
}

void UComboGraphData::ClearGraph()
{
	for (FComboGraphNodeReference& Node : AllNodes)
	{
		if (Node)
		{
			Node->ParentNodes.Empty();
			Node->ChildrenNodes.Empty();
			Node->Edges.Empty();
		}
	}

	AllNodes.Empty();
}

void UComboGraphData::SetPreviewMesh(USkeletalMesh* PreviewMesh, bool bMarkAsDirty)
{
#if WITH_EDITORONLY_DATA
	if (bMarkAsDirty)
	{
		Modify();
	}

	PreviewSkeletalMesh = PreviewMesh;
#endif
}

USkeletalMesh* UComboGraphData::GetPreviewMesh() const
{
#if WITH_EDITORONLY_DATA
	if (!PreviewSkeletalMesh.IsValid())
	{
		PreviewSkeletalMesh.LoadSynchronous();
	}

	return PreviewSkeletalMesh.Get();
#else
	return nullptr;
#endif
}

UComboGraph* UComboGraph::Make(UObject* Outer, UComboGraphData* Data, const TSharedPtr<FComboGraphContext>& InContext)
{
	UComboGraph* NewGraph = NewObject<UComboGraph>(Outer, NAME_None, RF_Transient);
	NewGraph->Initialize(Data, InContext);
	return NewGraph;
}

void UComboGraph::Initialize(UComboGraphData* Graph, TSharedPtr<FComboGraphContext> InContext)
{
	ReferenceData = Graph;
	Context = MoveTemp(InContext);
}

bool UComboGraph::BeginGraph(FString& FailReason, const FComboGraphInput& InitialInput)
{
	CG_RUNTIME_LOG(Log, TEXT("BeginGraph: %s"), *GetNameSafe(ReferenceData))

	if (!Context)
	{
		FailReason = TEXT("Combo Graph Context is invalid");
		return false;
	}

	if (!ReferenceData)
	{
		FailReason = TEXT("Reference GraphData is invalid");
		return false;
	}

	TArray<const UComboGraphEdge*> EntryEdges;
	if (!ReferenceData->GetEntryTransition(InitialInput, EntryEdges))
	{
		FailReason = FString::Printf(TEXT("Unable to find valid entry transition for input %s."), *InitialInput.ToString());
		return false;
	}

	SetupEventHandlers();

	PendingTransitions.Reset(EntryEdges.Num());
	for (const UComboGraphEdge* Edge : EntryEdges)
	{
		PendingTransitions.Emplace(Edge, 0, 0.0f);
	}

	bActivating = true;

	FlushPendingTransition(0.0f);
	FComboGraphDelegates::OnComboGraphStarted.Broadcast(*this, *ReferenceData);

	return bActivating;
}

bool UComboGraph::TickGraph(float DeltaTime)
{
	if (!bActivating)
	{
		return false;
	}

	if (!Context || Context->IsTerminated())
	{
		EndGraph();
		return false;
	}

	if (!CurrentNode)
	{
		EndGraph();
		return false;
	}

	if (TimeoutEdge && CurrentNode->GetRelevantTime() >= TimeoutEdge->TimeoutTime)
	{
		ReceivedInputConfirm(TimeoutEdge);
	}

	FlushPendingTransition(DeltaTime);

	CurrentNode->TickNode(DeltaTime);

	return true;
}

// ReSharper disable once CppMemberFunctionMayBeConst
void UComboGraph::EndGraph()
{
	PendingTransitions.Empty();

	ClearTransitionInputBindings();
	ClearEventHandlers();

	if (CurrentNode)
	{
		CurrentNode->UnbindAllEvents();
		CurrentNode->OnDeactivated();
	}

	bActivating = false;
	if (Context)
	{
		Context->Terminate();
	}

	FComboGraphDelegates::OnComboGraphEnded.Broadcast(*this, *ReferenceData);
}

AActor* UComboGraph::GetAvatarActor() const
{
	return Context ? Context->GetOwnerActor() : nullptr;
}

UComboGraphNode* UComboGraph::GetCurrentNode() const
{
	return CurrentNode;
}

const UComboGraphNodeData* UComboGraph::GetCurrentNodeData() const
{
	return CurrentNode ? CurrentNode->GetData() : nullptr;
}

bool UComboGraph::CanInterruptBy(const UComboGraphNodeData* NextNode) const
{
	// 当前没有激活的Node, 可以被打断
	if (!CurrentNode)
	{
		return true;
	}

	// 询问当前节点是否能被打断
	return CurrentNode->CanInterruptBy(NextNode);
}

bool UComboGraph::AdvanceNextNode(const UComboGraphNodeData* NextNodeData, FString& FailReason)
{
	CG_RUNTIME_LOG(Verbose, TEXT("AdvanceNextNode: %s (%s)"), *GetNameSafe(NextNodeData), *GetNameSafe(NextNodeData->GetClass()))

	if (!Context)
	{
		FailReason = TEXT("Combo Graph Context is invalid.");
		return false;
	}

	if (!NextNodeData)
	{
		FailReason = TEXT("Passed in next node is invalid.");
		return false;
	}

	// Initialize node instance
	UComboGraphNode* NextNode = GetRuntimeNode(NextNodeData);
	if (!NextNode)
	{
		FailReason = FString::Printf(TEXT("Make runtime node for %s failed."), *GetNameSafe(NextNodeData));
		return false;
	}

	// Check CanActivate
	if (!NextNode->PreActivation())
	{
		FailReason = FString::Printf(TEXT("PreActivation for %s prevented activation"), *GetNameSafe(NextNodeData));
		return false;
	}

	// Check and commit cost
	if (!NextNode->CommitNodeCost())
	{
		FailReason = FString::Printf(TEXT("CommitCost failed for node %s"), *GetNameSafe(NextNodeData));
		return false;
	}

	// Notify current node about deactivated here
	if (CurrentNode)
	{
		CurrentNode->UnbindAllEvents();
		CurrentNode->OnDeactivated();
	}

	// Reset combo states
	ResetComboState();
	ClearTransitionInputBindings();

	CurrentNode = NextNode;

	// Inputs are only handled client side
	SetupTransitionInputBindings();

	CurrentNode->OnCompleteEvent.AddUObject(this, &UComboGraph::OnCurrentNodeCompleted);
	CurrentNode->OnInterruptedEvent.AddUObject(this, &UComboGraph::OnCurrentNodeInterrupted);
	CurrentNode->OnCanceledEvent.AddUObject(this, &UComboGraph::OnCurrentNodeCanceled);

	// Activate here for next node
	if (!CurrentNode->OnActivated())
	{
		return false;
	}

	return true;
}

void UComboGraph::ReceivedInputActionConfirm(const FInputActionInstance& InputActionInstance, const UComboGraphEdge* Edge)
{
	ReceivedInputConfirm(Edge);
}

void UComboGraph::ReceivedInputEventConfirm(FComboGraphEventPayload* Payload, const UComboGraphEdge* Edge)
{
	ReceivedInputConfirm(Edge);
}

void UComboGraph::ReceivedInputConfirm(const UComboGraphEdge* Edge)
{
	if (!Edge)
	{
		CG_RUNTIME_LOG(Error, TEXT("ReceivedInputConfirm for Node %s - Invalid Edge variadic argument"), *GetNameSafe(CurrentNode))
		return;
	}

	// Bookkeeping triggers as we only want to transition once, and default behavior with no triggers (or just the down one) will trigger every frame
	if (IsEdgeConfirmed(Edge))
	{
		return;
	}

	const AActor* OwningActor = Context ? Context->GetOwnerActor() : nullptr;
	if (!OwningActor)
	{
		CG_RUNTIME_LOG(
			Error,
			TEXT("ReceivedInputConfirm %s with Input: %s but owning actor is not set"),
			*GetName(),
			*Edge->ToString()
		)

		return;
	}

	const UComboGraphNodeData* NextNode = Edge->EndNode.Get<UComboGraphNodeData>();
	if (!NextNode)
	{
		CG_RUNTIME_LOG(
			Error,
			TEXT("ReceivedInputConfirm %s with Input: %s but edge end not is invalid"),
			*GetName(),
			*Edge->ToString()
		)

		return;
	}

	CG_RUNTIME_LOG(Verbose, TEXT("ReceivedInputConfirm for Node %s - OwningActor: %s (Window Opened: %s)"), *GetNameSafe(CurrentNode), *GetNameSafe(Context->GetOwnerActor()),
	               IsComboWindowOpened() ? TEXT("true") : TEXT("false"))

	// Only consider if combo window is currently active / opened (except cancel trigger event, we always want to transition regardless of combo window)
	if (!Edge->IgnoreComboWindow() && !IsComboWindowOpened())
	{
		return;
	}

	CG_RUNTIME_LOG(Verbose, TEXT("\t ReceivedInputConfirm for Node %s - OwningActor: %s - Confirmed"), *GetNameSafe(CurrentNode), *GetNameSafe(OwningActor))

	// Mark this edge as "confirmed", preventing further confirmation if Enhanced Input callback is triggered multiple times
	SetEdgeConfirmed(Edge);

	HandleInputConfirmed(Edge);
}

void UComboGraph::HandleInputConfirmed(const UComboGraphEdge* Edge)
{
	if (!CurrentNode || !Edge)
	{
		return;
	}

	const UComboGraphNodeData* NextNode = Edge->EndNode.Get<UComboGraphNodeData>();
	check(NextNode);

	CG_RUNTIME_LOG(
		Log,
		TEXT("Set combo queued, Current: %s, Next: %s, Event: %s, QueuedNodes: %d"),
		*GetNameSafe(CurrentNode),
		*GetNameSafe(NextNode),
		Edge ? *Edge->GetTransitionComboTrigger().ToString() : TEXT("None"),
		QueuedTransitionEdges.Num() + 1
	)

	if (Edge->TransImmediately())
	{
		HandleComboTransition(Edge);
		return;
	}

	const FGameplayTag TriggerEvent = Edge->GetTransitionComboTrigger();
	if (!TriggerEvent.IsValid())
	{
		return;
	}

	const int32 ActivatingTriggerIndex = ActivatingTrigger.IndexOfByKey(TriggerEvent);
	if (ActivatingTriggerIndex != INDEX_NONE)
	{
		HandleComboTransition(Edge, ActivatingTriggerIndex);
		return;
	}

	if (const TObjectPtr<const UComboGraphEdge>* ExistTransition = QueuedTransitionEdges.FindByPredicate([TriggerEvent](const TObjectPtr<const UComboGraphEdge>& Item)
	{
		return Item && Item->TransitionComboTrigger == TriggerEvent;
	}))
	{
		CG_RUNTIME_LOG(Warning, TEXT("Transition with trigger %s to node %s alread queued"), *TriggerEvent.ToString(), *GetNameSafe((*ExistTransition)->EndNode.Get()));
		return;
	}

	// Transition trigger doesn't met currently, queue transition and waiting trigger
	QueuedTransitionEdges.Add(Edge);
}

void UComboGraph::HandleComboTransitionWithTrigger(const FGameplayTag& TriggerEvent)
{
	if (QueuedTransitionEdges.IsEmpty())
	{
		return;
	}

	const int32 ActivatingTriggerIndex = ActivatingTrigger.IndexOfByKey(TriggerEvent);
	if (ActivatingTriggerIndex == INDEX_NONE)
	{
		return;
	}

	const TObjectPtr<const UComboGraphEdge>* QueuedEdge = QueuedTransitionEdges.FindByPredicate([TriggerEvent](const TObjectPtr<const UComboGraphEdge>& Item)
	{
		return Item && Item->TransitionComboTrigger == TriggerEvent;
	});

	if (!QueuedEdge || !QueuedEdge->Get())
	{
		return;
	}

	HandleComboTransition(*QueuedEdge, ActivatingTriggerIndex);
}

void UComboGraph::HandleComboTransition(const UComboGraphEdge* Edge, int32 TriggerIndex, float PendingTime)
{
	CG_RUNTIME_LOG(Verbose, TEXT("Confirm combo transition to node %s with triggerIndex %d"), *GetNameSafe(Edge->EndNode.Get()), TriggerIndex)

	if (PendingTransitions.ContainsByPredicate([Edge](const FPendingTransition& Transition)
	{
		return Transition.Edge.IsValid() && Transition.Edge == Edge;
	}))
	{
		return;
	}

	PendingTransitions.Emplace(Edge, TriggerIndex, PendingTime);

	// Edge配置的Priority和TriggerIndex共同决定了优先级, 优先级高的在后面, 处理的时候会反向遍历, 靠后的优先触发
	// 注意, 这里的排序是不稳定的, 所以如果策划配置的优先级有相同的, 有可能触发结果是不明确的
	PendingTransitions.Sort();
}

void UComboGraph::FlushPendingTransition(float DeltaTime)
{
	if (!Context || PendingTransitions.IsEmpty())
	{
		return;
	}

	const IGameplayTagAssetInterface* TagContainer = Context->GetTagContainer();
	if (!TagContainer)
	{
		PendingTransitions.Empty();
		return;
	}

	const UComboGraphNodeData* NextNode = nullptr;
	const UComboGraphEdge* TransitionEdge = nullptr;
	TArray<int32> InvalidatedIndex;

	// 反向遍历, 越靠后的优先级越高
	for (int32 Index = PendingTransitions.Num() - 1; Index >= 0; --Index)
	{
		if (!PendingTransitions[Index].Edge.IsValid())
		{
			InvalidatedIndex.Add(Index);
			continue;
		}

		const UComboGraphEdge* Edge = PendingTransitions[Index].Edge.Get();
		if (!Edge->IsTransitionRequirementMatched(TagContainer))
		{
			PendingTransitions[Index].RemainTime -= DeltaTime;
			if (PendingTransitions[Index].RemainTime <= 0.0f)
			{
				InvalidatedIndex.Add(Index);
			}

			continue;
		}

		NextNode = Edge->EndNode.Get<UComboGraphNodeData>();
		TransitionEdge = Edge;
		check(NextNode);
		// 如果这里找到了有效的NextNode了就可以直接Break, 因为后面整个PendingList就被清了, 所以列表后面的RemainTime也不用再更新了
		break;
	}

	if (NextNode)
	{
		PendingTransitions.Empty();
		
		// 如果时因为超时触发的跳转, 需要把当前的按下的键都清掉, 防止后续抬起来触发下一个节点的跳转
		if (TransitionEdge && TransitionEdge->TransitionInputType == EComboGraphTransitionInputType::Timeout)
		{
			APlayerController* OwnerPlayerController = Context->GetPlayerController();
			if (OwnerPlayerController)
			{
				OwnerPlayerController->FlushPressedKeys();
			}
		}

		FString FailReason;
		if (!AdvanceNextNode(NextNode, FailReason))
		{
			CG_RUNTIME_LOG(Warning, TEXT("Advance Next node %s failed: %s"), *GetNameSafe(NextNode), *FailReason)
			EndGraph();
		}
	}
	// 如果没有成功触发跳转, 要把缓存时间已经到了的或者已经失效的Transition清掉
	// 如果触发成功就不用管了, 因为PendingTransitions会被清空
	else if (!InvalidatedIndex.IsEmpty())
	{
		// InvalidatedIndex里面的下标是从大到小存的(上面遍历PendingTransitions是反向遍历的), 所以这里正序遍历
		for (int32 Index = 0; Index < InvalidatedIndex.Num(); ++Index)
		{
			PendingTransitions.RemoveAt(InvalidatedIndex[Index]);
		}
	}
}

void UComboGraph::SetupTransitionInputBindings()
{
	if (!Context)
	{
		CG_RUNTIME_LOG(Error, TEXT("Combo Graph Context is invalid."));
		return;
	}

	for (const UComboGraphEdge* Edge : CurrentNode->GetAllEdges())
	{
		switch (Edge->TransitionInputType)
		{
		case EComboGraphTransitionInputType::InputAction:
			{
				const UInputAction* InputAction = Edge->TransitionInputAction;
				if (!InputAction)
				{
					continue;
				}

				// Convert out internal enum to the real Input Trigger Event for Enhanced Input
				const ETriggerEvent TriggerEvent = Edge->GetEnhancedInputTriggerEvent();

				CG_RUNTIME_LOG(
					Verbose,
					TEXT("SetupInputBindings for Node %s: Edge %s with Transition Input: %s - %s"),
					*GetNameSafe(CurrentNode),
					*Edge->GetName(),
					*GetNameSafe(InputAction),
					*UEnum::GetValueAsString(TriggerEvent)
				)

				uint32 ConfirmHandle = Context->BindInputAction(InputAction, TriggerEvent, this, &UComboGraph::ReceivedInputActionConfirm, Edge);
				InputActionHandles.Add(ConfirmHandle);
			}
			break;
		case EComboGraphTransitionInputType::InputEvent:
			{
				const FGameplayTag InputEvent = Edge->TransitionInputEvent;
				if (!InputEvent.IsValid())
				{
					continue;
				}

				CG_RUNTIME_LOG(
					Verbose,
					TEXT("SetupInputBindings for Node %s: Edge %s with Transition Evet: %s"),
					*GetNameSafe(CurrentNode),
					*Edge->GetName(),
					*InputEvent.ToString()
				)

				Context->AddComboGraphEventHandler(InputEvent, this, &UComboGraph::ReceivedInputEventConfirm, Edge);
				InputEventBindings.Add(InputEvent);
			}
			break;
		case EComboGraphTransitionInputType::Timeout:
			TimeoutEdge = Edge;
			break;
		}
	}
}

void UComboGraph::ClearTransitionInputBindings()
{
	if (!Context)
	{
		CG_RUNTIME_LOG(Error, TEXT("Combo Graph Context is invalid."));
		return;
	}

	for (const uint32 Handle : InputActionHandles)
	{
		Context->RemoveInputBindingByHandle(Handle);
	}

	for (const FGameplayTag Event : InputEventBindings)
	{
		Context->RemoveComboGraphEventHandler(Event, this);
	}

	TimeoutEdge = nullptr;
}

void UComboGraph::SetupEventHandlers()
{
	Context->AddComboGraphEventHandler(FComboGraphNativeTags::ComboBeginEvent, this, &UComboGraph::OnComboBegin);
	Context->AddComboGraphEventHandler(FComboGraphNativeTags::ComboEndEvent, this, &UComboGraph::OnComboEnd);
	Context->AddComboGraphEventHandler(FComboGraphNativeTags::ComboTriggerEvent, this, &UComboGraph::OnComboTriggerBegin);
	Context->AddComboGraphEventHandler(FComboGraphNativeTags::ComboTriggerEndEvent, this, &UComboGraph::OnComboTriggerEnd);
}

// ReSharper disable once CppMemberFunctionMayBeConst
void UComboGraph::ClearEventHandlers()
{
	Context->RemoveComboGraphEventHandler(this);
}

// ReSharper disable once CppMemberFunctionMayBeConst
void UComboGraph::OnComboBegin(FComboGraphEventPayload* Payload)
{
	if (Context)
	{
		Context->OpenComboWindow();
	}
}

void UComboGraph::OnComboEnd(FComboGraphEventPayload* Payload)
{
	if (Context)
	{
		Context->CloseComboWindow();
	}

	BeginTransitionTrigger(FComboGraphNativeTags::ComboEndEvent);
}

void UComboGraph::OnComboTriggerBegin(FComboGraphEventPayload* Payload)
{
	const FComboGraphEventPayload_TransitionTrigger* TriggerPayload = StaticCast<FComboGraphEventPayload_TransitionTrigger*>(Payload);
	if (!TriggerPayload)
	{
		return;
	}

	BeginTransitionTrigger(TriggerPayload->Trigger);
}

void UComboGraph::OnComboTriggerEnd(FComboGraphEventPayload* Payload)
{
	const FComboGraphEventPayload_TransitionTrigger* TriggerPayload = StaticCast<FComboGraphEventPayload_TransitionTrigger*>(Payload);
	if (!TriggerPayload)
	{
		return;
	}

	EndTransitionTrigger(TriggerPayload->Trigger);
}

void UComboGraph::OnCurrentNodeCompleted()
{
	EndGraph();
}

void UComboGraph::OnCurrentNodeInterrupted()
{
	EndGraph();
}

void UComboGraph::OnCurrentNodeCanceled()
{
	EndGraph();
}

UComboGraphNode* UComboGraph::GetRuntimeNode(const UComboGraphNodeData* NodeData)
{
	if (UComboGraphNode** ExistingNode = RuntimeNodeMap.Find(NodeData))
	{
		return *ExistingNode;
	}

	UComboGraphNode* RuntimeNode = NodeData->MakeRuntimeNode(Context);
	RuntimeNodeMap.Add(NodeData, RuntimeNode);

	return RuntimeNode;
}

const UComboGraphNodeEntryData* UComboGraph::GetEntryNode() const
{
	return ReferenceData ? ReferenceData->EntryNode.Get<UComboGraphNodeEntryData>() : nullptr;
}

void UComboGraph::ResetComboState()
{
	QueuedTransitionEdges.Empty();
	ActivatingTrigger.Empty();
	ConfirmedEdges.Empty();

	if (Context)
	{
		Context->ResetComboState();
	}
}

void UComboGraph::SetEdgeConfirmed(const UComboGraphEdge* Edge)
{
	ConfirmedEdges.Add(Edge);
}

bool UComboGraph::IsEdgeConfirmed(const UComboGraphEdge* Edge) const
{
	return ConfirmedEdges.Contains(Edge);
}

void UComboGraph::BeginTransitionTrigger(FGameplayTag Trigger)
{
	ActivatingTrigger.Add(Trigger);

	HandleComboTransitionWithTrigger(Trigger);
}

void UComboGraph::EndTransitionTrigger(FGameplayTag Trigger)
{
	ActivatingTrigger.Remove(Trigger);
}
