// Copyright 2022 Mickael Daniel. All Rights Reserved.

#include "ComboGraphModule.h"

#include "DataArchive.h"
#include "Graph/ComboGraph.h"
#include "Graph/ComboGraphNodeBase.h"
#include "Settings/ComboGraphProjectSettings.h"
#include "Misc/CoreDelegates.h"

#if WITH_EDITOR
#include "ISettingsModule.h"
#include "ISettingsSection.h"
#endif

#define LOCTEXT_NAMESPACE "ComboGraphModule"

void FComboGraphModule::StartupModule()
{
	// Register Settings
	SetupSettings();
	
	FDataArchiveManager::Load<UComboGraphData>();
	FDataArchiveManager::Load<UComboGraphNodeDataBase>();
}

void FComboGraphModule::ShutdownModule()
{
	// Unregister Settings
	ShutdownSettings();
}

void FComboGraphModule::SetupSettings()
{
#if WITH_EDITOR
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		const TSharedPtr<ISettingsSection> SettingsSection = SettingsModule->RegisterSettings(
			"Project",
			"Plugins",
			"ComboGraphEditor",
			LOCTEXT("ProjectSettingsName", "Combo Graph"),
			LOCTEXT("ProjectSettingsDescription", "Configure Combo Graph Plugin."),
			GetMutableDefault<UComboGraphProjectSettings>()
		);
	}
#endif
}

// ReSharper disable once CppMemberFunctionMayBeConst
void FComboGraphModule::ShutdownSettings()
{
#if WITH_EDITOR
	if (ISettingsModule* SettingsModule = FModuleManager::GetModulePtr<ISettingsModule>("Settings"))
	{
		SettingsModule->UnregisterSettings("Project", "Plugins", "ComboGraphEditor");
	}
#endif
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FComboGraphModule, ComboGraph)
