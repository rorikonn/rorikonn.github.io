﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "NativeGameplayTags.h"
#include "InputAction.h"
#include "ComboGraphRuntimeTypes.generated.h"

class UComboGraphNodeDataBase;

UENUM(BlueprintType)
enum class EComboGraphIconType : uint8
{
	PS4,
	PS5,
	XboxOne,
	XboxSeries,
	Keyboard
};

/** 触发跳转的输入类型(按键输入 or 事件输入) */
UENUM(BlueprintType)
enum class EComboGraphTransitionInputType : uint8
{
	/** 通过增强输入组件监听玩家输入触发跳转 */
	InputAction UMETA(DisplayName = "Transition On Input Action Trigger"),
	/** 通过监听ComboGraph系统的输入事件触发跳转 */
	InputEvent UMETA(DisplayName = "Transition On Input Event Fire"),
	/** 超时自动触发跳转 */
	Timeout UMETA(DisplayName = "Transition On Timeout")
};

/** 输入满足后的跳转时机 */
UENUM(BlueprintType)
enum class EComboGraphTransitionBehavior : uint8
{
	/** 输入到达时立刻跳转 */
	Immediately UMETA(DisplayName = "Transition Immediately"),

	/**
	 * 在特定的ComboTrigger触发后跳转
	 * 如果输入在ComboTrigger触发前收到, 会在ComboTrigger触发的时候立刻跳转
	 * 如果输入在ComboTrigger触发后收到, 会在输入达到时立刻跳转
	 */
	OnNotifyTrigger UMETA(DisplayName = "Wait for Combo Trigger"),

	/** 在ComboWindow结束时跳转 */
	OnComboWindowEnd UMETA(DisplayName = "Wait for Combo Window End"),
};

/** 监听的输入触发类型(与增强输入组件中的类型对应). */
UENUM(BlueprintType)
enum class EComboGraphTransitionInputActionEvent : uint8
{
	/**
	 * The most common trigger types are likely to be Started for actions that happen once, immediately upon pressing a button.
	 *
	 * This is the event to use for Input Action with default configuration (no triggers) or at least one trigger with the "Down" value.
	 */
	Started UMETA(DisplayName = "Activate on Action Started"),

	/**
	 * Triggered for continuous actions after one or more processing ticks.
	 *
	 * For action triggers that are triggered every frame, only the first trigger happening within a combo window will be considered.
	 */
	Triggered UMETA(DisplayName = "Activate on Action Triggered"),

	/**
	 * Triggered when input action has been canceled (eg. not fulfilling the trigger configuration). For instance, an hold and release trigger where hold time threshold has not been satisfied.
	 */
	Canceled UMETA(DisplayName = "Activate on Action Canceled"),
};

USTRUCT(BlueprintType)
struct COMBOGRAPH_API FComboGraphInput
{
	GENERATED_BODY()

	FComboGraphInput() = default;

	FComboGraphInput(const UInputAction* InputAction, ETriggerEvent InputTriggerEvent)
		: Type(EComboGraphTransitionInputType::InputAction),
		  InputTriggerEvent(InputTriggerEvent),
		  InputAction(InputAction)
	{
	}

	FComboGraphInput(FGameplayTag InputEvent)
		: Type(EComboGraphTransitionInputType::InputEvent),
		  InputTriggerEvent(ETriggerEvent::None),
		  InputAction(nullptr),
		  InputEvent(InputEvent)
	{
	}

	FORCEINLINE FString ToString() const
	{
		switch (Type)
		{
		case EComboGraphTransitionInputType::InputAction:
			return FString::Printf(TEXT("%s - %s[%s]"), *UEnum::GetValueAsString(Type), *GetNameSafe(InputAction), *UEnum::GetValueAsString(InputTriggerEvent));
		case EComboGraphTransitionInputType::InputEvent:
			return FString::Printf(TEXT("%s - %s"), *UEnum::GetValueAsString(Type), *InputEvent.ToString());
		default:
			return UEnum::GetValueAsString(Type);
		}
	}

	UPROPERTY()
	EComboGraphTransitionInputType Type;

	UPROPERTY()
	ETriggerEvent InputTriggerEvent;

	UPROPERTY()
	const UInputAction* InputAction;

	UPROPERTY()
	FGameplayTag InputEvent;
};

namespace FComboGraphNativeTags
{
	COMBOGRAPH_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(ComboBeginEvent)
	COMBOGRAPH_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(ComboEndEvent)
	COMBOGRAPH_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(ComboTriggerEvent)
	COMBOGRAPH_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(ComboTriggerEndEvent)
	COMBOGRAPH_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(BecomeInterruptableEvent)

	COMBOGRAPH_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(DefaultComboTrigger)
};


USTRUCT()
struct COMBOGRAPH_API FComboGraphID
{
	GENERATED_BODY()

	FComboGraphID();
	FComboGraphID(int32 ID);

	FComboGraphID& operator=(int32 InIndex)
	{
		ID = InIndex;
		return *this;
	}

	friend bool operator==(const FComboGraphID& Lhs, const FComboGraphID& Rhs)
	{
		return Lhs.ID == Rhs.ID;
	}

	friend bool operator!=(const FComboGraphID& Lhs, const FComboGraphID& Rhs)
	{
		return Lhs.ID != Rhs.ID;
	}

	friend uint32 GetTypeHash(const FComboGraphID& Ref)
	{
		return Ref.ID;
	}

	FString ToString() const
	{
		FString OutString;
		if (ExportTextItem(OutString))
		{
			return OutString;
		}

		return FString();
	}

	bool ExportTextItem(FString& ValueStr, FComboGraphID const& DefaultValue = FComboGraphID(), UObject* Parent = nullptr, int32 PortFlags = 0, UObject* ExportRootScope = nullptr) const
	{
		ValueStr += FString::FromInt(ID);
		return true;
	}

	/**
	 * Custom import item used to parse ini entries straight into the filename.
	 */
	bool ImportTextItem(const TCHAR*& Buffer, int32 PortFlags, UObject* Parent, FOutputDevice* ErrorText)
	{
		FString ImportedString = TEXT("");
		const TCHAR* NewBuffer = FPropertyHelpers::ReadToken(Buffer, ImportedString, true);
		if (!NewBuffer)
		{
			return false;
		}

		ID = FCString::Atoi(*ImportedString);

		return true;
	}

	UPROPERTY()
	int32 ID;
};

template <>
struct TStructOpsTypeTraits<FComboGraphID> : TStructOpsTypeTraitsBase2<FComboGraphID>
{
	enum
	{
		WithExportTextItem = true,
		WithImportTextItem = true,
	};
};

USTRUCT()
struct COMBOGRAPH_API FComboGraphNodeID
{
	GENERATED_BODY()

	FComboGraphNodeID();
	FComboGraphNodeID(FComboGraphID Owner, int32 Index);

	friend bool operator==(const FComboGraphNodeID& Lhs, const FComboGraphNodeID& Rhs)
	{
		return Lhs.Owner == Rhs.Owner && Lhs.ID == Rhs.ID;
	}

	friend bool operator!=(const FComboGraphNodeID& Lhs, const FComboGraphNodeID& Rhs)
	{
		return Lhs.Owner != Rhs.Owner || Lhs.ID != Rhs.ID;
	}

	friend uint32 GetTypeHash(const FComboGraphNodeID& Ref)
	{
		return HashCombine(Ref.Owner.ID, Ref.ID);
	}

	FString ToString() const
	{
		FString OutString;
		if (ExportTextItem(OutString))
		{
			return OutString;
		}

		return FString();
	}

	bool ExportTextItem(FString& ValueStr, FComboGraphNodeID const& DefaultValue = FComboGraphNodeID(), UObject* Parent = nullptr, int32 PortFlags = 0, UObject* ExportRootScope = nullptr) const
	{
		FString ContextString;
		Owner.ExportTextItem(ContextString);
		ValueStr += FString::Printf(TEXT("%s-%d"), *ContextString, ID);
		return true;
	}

	/**
	 * Custom import item used to parse ini entries straight into the filename.
	 */
	bool ImportTextItem(const TCHAR*& Buffer, int32 PortFlags, UObject* Parent, FOutputDevice* ErrorText)
	{
		FString ImportedString = TEXT("");
		const TCHAR* NewBuffer = FPropertyHelpers::ReadToken(Buffer, ImportedString, true);
		if (!NewBuffer)
		{
			return false;
		}

		FString Left, Right;
		if (!ImportedString.Split(TEXT("-"), &Left, &Right))
		{
			return false;
		}

		const TCHAR* ContextBuffer = *Left;
		Owner.ImportTextItem(ContextBuffer, 0, nullptr, nullptr);

		ID = FCString::Atoi(*Right);

		return true;
	}

	UPROPERTY()
	FComboGraphID Owner;

	UPROPERTY()
	int32 ID;
};

template <>
struct TStructOpsTypeTraits<FComboGraphNodeID> : TStructOpsTypeTraitsBase2<FComboGraphNodeID>
{
	enum
	{
		WithExportTextItem = true,
		WithImportTextItem = true,
	};
};

USTRUCT()
struct COMBOGRAPH_API FComboGraphNodeReference
{
	GENERATED_BODY()

	FComboGraphNodeReference()
	{
	}

	FComboGraphNodeReference(FComboGraphNodeID ID)
		: ID(ID)
	{
	}

	FComboGraphNodeReference(const UComboGraphNodeDataBase* Data);

	UPROPERTY()
	FComboGraphNodeID ID;

	UComboGraphNodeDataBase* Get();
	const UComboGraphNodeDataBase* Get() const;

	template <typename T>
	typename TEnableIf<TIsDerivedFrom<T, UComboGraphNodeDataBase>::Value, T*>::Type Get()
	{
		return Cast<T>(Get());
	}

	template <typename T>
	typename TEnableIf<TIsDerivedFrom<T, UComboGraphNodeDataBase>::Value, const T*>::Type Get() const
	{
		return Cast<T>(Get());
	}

	FComboGraphNodeReference& operator=(const FComboGraphNodeID& Other);

	FComboGraphNodeReference& operator=(const UComboGraphNodeDataBase* OtherData);

	UComboGraphNodeDataBase* operator->();
	const UComboGraphNodeDataBase* operator->() const;
	UComboGraphNodeDataBase* operator*();
	const UComboGraphNodeDataBase* operator*() const;

	FORCEINLINE operator bool() const;
	FORCEINLINE bool operator !() const;

	bool ExportTextItem(FString& ValueStr, FComboGraphNodeReference const& DefaultValue = FComboGraphNodeReference(), UObject* Parent = nullptr, int32 PortFlags = 0,
	                    UObject* ExportRootScope = nullptr) const
	{
		return ID.ExportTextItem(ValueStr);
	}

	/**
	 * Custom import item used to parse ini entries straight into the filename.
	 */
	bool ImportTextItem(const TCHAR*& Buffer, int32 PortFlags, UObject* Parent, FOutputDevice* ErrorText)
	{
		return ID.ImportTextItem(Buffer, PortFlags, Parent, ErrorText);
	}

private:
	mutable TWeakObjectPtr<UComboGraphNodeDataBase> Object;
};

template <>
struct TStructOpsTypeTraits<FComboGraphNodeReference> : TStructOpsTypeTraitsBase2<FComboGraphNodeReference>
{
	enum
	{
		WithExportTextItem = true,
		WithImportTextItem = true,
	};
};

struct FComboGraphEventPayload
{
};

DECLARE_MULTICAST_DELEGATE_OneParam(FComboGraphEvent, FComboGraphEventPayload*);
using FComboGraphEventHandler = FComboGraphEvent::FDelegate;

struct FComboGraphEventPayload_ComboWindow : FComboGraphEventPayload
{
	UAnimSequenceBase* RelevantSequence;
};

struct FComboGraphEventPayload_TransitionTrigger : FComboGraphEventPayload
{
	FGameplayTag Trigger;
};
