// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphNode.h"
#include "ComboGraphNodeMontage.generated.h"

/**
 *  Base Class for Combo Graph nodes acting based on an Anim Montage asset.
 *
 *  Holds runtime properties for animation and effects / cues containers.
 */
UCLASS(meta=(DisplayName="Montage Combo Node", DisplayColor="100,100,255"))
class COMBOGRAPH_API UComboGraphNodeMontageData : public UComboGraphNodeData
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	TSoftObjectPtr<UAnimMontage> Montage;

	UPROPERTY(EditDefaultsOnly, Category = "Animation")
	FName StartSection = NAME_None;

	virtual UComboGraphNode* MakeRuntimeNode(TSharedPtr<FComboGraphContext> Context) const override;

	virtual UAnimMontage* GetMontage() const override;
	virtual UAnimSequenceBase* GetAnimationAsset() const override;
	virtual float GetAnimationLength() const override;
	virtual FName GetAnimationStartSection() const override;
	virtual float GetSectionLength(FName SectionName) const override;
	virtual float GetAnimationLengthMinusSection(FName SectionName) const override;
	virtual float GetAnimationLengthMinusStartSection() const override;

	virtual void SetAnimationAsset(UAnimationAsset* Asset) override;
	virtual bool SupportsAssetClass(UClass* AssetClass) override;
	virtual FText GetNodeTitle() const override;

#if WITH_EDITOR
	virtual FText GetAnimAssetLabel() const override;
	virtual FText GetAnimAssetLabelTooltip() const override;
	virtual FText GetAnimAssetText() const override;
	virtual FLinearColor GetBackgroundColor() const override;
#endif
};


UCLASS()
class COMBOGRAPH_API UComboGraphNodeMontage : public UComboGraphNode
{
	GENERATED_BODY()

public:
	virtual bool OnActivated() override;
	virtual void OnDeactivated() override;

	virtual void TickNode(float DeltaTime) override;

protected:
	void OnMontageBlendingOut(UAnimMontage* Montage, bool bInterrupted) const;
	void OnMontageEnded(UAnimMontage* Montage, bool bInterrupted) const;

	void CheckComboWindow(float StartTime, float EndTime) const;

private:
	float ElapsedTime;
	
	float ComboStartTime;
	float ComboEndTime;

	TMap<FName, float> ComboTriggers;

	uint8 bMontageContainsComboWindowSetup:1;
	uint8 bHasComboBegan:1;
};
