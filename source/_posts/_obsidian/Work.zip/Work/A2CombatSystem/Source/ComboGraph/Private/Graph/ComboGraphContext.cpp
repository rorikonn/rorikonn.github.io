﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Graph/ComboGraphContext.h"

#include "GameplayTagAssetInterface.h"
#include "Components/ComboGraphSystemComponent.h"
#include "GameFramework/Character.h"


FComboGraphContext::FComboGraphContext(UComboGraphSystemComponent* Owner)
	: Owner(Owner),
	  bTerminated(false)
{
	if (const AActor* OwnerActor = GetOwnerActor())
	{
		InputComponent = Cast<UEnhancedInputComponent>(OwnerActor->InputComponent);
	}

	const ACharacter* OwnerCharacter = Cast<ACharacter>(GetOwnerActor());
	if (OwnerCharacter && OwnerCharacter->GetMesh())
	{
		AnimInstance = OwnerCharacter->GetMesh()->GetAnimInstance();
	}
}

FComboGraphContext::~FComboGraphContext()
{
}

UComboGraphSystemComponent* FComboGraphContext::GetOwner() const
{
	return Owner;
}

AActor* FComboGraphContext::GetOwnerActor() const
{
	return Owner ? Owner->GetOwner() : nullptr;
}

UAnimInstance* FComboGraphContext::GetAnimInstance() const
{
	return AnimInstance;
}

APlayerController* FComboGraphContext::GetPlayerController() const
{
	const APawn* OwnerPawn = Cast<APawn>(GetOwnerActor());
	return OwnerPawn ? Cast<APlayerController>(OwnerPawn->GetController()) : nullptr;
}

IGameplayTagAssetInterface* FComboGraphContext::GetTagContainer() const
{
	return Cast<IGameplayTagAssetInterface>(GetOwnerActor());
}

void FComboGraphContext::OpenComboWindow()
{
	bComboWindowOpened = true;
}

void FComboGraphContext::CloseComboWindow()
{
	if (bComboWindowOpened)
	{
		bComboWindowOpened = false;
		bComboWindowFinished = true;
	}
}

void FComboGraphContext::ResetComboState()
{
	bComboWindowOpened = false;
	bComboWindowFinished = false;
}

void FComboGraphContext::RemoveInputBindingByHandle(uint32 Handle) const
{
	if (InputComponent)
	{
		InputComponent->RemoveBindingByHandle(Handle);
	}
}

// ReSharper disable once CppMemberFunctionMayBeConst
FDelegateHandle FComboGraphContext::AddComboGraphEventHandler(FGameplayTag Event, FComboGraphEventHandler Handler)
{
	if (Owner)
	{
		return Owner->AddComboGraphEventHandler(Event, MoveTemp(Handler));
	}

	return FDelegateHandle();
}

// ReSharper disable once CppMemberFunctionMayBeConst
void FComboGraphContext::RemoveComboGraphEventHandler(FGameplayTag Event, FDelegateHandle Handle)
{
	if (Owner)
	{
		return Owner->RemoveComboGraphEventHandler(Event, Handle);
	}
}

// ReSharper disable once CppMemberFunctionMayBeConst
void FComboGraphContext::RemoveComboGraphEventHandler(FGameplayTag Event, const void* UserObject)
{
	if (Owner)
	{
		return Owner->RemoveComboGraphEventHandler(Event, UserObject);
	}
}

// ReSharper disable once CppMemberFunctionMayBeConst
void FComboGraphContext::RemoveComboGraphEventHandler(const void* UserObject)
{
	if (Owner)
	{
		return Owner->RemoveComboGraphEventHandler(UserObject);
	}
}
