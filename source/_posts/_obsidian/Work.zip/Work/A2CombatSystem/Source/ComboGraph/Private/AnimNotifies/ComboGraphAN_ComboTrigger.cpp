//

#include "AnimNotifies/ComboGraphAN_ComboTrigger.h"

#include "ComboGraphRuntimeTypes.h"
#include "Components/ComboGraphSystemComponent.h"

void UComboGraphAN_ComboTrigger::Notify(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	Super::Notify(MeshComp, Animation, EventReference);
	
	static FComboGraphEventPayload_TransitionTrigger Payload;
	Payload.Trigger = Trigger;
	UComboGraphSystemComponent::SendEvent(MeshComp, FComboGraphNativeTags::ComboTriggerEvent, &Payload);
}
