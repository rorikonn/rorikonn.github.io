﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Settings/ComboGraphProjectSettings.h"

UComboGraphProjectSettings::UComboGraphProjectSettings()
{
	DefaultNodeColor = FLinearColor(80.f / 255.f, 123.f / 255.f, 72.f / 255.f, 1.f);
	DisableNodeColor = FLinearColor(150.f / 255.f, 150.f / 255.f, 150.f / 255.f, 1.f);

	MontageNodeColor = FLinearColor(100.f / 255.f, 100.f / 255.f, 1.f, 1.f);

	DebugActiveColor = FLinearColor(1.f, 0.6f, 0.35f, 1.f);
	DebugFadeTime = 0.2f;

	ContentMargin = FMargin(8.f);
	ContentInternalPadding = FMargin(12.f, 8.f);

	IconSize = 48.f;

	DynamicMontageSlotName = TEXT("DefaultSlot");

	// TODO: Don't forget to update path when plugin gets renamed
	const FString PluginName = TEXT(UE_PLUGIN_NAME);
	IconsDataTable = FSoftObjectPath(FString::Format(TEXT("/{0}/KeyIcons/DT_ComboGraph_InputIconsMappings.DT_ComboGraph_InputIconsMappings"), {PluginName}));
}
