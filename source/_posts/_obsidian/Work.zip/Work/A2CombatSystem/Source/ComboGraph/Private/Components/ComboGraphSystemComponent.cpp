﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Components/ComboGraphSystemComponent.h"

#include "ComboGraphLog.h"
#include "GameplayTagAssetInterface.h"
#include "Graph/ComboGraph.h"
#include "Graph/ComboGraphEdge.h"
#include "Graph/ComboGraphNodeEntry.h"
#include "Utils/ComboGraphUtils.h"

void UComboGraphSystemComponent::OnRegister()
{
	Super::OnRegister();
}

UComboGraphSystemComponent* UComboGraphSystemComponent::GetFromOwner(const AActor* Owner)
{
	return Owner ? Owner->FindComponentByClass<UComboGraphSystemComponent>() : nullptr;
}

UComboGraphSystemComponent::UComboGraphSystemComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer),
	  ActivatingComboGraph(nullptr)
{
	PrimaryComponentTick.TickGroup = TG_PrePhysics;
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.bStartWithTickEnabled = true;
}

void UComboGraphSystemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	InternalTickComboGraph(DeltaTime);
}

void UComboGraphSystemComponent::BP_StartComboGraph(int32 GraphID, FComboGraphInput InitialInput)
{
	UComboGraphData* GraphData = FDataArchiveManager::Find<UComboGraphData>(GraphID);
	if (IsValid(GraphData))
	{
		InternalStartComboGraph(GraphData, InitialInput);
	}
}

void UComboGraphSystemComponent::StartComboGraph(int32 GraphID, const UInputAction* InitialInput, ETriggerEvent TriggerEvent)
{
	UComboGraphData* GraphData = FDataArchiveManager::Find<UComboGraphData>(GraphID);
	if (IsValid(GraphData))
	{
		InternalStartComboGraph(GraphData, FComboGraphInput(InitialInput, TriggerEvent));
	}
}

void UComboGraphSystemComponent::StartComboGraph(int32 GraphID, FGameplayTag InitialInput)
{
	UComboGraphData* GraphData = FDataArchiveManager::Find<UComboGraphData>(GraphID);
	if (IsValid(GraphData))
	{
		InternalStartComboGraph(GraphData, InitialInput);
	}
}

void UComboGraphSystemComponent::LearnComboGraph(int32 GraphID)
{
	if (LearnedComboGraphs.Contains(GraphID))
	{
		CG_RUNTIME_LOG(Log, TEXT("Learn ComboGraph %d failed, graph already learned"), GraphID)
		return;
	}

	UComboGraphData* GraphData = FDataArchiveManager::Find<UComboGraphData>(GraphID);
	if (!GraphData)
	{
		CG_RUNTIME_LOG(Warning, TEXT("Learn ComboGraph %d failed, graph data invalid"), GraphID)
		return;
	}

	const UComboGraphNodeEntryData* EntryNode = GraphData->EntryNode.Get<UComboGraphNodeEntryData>();
	if (!EntryNode)
	{
		CG_RUNTIME_LOG(Warning, TEXT("Learn ComboGraph %d failed, Graph doesn't have valid entry node"), GraphID)
		return;
	}

	UEnhancedInputComponent* InputComponent = GetOwner()->FindComponentByClass<UEnhancedInputComponent>();
	if (!InputComponent)
	{
		CG_RUNTIME_LOG(Warning, TEXT("Learn ComboGraph %d failed, couldn't find input component for owner %s"), GraphID, *GetNameSafe(GetOwner()))
		return;
	}

	CG_RUNTIME_LOG(Verbose, TEXT("Learn ComboGraph %d success for owner %s"), GraphID, *GetNameSafe(GetOwner()));
	LearnedComboGraphs.Add(GraphID);
	TArray<uint32>& InputActionBindings = ComboGraphInputActionBindings.FindOrAdd(GraphID);
	TArray<FGameplayTag>& InputEventBindings = ComboGraphInputEventBindings.FindOrAdd(GraphID);

	TArray<UComboGraphEdge*> EntryEdges = EntryNode->GetAllEdges();
	for (const UComboGraphEdge* Edge : EntryEdges)
	{
		if (Edge->TransitionInputType == EComboGraphTransitionInputType::InputAction)
		{
			const UInputAction* InputAction = Edge->TransitionInputAction;
			if (!InputAction)
			{
				continue;
			}

			const ETriggerEvent TriggerEvent = Edge->GetEnhancedInputTriggerEvent();
			uint32 BindingHandle = InputComponent->BindAction(InputAction, TriggerEvent, this, &ThisClass::StartComboGraph, GraphID, InputAction, TriggerEvent).GetHandle();
			InputActionBindings.Add(BindingHandle);
		}
		else if (Edge->TransitionInputType == EComboGraphTransitionInputType::InputEvent)
		{
			const FGameplayTag InputEvent = Edge->TransitionInputEvent;
			if (!InputEvent.IsValid())
			{
				continue;
			}

			AddComboGraphEventHandler(InputEvent, this, &ThisClass::OnStartComboGraphEventReceived, GraphID, InputEvent);
			InputEventBindings.Add(InputEvent);
		}
	}
}

void UComboGraphSystemComponent::ForgetComboGraph(int32 GraphID)
{
	if (!LearnedComboGraphs.Contains(GraphID))
	{
		CG_RUNTIME_LOG(Log, TEXT("ComboGraph %d has not learned yet"), GraphID)
		return;
	}

	UEnhancedInputComponent* InputComponent = GetOwner()->FindComponentByClass<UEnhancedInputComponent>();
	if (!InputComponent)
	{
		CG_RUNTIME_LOG(Warning, TEXT("Forget ComboGraph %d failed, couldn't find input component for owner %s"), GraphID, *GetNameSafe(GetOwner()))
		return;
	}

	TArray<uint32>& InputActionBindings = ComboGraphInputActionBindings.FindChecked(GraphID);
	for (const uint32 BindingHandle : InputActionBindings)
	{
		InputComponent->RemoveBindingByHandle(BindingHandle);
	}

	TArray<FGameplayTag>& InputEventBindings = ComboGraphInputEventBindings.FindChecked(GraphID);
	for (const FGameplayTag InputEvent : InputEventBindings)
	{
		RemoveComboGraphEventHandler(InputEvent, this);
	}

	ComboGraphInputActionBindings.Remove(GraphID);
	ComboGraphInputEventBindings.Remove(GraphID);
	LearnedComboGraphs.Remove(GraphID);
}

void UComboGraphSystemComponent::SendEvent(const AActor* Owner, FGameplayTag Event, FComboGraphEventPayload* Payload)
{
	if (!Owner || FComboGraphUtils::IsAnimationPreviewActor(Owner))
	{
		return;
	}

	UComboGraphSystemComponent* ComboGraphSystem = GetFromOwner(Owner);
	if (!ComboGraphSystem)
	{
		return;
	}

	ComboGraphSystem->HandleComboGraphEvent(Event, Payload);
}

void UComboGraphSystemComponent::SendEvent(const UActorComponent* Owner, FGameplayTag Event, FComboGraphEventPayload* Payload)
{
	if (!Owner)
	{
		return;
	}

	const AActor* OwnerActor = Owner->GetOwner();
	SendEvent(OwnerActor, Event, Payload);
}

void UComboGraphSystemComponent::HandleComboGraphEvent(FGameplayTag Event, FComboGraphEventPayload* Payload)
{
	if (const FComboGraphEvent* EventPtr = ComboGraphEventHandlers.Find(Event))
	{
		EventPtr->Broadcast(Payload);
	}
}

FDelegateHandle UComboGraphSystemComponent::AddComboGraphEventHandler(FGameplayTag Event, FComboGraphEventHandler Handler)
{
	FComboGraphEvent& EventRef = ComboGraphEventHandlers.FindOrAdd(Event);
	return EventRef.Add(MoveTemp(Handler));
}

void UComboGraphSystemComponent::RemoveComboGraphEventHandler(FGameplayTag Event, FDelegateHandle Handle)
{
	if (FComboGraphEvent* EventPtr = ComboGraphEventHandlers.Find(Event))
	{
		EventPtr->Remove(Handle);
	}
}

void UComboGraphSystemComponent::RemoveComboGraphEventHandler(FGameplayTag Event, const void* UserObject)
{
	if (FComboGraphEvent* EventPtr = ComboGraphEventHandlers.Find(Event))
	{
		EventPtr->RemoveAll(UserObject);
	}
}

void UComboGraphSystemComponent::RemoveComboGraphEventHandler(const void* UserObject)
{
	for (auto& Pair : ComboGraphEventHandlers)
	{
		Pair.Value.RemoveAll(UserObject);
	}
}

void UComboGraphSystemComponent::OnStartComboGraphInputReceived(int32 GraphID, const UComboGraphEdge* Edge)
{
}

void UComboGraphSystemComponent::OnStartComboGraphEventReceived(FComboGraphEventPayload* Payload, int32 GraphID, FGameplayTag InitialInput)
{
	StartComboGraph(GraphID, InitialInput);
}

bool UComboGraphSystemComponent::InternalStartComboGraph(UComboGraphData* Graph, const FComboGraphInput& InitialInput)
{
	if (!Graph)
	{
		CG_RUNTIME_SLOG(Error, TEXT("Provided Combo Graph asset is invalid."));
		return false;
	}

	if (ActivatingComboGraph)
	{
		const IGameplayTagAssetInterface* TagContainer = Cast<IGameplayTagAssetInterface>(GetOwner());
		if (!TagContainer)
		{
			return false;
		}

		// 已经有ComboGraph正在运行, 需要获取这次输入会触发的下一个节点, 然后让当前正在运行的Graph判断自己是否能被这个节点打断
		TArray<const UComboGraphEdge*> EntryEdges;
		if (!Graph->GetEntryTransition(InitialInput, EntryEdges))
		{
			// 没有合法的Transition
			return false;
		}

		bool CanInterrupt = false;
		for (const UComboGraphEdge* NextEdge : EntryEdges)
		{
			// 打断上一个Graph一定要当前就满足跳转条件(没有输入缓存逻辑)
			if (!NextEdge->IsTransitionRequirementMatched(TagContainer))
			{
				continue;
			}

			if (ActivatingComboGraph->CanInterruptBy(NextEdge->EndNode.Get<UComboGraphNodeData>()))
			{
				CanInterrupt = true;
				break;
			}
		}

		if (!CanInterrupt)
		{
			CG_RUNTIME_LOG(Verbose, TEXT("Start ComboGraph %s with input %s failed, activating graph %s can't interrupt"), *GetNameSafe(Graph), *InitialInput.ToString(), *GetNameSafe(ActivatingComboGraph));
			return false;
		}

		CG_RUNTIME_LOG(Verbose, TEXT("Activating ComboGraph %s interrupted by %s "), *GetNameSafe(ActivatingComboGraph), *GetNameSafe(Graph));
		ActivatingComboGraph->EndGraph();
	}

	const TSharedPtr<FComboGraphContext> Context = MakeGraphContext(Graph);
	if (!Context)
	{
		CG_RUNTIME_LOG(Warning, TEXT("Make Graph Context failed."));
		return false;
	}

	UComboGraph* RuntimeGraph = UComboGraph::Make(this, Graph, Context);
	if (!RuntimeGraph)
	{
		CG_RUNTIME_LOG(Error, TEXT("Make Runtime Instance for Graph: %s failed."), *GetNameSafe(Graph));
		return false;
	}

	if (FString FailReason; !RuntimeGraph->BeginGraph(FailReason, InitialInput))
	{
		CG_RUNTIME_LOG(Warning, TEXT("UComboGraphSystemComponent::InternalStartComboGraph - Start Combo Graph failed. Reason: %s"), *FailReason);
		return false;
	}

	ActivatingComboGraph = RuntimeGraph;
	return true;
}

void UComboGraphSystemComponent::InternalTickComboGraph(float DeltaTime)
{
	if (ActivatingComboGraph)
	{
		// TickGraph返回这个Graph是否仍处于活动状态
		if (!ActivatingComboGraph->TickGraph(DeltaTime))
		{
			ActivatingComboGraph = nullptr;
		}
	}
}

TSharedPtr<FComboGraphContext> UComboGraphSystemComponent::MakeGraphContext(UComboGraphData* Graph)
{
	return MakeShared<FComboGraphContext>(this);
}

void UComboGraphSystemBlueprintLibrary::SendEventToComboGraph(const AActor* Owner, FGameplayTag Event)
{
	UComboGraphSystemComponent::SendEvent(Owner, Event);
}
