﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#include "Graph/ComboGraphEdge.h"

#include "GameplayTagAssetInterface.h"
#include "Graph/ComboGraphNodeBase.h"
#include "Graph/ComboGraphNodeEntry.h"

bool UComboGraphEdge::IsTransitionRequirementMatched(const IGameplayTagAssetInterface* TagContainer) const
{
	if (!TagContainer)
	{
		return false;
	}

	FGameplayTagContainer OwnerTags;
	TagContainer->GetOwnedGameplayTags(OwnerTags);

	if (OwnerTags.HasAny(TransitionBlockedTags))
	{
		return false;
	}

	if (!OwnerTags.HasAll(TransitionRequiredTags))
	{
		return false;
	}

	return true;
}

bool UComboGraphEdge::TransImmediately() const
{
	return TransitionBehavior == EComboGraphTransitionBehavior::Immediately;
}

bool UComboGraphEdge::IsInputMatch(const FComboGraphInput& Input) const
{
	if (Input.Type != TransitionInputType)
	{
		return false;
	}

	if (Input.Type == EComboGraphTransitionInputType::InputAction)
	{
		return Input.InputAction == TransitionInputAction && Input.InputTriggerEvent == GetEnhancedInputTriggerEvent();
	}

	if (Input.Type == EComboGraphTransitionInputType::InputEvent)
	{
		return Input.InputEvent == TransitionInputEvent;
	}

	return false;
}

FGameplayTag UComboGraphEdge::GetTransitionComboTrigger() const
{
	switch (TransitionBehavior)
	{
	case EComboGraphTransitionBehavior::Immediately:
		return FGameplayTag();
	case EComboGraphTransitionBehavior::OnNotifyTrigger:
		return TransitionComboTrigger;
	case EComboGraphTransitionBehavior::OnComboWindowEnd:
		return FComboGraphNativeTags::ComboEndEvent;
	}

	checkNoEntry();
	return FGameplayTag();
}

ETriggerEvent UComboGraphEdge::GetEnhancedInputTriggerEvent() const
{
	// Convert out internal enum to the real Input Trigger Event for Enhanced Input
	switch (TransitionInputActionEvent)
	{
	case EComboGraphTransitionInputActionEvent::Started:
		return ETriggerEvent::Started;
	case EComboGraphTransitionInputActionEvent::Triggered:
		return ETriggerEvent::Triggered;
	case EComboGraphTransitionInputActionEvent::Canceled:
		return ETriggerEvent::Canceled;
	}

	return ETriggerEvent::None;
}

bool UComboGraphEdge::IgnoreComboWindow() const
{
	switch (TransitionInputType)
	{
	case EComboGraphTransitionInputType::InputAction:
		return TransitionInputActionEvent == EComboGraphTransitionInputActionEvent::Canceled;
	case EComboGraphTransitionInputType::InputEvent:
		return false;
	case EComboGraphTransitionInputType::Timeout:
		return true;
	default:
		return false;
	}
}

FString UComboGraphEdge::ToString() const
{
	switch (TransitionInputType)
	{
	case EComboGraphTransitionInputType::InputAction:
		return FString::Printf(TEXT("%s - %s"), *UEnum::GetValueAsString(TransitionInputType), *GetNameSafe(TransitionInputAction));
	case EComboGraphTransitionInputType::InputEvent:
		return FString::Printf(TEXT("%s - %s"), *UEnum::GetValueAsString(TransitionInputType), *TransitionInputEvent.ToString());
	case EComboGraphTransitionInputType::Timeout:
		return TEXT("Timeout");
	}

	return TEXT("Invalid");
}

#if WITH_EDITOR

void UComboGraphEdge::PostLoad()
{
	UObject::PostLoad();

	if (GetOuter() && GetOuter()->IsA(UComboGraphNodeEntryData::StaticClass()))
	{
		TransitionBehavior = EComboGraphTransitionBehavior::Immediately;
	}
}

void UComboGraphEdge::PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent)
{
	UObject::PostEditChangeProperty(PropertyChangedEvent);

	const FName PropertyName = PropertyChangedEvent.Property->GetFName();
	if (PropertyName == GET_MEMBER_NAME_CHECKED(UComboGraphEdge, TransitionInputType))
	{
		if (TransitionInputType == EComboGraphTransitionInputType::InputAction)
		{
			TransitionInputEvent = FGameplayTag();
		}
		else
		{
			TransitionInputAction = nullptr;
			TransitionInputActionEvent = EComboGraphTransitionInputActionEvent::Triggered;
		}
	}
}

bool UComboGraphEdge::CanEditChange(const FProperty* InProperty) const
{
	const FName PropertyName = InProperty ? InProperty->GetFName() : NAME_None;

	if (GetOuter() && GetOuter()->IsA(UComboGraphNodeEntryData::StaticClass()))
	{
		if (PropertyName == GET_MEMBER_NAME_CHECKED(UComboGraphEdge, TransitionBehavior))
		{
			return false;
		}
	}

	return UObject::CanEditChange(InProperty);
}

void UComboGraphEdge::SetNodeTitle(const FText& InTitle)
{
	NodeTitle = InTitle;
}

#endif
