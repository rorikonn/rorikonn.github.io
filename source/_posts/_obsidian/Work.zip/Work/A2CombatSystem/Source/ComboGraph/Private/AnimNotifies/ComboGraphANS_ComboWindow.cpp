// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "AnimNotifies/ComboGraphANS_ComboWindow.h"

#include "Components/ComboGraphSystemComponent.h"
#include "Components/SkeletalMeshComponent.h"
#include "Utils/ComboGraphUtils.h"

#if ENGINE_MAJOR_VERSION == 5

void UComboGraphANS_ComboWindow::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, float TotalDuration, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration, EventReference);
	
	static FComboGraphEventPayload_ComboWindow Payload;
	Payload.RelevantSequence = Animation;
	UComboGraphSystemComponent::SendEvent(MeshComp, FComboGraphNativeTags::ComboBeginEvent, &Payload);
}

void UComboGraphANS_ComboWindow::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const FAnimNotifyEventReference& EventReference)
{
	Super::NotifyEnd(MeshComp, Animation, EventReference);
	
	static FComboGraphEventPayload_ComboWindow Payload;
	Payload.RelevantSequence = Animation;
	UComboGraphSystemComponent::SendEvent(MeshComp, FComboGraphNativeTags::ComboEndEvent, &Payload);
}

#else

void UComboGraphANS_ComboWindow::NotifyBegin(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation, const float TotalDuration)
{
	Super::NotifyBegin(MeshComp, Animation, TotalDuration);
}

void UComboGraphANS_ComboWindow::NotifyEnd(USkeletalMeshComponent* MeshComp, UAnimSequenceBase* Animation)
{
	Super::NotifyEnd(MeshComp, Animation);
}

#endif
