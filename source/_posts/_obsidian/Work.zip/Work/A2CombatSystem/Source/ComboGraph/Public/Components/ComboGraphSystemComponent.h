﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Graph/ComboGraphContext.h"
#include "ComboGraphSystemComponent.generated.h"

class UComboGraph;
class UInputAction;
class UComboGraphData;

/**
 * 
 */
UCLASS(ClassGroup=ComboGraph, HideCategories=(Object, LOD, Lighting, Transform, Sockets, TextureStreaming), meta=(BlueprintSpawnableComponent))
class COMBOGRAPH_API UComboGraphSystemComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	static UComboGraphSystemComponent* GetFromOwner(const AActor* Owner);

	UComboGraphSystemComponent(const FObjectInitializer& ObjectInitializer);

	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

protected:
	virtual void OnRegister() override;

public:
	UFUNCTION(BlueprintCallable, meta=(DisplayName="Start Combo Graph", Tooltips="手动触发一个ComboGraph, 通常用于没有学会的Graph, 学会的ComboGraph会自动监听入口节点的输入触发"))
	void BP_StartComboGraph(int32 GraphID, FComboGraphInput InitialInput);
	
	void StartComboGraph(int32 GraphID, const UInputAction* InitialInput, ETriggerEvent TriggerEvent = ETriggerEvent::Started);
	void StartComboGraph(int32 GraphID, FGameplayTag InitialInput);

	UFUNCTION(BlueprintCallable, meta=(Tooltips="监听ComboGraph入口节点的输入, 自动触发ComboGraph"))
	void LearnComboGraph(int32 GraphID);

	UFUNCTION(BlueprintCallable, meta=(Tooltips="停止监听ComboGraph的入口输入"))
	void ForgetComboGraph(int32 GraphID);

	static void SendEvent(const AActor* Owner, FGameplayTag Event, FComboGraphEventPayload* Payload = nullptr);
	static void SendEvent(const UActorComponent* Owner, FGameplayTag Event, FComboGraphEventPayload* Payload = nullptr);

	void HandleComboGraphEvent(FGameplayTag Event, FComboGraphEventPayload* Payload);
	
	template<typename... ArgTypes>
	FDelegateHandle AddComboGraphEventHandler(FGameplayTag Event, ArgTypes&&... Args)
	{
		return AddComboGraphEventHandler(Event, FComboGraphEventHandler::CreateUObject(Forward<ArgTypes>(Args)...));
	}
	
	FDelegateHandle AddComboGraphEventHandler(FGameplayTag Event, FComboGraphEventHandler Handler);
	void RemoveComboGraphEventHandler(FGameplayTag Event, FDelegateHandle Handle);
	void RemoveComboGraphEventHandler(FGameplayTag Event, const void* UserObject);
	void RemoveComboGraphEventHandler(const void* UserObject);

private:
	void OnStartComboGraphInputReceived(int32 GraphID, const UComboGraphEdge* Edge);
	void OnStartComboGraphEventReceived(FComboGraphEventPayload* Payload, int32 GraphID, FGameplayTag InitialInput);
	
	bool InternalStartComboGraph(UComboGraphData* Graph, const FComboGraphInput& InitialInput);
	void InternalTickComboGraph(float DeltaTime);

	TSharedPtr<FComboGraphContext> MakeGraphContext(UComboGraphData* Graph);

	UPROPERTY(Transient)
	UComboGraph* ActivatingComboGraph;

	TMap<FGameplayTag, FComboGraphEvent> ComboGraphEventHandlers;
	TSet<int32> LearnedComboGraphs;
	TMap<int32, TArray<uint32>> ComboGraphInputActionBindings;
	TMap<int32, TArray<FGameplayTag>> ComboGraphInputEventBindings;
};

UCLASS()
class COMBOGRAPH_API UComboGraphSystemBlueprintLibrary : public UBlueprintFunctionLibrary
{
	GENERATED_BODY()

public:
	UFUNCTION(BlueprintCallable, Category="ComboGraph")
	static void SendEventToComboGraph(const AActor* Owner, FGameplayTag Event);
};
