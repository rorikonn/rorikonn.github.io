﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphRuntimeTypes.h"
#include "Layout/Margin.h"
#include "UObject/Object.h"
#include "ComboGraphProjectSettings.generated.h"

class UDataTable;
class UInputMappingContext;


UCLASS(Config = Game, DefaultConfig)
class COMBOGRAPH_API UComboGraphProjectSettings : public UObject
{
	GENERATED_BODY()

public:
	UComboGraphProjectSettings();

	/** Default background color for Sequence nodes */
	UPROPERTY(Config, EditAnywhere, Category="Colors")
	FLinearColor DefaultNodeColor;
	
	UPROPERTY(Config, EditAnywhere, Category="Colors")
	FLinearColor DisableNodeColor;

	/** Default background color for Montage nodes */
	UPROPERTY(Config, EditAnywhere, Category="Colors")
	FLinearColor MontageNodeColor;

	/** Default background color for combo nodes in active states (during debug) */
	UPROPERTY(Config, EditAnywhere, Category="Colors")
	FLinearColor DebugActiveColor;

	/**
	 * The duration used to interpolate the background color of nodes from Active to Default color when active states change (no longer active during debug).
	 *
	 * If set to 0.0, will disable color interpolation.
	 */
	UPROPERTY(Config, EditAnywhere, Category="Debug", meta=(ClampMin="0.0"))
	float DebugFadeTime;

	/** The padding around the main node box. */
	UPROPERTY(Config, EditAnywhere, Category="Size & Paddings")
	FMargin ContentMargin;

	/** The padding within the main node box. */
	UPROPERTY(Config, EditAnywhere, Category="Size & Paddings")
	FMargin ContentInternalPadding;

	/** The minimum desired sizes for pin connections. */
	UPROPERTY(Config, EditAnywhere, Category="Size & Paddings", meta=(ClampMin="20.0"))
	float PinSize = 20.f;

	/** The minimum amount of padding to draw around pin connections. */
	UPROPERTY(Config, EditAnywhere, Category="Size & Paddings", meta=(ClampMin="0.0"))
	float PinPadding = 20.f;

	/** Enhanced Input Context Mapping to use to draw edge (transition) icons in Graphs */
	UPROPERTY(Config, EditAnywhere, Category="Icons")
	TSoftObjectPtr<UInputMappingContext> ContextMapping;

	/**
	 * Path to the DataTable used to draw edge (transition) icons in Graph. Determine mappings between Keys and Icon textures.
	 */
	UPROPERTY(Config, EditDefaultsOnly, Category="Icons", meta=(RequiredAssetDataTags="RowStructure=/Script/ComboGraphEditor.ComboGraphInputsMetaData"))
	TSoftObjectPtr<UDataTable> IconsDataTable;

	/** Icon preference to draw edge (transition) icons in Graph. Can be either Keyboard or Gamepad based */
	UPROPERTY(Config, EditDefaultsOnly, Category="Icons")
	EComboGraphIconType IconPreference = EComboGraphIconType::Keyboard;

	/** Size of Icons when drawing edges (transitions) in Combo Graphs */
	UPROPERTY(Config, EditAnywhere, Category="Icons", meta=(ClampMin="0.0", ClampMax="100.0"))
	float IconSize;

	/** The Slot Name to use with dynamic montages, created from sequences */
	UPROPERTY(Config, EditAnywhere, Category="Auto Setup")
	FName DynamicMontageSlotName;

	/** Flag to enable / disable message warnings (logs and on screen) about Sequences being used in a networked environment */
	UPROPERTY(Config, EditAnywhere, Category="Warnings", AdvancedDisplay)
	bool bSequencesNetworkedWarning = true;

	/** Flag to disable validation warnings on startup (about missing config for AbilitySystemGlobals). Config writable but not exposed in editor. */
	UPROPERTY(Config)
	bool bIgnoreStartupValidationWarnings = false;
};
