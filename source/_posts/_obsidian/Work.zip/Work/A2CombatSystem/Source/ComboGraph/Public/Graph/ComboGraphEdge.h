﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphRuntimeTypes.h"
#include "InputAction.h"
#include "InputTriggers.h"
#include "ComboGraphEdge.generated.h"

class IGameplayTagAssetInterface;
class UComboGraphNodeDataBase;
class UInputAction;

UCLASS(Blueprintable, AutoExpandCategories=("Combo Graph | Transition", "Combo Graph | Icons"))
class COMBOGRAPH_API UComboGraphEdge : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Combo Graph | Transition", DisplayName="Input Type")
	EComboGraphTransitionInputType TransitionInputType;

	/**
	 * 触发跳转的输入(InputAction)
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Combo Graph | Transition", DisplayName="Input",
		meta=(EditCondition = "TransitionInputType == EComboGraphTransitionInputType::InputAction", EditConditionHides))
	TObjectPtr<UInputAction> TransitionInputAction;

	/**
	 * 触发跳转的输入事件
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Combo Graph | Transition", DisplayName="Input",
		meta=(Categories="ComboGraph.InputEvent", EditCondition = "TransitionInputType == EComboGraphTransitionInputType::InputEvent", EditConditionHides))
	FGameplayTag TransitionInputEvent;

	/**
	 * 触发跳转InputAction的Trigger(触发时机根据InputAction的Trigger配置各有不同, Started一般为按下, Canceled是HoldAndRelease按下时间低于阈值的情况, Triggered都不太一样, 详细参见EnhancedInputSystem文档)
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category= "Combo Graph | Transition", DisplayName="Input Action Trigger",
		meta=(EditCondition = "TransitionInputType == EComboGraphTransitionInputType::InputAction", EditConditionHides))
	EComboGraphTransitionInputActionEvent TransitionInputActionEvent = EComboGraphTransitionInputActionEvent::Started;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Combo Graph | Transition", DisplayName="Timeout Time",
		meta=(EditCondition = "TransitionInputType == EComboGraphTransitionInputType::Timeout", EditConditionHides, ClampMin=0.01))
	float TimeoutTime = 1.0f;

	/**
	 * 输入满足后什么时机跳转
	 * 1. Immediately 立即跳转
	 * 2. OnNotifyTrigger 在特定的ComboGraphTrigger触发之后跳转(如果输入在之前到达, 会延后到ComboGraphTrigger触发的时候跳转, 如果在之后到达, 则会立刻跳转)
	 * 3. OnComboWindowEnd 在ComboWindow的末尾跳转
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category= "Combo Graph | Transition", meta=(EditConditionHides))
	EComboGraphTransitionBehavior TransitionBehavior = EComboGraphTransitionBehavior::Immediately;

	/**
	 * 当TransitionBehavior配置为OnNotifyTrigger的时候, 这个Tag与具体的那个NotifyTrigger配置的Tag对应(应对一个技能有多个不同的Trigger处理不同招式的跳转时机)
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category= "Combo Graph | Transition", DisplayName="Combo Trigger",
		meta=(EditCondition = "TransitionBehavior == EComboGraphTransitionBehavior::OnNotifyTrigger", EditConditionHides, Categories="ComboGraph.Trigger"))
	FGameplayTag TransitionComboTrigger = FComboGraphNativeTags::DefaultComboTrigger;

	/**
	 * Transition的跳转条件, Caster身上有列出的所有Tag时满足
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category= "Combo Graph | Transition")
	FGameplayTagContainer TransitionRequiredTags;

	/**
	 * Transition的跳转条件, Caster身上没有任意一个Tag时满足
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category= "Combo Graph | Transition")
	FGameplayTagContainer TransitionBlockedTags;

	/**
	* 优先级越大越优先触发
	*/
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category= "Combo Graph | Transition", meta=(Tooltip="越大越优先"))
	int32 Priority = 0;

	/** Start or parent node for this edge */
	UPROPERTY()
	FComboGraphNodeReference StartNode;

	/** End or child node for this edge */
	UPROPERTY()
	FComboGraphNodeReference EndNode;

	bool IsTransitionRequirementMatched(const IGameplayTagAssetInterface* TagContainer) const;

	bool TransImmediately() const;
	bool IsInputMatch(const FComboGraphInput& Input) const;

	FGameplayTag GetTransitionComboTrigger() const;

	/** Returns the enhanced input event to consider for transitioning nodes */
	ETriggerEvent GetEnhancedInputTriggerEvent() const;

	/** Returns whether configured trigger event for this Edge is set on Canceled event */
	bool IgnoreComboWindow() const;

	FString ToString() const;

#if WITH_EDITORONLY_DATA
	FText NodeTitle;

	UPROPERTY(EditDefaultsOnly, Category = "Combo Graph | Icons")
	FLinearColor EdgeColour = FLinearColor(0.9f, 0.9f, 0.9f, 1.0f);
#endif

#if WITH_EDITOR
	virtual void PostLoad() override;
	virtual void PostEditChangeProperty(FPropertyChangedEvent& PropertyChangedEvent) override;
	virtual bool CanEditChange(const FProperty* InProperty) const override;
	virtual FText GetNodeTitle() const { return NodeTitle; }
	FLinearColor GetEdgeColour() const { return EdgeColour; }
	virtual void SetNodeTitle(const FText& InTitle);
#endif
};
