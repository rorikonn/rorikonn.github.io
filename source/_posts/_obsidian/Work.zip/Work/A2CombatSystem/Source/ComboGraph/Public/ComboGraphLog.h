﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/Engine.h"
#include "CommonLog.h"

COMBOGRAPH_API DECLARE_LOG_CATEGORY_EXTERN(LogComboGraph, Display, All);

#define CG_RUNTIME_LOG(Verbosity, Format, ...) COMMON_LOG(LogComboGraph, Verbosity, Format, ##__VA_ARGS__)
#define CG_RUNTIME_CLOG(Condition, Verbosity, Format, ...) COMMON_CLOG(LogComboGraph, Condition, Verbosity, Format, ##__VA_ARGS__)
#define CG_RUNTIME_SLOG(Verbosity, Format, ...) COMMON_SLOG(LogComboGraph, Verbosity, Format, ##__VA_ARGS__)

