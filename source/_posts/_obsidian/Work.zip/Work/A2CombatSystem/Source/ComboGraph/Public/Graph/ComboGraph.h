﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphContext.h"
#include "ComboGraphEdge.h"
#include "ComboGraphRuntimeTypes.h"
#include "DataArchive.h"
#include "UObject/Object.h"
#include "Templates/SubclassOf.h"
#include "Interfaces/Interface_PreviewMeshProvider.h"
#include "ComboGraph.generated.h"


struct FInputActionInstance;
class UComboGraph;
class UComboGraphNode;
struct FComboGraphContext;
class UInputMappingContext;
class UInputAction;
class UComboGraphNodeSequence;
class UComboGraphNodeMontageData;
class UComboGraphNodeEntryData;
class UComboGraphNodeData;
class UComboGraphEdge;
class UComboGraphNodeDataBase;


/** Last Selected Editor App Mode */
UENUM()
enum class EComboGraphSelectedAppMode : uint8
{
	/** Persona Mode */
	Persona UMETA(DisplayName="Persona Preview Mode"),

	/** Graph Mode */
	Graph UMETA(DisplayName="Combo Graph Mode"),
};

/**
 * Combo Graph Assets provide a way to visually design combo strings and link montages together.
 *
 * Combo Graphs are then run with custom Ability Tasks from within a Gameplay Ability.
 */
UCLASS(BlueprintType, AutoExpandCategories=("Combo Graph | Nodes", "Combo Graph | Transitions", "Combo Graph | Icons"))
class COMBOGRAPH_API UComboGraphData : public UObject, public IInterface_PreviewMeshProvider
{
	GENERATED_BODY()

public:
	UComboGraphData();

	UPROPERTY()
	FComboGraphID ID;

	UPROPERTY()
	FString Name;

	UPROPERTY()
	FString Description;

	UPROPERTY()
	FString Category;

	UPROPERTY()
	FComboGraphNodeReference EntryNode;

	UPROPERTY()
	TArray<FComboGraphNodeReference> AllNodes;

	bool GetEntryTransition(const FComboGraphInput& InitialInput, TArray<const UComboGraphEdge*>& OutEdges) const;

	void ClearGraph();

	//~ IInterface_PreviewMeshProvider
	virtual void SetPreviewMesh(USkeletalMesh* PreviewMesh, bool bMarkAsDirty) override;
	virtual USkeletalMesh* GetPreviewMesh() const override;
	//~ End IInterface_PreviewMeshProvider

#if WITH_EDITORONLY_DATA
	/** Last selected app mode, stored here to persist across re-opening and restart of the editor */
	UPROPERTY(VisibleDefaultsOnly, Category = "Combo Graph", meta=(HideInComboGraphDetailsPanel))
	EComboGraphSelectedAppMode SelectedAppMode = EComboGraphSelectedAppMode::Persona;

	// UPROPERTY(EditDefaultsOnly, Category = "Combo Graph")
	bool bCanRenameNode = true;

	/** Determine if we can have cycles or not in a graph */
	UPROPERTY(EditDefaultsOnly, Category = "Combo Graph | Transitions")
	bool bCanBeCyclical = true;

	/** Enhanced Input Context Mapping to use to draw edge (transition) icons in Graphs (if not set, will fallback to the one defined in Project Settings) */
	UPROPERTY(EditDefaultsOnly, Category = "Combo Graph | Icons")
	TSoftObjectPtr<UInputMappingContext> ContextMapping;

	/** Icon preference to draw edge (transition) icons in Graph. Can be either Keyboard or Gamepad based */
	UPROPERTY(EditDefaultsOnly, Category = "Combo Graph | Icons")
	EComboGraphIconType IconPreference;

private:
	/** The default skeletal mesh to use when previewing this asset */
	UPROPERTY(duplicatetransient, AssetRegistrySearchable)
	TSoftObjectPtr<class USkeletalMesh> PreviewSkeletalMesh;
#endif
};

template <>
struct TDataArchiveInfo<UComboGraphData> : TDataArchiveInfoBase<UComboGraphData>
{
	static FComboGraphID& GetKeyFromData(UComboGraphData* Data)
	{
		static FComboGraphID InvalidKey;
		return Data ? Data->ID : InvalidKey;
	}

	static FString GetArchiveTableName()
	{
		return TEXT("ComboGraph");
	}

	static FString GetArchiveCategory(const UComboGraphData* Data)
	{
		FString Category = TEXT("Default");
		if (Data && !Data->Category.IsEmpty())
		{
			Category = Data->Category;
		}

		return Category;
	}
};

UCLASS()
class COMBOGRAPH_API UComboGraph : public UObject
{
	GENERATED_BODY()

public:
	static UComboGraph* Make(UObject* Outer, UComboGraphData* Data, const TSharedPtr<FComboGraphContext>& InContext);

	void Initialize(UComboGraphData* Graph, TSharedPtr<FComboGraphContext> InContext);

	bool BeginGraph(FString& FailReason, const FComboGraphInput& InitialInput);
	bool TickGraph(float DeltaTime);
	void EndGraph();

	AActor* GetAvatarActor() const;
	UComboGraphNode* GetCurrentNode() const;
	const UComboGraphNodeData* GetCurrentNodeData() const;

	bool CanInterruptBy(const UComboGraphNodeData* NextNode) const;

private:
	bool AdvanceNextNode(const UComboGraphNodeData* NextNodeData, FString& FailReason);

	void ReceivedInputActionConfirm(const FInputActionInstance& InputActionInstance, const UComboGraphEdge* Edge);
	void ReceivedInputEventConfirm(FComboGraphEventPayload* Payload, const UComboGraphEdge* Edge);
	void ReceivedInputConfirm(const UComboGraphEdge* Edge);
	void HandleInputConfirmed(const UComboGraphEdge* Edge);
	void HandleComboTransitionWithTrigger(const FGameplayTag& TriggerEvent);
	void HandleComboTransition(const UComboGraphEdge* Edge, int32 TriggerIndex = 0, float PendingTime = 0.2f);
	void FlushPendingTransition(float DeltaTime);

	void SetupTransitionInputBindings();
	void ClearTransitionInputBindings();

	void SetupEventHandlers();
	void ClearEventHandlers();

	void OnComboBegin(FComboGraphEventPayload* Payload);
	void OnComboEnd(FComboGraphEventPayload* Payload);
	void OnComboTriggerBegin(FComboGraphEventPayload* Payload);
	void OnComboTriggerEnd(FComboGraphEventPayload* Payload);

	void OnCurrentNodeCompleted();
	void OnCurrentNodeInterrupted();
	void OnCurrentNodeCanceled();

	UComboGraphNode* GetRuntimeNode(const UComboGraphNodeData* NodeData);

	const UComboGraphNodeEntryData* GetEntryNode() const;

	void ResetComboState();
	void SetEdgeConfirmed(const UComboGraphEdge* Edge);
	bool IsEdgeConfirmed(const UComboGraphEdge* Edge) const;

	FORCEINLINE bool IsComboWindowOpened() const { return Context && Context->IsComboWindowOpened(); }
	void BeginTransitionTrigger(FGameplayTag Trigger);
	void EndTransitionTrigger(FGameplayTag Trigger);

	TSharedPtr<FComboGraphContext> Context;

	UPROPERTY(Transient)
	TObjectPtr<UComboGraphData> ReferenceData;

	UPROPERTY(Transient)
	TObjectPtr<UComboGraphNode> CurrentNode;

	// 在ComboWindow期间，满足了TransitionBehavior(Immediate/OnNotifyTrigger/OnComboWindowEnd)的Transition, 满足跳转条件就可以出发跳转了
	struct FPendingTransition
	{
		FPendingTransition(const UComboGraphEdge* Edge, int32 TriggerIndex, float RemainTime)
			: Edge(Edge),
			  RemainTime(RemainTime)
		{
			ensureMsgf(TriggerIndex < 8, TEXT("Only 8 trigger event is supported in a single skill"));
			// 最低三位存储TriggerIndex, 策划配的优先级保存在其他高位上
			Priority = (Edge->Priority << 3) + TriggerIndex;
		}

		friend bool operator <(const FPendingTransition& Lhs, const FPendingTransition& Rhs)
		{
			return Lhs.Priority < Rhs.Priority;
		}

		TWeakObjectPtr<const UComboGraphEdge> Edge;
		int32 Priority;
		// 在输入窗口期间, 短时间内条件不满足不会立即失败, 会缓存一小段时间用于优化输入手感, 这个时间很小通常在0.1 ~ 0.2左右
		float RemainTime;
	};

	TArray<FPendingTransition> PendingTransitions;

	UPROPERTY(Transient)
	TMap<const UComboGraphNodeData*, UComboGraphNode*> RuntimeNodeMap;

	UPROPERTY(Transient)
	TSet<const UComboGraphEdge*> ConfirmedEdges;

	UPROPERTY(Transient)
	const UComboGraphEdge* TimeoutEdge;

	TArray<TObjectPtr<const UComboGraphEdge>> QueuedTransitionEdges;

	TArray<uint32> InputActionHandles;
	TArray<FGameplayTag> InputEventBindings;

	TArray<FGameplayTag> ActivatingTrigger;

	uint8 bActivating : 1;
};
