// Fill out your copyright notice in the Description page of Project Settings.


#include "Skill/EnhancedSkillContext.h"

#include "AbilitySystemComponent.h"
#include "AbilitySystemGlobals.h"
#include "CombatMotionWarpingComponent.h"
#include "CombatTargetingModule.h"
#include "EnhancedAbilityWorld.h"
#include "EnhancedAbilitySystemComponent.h"
#include "GameFramework/Character.h"
#include "GameFramework/PawnMovementComponent.h"

FEnhancedSkillContext::FEnhancedSkillContext(FEnhancedSkillHandle Handle, const UEnhancedAbilitySystemComponent* CasterComponent, const UEnhancedSkillData* SkillData)
	: CurrentStage(),
	  Handle(Handle),
	  ReferenceData(SkillData),
	  RootMotionInstanceID(0)
{
	if (CasterComponent)
	{
		Caster = FCombatTarget::MakeFromActor(CasterComponent->GetOwner());
	}

	SetupContext();
}

FEnhancedSkillHandle FEnhancedSkillContext::GetHandle() const
{
	return Handle;
}

FSkillID FEnhancedSkillContext::GetSkillID() const
{
	return ReferenceData ? ReferenceData->ID : FSkillID();
}

const UEnhancedSkillData* FEnhancedSkillContext::GetSkillData() const
{
	return ReferenceData;
}

AActor* FEnhancedSkillContext::GetCasterActor() const
{
	return Caster.GetActor();
}

FTransform FEnhancedSkillContext::GetCasterInitialTransform() const
{
	return Caster.GetInitialTransform();
}

FCombatTarget FEnhancedSkillContext::GetTarget() const
{
	return Target;
}

UWorld* FEnhancedSkillContext::GetWorld() const
{
	return OwningWorld ? OwningWorld->GetWorld() : nullptr;
}

UEnhancedAbilityWorld* FEnhancedSkillContext::GetAbilityWorld() const
{
	return OwningWorld;
}

AController* FEnhancedSkillContext::GetController() const
{
	if (const APawn* OwnerPawn = Cast<APawn>(GetCasterActor()))
	{
		return OwnerPawn->GetController();
	}

	return nullptr;
}

APlayerController* FEnhancedSkillContext::GetPlayerController() const
{
	return Cast<APlayerController>(GetController());
}

UEnhancedAbilitySystemComponent* FEnhancedSkillContext::GetAbilityComponent() const
{
	return UEnhancedAbilitySystemComponent::GetFromOwner(GetCasterActor());
}

UAnimInstance* FEnhancedSkillContext::GetAnimInstance() const
{
	return OwnerAnimInstance;
}

UPawnMovementComponent* FEnhancedSkillContext::GetMovementComponent() const
{
	if (const APawn* OwnerPawn = Cast<APawn>(GetCasterActor()))
	{
		return OwnerPawn->GetMovementComponent();
	}

	return nullptr;
}

ENetRole FEnhancedSkillContext::GetLocalNetRole() const
{
	return GetCasterActor() ? GetCasterActor()->GetLocalRole() : ROLE_None;
}

bool FEnhancedSkillContext::IsLocallyControlled() const
{
	if (const APlayerController* PlayerController = Cast<APlayerController>(GetCasterActor()))
	{
		return PlayerController->IsLocalController();
	}

	if (const APawn* PawnOwner = Cast<APawn>(GetCasterActor()))
	{
		return PawnOwner->IsLocallyControlled();
	}

	if (HasAuthority())
	{
		return true;
	}

	return false;
}

bool FEnhancedSkillContext::HasAuthority() const
{
	return GetLocalNetRole() == ROLE_Authority;
}

bool FEnhancedSkillContext::PreCheck(FString* FailReason)
{
	Target = EventData.GetInitialTarget();

	if (!Target.IsValid())
	{
		Target = PerformTargeting();
	}

	if (ReferenceData->bTargetingGround)
	{
		Target.SetProjectToGround(true);
	}

	return true;
}

bool FEnhancedSkillContext::CommitSkill(FString* FailReason)
{
	return true;
}

// ReSharper disable once CppMemberFunctionMayBeConst
void FEnhancedSkillContext::OnSkillBegin()
{
	OnEnterSkillStage(EEnhancedSkillStage::Begin);
}

void FEnhancedSkillContext::Terminate(EEnhancedSkillStage Stage)
{
	if (!ensure(Stage != EEnhancedSkillStage::Begin))
	{
		return;
	}

	if (IsTerminated())
	{
		return;
	}

	CurrentStage = Stage;
	OnEnterSkillStage(Stage);


	/** TODO(jimmyzou):
	 * 这里不能直接上行打断结果, 要上行打断的原因, 然后服务器校验一次是否能打断
	 * 执行到这里时, 客户端已经完成了打断逻辑了, 但是如果服务器判断不能被打断, 目前是无法回滚到打断之前的状态的
	 * 所以要么打断行为要延后到服务器回包之后(影响操作手感)
	 * 要么这里需要保存打断时的快照, 这样如果失败可以回滚状态(怎么回滚也是个挺麻烦的事情, 还涉及到回滚Sequence的运行状态)
	 * 或者干脆这种打断就信任客户端
	 */

	// 打断事件需要广播, 第一方的打断会在上面先进行, 然后上行服务器(移动, 跳跃, ComboGraph等), 服务器的打断会进行广播
	if ((IsLocallyControlled() || HasAuthority()) && Stage == EEnhancedSkillStage::Interrupted)
	{
		GetAbilityComponent()->ServerInterruptSkill(GetHandle());
	}
}

bool FEnhancedSkillContext::CanInterruptBy(FGameplayTag InComingEvent) const
{
	// 移动打断要特殊处理, 因为不带RootMotion位移的技能不用被移动打断, 或者根据配置决定是否要被移动打断
	if (IsMovementEvent(InComingEvent) && !HasActiveRootMotion())
	{
		// 没有RootMotion的情况下这里返回true, 标识进来的这个Event是能够执行的, 至于当前这个技能要不要被打断, 由ProcessInterrupt决定
		return true;
	}

	return AllowedInterruptEvent.Contains(InComingEvent);
}

bool FEnhancedSkillContext::HandleInterruptEvent(FGameplayTag InComingEvent)
{
	if (!CanInterruptBy(InComingEvent))
	{
		return false;
	}

	// 移动行为的打断需要特殊处理
	if (IsMovementEvent(InComingEvent))
	{
		if (TerminateWhenInterruptByMovementEvent())
		{
			Terminate(EEnhancedSkillStage::Interrupted);

			// 移动打断技能需要保留当前的速度, 不然人物起步不流畅
			if (UPawnMovementComponent* MovementComponent = GetMovementComponent())
			{
				const float MaxSpeed = MovementComponent->GetMaxSpeed();
				MovementComponent->Velocity = MovementComponent->Velocity.GetSafeNormal() * FMath::Min(MaxSpeed, MovementComponent->Velocity.Length());
			}
		}
	}
	else
	{
		Terminate(EEnhancedSkillStage::Interrupted);
	}

	return true;
}

void FEnhancedSkillContext::EnableInterruptEvent(FGameplayTag InterruptEvent)
{
	if (!InterruptEvent.IsValid())
	{
		return;
	}

	AllowedInterruptEvent.Add(InterruptEvent);
}

void FEnhancedSkillContext::DisableInterruptEvent(FGameplayTag InterruptEvent)
{
	if (!InterruptEvent.IsValid())
	{
		return;
	}

	AllowedInterruptEvent.Remove(InterruptEvent);
}

bool FEnhancedSkillContext::TerminateWhenInterruptByMovementEvent() const
{
	// 目前先简单处理成, 有RootMotion就打断当前技能, 如果没有就不打断
	// 后续可能需要加配置开放给策划控制
	return HasActiveRootMotion();
}

bool FEnhancedSkillContext::IsMovementEvent(FGameplayTag InComingEvent)
{
	// Dodge虽然也是移动行为, 但是目前是用技能实现的, 所以Dodge不算MovementEvent
	return InComingEvent == SkillEvent_Move || InComingEvent == SkillEvent_Jump;
}

void FEnhancedSkillContext::BeginRootMotionMontage(int32 MontageInstanceID)
{
	if (RootMotionInstanceID != 0 && MotionWarpingComponent)
	{
		MotionWarpingComponent->RemoveMontageWarpTarget(RootMotionInstanceID);
	}

	RootMotionInstanceID = MontageInstanceID;

	if (MotionWarpingComponent && Target.IsValid())
	{
		MotionWarpingComponent->UpdateMontageWarpTarget(RootMotionInstanceID, Target);
	}
}

void FEnhancedSkillContext::EndRootMotionMontage(int32 MontageInstanceID)
{
	ensureMsgf(RootMotionInstanceID == MontageInstanceID, TEXT("Only one root motion animation is allowed to play in one skill context, other wise some unexpected error may happen, please check"));

	if (RootMotionInstanceID != 0 && MotionWarpingComponent)
	{
		MotionWarpingComponent->RemoveMontageWarpTarget(RootMotionInstanceID);
	}

	RootMotionInstanceID = 0;
}

bool FEnhancedSkillContext::HasActiveRootMotion() const
{
	if (!OwnerAnimInstance)
	{
		return false;
	}

	const FAnimMontageInstance* RootMotionInstance = OwnerAnimInstance->GetMontageInstanceForID(RootMotionInstanceID);
	if (!RootMotionInstance)
	{
		return false;
	}

	return RootMotionInstance->IsActive() && !RootMotionInstance->IsRootMotionDisabled();
}

int32 FEnhancedSkillContext::ActiveTransformSync(float RotateDuration, float TranslateDuration, const UAnimMontage* Montage) const
{
	if (MotionWarpingComponent)
	{
		return MotionWarpingComponent->SyncRootMotionInitialTransform(GetCasterInitialTransform(), RotateDuration, TranslateDuration, Montage);
	}

	return INDEX_NONE;
}

void FEnhancedSkillContext::SetupEventData(FEnhancedSkillEventDataContainer* InEventData)
{
	if (InEventData)
	{
		EventData = MoveTemp(*InEventData);
	}
}

void FEnhancedSkillContext::SetupEventHandler(FEnhancedSkillStageEventHandler* InEventHandler)
{
	if (InEventHandler)
	{
		EventHandler = MoveTemp(*InEventHandler);
	}
}

void FEnhancedSkillContext::AddEventHandler(EEnhancedSkillStage Stage, FEnhancedSkillStageEvent::FDelegate Handler)
{
	switch (Stage)
	{
	case EEnhancedSkillStage::Begin:
		EventHandler.OnSkillBegin.Add(MoveTemp(Handler));
		break;
	case EEnhancedSkillStage::Canceled:
		EventHandler.OnSkillCanceled.Add(MoveTemp(Handler));
		break;
	case EEnhancedSkillStage::Interrupted:
		EventHandler.OnSkillInterrupted.Add(MoveTemp(Handler));
		break;
	case EEnhancedSkillStage::Complete:
		EventHandler.OnSkillComplete.Add(MoveTemp(Handler));
		break;
	case EEnhancedSkillStage::Terminate:
		EventHandler.OnSkillTerminate.Add(MoveTemp(Handler));
		break;
	default: ;
	}
}

void FEnhancedSkillContext::ClearEventHandler(const UObject* UserObject)
{
	if (!UserObject)
	{
		EventHandler.Clear();
	}
	else
	{
		EventHandler.RemoveAll(UserObject);
	}
}

void FEnhancedSkillContext::SetupContext()
{
	if (AActor* CasterActor = GetCasterActor())
	{
		const USkeletalMeshComponent* AvatarMesh;
		if (const ACharacter* OwnerCharacter = Cast<ACharacter>(CasterActor))
		{
			AvatarMesh = OwnerCharacter->GetMesh();
		}
		else
		{
			AvatarMesh = CasterActor->FindComponentByClass<USkeletalMeshComponent>();
		}

		const UWorld* World = CasterActor->GetWorld();
		OwningWorld = World ? World->GetSubsystem<UEnhancedAbilityWorld>() : nullptr;
		OwnerAnimInstance = AvatarMesh ? AvatarMesh->GetAnimInstance() : nullptr;
		MotionWarpingComponent = UCombatMotionWarpingComponent::GetFromOwner(CasterActor);
	}
	else
	{
		OwningWorld = nullptr;
		OwnerAnimInstance = nullptr;
		MotionWarpingComponent = nullptr;
	}
}

void FEnhancedSkillContext::OnEnterSkillStage(EEnhancedSkillStage Stage) const
{
	switch (Stage)
	{
	case EEnhancedSkillStage::Begin:
		{
			UAbilitySystemComponent* ASC = UAbilitySystemGlobals::GetAbilitySystemComponentFromActor(GetCasterActor());
			if (ASC && ReferenceData)
			{
				ASC->AddLooseGameplayTag(ReferenceData->EventTag, 1);
			}

			EventHandler.OnSkillBegin.Broadcast();
			break;
		}
	case EEnhancedSkillStage::Canceled:
		EventHandler.OnSkillCanceled.Broadcast();
		break;
	case EEnhancedSkillStage::Interrupted:
		EventHandler.OnSkillInterrupted.Broadcast();
		break;
	case EEnhancedSkillStage::Complete:
		EventHandler.OnSkillComplete.Broadcast();
		break;
	case EEnhancedSkillStage::Terminate:
		{
			UAbilitySystemComponent* ASC = UAbilitySystemGlobals::GetAbilitySystemComponentFromActor(GetCasterActor());
			if (ASC && ReferenceData)
			{
				ASC->AddLooseGameplayTag(ReferenceData->EventTag, -1);
			}

			EventHandler.OnSkillTerminate.Broadcast();
			// Terminate之后就直接return了, 不然无限循环
			return;
		}
	default: ;
	}

	if (IsTerminated())
	{
		OnEnterSkillStage(EEnhancedSkillStage::Terminate);
	}
}

FCombatTarget FEnhancedSkillContext::PerformTargeting() const
{
	const ICombatTargetingSystem& TargetingSystem = ICombatTargetingSystem::Get();
	TArray<FCombatTarget> NearbyTargets;
	FCombatTargetFilter Filter;
	Filter.ActorsToIgnore = {GetCasterActor()};
	if (!TargetingSystem.ScanTargets(GetCasterActor(), GetCasterInitialTransform(), ReferenceData->TargetingRange, NearbyTargets, &Filter))
	{
		const FVector MovementInput = TargetingSystem.GetMovementInputDirection(GetPlayerController());
		return FCombatTarget::MakeFromDirection(MovementInput);
	}

	return NearbyTargets[0];
}

bool FEnhancedSkillContext::NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess)
{
	bOutSuccess = true;

	uint8 Terminated = bTerminated;
	Ar.SerializeBits(&Terminated, 1);
	bTerminated = Terminated & 1;

	Ar << CurrentStage;
	Ar << Caster;
	Ar << Target;

	Handle.NetSerialize(Ar, Map, bOutSuccess);

	if (!EventData.NetSerialize(Ar, Map, bOutSuccess))
	{
		return false;
	}

	uint8 DataValid = 0;
	FSkillID SkillID;
	if (ReferenceData)
	{
		SkillID = ReferenceData->ID;
		DataValid = 1;
	}

	Ar.SerializeBits(&DataValid, 1);

	if (DataValid)
	{
		SkillID.NetSerialize(Ar, Map, bOutSuccess);

		if (Ar.IsLoading())
		{
			ReferenceData = FDataArchiveManager::Find<UEnhancedSkillData>(SkillID);
		}
	}

	if (Ar.IsLoading())
	{
		SetupContext();
	}

	return bOutSuccess;
}
