﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Skill/EnhancedSkillAction.h"
#include "ComboGraphComboWindow.generated.h"

/**
 * 
 */
UCLASS(DisplayName="ComboGraph: Combo Window", meta=(SectionColor="51,158,250",
	ToolTip="在窗口期间允许接收下一段连招的输入, ComboGraphEdge的TransitionBehavior设置为OnComboWindowEnd的时候, 窗口期间接收到的输入会在窗口结束的时候被触发"))
class ENHANCEDABILITY_API UComboGraphComboWindowData : public UEnhancedSkillActionData
{
	GENERATED_BODY()
	GENERATED_UNIVERSAL_TIMELINE_BODY()
};

class FComboGraphComboWindow : public FEnhancedSkillAction
{
	virtual void OnSectionStart() override;
	virtual void OnSectionEnd() override;
};

template<>
struct TUniversalTimelineSectionTypeTraits<UComboGraphComboWindowData> : TUniversalTimelineSectionTypeTraitsBase<UComboGraphComboWindowData>
{
	enum
	{
		RunSimulated = false,
		RunAutonomous = true,
		RunAuthority = true,

		RunOnServer = false,
		RunOnClient = true,
	};
	
	using ExecutorClass = FComboGraphComboWindow;
};
