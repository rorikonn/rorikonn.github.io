﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "LevelSequence/UniversalTimelineSectionContext.h"
#include "Skill/EnhancedSkillTypes.h"
#include "EnhancedAbilityTimelineContext.generated.h"

struct FEnhancedSkillContext;
class UEnhancedAbilitySystemComponent;
class UEnhancedAbilityWorld;
class UEnhancedSkillData;
/**
 * 
 */
USTRUCT()
struct ENHANCEDABILITY_API FEnhancedAbilityTimelineContext : public FUniversalTimelineSectionContext
{
	GENERATED_BODY()

	FEnhancedAbilityTimelineContext() = default;
	FEnhancedAbilityTimelineContext(const UEnhancedAbilitySystemComponent* OwnerComponent);

	virtual UScriptStruct* GetScriptStruct() const override { return StaticStruct(); }
	virtual AActor* GetBindActor() override { return GetOwnerActor(); }

	FCombatTarget GetOwner() const;
	FTransform GetInitialTransform() const;

	UEnhancedAbilityWorld* GetAbilityWorld() const;
	UEnhancedAbilitySystemComponent* GetAbilityComponent() const;
	UAnimInstance* GetAnimInstance() const;
	UPawnMovementComponent* GetMovementComponent() const;

	template <typename T>
	typename TEnableIf<TIsDerivedFrom<T, UPawnMovementComponent>::Value, T*>::Type GetMovementComponent() const
	{
		return Cast<T>(GetMovementComponent());
	}

protected:
	UPROPERTY()
	FCombatTarget Owner;

	UPROPERTY(Transient)
	mutable TWeakObjectPtr<UEnhancedAbilityWorld> OwningAbilityWorld;

	UPROPERTY(Transient)
	mutable TWeakObjectPtr<UAnimInstance> OwnerAnimInstance;
};
