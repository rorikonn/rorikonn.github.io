﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "EnhancedAbilityTimelineContext.h"

#include "EnhancedAbilitySystemComponent.h"
#include "EnhancedAbilityWorld.h"
#include "GameFramework/Character.h"

FEnhancedAbilityTimelineContext::FEnhancedAbilityTimelineContext(const UEnhancedAbilitySystemComponent* OwnerComponent)
	: FUniversalTimelineSectionContext(OwnerComponent ? OwnerComponent->GetOwner() : nullptr)
{
	if (ContextOwner.IsValid())
	{
		Owner = FCombatTarget::MakeFromActor(ContextOwner.Get());
	}
}

FCombatTarget FEnhancedAbilityTimelineContext::GetOwner() const
{
	return Owner;
}

FTransform FEnhancedAbilityTimelineContext::GetInitialTransform() const
{
	return Owner.GetInitialTransform();
}

UEnhancedAbilityWorld* FEnhancedAbilityTimelineContext::GetAbilityWorld() const
{
	if (!OwningAbilityWorld.IsValid() && ContextOwner.IsValid())
	{
		const UWorld* World = ContextOwner->GetWorld();
		OwningAbilityWorld = World ? World->GetSubsystem<UEnhancedAbilityWorld>() : nullptr;
	}
	
	return OwningAbilityWorld.Get();
}

UEnhancedAbilitySystemComponent* FEnhancedAbilityTimelineContext::GetAbilityComponent() const
{
	return UEnhancedAbilitySystemComponent::GetFromOwner(GetOwnerActor());
}

UAnimInstance* FEnhancedAbilityTimelineContext::GetAnimInstance() const
{
	if (!OwnerAnimInstance.IsValid() && ContextOwner.IsValid())
	{
		const USkeletalMeshComponent* AvatarMesh;
		if (const ACharacter* OwnerCharacter = Cast<ACharacter>(ContextOwner))
		{
			AvatarMesh = OwnerCharacter->GetMesh();
		}
		else
		{
			AvatarMesh = ContextOwner->FindComponentByClass<USkeletalMeshComponent>();
		}

		OwnerAnimInstance = AvatarMesh ? AvatarMesh->GetAnimInstance() : nullptr;
	}

	return OwnerAnimInstance.Get();
}

UPawnMovementComponent* FEnhancedAbilityTimelineContext::GetMovementComponent() const
{
	if (const APawn* OwnerPawn = Cast<APawn>(GetOwnerActor()))
	{
		return OwnerPawn->GetMovementComponent();
	}

	return nullptr;
}
