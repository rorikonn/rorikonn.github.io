﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "ComboGraph/ComboGraphComboWindow.h"

#include "ComboGraphRuntimeTypes.h"
#include "EnhancedAbilityLog.h"
#include "Components/ComboGraphSystemComponent.h"
#include "Skill/EnhancedSkillContext.h"

void FComboGraphComboWindow::OnSectionStart()
{
	static FComboGraphEventPayload_ComboWindow Payload;
	UComboGraphSystemComponent::SendEvent(GetContext().GetOwnerActor(), FComboGraphNativeTags::ComboBeginEvent, &Payload);
}

void FComboGraphComboWindow::OnSectionEnd()
{
	static FComboGraphEventPayload_ComboWindow Payload;
	UComboGraphSystemComponent::SendEvent(GetContext().GetOwnerActor(), FComboGraphNativeTags::ComboEndEvent, &Payload);
}
