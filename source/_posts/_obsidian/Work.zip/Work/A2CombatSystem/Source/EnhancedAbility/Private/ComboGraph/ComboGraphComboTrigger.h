﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphRuntimeTypes.h"
#include "GameplayTagContainer.h"
#include "Skill/EnhancedSkillAction.h"
#include "ComboGraphComboTrigger.generated.h"

/**
 * 
 */
UCLASS(DisplayName="ComboGraph: Combo Trigger", meta=(SectionColor="255,220,0",
	ToolTip="ComboGraphEdge的TransitionBehavior设置为OnNotifyTrigger的时候, ComboWindow接收到的输入会在这个Action开始的时候被触发, 在这个Action开始之后收到的输入会立刻触发"))
class ENHANCEDABILITY_API UComboGraphComboTriggerData : public UEnhancedSkillActionData
{
	GENERATED_BODY()
	GENERATED_UNIVERSAL_TIMELINE_BODY()

	UPROPERTY(EditDefaultsOnly, meta=(Categories="ComboGraph.Trigger"))
	FGameplayTag Trigger = FComboGraphNativeTags::DefaultComboTrigger;
};

class FComboGraphComboTrigger : public FEnhancedSkillAction
{
	virtual void OnSectionStart() override;
	virtual void OnSectionEnd() override;
};

template<>
struct TUniversalTimelineSectionTypeTraits<UComboGraphComboTriggerData> : TUniversalTimelineSectionTypeTraitsBase<UComboGraphComboTriggerData>
{
	enum
	{
		RunSimulated = false,
		RunAutonomous = true,
		RunAuthority = true,

		RunOnServer = false,
		RunOnClient = true,
	};
	
	using ExecutorClass = FComboGraphComboTrigger;
};
