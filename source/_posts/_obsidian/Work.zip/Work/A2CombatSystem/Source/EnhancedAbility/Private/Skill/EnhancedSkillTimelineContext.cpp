﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Skill/EnhancedSkillTimelineContext.h"

#include "EnhancedAbilitySystemComponent.h"


FEnhancedSkillTimelineContext::FEnhancedSkillTimelineContext(const TSharedPtr<FEnhancedSkillContext>& SkillContext)
	: FEnhancedAbilityTimelineContext(SkillContext->GetAbilityComponent()), Handle(),
	  SkillContext(SkillContext)
{
}

FEnhancedSkillContext* FEnhancedSkillTimelineContext::GetSkillContext() const
{
	return SkillContext.IsValid() ? SkillContext.Pin().Get() : nullptr;
}

FEnhancedSkillHandle FEnhancedSkillTimelineContext::GetHandle() const
{
	return SkillContext.IsValid() ? SkillContext.Pin()->GetHandle() : FEnhancedSkillHandle();
}

FSkillID FEnhancedSkillTimelineContext::GetSkillID() const
{
	return SkillContext.IsValid() ? SkillContext.Pin()->GetSkillID() : 0;
}

const UEnhancedSkillData* FEnhancedSkillTimelineContext::GetSkillData() const
{
	return SkillContext.IsValid() ? SkillContext.Pin()->GetSkillData() : nullptr;
}

FCombatTarget FEnhancedSkillTimelineContext::GetTarget() const
{
	return SkillContext.IsValid() ? SkillContext.Pin()->GetTarget() : FCombatTarget();
}
