﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Graph/ComboGraphNode.h"
#include "Skill/EnhancedSkillTypes.h"
#include "ComboGraphNodeSkill.generated.h"

struct FEnhancedSkillContext;
class UEnhancedAbilitySystemComponent;
class UEnhancedSkillData;

UCLASS(Abstract)
class ENHANCEDABILITY_API UComboGraphBaseSkillNodeData : public UComboGraphNodeData
{
	GENERATED_BODY()

public:
	// 这个节点触发技能的Event Tag, 会用来处理打断, 冲突等逻辑
	virtual FGameplayTag GetSkillEvent() const { PURE_VIRTUAL(UComboGraphBaseSkillNodeData::GetSkillEvent(), return FGameplayTag();) }
};

UCLASS(Abstract)
class ENHANCEDABILITY_API UComboGraphBaseSkillNode : public UComboGraphNode
{
	GENERATED_BODY()

public:
	virtual void Initialize(const UComboGraphNodeData* Data, TSharedPtr<FComboGraphContext> GraphContext) override;
	virtual bool CanInterruptBy(const UComboGraphNodeData* NextNode) override;

protected:
	bool CastSkill(FSkillID SkillID, FEnhancedSkillEventDataContainer* EventData, FEnhancedSkillStageEventHandler* EventHandler);
	FEnhancedSkillHandle GetSkillHandle() const;
	TSharedPtr<FEnhancedSkillContext> GetRelevantSkillContext() const;

	UPROPERTY(Transient)
	TObjectPtr<UEnhancedAbilitySystemComponent> EnhancedAbilitySystem;

	FEnhancedSkillHandle SkillHandle;
};

/**
 * 
*/
UCLASS(meta=(DisplayName="Skill Combo Node", DisplayColor="255,102,51"))
class ENHANCEDABILITY_API UComboGraphNodeSkillData : public UComboGraphBaseSkillNodeData
{
	GENERATED_BODY()

public:
	UPROPERTY(EditAnywhere)
	FSkillID Skill;

	UPROPERTY(EditAnywhere, DisplayName="需要有目标才能释放", AdvancedDisplay)
	uint8 bRequiresTarget : 1;

	UPROPERTY(EditAnywhere, DisplayName="索敌范围", AdvancedDisplay, meta=(EditCondition="bRequiresTarget", EditConditionHides))
	float TargetingRange;

	virtual UComboGraphNode* MakeRuntimeNode(TSharedPtr<FComboGraphContext> Context) const override;
	virtual FGameplayTag GetSkillEvent() const override;
};


UCLASS()
class ENHANCEDABILITY_API UComboGraphNodeSkill : public UComboGraphBaseSkillNode
{
	GENERATED_BODY()
	
	virtual bool PreActivation() override;
	
	virtual bool OnActivated() override;
	virtual void OnDeactivated() override;

	void OnSkillCanceled() const;
	void OnSkillInterrupted() const;
	void OnSkillComplete() const;

	FCombatTarget NodeTarget;
};
