﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "ComboGraphComboTrigger.h"

#include "ComboGraphRuntimeTypes.h"
#include "Components/ComboGraphSystemComponent.h"
#include "Skill/EnhancedSkillContext.h"

void FComboGraphComboTrigger::OnSectionStart()
{
	static FComboGraphEventPayload_TransitionTrigger Payload;
	Payload.Trigger = GetDataChecked<UComboGraphComboTriggerData>().Trigger;
	UComboGraphSystemComponent::SendEvent(GetContext().GetOwnerActor(), FComboGraphNativeTags::ComboTriggerEvent, &Payload);
}

void FComboGraphComboTrigger::OnSectionEnd()
{
	static FComboGraphEventPayload_TransitionTrigger Payload;
	Payload.Trigger = GetDataChecked<UComboGraphComboTriggerData>().Trigger;
	UComboGraphSystemComponent::SendEvent(GetContext().GetOwnerActor(), FComboGraphNativeTags::ComboTriggerEndEvent, &Payload);
}
