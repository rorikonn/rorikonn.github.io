﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnhancedAbilityNetwork.generated.h"

USTRUCT()
struct FEnhancedAbilityLocalMontageInfo
{
	GENERATED_BODY()
	
	UPROPERTY()
	TObjectPtr<UAnimMontage> AnimMontage;

	UPROPERTY()
	uint8 PlayInstanceID;
};
