﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "DataArchive.h"
#include "EnhancedSkillContext.h"
#include "EnhancedSkillTimelineContext.h"
#include "EnhancedSkillTypes.h"
#include "UniversalTimelinePlayer.h"
#include "UObject/Object.h"
#include "EnhancedSkill.generated.h"

struct FEnhancedSkillContext;
class ALevelSequenceActor;
class ULevelSequence;

UCLASS(EditInlineNew)
class ENHANCEDABILITY_API UEnhancedSkillData : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY(VisibleAnywhere)
	FSkillID ID;

	UPROPERTY(EditAnywhere)
	FString Name;

	UPROPERTY(EditAnywhere)
	FString Description;

	UPROPERTY(EditAnywhere)
	FString Category;

	UPROPERTY(EditAnywhere)
	float TargetingRange = 500.0f;

	UPROPERTY(EditAnywhere, meta=(Tooltip="如果技能目标是角色, 会使用角色的地面投影点作为目标"))
	uint8 bTargetingGround : 1;

	UPROPERTY(EditAnywhere, meta=(Tooltip="这个技能是否是持续性的, 如果是true, 那么技能Timeline会在播到最后一帧时暂停, 直到其他事件打断或者主动打断"))
	uint8 bIsPersistent : 1;

	// 技能的标签, 用于处理技能的打断, 冲突等逻辑
	UPROPERTY(EditAnywhere, meta=(Categories="SkillEvent"))
	FGameplayTag EventTag = SkillEvent_LightAttack;

	UPROPERTY(EditDefaultsOnly)
	TSoftObjectPtr<ULevelSequence> Sequence;

	ULevelSequence* GetSequence() const;
};


template <>
struct TDataArchiveInfo<UEnhancedSkillData> : TDataArchiveInfoBase<UEnhancedSkillData>
{
	static FSkillID& GetKeyFromData(UEnhancedSkillData* Data)
	{
		static FSkillID InvalidKey;
		return Data ? Data->ID : InvalidKey;
	}

	static FString GetArchiveTableName()
	{
		return TEXT("SkillObject");
	}

	static FString GetArchiveCategory(const UEnhancedSkillData* Data)
	{
		FString Category = TEXT("Default");
		if (Data && !Data->Category.IsEmpty())
		{
			Category = Data->Category;
		}
		return Category;
	}
};

/**
 * 
 */
UCLASS()
class ENHANCEDABILITY_API UEnhancedSkill : public UObject
{
	GENERATED_BODY()

public:
	UEnhancedSkill();
	static UEnhancedSkill* Make(UObject* Outer, const UEnhancedSkillData* Data, const TSharedPtr<FEnhancedSkillContext>& InContext);

	void Initialize(const UEnhancedSkillData* Data, TSharedPtr<FEnhancedSkillContext> InContext);

	bool BeginSkill(FString& FailReason);
	void TickSkill(float DeltaTime);
	void EndSkill();

	FORCEINLINE TSharedPtr<FEnhancedSkillContext> GetSkillContext() const
	{
		return Context;
	}

	FORCEINLINE bool IsTerminated() const
	{
		return bTerminated;
	}

	UFUNCTION()
	void OnSequenceStop();

private:
	UPROPERTY(Transient)
	TObjectPtr<const UEnhancedSkillData> ReferenceData;

	TSharedPtr<FEnhancedSkillContext> Context;

	TSharedPtr<FEnhancedSkillTimelineContext> TimelineContext;
	FUniversalTimelinePlayer TimelinePlayer;

	/**
	 * 注意与Context中的Terminated区分, 如果技能的EndSkill被调用, 会同时将Context的bTerminated和这个都置为true
	 * 如果Context被外部置为Terminated了, 会在下一次TickSkill的开始将这个把Terminated置为true, 并以Interrupted为参数调用技能的EndSkill
	 */
	uint8 bTerminated : 1;
};
