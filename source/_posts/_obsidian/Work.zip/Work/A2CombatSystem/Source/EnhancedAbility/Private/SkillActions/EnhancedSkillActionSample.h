﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Skill/EnhancedSkillAction.h"
#include "EnhancedSkillActionSample.generated.h"

/**
 * SkillAction的数据类, 配置都放在这里
 * SequenceEditor中的菜单项会自动生成, MetaData里面配置Section在菜单中的Label(DisplayName) 和 颜色(SectionColor)
 * 颜色支持常用颜色的英文单词(Red, White, Black等等, 见"UniversalTimelineTrack.h") 和 RGB值(0 - 255整数)
 * 可选配置Category, 表示在SequenceEditor中的SubMenu, 不配默认用父类的Category
 * GENERATED_UNIVERSAL_TIMELINE_BODY一定要加, 里面包含了TypeTraits工作的基础实现
 * 注: Deprecated是为了不在正常的菜单中显示这个项, 正常的Action不要加这个
 */
UCLASS(Deprecated, meta=(DisplayName="Action Sample", SectionColor="155,155,155"))
class ENHANCEDABILITY_API UDEPRECATED_SampleActionData : public UEnhancedSkillActionData
{
	GENERATED_BODY()
	GENERATED_UNIVERSAL_TIMELINE_BODY()

	// 数据字段, EditAnywhere很重要, 不然不会在编辑器中显示出来
	UPROPERTY(EditAnywhere)
	bool bEnable;
};

/**
 * SkillAction的运行时类, 通过下面的TypeTraits和数据类绑定, 记得FEnhancedSkillAction要是public继承
 * 最常用的三个重载, OnSectionStart, OnSectionTick, OnSectionEnd
 * Start和End在Section开始和结束的时候执行, Tick默认不会执行, 需要在TypeTraits中打开才会执行Tick
 * GetContext<T>() 和 GetData<T>() 可以获取技能上下文和数据对象
 * 注: 可以多个运行时类对应一个数据类, 通过在TypeTraits中定义数据类指针(const DataClass*)为参数的MakeExecutor函数来实现
 */
class FSampleAction : public FEnhancedSkillAction
{
	/**
	 * 在Action初始化完成后调用, GetContext<T>() 和 GetData<T>()在这个时候都可用
	 * 通常用于在某些上下文中, 或者根据配置选择是否执行这个Action
	 * 如果是跟上下文无关的禁用, 建议直接在TypeTraits中的MakeExecutor函数里直接返回空, 这样可用省下创建这个对象并初始化的开销
	 * @return Action在当前上下文中是否可以执行
	 */
	virtual bool IsEnabled() const override
	{
		return GetData<UDEPRECATED_SampleActionData>()->bEnable;
	}

	/**
	 * 在Section的StartTime到的时候执行
	 * OnSectionStart和OnSectionEnd保证成对, 即要么都执行, 要么都不执行
	 */
	virtual void OnSectionStart() override
	{
	}

	/**
	 * 如果TypeTraits中的EnableTick设为true了, 就每帧执行, 否则不执行
	 * 在OnSectionStart的同一帧也会执行一次
	 * @param DeltaTime 单位秒
	 */
	virtual void OnSectionTick(float DeltaTime) override
	{
	}

	/**
	 * 在Section的EndTime到的时候执行
	 * OnSectionStart和OnSectionEnd保证成对, 即要么都执行, 要么都不执行
	 */
	virtual void OnSectionEnd() override
	{
	}
};

/** Previewer的写法较为复杂，后续补全文档 */
class FSampleActionPreviewer : public FEnhancedSkillActionPreviewer
{
	virtual void OnPreviewStart(AActor* BoundActor) override
	{
	}

	virtual void OnPreviewTick(AActor* BoundActor, const FMovieSceneContext& SceneContext, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override
	{
	}

	virtual void OnPreviewEnd(AActor* BoundActor) override
	{
	}
};


/**
 * 数据类的TypeTraits
 * 除了绑定运行时类的定义一定要有外, 其他的都是可选的
 * 如果只需要进行最简单的数据类-运行时类的 绑定, 也可以用下面的宏替代
 */
template <>
struct TUniversalTimelineSectionTypeTraits<UDEPRECATED_SampleActionData> : TUniversalTimelineSectionTypeTraitsBase<UDEPRECATED_SampleActionData>
{
	// enum hack, 主要用来声明这个Action的运行条件
	// 以下所有枚举都可以省略, 除了EnableTick默认为false外, 其他的默认都是true
	enum
	{
		EnableTick = true,
		
		RunSimulated = true,
		RunAutonomous = true,
		RunAuthority = true,
		
		RunOnServer = true,
		RunOnClient = true,
	};

	// 简单的绑定数据类与运行时类的方法, 也可以用typedef
	// using ExecutorClass = FSampleAction;

	// 绑定预览类, 也可以用typedef
	// using PreviewerClass = FSampleActionPreviewer;

	// 绑定数据类和运行时类, 可以带参数, 也可以不带参数. 如果带参数必须是这个TypeTraits的数据类的指针
	// 返回一个新的UniquePtr就可以了, 不用做任何初始化, 初始化会在这个之后自动完成
	// 和上面的简单绑定只能存在一个
	TUniquePtr<FUniversalTimelineExecutor> MakeExecutor(const UDEPRECATED_SampleActionData* Data)
	{
		return MakeUnique<FSampleAction>();
	}
};
