﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Object.h"
#include "Skill/EnhancedSkillTypes.h"
#include "EnhancedAbilityWorld.generated.h"


struct FEnhancedSkillHandle;
class UEnhancedSkillData;
class UEnhancedAbilitySystemComponent;
struct FEnhancedSkillContext;


/**
 * 用来管理EnhancedAbility系统中与角色无关的上下文.
 * 例如: 技能上下文. 技能上下文不再由Caster所有, 考虑到受击方在攻击方被裁剪或出于某种原因未在视野中的情况下, 受击表现应该要正常执行
 */
UCLASS()
class ENHANCEDABILITY_API UEnhancedAbilityWorld : public UTickableWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual TStatId GetStatId() const override;
	virtual void Tick(float DeltaTime) override;
	
	TSharedPtr<FEnhancedSkillContext> MakeSkillContext(UEnhancedAbilitySystemComponent* Owner, const UEnhancedSkillData* SkillData);
	TSharedPtr<FEnhancedSkillContext> FindSkillContext(FEnhancedSkillHandle Handle);

protected:
	friend class UEnhancedAbilitySystemComponent;
	TSharedPtr<FEnhancedSkillContext> ReceiveNetSkillContext(const FEnhancedSkillContext& NetContext);
	
private:
	void CheckInvalidatedContext(float DeltaTime);
	
	TMap<FEnhancedSkillHandle, TSharedPtr<FEnhancedSkillContext>> SkillContexts;
};
