﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Skill/EnhancedSkillTypes.h"

#include "EnhancedAbilityLog.h"

UE_DEFINE_GAMEPLAY_TAG(SkillEvent_LightAttack, TEXT("SkillEvent.LightAttack"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_HeavyAttack, TEXT("SkillEvent.HeavyAttack"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_ChargeAttack, TEXT("SkillEvent.ChargeAttack"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_Charge, TEXT("SkillEvent.Charge"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_Parry, TEXT("SkillEvent.Parry"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_Block, TEXT("SkillEvent.Block"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_Move, TEXT("SkillEvent.Move"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_Jump, TEXT("SkillEvent.Jump"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_Dodge, TEXT("SkillEvent.Dodge"))
UE_DEFINE_GAMEPLAY_TAG(SkillEvent_Projectile, TEXT("SkillEvent.Projectile"))


FSkillID::FSkillID()
	: ID(0)
{
}

FSkillID::FSkillID(int32 ID)
	: ID(ID)
{
}


FEnhancedSkillHandle FEnhancedSkillHandle::Generate()
{
	static uint32 GHandle = 0;
	FEnhancedSkillHandle NewHandle;
	NewHandle.Handle = ++GHandle;
	NewHandle.NetOwner = 0;
	return NewHandle;
}

bool FEnhancedSkillHandle::NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess)
{
	uint8 IsRemoteHandle = 0;
	if (Ar.IsSaving())
	{
		/**
		 * Remote表示这个Handle对于目标来说是本地的还是网络上其他人创建的
		 * 如果NetOwner是0, 表示这个是本地创建的Handle, 那对目标来说一定是Remote的
		 * 如果NetOwner和发送的目标相同, 则对于目标来说就不是Remote的
		 * 其他情况下, 对目标来说都是Remote的
		 */
		IsRemoteHandle = NetOwner == 0 || NetOwner != reinterpret_cast<UPTRINT>(Map);
	}

	Ar.SerializeBits(&IsRemoteHandle, 1);

	if (IsRemoteHandle)
	{
		// 写入的时候, 要把这个Handle的NetOwner发送给其他人, 如果是自己创建的, NetOwner就是0
		Ar << NetOwner;

		if (Ar.IsLoading())
		{
			// 如果收到的NetOwner是0, 说明收到的是发送者创建的Handle, 则把发送者的PackageMap记下来
			if (NetOwner == 0)
			{
				NetOwner = reinterpret_cast<UPTRINT>(Map);
			}
		}
	}

	Ar << Handle;
	bOutSuccess = true;
	return true;
}

FCombatTarget& FEnhancedSkillEventDataContainer::AddInitialTarget(const FCombatTarget& Target)
{
	FCombatTarget& InitialTarget = Add<FEnhancedSkillEventData_InitTarget>().Target;
	InitialTarget = Target;
	return InitialTarget;
}

FCombatTarget FEnhancedSkillEventDataContainer::GetInitialTarget() const
{
	const FEnhancedSkillEventData_InitTarget* InitialTargetData = Get<FEnhancedSkillEventData_InitTarget>();
	if (!InitialTargetData)
	{
		return FCombatTarget();
	}

	return InitialTargetData->Target;
}

void FEnhancedSkillEventDataContainer::SetStartPosition(float StartPosition)
{
	Add<FEnhancedSkillEventData_StartPosition>().StartPosition = StartPosition;
}

float FEnhancedSkillEventDataContainer::GetStartPosition() const
{
	const FEnhancedSkillEventData_StartPosition* StartPositionData = Get<FEnhancedSkillEventData_StartPosition>();
	if (!StartPositionData)
	{
		return 0.0f;
	}

	return StartPositionData->StartPosition;
}

bool FEnhancedSkillEventDataContainer::NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess)
{
	uint8 DataNum;
	if (Ar.IsSaving())
	{
		EA_RUNTIME_CLOG(Data.Num() > MAX_uint8, Warning, TEXT("Too many Data(%d!) in container to net serialize. Clamping to %d"), Data.Num(), MAX_uint8);
		DataNum = FMath::Min<int32>(Data.Num(), MAX_uint8);
	}

	Ar << DataNum;
	if (Ar.IsLoading())
	{
		Data.SetNum(DataNum);
	}

	for (int32 Index = 0; Index < DataNum && !Ar.IsError(); ++Index)
	{
		TCheckedObjPtr<UScriptStruct> ScriptStruct = Data[Index].IsValid() ? Data[Index]->GetScriptStruct() : nullptr;
		Ar << ScriptStruct;

		if (ScriptStruct.IsValid())
		{
			if (Ar.IsLoading())
			{
				check(!Data[Index].IsValid());
				FEnhancedSkillEventData* NewData = StaticCast<FEnhancedSkillEventData*>(FMemory::Malloc(ScriptStruct->GetStructureSize()));
				ScriptStruct->InitializeStruct(NewData);

				Data[Index] = TSharedPtr<FEnhancedSkillEventData>(NewData, FEnhancedSkillEventData::FDeleter());
			}

			check(Data[Index].IsValid());
			Data[Index]->NetSerialize(Ar, Map, bOutSuccess);
		}
		else if (ScriptStruct.IsError())
		{
			EA_RUNTIME_LOG(Error, TEXT("Bad ScriptStruct serialized, can't recover."));
			Ar.SetError();
			break;
		}
	}

	if (Ar.IsError())
	{
		for (int32 Index = Data.Num() - 1; Index >= 0; --Index)
		{
			if (!Data[Index].IsValid())
			{
				Data.RemoveAt(Index);
			}
		}

		bOutSuccess = false;
		return false;
	}

	bOutSuccess = true;
	return true;
}

bool FEnhancedSkillEventData_InitTarget::NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess)
{
	Ar << Target;
	bOutSuccess = true;
	return true;
}

bool FEnhancedSkillEventData_StartPosition::NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess)
{
	Ar << StartPosition;
	bOutSuccess = true;
	return true;
}
