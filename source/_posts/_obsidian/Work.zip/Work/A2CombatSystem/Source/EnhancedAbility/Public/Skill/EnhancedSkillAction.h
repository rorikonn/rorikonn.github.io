﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnhancedAbilityTimelineContext.h"
#include "EnhancedSkillTimelineContext.h"
#include "LevelSequence/UniversalTimelineSection.h"
#include "EnhancedSkillAction.generated.h"

/**
 * 
 */
UCLASS(Abstract, meta=(Category="Skill Action"))
class ENHANCEDABILITY_API UEnhancedSkillActionData : public UUniversalTimelineSection
{
	GENERATED_BODY()
};

class ENHANCEDABILITY_API FEnhancedSkillAction : public FUniversalTimelineExecutor
{
protected:
	FEnhancedSkillTimelineContext& GetContext() const
	{
		return FUniversalTimelineExecutor::GetContext<FEnhancedSkillTimelineContext>();
	}

	FEnhancedSkillContext* GetSkillContext() const
	{
		return GetContext().GetSkillContext();
	}
};

class ENHANCEDABILITY_API FEnhancedSkillActionPreviewer : public FUniversalTimelinePreviewer
{
};


/**
 * 
 */
UCLASS(Abstract)
class ENHANCEDABILITY_API UEnhancedSkillSubActionData : public UUniversalTimelineSubSection
{
	GENERATED_BODY()
};

class ENHANCEDABILITY_API FEnhancedSkillSubAction : public FUniversalTimelineExecutor
{
};

class ENHANCEDABILITY_API FEnhancedSkillSubActionPreviewer : public FEnhancedSkillActionPreviewer
{
};

