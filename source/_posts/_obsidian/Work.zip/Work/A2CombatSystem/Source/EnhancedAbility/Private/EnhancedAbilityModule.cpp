﻿//


#include "EnhancedAbilityModule.h"

#include "DataArchive.h"
#include "Skill/EnhancedSkill.h"

#define LOCTEXT_NAMESPACE "FEnhancedAbilityModule"

void FEnhancedAbilityModule::StartupModule()
{
	FDataArchiveManager::Load<UEnhancedSkillData>();
}

void FEnhancedAbilityModule::ShutdownModule()
{
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FEnhancedAbilityModule, EnhancedAbility)
