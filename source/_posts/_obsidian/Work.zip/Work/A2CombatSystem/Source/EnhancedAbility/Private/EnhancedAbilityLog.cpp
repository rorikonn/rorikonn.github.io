﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "EnhancedAbilityLog.h"

DEFINE_LOG_CATEGORY(LogEnhancedAbility)
