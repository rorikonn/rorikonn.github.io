// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTarget.h"
#include "NativeGameplayTags.h"
#include "EnhancedSkillTypes.generated.h"

ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_LightAttack);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_HeavyAttack);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_ChargeAttack);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_Charge);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_Parry);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_Block);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_Move);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_Jump);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_Dodge);
ENHANCEDABILITY_API UE_DECLARE_GAMEPLAY_TAG_EXTERN(SkillEvent_Projectile);

USTRUCT(BlueprintType)
struct ENHANCEDABILITY_API FSkillID
{
	GENERATED_BODY()

	FSkillID();
	FSkillID(int32 ID);

	FSkillID& operator=(int32 InIndex)
	{
		ID = InIndex;
		return *this;
	}

	friend bool operator==(const FSkillID& Lhs, const FSkillID& Rhs)
	{
		return Lhs.ID == Rhs.ID;
	}

	friend bool operator!=(const FSkillID& Lhs, const FSkillID& Rhs)
	{
		return Lhs.ID != Rhs.ID;
	}

	friend uint32 GetTypeHash(const FSkillID& Ref)
	{
		return Ref.ID;
	}

	FString ToString() const
	{
		FString OutString;
		if (ExportTextItem(OutString))
		{
			return OutString;
		}

		return FString();
	}

	bool ExportTextItem(FString& ValueStr, FSkillID const& DefaultValue = FSkillID(), UObject* Parent = nullptr, int32 PortFlags = 0, UObject* ExportRootScope = nullptr) const
	{
		ValueStr += FString::FromInt(ID);
		return true;
	}

	bool ImportTextItem(const TCHAR*& Buffer, int32 PortFlags, UObject* Parent, FOutputDevice* ErrorText)
	{
		FString ImportedString = TEXT("");
		const TCHAR* NewBuffer = FPropertyHelpers::ReadToken(Buffer, ImportedString, true);
		if (!NewBuffer)
		{
			return false;
		}

		ID = FCString::Atoi(*ImportedString);

		return true;
	}

	bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess)
	{
		Ar << ID;
		bOutSuccess = true;
		return true;
	}

	UPROPERTY(EditAnywhere, BlueprintReadWrite)
	int32 ID;
};

template <>
struct TStructOpsTypeTraits<FSkillID> : TStructOpsTypeTraitsBase2<FSkillID>
{
	enum
	{
		WithExportTextItem = true,
		WithImportTextItem = true,
		WithNetSerializer = true,
	};
};

USTRUCT()
struct ENHANCEDABILITY_API FEnhancedSkillHandle
{
	GENERATED_BODY()

	static FEnhancedSkillHandle Generate();

	UPROPERTY()
	uint32 Handle;

	/** 标识这个Handle是本地创建的还是从网络同步过来的 */
	UPTRINT NetOwner;

	FORCEINLINE bool IsValid() const
	{
		return Handle > 0;
	}

	FORCEINLINE bool IsRemoteHandle() const
	{
		return NetOwner != 0;
	}

	FORCEINLINE bool IsLocalHandle() const
	{
		return NetOwner == 0;
	}

	FORCEINLINE operator bool() const
	{
		return IsValid();
	}

	friend bool operator ==(const FEnhancedSkillHandle& Lhs, const FEnhancedSkillHandle& Rhs)
	{
		return Lhs.Handle == Rhs.Handle && Lhs.NetOwner == Rhs.NetOwner;
	}

	friend bool operator !=(const FEnhancedSkillHandle& Lhs, const FEnhancedSkillHandle& Rhs)
	{
		return Lhs.Handle != Rhs.Handle || Lhs.NetOwner != Rhs.NetOwner;
	}

	friend uint32 GetTypeHash(const FEnhancedSkillHandle& Ref)
	{
		return HashCombine(Ref.Handle, GetTypeHash(Ref.NetOwner));
	}

	FString ToString() const
	{
		return FString::Printf(TEXT("%s Skill-%d"), IsLocalHandle() ? TEXT("Local") : TEXT("Remote"), Handle);
	}

	bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess);
};

template <>
struct TStructOpsTypeTraits<FEnhancedSkillHandle> : TStructOpsTypeTraitsBase2<FEnhancedSkillHandle>
{
	enum
	{
		WithNetSerializer = true,
	};
};


/**
 * Skill Event Order: Begin --> Canceled/Interrupted/Complete --> Terminate
 */
UENUM()
enum class EEnhancedSkillStage : uint8
{
	Begin,
	Canceled,
	Interrupted,
	Complete,
	Terminate,
};

DECLARE_MULTICAST_DELEGATE(FEnhancedSkillStageEvent);

struct FEnhancedSkillStageEventHandler
{
	FEnhancedSkillStageEvent OnSkillBegin;
	FEnhancedSkillStageEvent OnSkillCanceled;
	FEnhancedSkillStageEvent OnSkillInterrupted;
	FEnhancedSkillStageEvent OnSkillComplete;
	FEnhancedSkillStageEvent OnSkillTerminate;

	void Clear()
	{
		OnSkillBegin.Clear();
		OnSkillCanceled.Clear();
		OnSkillInterrupted.Clear();
		OnSkillComplete.Clear();
		OnSkillTerminate.Clear();
	}

	void RemoveAll(const UObject* UserObject)
	{
		OnSkillBegin.RemoveAll(UserObject);
		OnSkillCanceled.RemoveAll(UserObject);
		OnSkillInterrupted.RemoveAll(UserObject);
		OnSkillComplete.RemoveAll(UserObject);
		OnSkillTerminate.RemoveAll(UserObject);
	}
};

USTRUCT()
struct FEnhancedSkillEventData
{
	GENERATED_BODY()
	struct FDeleter
	{
		FORCEINLINE void operator()(FEnhancedSkillEventData* Object) const
		{
			check(Object);
			const UScriptStruct* ScriptStruct = Object->GetScriptStruct();
			check(ScriptStruct);
			ScriptStruct->DestroyStruct(Object);
			FMemory::Free(Object);
		}
	};

	virtual ~FEnhancedSkillEventData() = default;

	virtual UScriptStruct* GetScriptStruct() const PURE_VIRTUAL(FEnhancedSkillEventData::GetScriptStruct, return StaticStruct();)
	virtual bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess) PURE_VIRTUAL(FEnhancedSkillEventData::NetSerialize, return false;)
};


/**
 * 用于技能间通信, 技能和其他系统通信
 * 如: 释放技能时的初始目标, ComboGraph附带的额外信息等
 */
USTRUCT()
struct FEnhancedSkillEventDataContainer
{
	GENERATED_BODY()

	template <typename T, typename... ArgsType>
	FORCEINLINE T& Add(ArgsType&&... Args)
	{
		TSharedPtr<T> NewData = MakeShared<T>(Forward<ArgsType>(Args)...);
		Data.Emplace(NewData);
		return *NewData;
	}

	ENHANCEDABILITY_API FCombatTarget& AddInitialTarget(const FCombatTarget& Target);
	ENHANCEDABILITY_API FCombatTarget GetInitialTarget() const;

	ENHANCEDABILITY_API void SetStartPosition(float StartPosition);
	ENHANCEDABILITY_API float GetStartPosition() const;
	
	template <typename T>
	FORCEINLINE const T* Get() const
	{
		for (const TSharedPtr<FEnhancedSkillEventData>& DataIter : Data)
		{
			if (DataIter->GetScriptStruct() == T::StaticStruct())
			{
				return StaticCast<const T*>(DataIter.Get());
			}
		}

		return nullptr;
	}

	bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess);

private:
	TArray<TSharedPtr<FEnhancedSkillEventData>, TInlineAllocator<1>> Data;
};

template <>
struct TStructOpsTypeTraits<FEnhancedSkillEventDataContainer> : TStructOpsTypeTraitsBase2<FEnhancedSkillEventDataContainer>
{
	enum
	{
		WithNetSerializer = true,
	};
};

USTRUCT()
struct ENHANCEDABILITY_API FEnhancedSkillEventData_InitTarget : public FEnhancedSkillEventData
{
	GENERATED_BODY()

	FCombatTarget Target;

	virtual UScriptStruct* GetScriptStruct() const override { return StaticStruct(); }
	virtual bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess) override;
};

USTRUCT()
struct ENHANCEDABILITY_API FEnhancedSkillEventData_StartPosition : public FEnhancedSkillEventData
{
	GENERATED_BODY()

	float StartPosition;

	virtual UScriptStruct* GetScriptStruct() const override { return StaticStruct(); }
	virtual bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess) override;
};
