﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnhancedAbilityTimelineContext.h"
#include "EnhancedSkillTimelineContext.generated.h"

/**
 * 
 */
USTRUCT()
struct ENHANCEDABILITY_API FEnhancedSkillTimelineContext : public FEnhancedAbilityTimelineContext
{
	GENERATED_BODY()

	FEnhancedSkillTimelineContext() = default;
	FEnhancedSkillTimelineContext(const TSharedPtr<FEnhancedSkillContext>& SkillContext);

	virtual UScriptStruct* GetScriptStruct() const override { return StaticStruct(); }

	FEnhancedSkillContext* GetSkillContext() const;
	FEnhancedSkillHandle GetHandle() const;
	FSkillID GetSkillID() const;
	const UEnhancedSkillData* GetSkillData() const;

	FCombatTarget GetTarget() const;

private:
	UPROPERTY()
	FEnhancedSkillHandle Handle;
	TWeakPtr<FEnhancedSkillContext> SkillContext;
};
