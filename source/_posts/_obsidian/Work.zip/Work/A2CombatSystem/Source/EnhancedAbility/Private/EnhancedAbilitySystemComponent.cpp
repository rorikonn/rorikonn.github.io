﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "EnhancedAbilitySystemComponent.h"

#include "DataArchive.h"
#include "EnhancedAbilityLog.h"
#include "EnhancedAbilityWorld.h"
#include "Net/UnrealNetwork.h"
#include "Skill/EnhancedSkill.h"
#include "Skill/EnhancedSkillContext.h"


UEnhancedAbilitySystemComponent* UEnhancedAbilitySystemComponent::GetFromOwner(const AActor* OwnerActor)
{
	return OwnerActor ? OwnerActor->FindComponentByClass<UEnhancedAbilitySystemComponent>() : nullptr;
}

UEnhancedAbilitySystemComponent::UEnhancedAbilitySystemComponent()
	: bLoopingActivatingSkills(false),
	  AbilityWorld(nullptr)
{
	PrimaryComponentTick.bCanEverTick = true;
}

void UEnhancedAbilitySystemComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(ThisClass, AbilityStates);
}

void UEnhancedAbilitySystemComponent::InitializeComponent()
{
	Super::InitializeComponent();
}

void UEnhancedAbilitySystemComponent::BeginPlay()
{
	Super::BeginPlay();

	AbilityWorld = GetWorld() ? GetWorld()->GetSubsystem<UEnhancedAbilityWorld>() : nullptr;
}

void UEnhancedAbilitySystemComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	InternalTickSkills(DeltaTime);
}

FEnhancedSkillHandle UEnhancedAbilitySystemComponent::CastSkill(FSkillID SkillID, FEnhancedSkillEventDataContainer* EventData, FEnhancedSkillStageEventHandler* EventHandler)
{
	if (!IsValid(AbilityWorld))
	{
		EA_RUNTIME_LOG(Error, TEXT("Cast skill %s failed, AbilityWorld invalid, Actor: %s "), *SkillID.ToString(), *GetNameSafe(GetOwner()));
		return FEnhancedSkillHandle();
	}

	const bool bIsLocal = IsLocallyControlled();
	const bool bHasAuthority = HasAuthority();

	if (!bIsLocal && !bHasAuthority)
	{
		EA_RUNTIME_LOG(Warning, TEXT("Cast skill %s failed with bad net role, Actor: %s, Local: %s, Authority: %s"), *SkillID.ToString(), *GetNameSafe(GetOwner()), *BoolToString(bIsLocal),
		               *BoolToString(bHasAuthority));
		return FEnhancedSkillHandle();
	}

	const UEnhancedSkillData* SkillData = FDataArchiveManager::Find<UEnhancedSkillData>(SkillID);
	if (!SkillData)
	{
		EA_RUNTIME_LOG(Warning, TEXT("Find skill data failed with ID: %s, Actor: %s"), *SkillID.ToString(), *GetNameSafe(GetOwner()));
		return FEnhancedSkillHandle();
	}

	if (!HandleInterruptEvent(SkillData->EventTag))
	{
		EA_RUNTIME_LOG(Log, TEXT("Skill %s[%s] can't interrupt current activating skill on Actor: %s"), *SkillID.ToString(), *SkillData->EventTag.ToString(), *GetNameSafe(GetOwner()));
		return FEnhancedSkillHandle();
	}

	const TSharedPtr<FEnhancedSkillContext> Context = AbilityWorld->MakeSkillContext(this, SkillData);
	if (!Context)
	{
		EA_RUNTIME_LOG(Error, TEXT("Make skill context failed ID: %s, Actor: %s"), *SkillID.ToString(), *GetNameSafe(GetOwner()));
		return FEnhancedSkillHandle();
	}

	Context->SetupEventData(EventData);
	Context->SetupEventHandler(EventHandler);

	FString FailReason;
	if (!Context->PreCheck(&FailReason))
	{
		EA_RUNTIME_LOG(Log, TEXT("Skill PreCheck failed Reason: %s, ID: %s, Actor: %s"), *FailReason, *SkillID.ToString(), *GetNameSafe(GetOwner()));
		return FEnhancedSkillHandle();
	}

	if (!Context->CommitSkill(&FailReason))
	{
		EA_RUNTIME_LOG(Log, TEXT("CommitSkill failed Reason: %s, ID: %s, Actor: %s"), *FailReason, *SkillID.ToString(), *GetNameSafe(GetOwner()));
		return FEnhancedSkillHandle();
	}

	return TryCastSkillInternal(Context);
}

TSharedPtr<FEnhancedSkillContext> UEnhancedAbilitySystemComponent::FindSkillContext(FEnhancedSkillHandle Handle) const
{
	if (!IsValid(AbilityWorld))
	{
		EA_RUNTIME_LOG(Error, TEXT("AbilityWorld invalid, Actor: %s "), *GetNameSafe(GetOwner()));
		return nullptr;
	}

	return AbilityWorld->FindSkillContext(Handle);
}

bool UEnhancedAbilitySystemComponent::HandleInterruptEvent(FGameplayTag InComingEvent)
{
	// 只有第一方和服务器允许处理打断逻辑
	if (!IsLocallyControlled() && !HasAuthority())
	{
		return false;
	}

	bool bCanInterrupt = true;

	// 打断所有技能, 有任意一个打断失败视为打断失败
	// TODO(jimmyzou): 理论上应该一个角色同时只能有一个行为在前台(有动画表现), 这里只需要处理这个在前台的技能就好了
	for (const UEnhancedSkill* ActivatingSkill : ActivatingSkills)
	{
		const TSharedPtr<FEnhancedSkillContext> SkillContext = ActivatingSkill->GetSkillContext();
		if (!SkillContext || SkillContext->IsTerminated())
		{
			continue;
		}

		// ProcessInterruptEvent会返回这个Event能否成功执行, 并处理打断逻辑(就是说SkillContext如果被打断了, 会在这个调用里直接调Terminate进行打断)
		bCanInterrupt &= SkillContext->HandleInterruptEvent(InComingEvent);
	}

	return bCanInterrupt;
}

bool UEnhancedAbilitySystemComponent::CanInterruptByEvent(FGameplayTag InComingEvent)
{
	bool bCanInterrupt = true;

	// 查询所有技能, 任意一个无法打断则返回失败
	for (const UEnhancedSkill* ActivatingSkill : ActivatingSkills)
	{
		const TSharedPtr<FEnhancedSkillContext> SkillContext = ActivatingSkill->GetSkillContext();
		if (!SkillContext || SkillContext->IsTerminated())
		{
			continue;
		}

		bCanInterrupt &= SkillContext->CanInterruptBy(InComingEvent);
	}

	return bCanInterrupt;
}

void UEnhancedAbilitySystemComponent::ClearSkillEventHandler(FEnhancedSkillHandle Handle) const
{
	if (!IsValid(AbilityWorld))
	{
		EA_RUNTIME_LOG(Error, TEXT("AbilityWorld invalid, Actor: %s "), *GetNameSafe(GetOwner()));
		return;
	}

	const TSharedPtr<FEnhancedSkillContext> Context = AbilityWorld->FindSkillContext(Handle);
	if (!Context)
	{
		EA_RUNTIME_LOG(Error, TEXT("Find skill context failed Handle: %s, Actor: %s"), *Handle.ToString(), *GetNameSafe(GetOwner()));
		return;
	}

	Context->ClearEventHandler();
}

void UEnhancedAbilitySystemComponent::ServerInterruptSkill_Implementation(FEnhancedSkillHandle Handle) const
{
	if (!IsValid(AbilityWorld))
	{
		EA_RUNTIME_LOG(Error, TEXT("AbilityWorld invalid, Actor: %s "), *GetNameSafe(GetOwner()));
		return;
	}

	const TSharedPtr<FEnhancedSkillContext> Context = AbilityWorld->FindSkillContext(Handle);
	if (!Context)
	{
		EA_RUNTIME_LOG(Error, TEXT("Find skill context failed Handle: %s, Actor: %s"), *Handle.ToString(), *GetNameSafe(GetOwner()));
		return;
	}

	MulticastInterruptSkill(Handle);
}

void UEnhancedAbilitySystemComponent::MulticastInterruptSkill_Implementation(FEnhancedSkillHandle Handle) const
{
	if (!IsValid(AbilityWorld))
	{
		EA_RUNTIME_LOG(Error, TEXT("AbilityWorld invalid, Actor: %s "), *GetNameSafe(GetOwner()));
		return;
	}

	const TSharedPtr<FEnhancedSkillContext> Context = AbilityWorld->FindSkillContext(Handle);
	if (!Context)
	{
		EA_RUNTIME_LOG(Error, TEXT("Find skill context failed Handle: %s, Actor: %s"), *Handle.ToString(), *GetNameSafe(GetOwner()));
		return;
	}

	Context->Terminate(EEnhancedSkillStage::Interrupted);
}

FEnhancedSkillHandle UEnhancedAbilitySystemComponent::TryCastSkillInternal(const TSharedPtr<FEnhancedSkillContext>& Context)
{
	const bool bIsLocal = Context->IsLocallyControlled();
	const bool bHasAuthority = Context->HasAuthority();
	// 服务器或者是本地单位, 广播技能释放消息
	if (bHasAuthority && !bIsLocal)
	{
		MulticastCastSkillSuccess(*Context);
	}
	// 受本地控制,但是不是Authority的, 执行预测逻辑并通知Server释放技能
	else if (bIsLocal)
	{
		// 客户端预表现技能
		LocalCastSkillInternal(Context);

		if (!bHasAuthority)
		{
			ServerTryCastSkill(*Context);
		}
	}

	return Context->GetHandle();
}

void UEnhancedAbilitySystemComponent::LocalCastSkillInternal(const TSharedPtr<FEnhancedSkillContext>& Context)
{
	// 到这一步, 所有的检查都已经通过了, 后面的检查都只是出于代码保护, 所以后面的错误都应该是Error级别的
	const UEnhancedSkillData* SkillData = Context->GetSkillData();
	if (!SkillData)
	{
		EA_RUNTIME_LOG(Error, TEXT("Received skill data in net context is invalid, Actor: %s "), *GetNameSafe(GetOwner()));
		return;
	}

	UEnhancedSkill* RuntimeSkill = UEnhancedSkill::Make(this, SkillData, Context);
	if (!IsValid(RuntimeSkill))
	{
		EA_RUNTIME_LOG(Error, TEXT("Make runtime skill failed ID: %s, Actor: %s"), *SkillData->ID.ToString(), *GetNameSafe(GetOwner()));
		return;
	}

	FString FailReason;
	if (!RuntimeSkill->BeginSkill(FailReason))
	{
		EA_RUNTIME_LOG(Error, TEXT("Begin runtime skill failed Reason: %s, ID: %s, Actor: %s"), *FailReason, *SkillData->ID.ToString(), *GetNameSafe(GetOwner()));
		return;
	}

	AddActivatingSkill(RuntimeSkill);
}

void UEnhancedAbilitySystemComponent::MulticastCastSkillSuccess_Implementation(FEnhancedSkillContext NetContext)
{
	// 收到本地释放技能成功的回包
	if (NetContext.GetHandle().IsLocalHandle() && ActivatingSkills.ContainsByPredicate([Handle = NetContext.GetHandle()](const UEnhancedSkill* SkillItem)
	{
		return SkillItem->GetSkillContext() && SkillItem->GetSkillContext()->GetHandle() == Handle;
	}))
	{
		ClientSkillConfirmed(NetContext.GetHandle());
		return;
	}

	if (!AbilityWorld)
	{
		EA_RUNTIME_LOG(Error, TEXT("AbilityWorld invalid, Actor: %s "), *GetNameSafe(GetOwner()));
		return;
	}

	const TSharedPtr<FEnhancedSkillContext> Context = AbilityWorld->ReceiveNetSkillContext(NetContext);
	if (!Context)
	{
		EA_RUNTIME_LOG(Error, TEXT("Receive skill context from network failed, Actor: %s "), *GetNameSafe(GetOwner()));
		return;
	}

	LocalCastSkillInternal(Context);
}

void UEnhancedAbilitySystemComponent::ServerTryCastSkill_Implementation(FEnhancedSkillContext NetContext)
{
	struct FScopedRequest
	{
		UEnhancedAbilitySystemComponent* Owner;
		FEnhancedSkillHandle Handle;
		bool bConfirmed;

		FScopedRequest(UEnhancedAbilitySystemComponent* Owner, FEnhancedSkillHandle Handle)
			: Owner(Owner),
			  Handle(Handle),
			  bConfirmed(false)
		{
		}

		~FScopedRequest()
		{
			if (!bConfirmed)
			{
				Owner->ClientSkillRejected(Handle);
			}
		}

		void Confirm()
		{
			bConfirmed = true;
		}
	} Request(this, NetContext.GetHandle());

	if (!AbilityWorld)
	{
		EA_RUNTIME_LOG(Error, TEXT("AbilityWorld invalid, Actor: %s "), *GetNameSafe(GetOwner()));
		return;
	}

	const TSharedPtr<FEnhancedSkillContext> Context = AbilityWorld->ReceiveNetSkillContext(NetContext);
	if (!Context)
	{
		EA_RUNTIME_LOG(Error, TEXT("Receive skill context from network failed, Actor: %s "), *GetNameSafe(GetOwner()));
		return;
	}

	FString FailReason;
	if (!Context->PreCheck(&FailReason))
	{
		EA_RUNTIME_LOG(Log, TEXT("Server PreCheck failed Reason: %s, ID: %s, Actor: %s"), *FailReason, *Context->GetSkillID().ToString(), *GetNameSafe(GetOwner()));
		return;
	}

	if (!Context->CommitSkill(&FailReason))
	{
		EA_RUNTIME_LOG(Log, TEXT("Server CommitSkill failed Reason: %s, ID: %s, Actor: %s"), *FailReason, *Context->GetSkillID().ToString(), *GetNameSafe(GetOwner()));
		return;
	}

	Request.Confirm();
	TryCastSkillInternal(Context);
}

void UEnhancedAbilitySystemComponent::ClientSkillRejected_Implementation(FEnhancedSkillHandle Handle)
{
}

void UEnhancedAbilitySystemComponent::ClientSkillConfirmed(FEnhancedSkillHandle Handle)
{
}

void UEnhancedAbilitySystemComponent::InternalTickSkills(float DeltaTime)
{
	TArray<int32> TerminatedIndex;

	{
		TGuardValue LoopingGuard(bLoopingActivatingSkills, true);
		for (int32 Index = 0, Num = ActivatingSkills.Num(); Index < Num; ++Index)
		{
			UEnhancedSkill* RuntimeSkill = ActivatingSkills[Index];
			if (!RuntimeSkill->IsTerminated())
			{
				RuntimeSkill->TickSkill(DeltaTime);
			}

			if (RuntimeSkill->IsTerminated())
			{
				TerminatedIndex.Add(Index);
			}
		}
	}

	for (int32 Index = TerminatedIndex.Num() - 1; Index >= 0; --Index)
	{
		ActivatingSkills.RemoveAtSwap(TerminatedIndex[Index]);
	}

	ActivatingSkills.Append(PendingActivatingSkills);
	PendingActivatingSkills.Empty();
}

void UEnhancedAbilitySystemComponent::AddActivatingSkill(UEnhancedSkill* RuntimeSkill)
{
	if (bLoopingActivatingSkills)
	{
		PendingActivatingSkills.Emplace(RuntimeSkill);
		return;
	}

	ActivatingSkills.Emplace(RuntimeSkill);
}

bool UEnhancedAbilitySystemComponent::IsLocallyControlled() const
{
	if (const APlayerController* PlayerController = Cast<APlayerController>(GetOwner()))
	{
		return PlayerController->IsLocalController();
	}

	if (const APawn* Pawn = Cast<APawn>(GetOwner()))
	{
		return Pawn->IsLocallyControlled();
	}

	return HasAuthority();
}

bool UEnhancedAbilitySystemComponent::HasAuthority() const
{
	if (const AActor* OwnerActor = GetOwner())
	{
		return OwnerActor->GetLocalRole() == ROLE_Authority;
	}

	return false;
}
