﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnhancedAbilityState.h"
#include "Components/ActorComponent.h"
#include "Skill/EnhancedSkill.h"
#include "Skill/EnhancedSkillTypes.h"
#include "EnhancedAbilitySystemComponent.generated.h"

class UEnhancedSkill;
class UEnhancedSkillData;
struct FEnhancedSkillContext;
class UEnhancedAbilityWorld;

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class ENHANCEDABILITY_API UEnhancedAbilitySystemComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	static UEnhancedAbilitySystemComponent* GetFromOwner(const AActor* OwnerActor);
	UEnhancedAbilitySystemComponent();

	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void InitializeComponent() override;
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	FEnhancedSkillHandle CastSkill(FSkillID SkillID, FEnhancedSkillEventDataContainer* EventData = nullptr, FEnhancedSkillStageEventHandler* EventHandler = nullptr);
	TSharedPtr<FEnhancedSkillContext> FindSkillContext(FEnhancedSkillHandle Handle) const;

	/**
	 * 当前所有正在播放的技能, 是否都能被给定的事件打断
	 * 所有技能都能打断时, 返回true
	 */
	bool CanInterruptByEvent(FGameplayTag InComingEvent);

	/**
	 * 使用传入的事件尝试打断当前技能, 并返回打断的结果
	 * @param InComingEvent 打断事件
	 * @return 是否打断成功, 通常情况下如果这里返回false, 那调用方应该认为传入的事件目前是不能执行的
	 */
	bool HandleInterruptEvent(FGameplayTag InComingEvent);

	void ClearSkillEventHandler(FEnhancedSkillHandle Handle) const;

	UFUNCTION(Server, Reliable)
	void ServerInterruptSkill(FEnhancedSkillHandle Handle) const;

protected:
	FEnhancedSkillHandle TryCastSkillInternal(const TSharedPtr<FEnhancedSkillContext>& Context);
	void LocalCastSkillInternal(const TSharedPtr<FEnhancedSkillContext>& Context);

	/** 本地释放, 客户端预测后服务器的成功的消息, 以及第三方收到的服务器通知都在这个函数里处理 */
	UFUNCTION(NetMulticast, Reliable)
	void MulticastCastSkillSuccess(FEnhancedSkillContext NetContext);

	UFUNCTION(Server, Reliable)
	void ServerTryCastSkill(FEnhancedSkillContext NetContext);

	UFUNCTION(Client, Reliable)
	void ClientSkillRejected(FEnhancedSkillHandle Handle);

	/** Confirm的调用跟着MultiCastSuccess一起下来, 所以这个函数不需要是个RPC */
	void ClientSkillConfirmed(FEnhancedSkillHandle Handle);

	UFUNCTION(NetMulticast, Reliable)
	void MulticastInterruptSkill(FEnhancedSkillHandle Handle) const;

	void InternalTickSkills(float DeltaTime);

	void AddActivatingSkill(UEnhancedSkill* RuntimeSkill);

	bool IsLocallyControlled() const;
	bool HasAuthority() const;

private:
	/** 正在遍历ActivatingSkills列表, 防止遍历过程中修改列表, 这个期间新增的技能实例会放到PendingActivatingSkills中 */
	bool bLoopingActivatingSkills;

	UPROPERTY(Transient)
	UEnhancedAbilityWorld* AbilityWorld;

	UPROPERTY(Transient)
	TArray<UEnhancedSkill*> ActivatingSkills;

	UPROPERTY(Transient)
	TArray<UEnhancedSkill*> PendingActivatingSkills;

public:
	template <typename T, typename... ArgsType>
	FORCEINLINE T& SetAbilityState(ArgsType&&... Args)
	{
		return AbilityStates.Set<T>(Forward<ArgsType>(Args)...);
	}

	template <typename T>
	FORCEINLINE void ClearAbilityState()
	{
		AbilityStates.Clear<T>();
	}


	template <typename T>
	FORCEINLINE bool ContainsAbilityState() const
	{
		return AbilityStates.Get<T>() != nullptr;
	}

	/**
	 * 查找并返回给定类型的AbilityState对象的拷贝, 需要Struct类型严格一致, 不考虑继承关系
	 * 返回拷贝而不是指针时因为指针指向的对象随时可能因为网络同步而修改或失效, 返回指针不安全
	 * @return 是否有该类型的State
	 */
	template <typename T>
	FORCEINLINE bool TryGetAbilityState(T& OutState) const
	{
		const T* FoundState = AbilityStates.Get<T>();
		if (!FoundState)
		{
			return false;
		}

		OutState = *FoundState;
		return true;
	}

	template <typename T>
	FORCEINLINE bool WriteAbilityState(const T& InState)
	{
		T* FoundState = AbilityStates.Get<T>();
		if (!FoundState)
		{
			return false;
		}

		*FoundState = InState;
		return true;
	}

private:
	UPROPERTY(Replicated)
	FEnhancedAbilityStateContainer AbilityStates;
};
