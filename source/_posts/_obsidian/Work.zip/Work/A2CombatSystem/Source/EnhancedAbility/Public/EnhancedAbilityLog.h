﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/Engine.h"

ENHANCEDABILITY_API DECLARE_LOG_CATEGORY_EXTERN(LogEnhancedAbility, Display, All);

FORCEINLINE FString BoolToString(const bool Value)
{
	return Value ? TEXT("true") : TEXT("false");
}

class FEnhancedAbilityScreenLogger
{
public:

	static FColor GetOnScreenVerbosityColor(const ELogVerbosity::Type Verbosity)
	{
		return
			Verbosity == ELogVerbosity::Fatal || Verbosity == ELogVerbosity::Error ? FColor::Red :
			Verbosity == ELogVerbosity::Warning ? FColor::Yellow :
			Verbosity == ELogVerbosity::Display || Verbosity == ELogVerbosity::Log ? FColor::Cyan :
			Verbosity == ELogVerbosity::Verbose || Verbosity == ELogVerbosity::VeryVerbose ? FColor::Orange :
			FColor::Cyan;
	}

	static void AddOnScreenDebugMessage(const ELogVerbosity::Type Verbosity, const FString& Message)
	{
		if (GEngine)
		{
			const FColor Color = GetOnScreenVerbosityColor(Verbosity);
			GEngine->AddOnScreenDebugMessage(INDEX_NONE, 5.f, Color, Message);
		}
	}
};

#define EA_RUNTIME_LOG(Verbosity, Format, ...) \
{ \
UE_LOG(LogEnhancedAbility, Verbosity, TEXT("[%llu] %s(%d) - %s"), GFrameCounter, *FString(__FUNCTION__), __LINE__, *FString::Printf(Format, ##__VA_ARGS__)); \
}

#define EA_RUNTIME_CLOG(Condition, Verbosity, Format, ...) \
{ \
UE_CLOG(Condition, LogEnhancedAbility, Verbosity, TEXT("[%llu] %s(%d) - %s"), GFrameCounter, *FString(__FUNCTION__), __LINE__, *FString::Printf(Format, ##__VA_ARGS__)); \
}

#define EA_RUNTIME_SLOG(Verbosity, Format, ...) \
{ \
FEnhancedAbilityScreenLogger::AddOnScreenDebugMessage(ELogVerbosity::Verbosity, FString::Printf(Format, ##__VA_ARGS__)); \
EA_RUNTIME_LOG(Verbosity, Format, ##__VA_ARGS__) \
}

