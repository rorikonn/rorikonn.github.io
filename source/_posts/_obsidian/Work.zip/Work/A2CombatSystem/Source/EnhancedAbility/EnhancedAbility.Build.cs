﻿using UnrealBuildTool;

public class EnhancedAbility : ModuleRules
{
	public EnhancedAbility(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"Engine",
				"Projects",
				"MovieScene",
				"LevelSequence",
				"UniversalTimeline",
				"CombatCommon",
				"ComboGraph",
				"GameplayTags",
				"CombatTargeting",
				"AnimGraphRuntime",
				"CombatMotionWarping",
				"GameplayAbilities",
			}
		);

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine",
				"ComboGraph"
			}
		);
	}
}