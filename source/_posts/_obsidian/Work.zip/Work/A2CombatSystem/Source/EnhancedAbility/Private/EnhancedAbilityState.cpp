﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "EnhancedAbilityState.h"

#include "EnhancedAbilityLog.h"


bool FEnhancedAbilityStateContainer::NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess)
{
	uint8 DataNum;
	if (Ar.IsSaving())
	{
		EA_RUNTIME_CLOG(Data.Num() > MAX_uint8, Warning, TEXT("Too many Data(%d!) in container to net serialize. Clamping to %d"), Data.Num(), MAX_uint8);
		DataNum = FMath::Min<int32>(Data.Num(), MAX_uint8);
	}

	Ar << DataNum;
	if (Ar.IsLoading())
	{
		Data.SetNum(DataNum);
	}

	for (int32 Index = 0; Index < DataNum && !Ar.IsError(); ++Index)
	{
		TCheckedObjPtr<UScriptStruct> ScriptStruct = Data[Index].IsValid() ? Data[Index]->GetScriptStruct() : nullptr;
		Ar << ScriptStruct;

		if (ScriptStruct.IsValid())
		{
			if (Ar.IsLoading())
			{
				check(!Data[Index].IsValid());
				FEnhancedAbilityState* NewData = StaticCast<FEnhancedAbilityState*>(FMemory::Malloc(ScriptStruct->GetStructureSize()));
				ScriptStruct->InitializeStruct(NewData);

				Data[Index] = TSharedPtr<FEnhancedAbilityState>(NewData, FEnhancedAbilityState::FDeleter());
			}

			check(Data[Index].IsValid());
			Data[Index]->NetSerialize(Ar, Map, bOutSuccess);
		}
		else if (ScriptStruct.IsError())
		{
			EA_RUNTIME_LOG(Error, TEXT("Bad ScriptStruct serialized, can't recover."));
			Ar.SetError();
			break;
		}
	}

	if (Ar.IsError())
	{
		for (int32 Index = Data.Num() - 1; Index >= 0; --Index)
		{
			if (!Data[Index].IsValid())
			{
				Data.RemoveAt(Index);
			}
		}

		bOutSuccess = false;
		return false;
	}

	bOutSuccess = true;
	return true;
}
