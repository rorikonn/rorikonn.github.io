﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "EnhancedAbilityWorld.h"
#include "Skill/EnhancedSkillContext.h"


TStatId UEnhancedAbilityWorld::GetStatId() const
{
	RETURN_QUICK_DECLARE_CYCLE_STAT(UEnhancedAbilityWorld, STATGROUP_Tickables);
}

void UEnhancedAbilityWorld::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	CheckInvalidatedContext(DeltaTime);
}

TSharedPtr<FEnhancedSkillContext> UEnhancedAbilityWorld::MakeSkillContext(UEnhancedAbilitySystemComponent* Owner, const UEnhancedSkillData* SkillData)
{
	const FEnhancedSkillHandle NewHandle = FEnhancedSkillHandle::Generate();
	return SkillContexts.Add(NewHandle, MakeShared<FEnhancedSkillContext>(NewHandle, Owner, SkillData));
}

TSharedPtr<FEnhancedSkillContext> UEnhancedAbilityWorld::FindSkillContext(FEnhancedSkillHandle Handle)
{
	if (TSharedPtr<FEnhancedSkillContext>* FoundContext = SkillContexts.Find(Handle))
	{
		return *FoundContext;
	}

	return nullptr;
}

TSharedPtr<FEnhancedSkillContext> UEnhancedAbilityWorld::ReceiveNetSkillContext(const FEnhancedSkillContext& NetContext)
{
	const FEnhancedSkillHandle Handle = NetContext.GetHandle();
	TSharedPtr<FEnhancedSkillContext>& ContextPtr = SkillContexts.FindOrAdd(Handle);
	if (!ContextPtr)
	{
		ContextPtr = MakeShared<FEnhancedSkillContext>();
	}

	*ContextPtr = NetContext;
	return ContextPtr;
}

void UEnhancedAbilityWorld::CheckInvalidatedContext(float DeltaTime)
{
	constexpr int32 MaxInvalidNumEveryCheck = 4;
	FEnhancedSkillHandle InvalidHandles[MaxInvalidNumEveryCheck];
	int32 InvalidNumThisCheck = 0;
	for (const TTuple<FEnhancedSkillHandle, TSharedPtr<FEnhancedSkillContext>>& Pair : SkillContexts)
	{
		if (!Pair.Value->IsTerminated() || !Pair.Value.IsUnique())
		{
			continue;
		}

		InvalidHandles[InvalidNumThisCheck] = Pair.Key;
		++InvalidNumThisCheck;
		if (InvalidNumThisCheck >= MaxInvalidNumEveryCheck)
		{
			break;
		}
	}

	while (InvalidNumThisCheck > 0)
	{
		SkillContexts.Remove(InvalidHandles[--InvalidNumThisCheck]);
	}
}
