﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Skill/EnhancedSkill.h"

#include "EnhancedAbilityWorld.h"
#include "LevelSequence.h"
#include "LevelSequencePlayer.h"
#include "UniversalTimelinePlayer.h"
#include "Skill/EnhancedSkillContext.h"

ULevelSequence* UEnhancedSkillData::GetSequence() const
{
	if (!Sequence.IsValid())
	{
		return Sequence.LoadSynchronous();
	}

	return Sequence.Get();
}

UEnhancedSkill::UEnhancedSkill()
	: bTerminated(false)
{
}

UEnhancedSkill* UEnhancedSkill::Make(UObject* Outer, const UEnhancedSkillData* Data, const TSharedPtr<FEnhancedSkillContext>& InContext)
{
	UEnhancedSkill* NewSkill = NewObject<UEnhancedSkill>(Outer, NAME_None, RF_Transient);
	NewSkill->Initialize(Data, InContext);
	return NewSkill;
}

void UEnhancedSkill::Initialize(const UEnhancedSkillData* Data, TSharedPtr<FEnhancedSkillContext> InContext)
{
	ReferenceData = Data;
	Context = MoveTemp(InContext);
	Context->AddEventHandler(EEnhancedSkillStage::Terminate, FEnhancedSkillStageEvent::FDelegate::CreateUObject(this, &UEnhancedSkill::EndSkill));
	TimelineContext = MakeShared<FEnhancedSkillTimelineContext>(Context);
}

bool UEnhancedSkill::BeginSkill(FString& FailReason)
{
	check(Context.IsValid());
	check(ReferenceData);

	Context->OnSkillBegin();

	FMovieSceneSequencePlaybackSettings PlaybackSettings;
	PlaybackSettings.bPauseAtEnd = ReferenceData->bIsPersistent;
	TimelinePlayer = UUniversalTimelinePlayerManager::GetSequencePlayer(Context->GetCasterActor(), ReferenceData->GetSequence(), PlaybackSettings);
	if (TimelinePlayer)
	{
		TimelinePlayer->OnStop.AddDynamic(this, &UEnhancedSkill::OnSequenceStop);
		TimelinePlayer->SetTimeController(MakeShared<FMovieSceneTimeController_TickWithActor>(Context->GetCasterActor()));
		TimelinePlayer->PlayWithContext(TimelineContext);
	}
	else
	{
		OnSequenceStop();
	}

	return true;
}

void UEnhancedSkill::TickSkill(float DeltaTime)
{
}

// ReSharper disable once CppMemberFunctionMayBeConst
void UEnhancedSkill::EndSkill()
{
	if (bTerminated)
	{
		return;
	}

	check(Context.IsValid());
	check(ReferenceData);

	bTerminated = true;
	Context->ClearEventHandler(this);

	if (TimelinePlayer && (TimelinePlayer->IsPlaying() || TimelinePlayer->IsPaused()))
	{
		TimelinePlayer->StopAtCurrentTime();
	}
}

// ReSharper disable once CppMemberFunctionMayBeConst
void UEnhancedSkill::OnSequenceStop()
{
	if (Context)
	{
		Context->Terminate(EEnhancedSkillStage::Complete);
	}

	if (TimelinePlayer)
	{
		TimelinePlayer->OnStop.RemoveAll(this);
		TimelinePlayer.Release();
	}
}
