﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "EnhancedAbilityState.generated.h"

/**
 * 自定义的AbilityState
 */
USTRUCT()
struct ENHANCEDABILITY_API FEnhancedAbilityState
{
	GENERATED_BODY()
	struct FDeleter
	{
		FORCEINLINE void operator()(FEnhancedAbilityState* Object) const
		{
			check(Object);
			const UScriptStruct* ScriptStruct = Object->GetScriptStruct();
			check(ScriptStruct);
			ScriptStruct->DestroyStruct(Object);
			FMemory::Free(Object);
		}
	};

	virtual ~FEnhancedAbilityState() = default;

	virtual UScriptStruct* GetScriptStruct() const PURE_VIRTUAL(FEnhancedAbilityState::GetScriptStruct, return StaticStruct();)
	virtual bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess) PURE_VIRTUAL(FEnhancedAbilityState::NetSerialize, return false;)
};


/**
 * 自定义的AbilityState, 用于存储外围系统的状态, 如GP系统等
 */
USTRUCT()
struct FEnhancedAbilityStateContainer
{
	GENERATED_BODY()

	/** 如果没有就新增, 如果有就替换  */
	template <typename T, typename... ArgsType>
	FORCEINLINE T& Set(ArgsType&&... Args)
	{
		T* ExistData = Get<T>();
		if (!ExistData)
		{
			TSharedPtr<T> NewData = MakeShared<T>(Forward<ArgsType>(Args)...);
			Data.Add(MoveTemp(NewData));
			return *NewData;
		}

		*ExistData = T(Forward<ArgsType>(Args)...);
		return *ExistData;
	}

	template <typename T>
	FORCEINLINE void Clear()
	{
		for (int32 Index = Data.Num() - 1; Index >= 0; --Index)
		{
			const TSharedPtr<FEnhancedAbilityState>& DataIter = Data[Index];
			if (DataIter->GetScriptStruct() == T::StaticStruct())
			{
				Data.RemoveAtSwap(Index);
				break;
			}
		}
	}

	template <typename T>
	FORCEINLINE bool TryGet(T& OutData) const
	{
		const T* FoundData = Get<T>();
		if (!FoundData)
		{
			return false;
		}

		OutData = *FoundData;
		return true;
	}

	template <typename T>
	FORCEINLINE const T* Get() const
	{
		for (const TSharedPtr<FEnhancedAbilityState>& DataIter : Data)
		{
			if (DataIter->GetScriptStruct() == T::StaticStruct())
			{
				return StaticCast<const T*>(DataIter.Get());
			}
		}

		return nullptr;
	}

	template <typename T>
	FORCEINLINE T* Get()
	{
		for (const TSharedPtr<FEnhancedAbilityState>& DataIter : Data)
		{
			if (DataIter->GetScriptStruct() == T::StaticStruct())
			{
				return StaticCast<T*>(DataIter.Get());
			}
		}

		return nullptr;
	}

	bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess);

private:
	TArray<TSharedPtr<FEnhancedAbilityState>> Data;
};


template <>
struct TStructOpsTypeTraits<FEnhancedAbilityStateContainer> : TStructOpsTypeTraitsBase2<FEnhancedAbilityStateContainer>
{
	enum
	{
		WithNetSerializer = true,
	};
};
