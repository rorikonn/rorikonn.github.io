// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatMotionWarpingComponent.h"
#include "EnhancedSkillTypes.h"
#include "GameplayTagContainer.h"
#include "LevelSequence/UniversalTimelineSectionContext.h"
#include "EnhancedSkillContext.generated.h"

class UEnhancedAbilityWorld;
class UEnhancedSkillData;
class UEnhancedAbilitySystemComponent;

/**
 * 技能的运行时上下文, 承载技能与外部系统交互信息的功能, 设计上这个是技能运行时与外部系统交互的唯一对象.
 * 包括技能和技能的Action需要信息传递时, 也应该使用这个对象进行.
 * UEnhancedSkill这个运行时对象本身不应该被外部感知, 也不应该在C-S同步的过程中也被关心.
 * 所以技能运行时仅内部需要的维护的信息可以放在UEnhancedSkill这个对象中, 其他外部可能需要获取/写入的信息都放在这个上下文中
 */
USTRUCT()
struct ENHANCEDABILITY_API FEnhancedSkillContext
{
	GENERATED_BODY()

	FEnhancedSkillContext() = default;
	FEnhancedSkillContext(FEnhancedSkillHandle Handle, const UEnhancedAbilitySystemComponent* CasterComponent, const UEnhancedSkillData* SkillData);

	FEnhancedSkillHandle GetHandle() const;
	FSkillID GetSkillID() const;
	const UEnhancedSkillData* GetSkillData() const;
	AActor* GetCasterActor() const;
	FTransform GetCasterInitialTransform() const;

	FCombatTarget GetTarget() const;

	UWorld* GetWorld() const;
	UEnhancedAbilityWorld* GetAbilityWorld() const;
	AController* GetController() const;
	APlayerController* GetPlayerController() const;
	UEnhancedAbilitySystemComponent* GetAbilityComponent() const;
	UAnimInstance* GetAnimInstance() const;

	UPawnMovementComponent* GetMovementComponent() const;

	template <typename T>
	typename TEnableIf<TIsDerivedFrom<T, UPawnMovementComponent>::Value, T*>::Type GetMovementComponent() const
	{
		return Cast<T>(GetMovementComponent());
	}

	ENetRole GetLocalNetRole() const;
	bool IsLocallyControlled() const;
	bool HasAuthority() const;

	/**
	 * 释放条件检查, 包括:
	 * 1. Requirements/Conflicts, 包含Tag, Buff等
	 * 2. Targeting, 执行索敌逻辑, 如果无法满足索敌要求, 则技能也会释放失败
	 * 资源的检查放到Commit阶段, 区分第一方和服务器逻辑处理
	 * @param FailReason 如果返回失败, 输出失败的原因
	 * @return 技能是否能释放
	 */
	bool PreCheck(FString* FailReason);

	/**
	 * 执行资源消耗, 如: 体力, 能量, Buff, 道具等
	 * @param FailReason 资源消耗失败的具体原因
	 * @return 资源消耗成功与否, 如果失败则技能也会释放失败
	 */
	bool CommitSkill(FString* FailReason);

	void OnSkillBegin();
	/** 可能会被多次调用(外部调用, 或者技能EndSkill被调用的时候也会调用这里) */
	void Terminate(EEnhancedSkillStage Stage);

	FORCEINLINE bool IsTerminated() const
	{
		return CurrentStage != EEnhancedSkillStage::Begin;
	}

	FORCEINLINE bool IsInterrupted() const
	{
		return CurrentStage == EEnhancedSkillStage::Interrupted;
	}

	FORCEINLINE EEnhancedSkillStage GetCurrentStage() const
	{
		return CurrentStage;
	}

	template <typename T>
	const T* GetEventData() const
	{
		return EventData.Get<T>();
	}

	/** 当前技能能否被给定的事件打断 */
	bool CanInterruptBy(FGameplayTag InComingEvent) const;
	
	/** 用给定的事件打断当前技能, 返回打断是否成功 */
	bool HandleInterruptEvent(FGameplayTag InComingEvent);
	
	void EnableInterruptEvent(FGameplayTag InterruptEvent);
	void DisableInterruptEvent(FGameplayTag InterruptEvent);

	/** 在被移动事件打断时, 是否要结束当前技能 */
	bool TerminateWhenInterruptByMovementEvent() const;
	static bool IsMovementEvent(FGameplayTag InComingEvent);

	void BeginRootMotionMontage(int32 MontageInstanceID);
	void EndRootMotionMontage(int32 MontageInstanceID);
	bool HasActiveRootMotion() const;

	/**
	 * 激活一次位置的同步，会向Context的CasterInitialTransform位置对齐
	 * @param RotateDuration 旋转所需的时长，填0则会瞬间转过来
	 * @param TranslateDuration 位移所需的时长，填0则会瞬间转过来
	 * @param Montage 如果是在有RootMotion的Montage过程中同步，需要传入这个蒙太奇的指针
	 * @return 如果传入了一个有RootMotion的Montage，则返回Montage的InstanceID，其他情况将返回RootMotionSourceID(TODO(yuhanlu):待完成)
	 */
	int32 ActiveTransformSync(float RotateDuration, float TranslateDuration, const UAnimMontage* Montage = nullptr) const;


#pragma region Internal Setup

	void SetupEventData(FEnhancedSkillEventDataContainer* InEventData);

	void SetupEventHandler(FEnhancedSkillStageEventHandler* InEventHandler);
	void AddEventHandler(EEnhancedSkillStage Stage, FEnhancedSkillStageEvent::FDelegate Handler);

	/**
	 * 清除SkillStageEvent的EventHandler, 如果UserObject传入非空则只清除该UserObject绑定的EventHandler, 否则清除所有的EventHandler
	 */
	void ClearEventHandler(const UObject* UserObject = nullptr);

#pragma endregion

private:
	void SetupContext();
	void OnEnterSkillStage(EEnhancedSkillStage Stage) const;

	FCombatTarget PerformTargeting() const;


#pragma region Replicated Data

	UPROPERTY()
	uint8 bTerminated : 1;

	UPROPERTY()
	EEnhancedSkillStage CurrentStage;

	UPROPERTY()
	FEnhancedSkillHandle Handle;

	UPROPERTY()
	FCombatTarget Caster;

	UPROPERTY()
	FCombatTarget Target;

	FEnhancedSkillEventDataContainer EventData;

#pragma endregion


	UPROPERTY(Transient)
	UEnhancedAbilityWorld* OwningWorld;

	UPROPERTY(Transient)
	const UEnhancedSkillData* ReferenceData;

	UPROPERTY(Transient)
	UAnimInstance* OwnerAnimInstance;

	UPROPERTY(Transient)
	UCombatMotionWarpingComponent* MotionWarpingComponent;

	// 这个技能正在播放的含有RootMotion的MontageInstanceID, 目前设计上认为一个技能最多只能有一个RootMotion动画
	int32 RootMotionInstanceID;

	TSet<FGameplayTag> AllowedInterruptEvent;
	FEnhancedSkillStageEventHandler EventHandler;

public:
	bool NetSerialize(FArchive& Ar, UPackageMap* Map, bool& bOutSuccess);
};

template <>
struct TStructOpsTypeTraits<FEnhancedSkillContext> : TStructOpsTypeTraitsBase2<FEnhancedSkillContext>
{
	enum
	{
		WithNetSerializer = true,
	};
};
