﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "ComboGraph/ComboGraphNodeSkill.h"

#include "CombatTargetingModule.h"
#include "ComboGraphLog.h"
#include "Graph/ComboGraphContext.h"
#include "Components/ComboGraphSystemComponent.h"
#include "EnhancedAbilitySystemComponent.h"

void UComboGraphBaseSkillNode::Initialize(const UComboGraphNodeData* Data, TSharedPtr<FComboGraphContext> GraphContext)
{
	Super::Initialize(Data, GraphContext);

	EnhancedAbilitySystem = UEnhancedAbilitySystemComponent::GetFromOwner(Context->GetOwnerActor());
}

bool UComboGraphBaseSkillNode::CanInterruptBy(const UComboGraphNodeData* NextNode)
{
	const UComboGraphBaseSkillNodeData* NextSkillNode = Cast<UComboGraphBaseSkillNodeData>(NextNode);
	if (!NextSkillNode)
	{
		return Super::CanInterruptBy(NextNode);
	}

	// 下一个节点是技能节点, 处理技能Event的打断
	const TSharedPtr<FEnhancedSkillContext> SkillContext = GetRelevantSkillContext();
	if (!SkillContext)
	{
		// 如果当前没有这个节点正在释放的技能上下文, 可以被打断
		return true;
	}

	// 判断正在释放的技能能不能被下一个节点的技能打断
	return SkillContext->CanInterruptBy(NextSkillNode->GetSkillEvent());
}

bool UComboGraphBaseSkillNode::CastSkill(FSkillID SkillID, FEnhancedSkillEventDataContainer* EventData, FEnhancedSkillStageEventHandler* EventHandler)
{
	SkillHandle = EnhancedAbilitySystem->CastSkill(SkillID, EventData, EventHandler);
	return SkillHandle.IsValid();
}

FEnhancedSkillHandle UComboGraphBaseSkillNode::GetSkillHandle() const
{
	return SkillHandle;
}

TSharedPtr<FEnhancedSkillContext> UComboGraphBaseSkillNode::GetRelevantSkillContext() const
{
	if (!EnhancedAbilitySystem)
	{
		return nullptr;
	}

	if (!SkillHandle.IsValid())
	{
		return nullptr;
	}

	return EnhancedAbilitySystem->FindSkillContext(SkillHandle);
}

UComboGraphNode* UComboGraphNodeSkillData::MakeRuntimeNode(TSharedPtr<FComboGraphContext> Context) const
{
	check(Context);

	UComboGraphNode* RuntimeNode = NewObject<UComboGraphNodeSkill>(Context->GetOwner(), NAME_None, RF_Transient);
	RuntimeNode->Initialize(this, Context);

	return RuntimeNode;
}

FGameplayTag UComboGraphNodeSkillData::GetSkillEvent() const
{
	const UEnhancedSkillData* SkillData = FDataArchiveManager::Find<UEnhancedSkillData>(Skill);
	if (SkillData)
	{
		return SkillData->EventTag;
	}

	return FGameplayTag();
}

bool UComboGraphNodeSkill::PreActivation()
{
	if (!GetDataChecked<UComboGraphNodeSkillData>().bRequiresTarget)
	{
		return true;
	}

	TArray<FCombatTarget> ScanTargets;
	ICombatTargetingSystem::Get().ScanTargets(Context->GetOwnerActor(), Context->GetOwnerActor()->GetActorTransform(), GetDataChecked<UComboGraphNodeSkillData>().TargetingRange, ScanTargets);

	for (const FCombatTarget& ScanTarget : ScanTargets)
	{
		if (!ScanTarget.IsValid())
		{
			continue;
		}

		NodeTarget = ScanTarget;
		break;
	}

	return NodeTarget.IsValid();
}

bool UComboGraphNodeSkill::OnActivated()
{
	Super::OnActivated();

	if (!EnhancedAbilitySystem)
	{
		CG_RUNTIME_LOG(Warning, TEXT("%s Activate failed, couldn't find valid EnhancedAbilitySystem"), *GetNameSafe(ReferenceData))
		return false;
	}

	FEnhancedSkillEventDataContainer EventData;
	if (NodeTarget.IsValid())
	{
		EventData.AddInitialTarget(NodeTarget);
	}

	FEnhancedSkillStageEventHandler EventHandler;
	EventHandler.OnSkillCanceled.AddUObject(this, &ThisClass::OnSkillCanceled);
	EventHandler.OnSkillInterrupted.AddUObject(this, &ThisClass::OnSkillInterrupted);
	EventHandler.OnSkillComplete.AddUObject(this, &ThisClass::OnSkillComplete);

	return CastSkill(GetDataChecked<UComboGraphNodeSkillData>().Skill, &EventData, &EventHandler);
}

void UComboGraphNodeSkill::OnDeactivated()
{
	Super::OnDeactivated();

	const TSharedPtr<FEnhancedSkillContext> SkillContext = GetRelevantSkillContext();
	if (!SkillContext)
	{
		return;
	}

	SkillContext->ClearEventHandler(this);
	SkillContext->Terminate(EEnhancedSkillStage::Interrupted);
}

void UComboGraphNodeSkill::OnSkillCanceled() const
{
	OnCanceledEvent.Broadcast();
}

void UComboGraphNodeSkill::OnSkillInterrupted() const
{
	OnInterruptedEvent.Broadcast();
}

void UComboGraphNodeSkill::OnSkillComplete() const
{
	OnCompleteEvent.Broadcast();
}
