﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "LevelSequenceActor.h"
#include "MovieSceneSequencePlaybackSettings.h"
#include "UniversalTimelinePlayer.generated.h"

class UUniversalTimelinePlayerManager;
class ALevelSequenceActor;
class ULevelSequence;
class ULevelSequencePlayer;

struct FUniversalTimelinePlayerStruct : FNoncopyable
{
	FUniversalTimelinePlayerStruct(UUniversalTimelinePlayerManager* Owner)
		: Owner(Owner)
	{
	}

	~FUniversalTimelinePlayerStruct();

	TObjectPtr<ALevelSequenceActor> SequenceActor;
	TWeakObjectPtr<UUniversalTimelinePlayerManager> Owner;
};

struct FUniversalTimelinePlayer
{
	FUniversalTimelinePlayer() = default;

	FUniversalTimelinePlayer(UUniversalTimelinePlayerManager* Owner, ALevelSequenceActor* Actor)
	{
		Inner = MakeShared<FUniversalTimelinePlayerStruct>(Owner);
		Inner->SequenceActor = Actor;
	}

	FORCEINLINE bool IsValid() const
	{
		return Inner.IsValid() && Inner->SequenceActor;
	}

	operator bool() const
	{
		return IsValid();
	}

	void Release()
	{
		Inner.Reset();
	}

	ULevelSequencePlayer* operator->() const
	{
		return IsValid() ? Inner->SequenceActor->SequencePlayer.Get() : nullptr;
	}

	ULevelSequencePlayer& operator*() const
	{
		return *Inner->SequenceActor->SequencePlayer;
	}

private:
	TSharedPtr<FUniversalTimelinePlayerStruct> Inner;
};

/**
 * ALevelSequenceActor默认是开启同步的, 但是这里播Sequence并不需要同步, 所以继承一个子类Player出来在构造函数里关掉同步
 * 构造完之后再改Replicates会疯狂刷Warning, 这个问题修掉之后这个Actor就不用了, 构造完之后把Replicates改成false就行了
 */
UCLASS()
class AUniversalTimelinePlayerActor : public ALevelSequenceActor
{
	GENERATED_BODY()

	AUniversalTimelinePlayerActor(const FObjectInitializer& ObjectInitializer);
};

/**
 * 
 */
UCLASS()
class UNIVERSALTIMELINE_API UUniversalTimelinePlayerManager : public UWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual void Initialize(FSubsystemCollectionBase& Collection) override;
	virtual void Deinitialize() override;

	static FUniversalTimelinePlayer GetSequencePlayer(const UObject* Owner, ULevelSequence* Sequence, const FMovieSceneSequencePlaybackSettings& Settings = FMovieSceneSequencePlaybackSettings());

protected:
	friend FUniversalTimelinePlayerStruct;
	ALevelSequenceActor* GetSequenceActor();
	void ReleaseSequenceActor(ALevelSequenceActor* Actor);

private:
	TQueue<ALevelSequenceActor*> IdlingSequenceActor;
};

/**
 * 会受到Actor的TimeDilation影响的TickController 
 */
struct UNIVERSALTIMELINE_API FMovieSceneTimeController_TickWithActor final : FMovieSceneTimeController
{
	FMovieSceneTimeController_TickWithActor(AActor* OwnerActor)
		: CurrentOffsetSeconds(0.0f),
		  OwnerActor(OwnerActor)
	{
	}

protected:
	virtual void OnTick(float DeltaSeconds, float InPlayRate) override;
	virtual void OnStartPlaying(const FQualifiedFrameTime& InStartTime) override;
	virtual FFrameTime OnRequestCurrentTime(const FQualifiedFrameTime& InCurrentTime, float InPlayRate) override;

private:
	double CurrentOffsetSeconds;
	TWeakObjectPtr<AActor> OwnerActor;
};
