﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UniversalTimelineSection.h"
#include "Internationalization/Regex.h"
#include "MovieSceneNameableTrack.h"
#include "Compilation/IMovieSceneTrackTemplateProducer.h"
#include "UniversalTimelineTrack.generated.h"


/**
 * 
 */
UCLASS()
class UNIVERSALTIMELINE_API UUniversalTimelineTrack : public UMovieSceneNameableTrack, public IMovieSceneTrackTemplateProducer
{
	GENERATED_BODY()

public:
	UUniversalTimelineTrack();
	virtual ~UUniversalTimelineTrack() override;
	virtual void PreCompileImpl(FMovieSceneTrackPreCompileResult& OutPreCompileResult) override;

	void Setup(TSubclassOf<UUniversalTimelineSection> MasterSectionClass);
	TSubclassOf<UUniversalTimelineSection> GetMainSectionClass() const;
	
	virtual bool SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const override;
	virtual FMovieSceneEvalTemplatePtr CreateTemplateForSection(const UMovieSceneSection& InSection) const override;

	virtual void RemoveAllAnimationData() override
	{
		AllSections.Empty();
	}

	virtual bool HasSection(const UMovieSceneSection& Section) const override
	{
		return AllSections.Contains(&Section);
	}

	virtual void AddSection(UMovieSceneSection& Section) override
	{
		AllSections.Add(&Section);
	}

	virtual void RemoveSection(UMovieSceneSection& Section) override
	{
		AllSections.Remove(&Section);
	}

	virtual void RemoveSectionAt(int32 SectionIndex) override
	{
		AllSections.RemoveAt(SectionIndex);
	}

	virtual bool IsEmpty() const override
	{
		return AllSections.IsEmpty();
	}

	virtual const TArray<UMovieSceneSection*>& GetAllSections() const override
	{
		return AllSections;
	}

	virtual bool SupportsMultipleRows() const override { return true; }

protected:
	UPROPERTY()
	TArray<UMovieSceneSection*> AllSections;

	UPROPERTY()
	TSubclassOf<UUniversalTimelineSection> OwningSectionClass;

#if WITH_EDITOR

public:
	virtual bool CanRename() const override { return false; }
	virtual FText GetDefaultDisplayName() const override { return OwningSectionClass ? OwningSectionClass->GetDisplayNameText() : GetClass()->GetDisplayNameText(); }

	virtual UMovieSceneSection* CreateNewSection() override;
	virtual UMovieSceneSection* AddNewSection(FFrameNumber KeyTime);
	virtual UMovieSceneSection* AddSubSection(FFrameNumber KeyTime, TSubclassOf<UUniversalTimelineSubSection> SubSectionClass);

	TArray<TSubclassOf<UUniversalTimelineSubSection>> GetSubSectionClasses() const;
	bool HasSubSection() const;

	static FColor GetTrackTintColor(const UClass* Class)
	{
		if (Class)
		{
			const FString ColorString = Class->GetMetaDataText(TEXT("SectionColor")).ToString();

			if (!ColorString.IsEmpty())
			{
				const FRegexPattern RegexPattern(TEXT(R"(^\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*$)"));
				FRegexMatcher RegexMatcher(RegexPattern, ColorString);
				if (RegexMatcher.FindNext())
				{
					const FString R = RegexMatcher.GetCaptureGroup(1);
					const FString G = RegexMatcher.GetCaptureGroup(2);
					const FString B = RegexMatcher.GetCaptureGroup(3);
					return FColor(FCString::Atoi(*R), FCString::Atoi(*G), FCString::Atoi(*B));
				}

				if (ColorString.Equals(TEXT("White"), ESearchCase::IgnoreCase))
					return FColor::White;
				if (ColorString.Equals(TEXT("Black"), ESearchCase::IgnoreCase))
					return FColor::Black;
				if (ColorString.Equals(TEXT("Transparent"), ESearchCase::IgnoreCase))
					return FColor::Transparent;
				if (ColorString.Equals(TEXT("Red"), ESearchCase::IgnoreCase))
					return FColor::Red;
				if (ColorString.Equals(TEXT("Green"), ESearchCase::IgnoreCase))
					return FColor::Green;
				if (ColorString.Equals(TEXT("Blue"), ESearchCase::IgnoreCase))
					return FColor::Blue;
				if (ColorString.Equals(TEXT("Yellow"), ESearchCase::IgnoreCase))
					return FColor::Yellow;
				if (ColorString.Equals(TEXT("Cyan"), ESearchCase::IgnoreCase))
					return FColor::Cyan;
				if (ColorString.Equals(TEXT("Magenta"), ESearchCase::IgnoreCase))
					return FColor::Magenta;
				if (ColorString.Equals(TEXT("Orange"), ESearchCase::IgnoreCase))
					return FColor::Orange;
				if (ColorString.Equals(TEXT("Purple"), ESearchCase::IgnoreCase))
					return FColor::Purple;
				if (ColorString.Equals(TEXT("Turquoise"), ESearchCase::IgnoreCase))
					return FColor::Turquoise;
				if (ColorString.Equals(TEXT("Silver"), ESearchCase::IgnoreCase))
					return FColor::Silver;
				if (ColorString.Equals(TEXT("Emerald"), ESearchCase::IgnoreCase))
					return FColor::Emerald;
			}
		}

		return FColor(150.f, 150.f, 150.f, 255.f);
	}

#endif
};
