// Fill out your copyright notice in the Description page of Project Settings.


#include "LevelSequence/UniversalTimelineEvalTemplate.h"

#include "UniversalTimelineLog.h"
#include "LevelSequence/UniversalTimelineSection.h"
#include "CustomSpawn/CustomSpawn.h"

AActor* GetBoundActor(const FMovieSceneEvaluationOperand& Operand, IMovieScenePlayer& Player)
{
	TSharedPtr<FCustomSpawn> FoundCustomSpawn = Player.FindCustomSpawn(Operand);
	if (FoundCustomSpawn.IsValid())
	{
		return FoundCustomSpawn->GetRealBindActor();
	}

	return nullptr;
}

bool SupportPreview(const FMovieSceneEvaluationOperand& Operand, IMovieScenePlayer& Player)
{
	const AActor* BoundActor = GetBoundActor(Operand, Player);
	if (!BoundActor)
	{
		return false;
	}

	const bool bIsNotInPIEOrNotPlaying = (BoundActor->GetWorld() && !BoundActor->GetWorld()->HasBegunPlay()) || Player.GetPlaybackStatus() != EMovieScenePlayerStatus::Playing;
	return GIsEditor && bIsNotInPIEOrNotPlaying;
}

FUniversalTimelineExecutor* FUniversalTimelineTrackEvalData::MakeSectionExecutor(const FPersistentEvaluationData& PersistentData, const UUniversalTimelineSection* Section)
{
	if (!Section || !ensure(!ExecutorMap.Contains(reinterpret_cast<UPTRINT>(Section))))
	{
		return nullptr;
	}

	IUniversalTimelineSectionOps* ActionOps = Section->GetTimelineSectionOps();
	const TSharedPtr<FUniversalTimelineSectionContext> TimelineContext = PersistentData.GetTypedCustomContext<FUniversalTimelineSectionContext>();
	if (!TimelineContext)
	{
		return nullptr;
	}

	if (!ActionOps->IsEnabled(TimelineContext.Get()))
	{
		return nullptr;
	}

	TUniquePtr<FUniversalTimelineExecutor> Executor = ActionOps->MakeExecutor(Section, TimelineContext.Get());
	if (!Executor.IsValid())
	{
		UT_RUNTIME_LOG(Verbose, TEXT("Setup Section %s failed, executor invalid."), *FUniversalTimelineEvalTemplate::GetDisplayNameSafe(Section));
		return nullptr;
	}

	Executor->ExecutorState = FUniversalTimelineExecutor::EExecutorState::Waiting;
	Executor->Initialize(Section, TimelineContext);
	if (!Executor->IsEnabled())
	{
		UT_RUNTIME_LOG(Verbose, TEXT("Section %s disable by IsEnabled override in current context."), *FUniversalTimelineEvalTemplate::GetDisplayNameSafe(Section));
		return nullptr;
	}

	// 同一个Track下的不同Section, 这个值总是相同的, 所以这里直接覆盖
	bIsTickEnabled = ActionOps->IsTickEnabled();

	FUniversalTimelineExecutor* ExecutorPtr = Executor.Get();
	ExecutorMap.Add(reinterpret_cast<UPTRINT>(Section), MoveTemp(Executor));
	return ExecutorPtr;
}

FUniversalTimelineEvalTemplate::FUniversalTimelineEvalTemplate()
{
}

void FUniversalTimelineEvalTemplate::OnBeginCustomEvaluation(const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
	const UUniversalTimelineSection* SourceSection = Cast<UUniversalTimelineSection>(GetSourceSection());
	if (!SourceSection)
	{
		UT_RUNTIME_LOG(Verbose, TEXT("Setup Section failed, Section invalid."));
		return;
	}

#if WITH_EDITOR
	if (SupportPreview(Operand, Player))
	{
		FUniversalTimelineSectionEvalData& SectionEvalData = PersistentData.GetOrAddSectionData<FUniversalTimelineSectionEvalData>();
		IUniversalTimelineSectionOps* ActionOps = SourceSection->GetTimelineSectionOps();
		if (!ActionOps)
		{
			return;
		}

		TUniquePtr<FUniversalTimelinePreviewer> Previewer = ActionOps->MakePreviewer(SourceSection);
		if (!Previewer.IsValid())
		{
			return;
		}

		Previewer->Initialize(SourceSection);
		Previewer->OnPreviewStart(GetBoundActor(Operand, Player));
		SectionEvalData.Previewer = MoveTemp(Previewer);
		return;
	}
#endif

	FUniversalTimelineTrackEvalData& TrackEvalData = PersistentData.GetOrAddTrackData<FUniversalTimelineTrackEvalData>();

	if (const UUniversalTimelineSubSection* SubSection = Cast<UUniversalTimelineSubSection>(SourceSection))
	{
		const UUniversalTimelineSection* MainSection = SubSection->GetMainSection();
		if (FUniversalTimelineExecutor* MainSectionExecutor = TrackEvalData.GetOrAddSectionExecutor(PersistentData, MainSection))
		{
			MainSectionExecutor->EvaluatingTime = SubSection->GetSectionStartTimeFrame();
			MainSectionExecutor->FrameRate = SubSection->GetSequenceFrameRate();
			MainSectionExecutor->OnSubSectionStart(SubSection);
		}
	}
	else
	{
		if (FUniversalTimelineExecutor* SectionExecutor = TrackEvalData.GetOrAddSectionExecutor(PersistentData, SourceSection))
		{
			SectionExecutor->ExecutorState = FUniversalTimelineExecutor::EExecutorState::Running;
			SectionExecutor->EvaluatingTime = SourceSection->GetSectionStartTimeFrame();
			SectionExecutor->FrameRate = SourceSection->GetSequenceFrameRate();
			SectionExecutor->OnSectionStart();
		}
	}
}

void FUniversalTimelineEvalTemplate::OnEndCustomEvaluation(const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const
{
#if WITH_EDITOR
	FUniversalTimelineSectionEvalData* SectionEvalData = PersistentData.FindSectionData<FUniversalTimelineSectionEvalData>();
	// End的时候, SupportPreview的检查会失效, 因为无论是不是Preview, Player的Status都不是Playing了
	// Previewer和Executor的逻辑不会同时执行, 所以这里Previewer如果有就执行完PreviewEnd之后直接返回
	if (SectionEvalData && SectionEvalData->Previewer.IsValid())
	{
		SectionEvalData->Previewer->OnPreviewEnd(GetBoundActor(Operand, Player));
		SectionEvalData->Previewer.Reset();
		return;
	}
#endif

	FUniversalTimelineTrackEvalData* TrackEvalData = PersistentData.FindTrackData<FUniversalTimelineTrackEvalData>();
	if (!TrackEvalData)
	{
		return;
	}

	const UUniversalTimelineSection* SourceSection = Cast<UUniversalTimelineSection>(GetSourceSection());
	if (const UUniversalTimelineSubSection* SubSection = Cast<UUniversalTimelineSubSection>(SourceSection))
	{
		const UUniversalTimelineSection* MainSection = SubSection->GetMainSection();
		if (FUniversalTimelineExecutor* MainSectionExecutor = TrackEvalData->FindSectionExecutor(MainSection))
		{
			MainSectionExecutor->EvaluatingTime = SubSection->GetSectionEndTimeFrame();
			MainSectionExecutor->FrameRate = SubSection->GetSequenceFrameRate();
			MainSectionExecutor->OnSubSectionEnd(SubSection);
		}
	}
	else if (FUniversalTimelineExecutor* SectionExecutor = TrackEvalData->FindSectionExecutor(SourceSection))
	{
		SectionExecutor->EvaluatingTime = SourceSection->GetSectionEndTimeFrame();
		SectionExecutor->FrameRate = SourceSection->GetSequenceFrameRate();
		SectionExecutor->OnSectionEnd();
		SectionExecutor->ExecutorState = FUniversalTimelineExecutor::EExecutorState::Finished;
	}
}

void FUniversalTimelineEvalTemplate::Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const
{
#if WITH_EDITOR
	FUniversalTimelineSectionEvalData* SectionEvalData = PersistentData.FindSectionData<FUniversalTimelineSectionEvalData>();
	if (SectionEvalData && SectionEvalData->Previewer.IsValid())
	{
		ExecutionTokens.Add(FUniversalTimelineSectionPreviewToken(*SectionEvalData));
	}
#endif

	FUniversalTimelineTrackEvalData* TrackEvalData = PersistentData.FindTrackData<FUniversalTimelineTrackEvalData>();
	if (!TrackEvalData || !TrackEvalData->bIsTickEnabled)
	{
		return;
	}

	const UUniversalTimelineSection* SourceSection = Cast<UUniversalTimelineSection>(GetSourceSection());
	if (const UUniversalTimelineSubSection* SubSection = Cast<UUniversalTimelineSubSection>(SourceSection))
	{
		const UUniversalTimelineSection* MainSection = SubSection->GetMainSection();
		if (FUniversalTimelineExecutor* MainSectionExecutor = TrackEvalData->FindSectionExecutor(MainSection))
		{
			const TRange<FFrameTime> EvaluatingRange = Context.GetRange();
			const TRange<FFrameNumber> SectionRange = SubSection->SectionRange.Value;
			
			ExecutionTokens.Add(FUniversalTimelineSubSectionTickToken(*MainSectionExecutor, SubSection));
		}
	}
	else if (FUniversalTimelineExecutor* SectionExecutor = TrackEvalData->FindSectionExecutor(SourceSection))
	{
		ExecutionTokens.Add(FUniversalTimelineSectionTickToken(*SectionExecutor, SourceSection));
	}
}

TUniquePtr<FUniversalTimelineExecutor> FUniversalTimelineEvalTemplate::MakeSectionExecutor(const FPersistentEvaluationData& PersistentData, const UUniversalTimelineSection* Section, bool& OutEnableTick)
{
	if (!Section)
	{
		return nullptr;
	}

	IUniversalTimelineSectionOps* ActionOps = Section->GetTimelineSectionOps();
	const TSharedPtr<FUniversalTimelineSectionContext> TimelineContext = PersistentData.GetTypedCustomContext<FUniversalTimelineSectionContext>();
	if (!TimelineContext)
	{
		return nullptr;
	}

	if (!ActionOps->IsEnabled(TimelineContext.Get()))
	{
		return nullptr;
	}

	TUniquePtr<FUniversalTimelineExecutor> Executor = ActionOps->MakeExecutor(Section, TimelineContext.Get());
	if (!Executor.IsValid())
	{
		UT_RUNTIME_LOG(Verbose, TEXT("Setup Section %s failed, executor invalid."), *GetDisplayNameSafe(Section));
		return nullptr;
	}

	Executor->Initialize(Section, TimelineContext);
	if (!Executor->IsEnabled())
	{
		UT_RUNTIME_LOG(Verbose, TEXT("Section %s disable by IsEnabled override in current context."), *GetDisplayNameSafe(Section));
		return nullptr;
	}

	OutEnableTick = ActionOps->IsTickEnabled();
	return MoveTemp(Executor);
}

FString FUniversalTimelineEvalTemplate::GetDisplayNameSafe(const UObject* Object)
{
#if WITH_EDITORONLY_DATA
	if (const UClass* Class = Object ? Object->GetClass() : nullptr)
	{
		return Class->GetDisplayNameText().ToString();
	}

	return TEXT("None");
#else
	return GetNameSafe(Object);
#endif
}

void FUniversalTimelineSectionTickToken::Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player)
{
	check(Section);
	const TRange<FFrameTime> EvaluatingRange = Context.GetRange();
	const TRange<FFrameNumber> SectionRange = Section->SectionRange.Value;

	const int32 CurrentFrame = FMath::Min(EvaluatingRange.GetUpperBoundValue().FrameNumber.Value, SectionRange.GetUpperBoundValue().Value);
	const int32 LastFrame = FMath::Max(EvaluatingRange.GetLowerBoundValue().FrameNumber.Value, SectionRange.GetLowerBoundValue().Value);

	const float DeltaTime = Context.GetFrameRate().AsSeconds(FFrameTime(CurrentFrame - LastFrame));

	Executor.EvaluatingTime = Context.GetTime();
	Executor.FrameRate = Context.GetFrameRate();
	Executor.OnSectionTick(DeltaTime);
}

void FUniversalTimelineSubSectionTickToken::Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player)
{
	check(SubSection);
	const TRange<FFrameTime> EvaluatingRange = Context.GetRange();
	const TRange<FFrameNumber> SectionRange = SubSection->SectionRange.Value;

	const int32 CurrentFrame = FMath::Min(EvaluatingRange.GetUpperBoundValue().FrameNumber.Value, SectionRange.GetUpperBoundValue().Value);
	const int32 LastFrame = FMath::Max(EvaluatingRange.GetLowerBoundValue().FrameNumber.Value, SectionRange.GetLowerBoundValue().Value);

	const float DeltaTime = Context.GetFrameRate().AsSeconds(FFrameTime(CurrentFrame - LastFrame));

	Executor.EvaluatingTime = Context.GetTime();
	Executor.FrameRate = Context.GetFrameRate();
	Executor.OnSubSectionTick(SubSection, DeltaTime);
}

#if WITH_EDITOR
void FUniversalTimelineSectionPreviewToken::Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player)
{
	if (!SupportPreview(Operand, Player))
	{
		return;
	}

	EvalData.Previewer->OnPreviewTick(GetBoundActor(Operand, Player), Context, Operand, PersistentData, Player);
}
#endif
