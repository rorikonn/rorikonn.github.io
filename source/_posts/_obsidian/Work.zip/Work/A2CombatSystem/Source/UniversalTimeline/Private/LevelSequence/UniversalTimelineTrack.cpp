﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "LevelSequence/UniversalTimelineTrack.h"

#include "Evaluation/MovieSceneEvalTemplate.h"
#include "LevelSequence/UniversalTimelineSection.h"
#include "LevelSequence/UniversalTimelineEvalTemplate.h"

UUniversalTimelineTrack::UUniversalTimelineTrack()
{
}

UUniversalTimelineTrack::~UUniversalTimelineTrack()
{
}

void UUniversalTimelineTrack::PreCompileImpl(FMovieSceneTrackPreCompileResult& OutPreCompileResult)
{
	for (UMovieSceneSection* Section : AllSections)
	{
		if (UUniversalTimelineSection* UniversalTimelineSection = Cast<UUniversalTimelineSection>(Section))
		{
			UniversalTimelineSection->PreCompile();
		}
	}
}

void UUniversalTimelineTrack::Setup(TSubclassOf<UUniversalTimelineSection> MasterSectionClass)
{
	OwningSectionClass = MasterSectionClass;

#if WITH_EDITOR
	TrackTint = GetTrackTintColor(MasterSectionClass);
#endif
}

TSubclassOf<UUniversalTimelineSection> UUniversalTimelineTrack::GetMainSectionClass() const
{
	return OwningSectionClass;
}

bool UUniversalTimelineTrack::SupportsType(TSubclassOf<UMovieSceneSection> SectionClass) const
{
	return SectionClass == OwningSectionClass;
}

FMovieSceneEvalTemplatePtr UUniversalTimelineTrack::CreateTemplateForSection(const UMovieSceneSection& InSection) const
{
	return StaticCast<const UUniversalTimelineSection&>(InSection).CreateEvalTemplate();
}


#if WITH_EDITOR

UMovieSceneSection* UUniversalTimelineTrack::CreateNewSection()
{
	return NewObject<UUniversalTimelineSection>(this, OwningSectionClass, NAME_None, RF_Transactional);
}

UMovieSceneSection* UUniversalTimelineTrack::AddNewSection(FFrameNumber KeyTime)
{
	UUniversalTimelineSection* NewSection = Cast<UUniversalTimelineSection>(CreateNewSection());
	if (!NewSection)
	{
		return nullptr;
	}

	NewSection->InitialPlacementOnRow(AllSections, KeyTime, 7200, 0);
	AddSection(*NewSection);
	return NewSection;
}

UMovieSceneSection* UUniversalTimelineTrack::AddSubSection(FFrameNumber KeyTime, TSubclassOf<UUniversalTimelineSubSection> SubSectionClass)
{
	UUniversalTimelineSubSection* NewSection = NewObject<UUniversalTimelineSubSection>(this, SubSectionClass, NAME_None, RF_Transactional);
	if (!NewSection)
	{
		return nullptr;
	}
	
	NewSection->InitialPlacementOnRow(AllSections, KeyTime, 7200, 0);
	AddSection(*NewSection);
	return NewSection;
}

TArray<TSubclassOf<UUniversalTimelineSubSection>> UUniversalTimelineTrack::GetSubSectionClasses() const
{
	if (!OwningSectionClass)
	{
		return TArray<TSubclassOf<UUniversalTimelineSubSection>>();
	}

	IUniversalTimelineSectionOps* SectionOps = OwningSectionClass.GetDefaultObject()->GetTimelineSectionOps();
	if (!SectionOps)
	{
		return TArray<TSubclassOf<UUniversalTimelineSubSection>>();
	}

	return SectionOps->GetSubSections();
}

bool UUniversalTimelineTrack::HasSubSection() const
{
	return !GetSubSectionClasses().IsEmpty();
}

#endif
