﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "LevelSequence/UniversalTimelineSection.h"

#include "Evaluation/MovieSceneEvalTemplate.h"
#include "LevelSequence/UniversalTimelineEvalTemplate.h"
#include "LevelSequence/UniversalTimelineSectionContext.h"


void UUniversalTimelineSection::PreCompile()
{
}

FMovieSceneEvalTemplatePtr UUniversalTimelineSection::CreateEvalTemplate() const
{
	return FUniversalTimelineEvalTemplate();
}

#if WITH_EDITOR

FText UUniversalTimelineSection::GetSectionTitle() const
{
	return GetClass()->GetDisplayNameText();
}

const UUniversalTimelineSection* UUniversalTimelineSubSection::GetMainSection() const
{
	const UMovieSceneTrack* SourceTrack = GetTypedOuter<UMovieSceneTrack>();
	if (!SourceTrack)
	{
		return nullptr;
	}

	for (const UMovieSceneSection* Section : SourceTrack->GetAllSections())
	{
		const UUniversalTimelineSection* TimelineSection = Cast<UUniversalTimelineSection>(Section);
		if (!TimelineSection)
		{
			continue;
		}

		IUniversalTimelineSectionOps* SectionOps = TimelineSection->GetTimelineSectionOps();
		if (SectionOps && SectionOps->IsMainSection())
		{
			return TimelineSection;
		}
	}

	return nullptr;
}

#endif

void FUniversalTimelineExecutor::Initialize(const UUniversalTimelineSection* InData, TSharedPtr<FUniversalTimelineSectionContext> InContext)
{
	Data = InData;
	TimelineContext = MoveTemp(InContext);
}

bool FUniversalTimelineExecutor::IsEnabled() const
{
	return true;
}

void FUniversalTimelineExecutor::OnSectionStart()
{
}

void FUniversalTimelineExecutor::OnSectionTick(float DeltaTime)
{
}

void FUniversalTimelineExecutor::OnSectionEnd()
{
}

void FUniversalTimelineExecutor::OnSubSectionStart(const UUniversalTimelineSubSection* SubSection)
{
}

void FUniversalTimelineExecutor::OnSubSectionTick(const UUniversalTimelineSubSection* SubSection, float DeltaTime)
{
}

void FUniversalTimelineExecutor::OnSubSectionEnd(const UUniversalTimelineSubSection* SubSection)
{
}

void FUniversalTimelinePreviewer::Initialize(const UUniversalTimelineSection* InData)
{
	Data = InData;
}

void FUniversalTimelinePreviewer::OnPreviewStart(AActor* BoundActor)
{
}

void FUniversalTimelinePreviewer::OnPreviewEnd(AActor* BoundActor)
{
}

void FUniversalTimelinePreviewer::OnPreviewTick(AActor* BoundActor, const FMovieSceneContext& SceneContext, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player)
{
}
