﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "Engine/Engine.h"

UNIVERSALTIMELINE_API DECLARE_LOG_CATEGORY_EXTERN(LogUniversalTimeline, Display, All);

class FUniversalTimelineScreenLogger
{
public:

	static FColor GetOnScreenVerbosityColor(const ELogVerbosity::Type Verbosity)
	{
		return
			Verbosity == ELogVerbosity::Fatal || Verbosity == ELogVerbosity::Error ? FColor::Red :
			Verbosity == ELogVerbosity::Warning ? FColor::Yellow :
			Verbosity == ELogVerbosity::Display || Verbosity == ELogVerbosity::Log ? FColor::Cyan :
			Verbosity == ELogVerbosity::Verbose || Verbosity == ELogVerbosity::VeryVerbose ? FColor::Orange :
			FColor::Cyan;
	}

	static void AddOnScreenDebugMessage(const ELogVerbosity::Type Verbosity, const FString& Message)
	{
		if (GEngine)
		{
			const FColor Color = GetOnScreenVerbosityColor(Verbosity);
			GEngine->AddOnScreenDebugMessage(INDEX_NONE, 5.f, Color, Message);
		}
	}
};

#define UT_RUNTIME_LOG(Verbosity, Format, ...) \
{ \
UE_LOG(LogUniversalTimeline, Verbosity, TEXT("[%llu] %s(%d) - %s"), GFrameCounter, *FString(__FUNCTION__), __LINE__, *FString::Printf(Format, ##__VA_ARGS__)); \
}

#define UT_RUNTIME_CLOG(Condition, Verbosity, Format, ...) \
{ \
UE_CLOG(Condition, LogUniversalTimeline, Verbosity, TEXT("[%llu] %s(%d) - %s"), GFrameCounter, *FString(__FUNCTION__), __LINE__, *FString::Printf(Format, ##__VA_ARGS__)); \
}

#define UT_RUNTIME_SLOG(Verbosity, Format, ...) \
{ \
FEnhancedAbilityScreenLogger::AddOnScreenDebugMessage(ELogVerbosity::Verbosity, FString::Printf(Format, ##__VA_ARGS__)); \
EA_RUNTIME_LOG(Verbosity, Format, ##__VA_ARGS__) \
}

