﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/PlayerController.h"
#include "IMovieScenePlayerCustomContext.h"
#include "UniversalTimelineSectionContext.generated.h"

USTRUCT()
struct FUniversalTimelineSectionContext : public FMovieScenePlayerCustomContext
{
	GENERATED_BODY()

	FUniversalTimelineSectionContext() = default;

	FUniversalTimelineSectionContext(AActor* OwnerActor)
		: FMovieScenePlayerCustomContext(),
		  ContextOwner(OwnerActor)
	{
	}

	virtual UScriptStruct* GetScriptStruct() const override { return StaticStruct(); }
	virtual AActor* GetBindActor() override { return GetOwnerActor(); }

	AActor* GetOwnerActor() const
	{
		return ContextOwner.IsValid() ? ContextOwner.Get() : nullptr;
	}

	UWorld* GetWorld() const
	{
		return ContextOwner.IsValid() ? ContextOwner->GetWorld() : nullptr;
	}

	ENetRole GetLocalNetRole() const
	{
		return GetOwnerActor() ? GetOwnerActor()->GetLocalRole() : ROLE_None;
	}

	bool IsLocallyControlled() const
	{
		if (const APlayerController* PlayerController = Cast<APlayerController>(GetOwnerActor()))
		{
			return PlayerController->IsLocalController();
		}

		if (const APawn* PawnOwner = Cast<APawn>(GetOwnerActor()))
		{
			return PawnOwner->IsLocallyControlled();
		}

		if (HasAuthority())
		{
			return true;
		}

		return false;
	}

	bool HasAuthority() const
	{
		return GetLocalNetRole() == ROLE_Authority;
	}

protected:
	TWeakObjectPtr<AActor> ContextOwner;
};
