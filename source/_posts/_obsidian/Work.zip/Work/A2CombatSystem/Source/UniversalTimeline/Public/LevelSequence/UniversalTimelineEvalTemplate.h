﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UniversalTimelineSection.h"
#include "Evaluation/MovieSceneEvalTemplate.h"
#include "UniversalTimelineEvalTemplate.generated.h"

class FUniversalTimelinePreviewer;
class FUniversalTimelineExecutor;
class UUniversalTimelineSection;

/**
 * 以Track为Key索引的数据, 用来保存MainSection的Executor, SubSection可以获取
 */
struct FUniversalTimelineTrackEvalData : IPersistentEvaluationData
{
	bool bIsTickEnabled;
	TMap<UPTRINT, TUniquePtr<FUniversalTimelineExecutor>> ExecutorMap;

	FORCEINLINE bool IsEmpty() const
	{
		return ExecutorMap.IsEmpty();
	}

	FORCEINLINE FUniversalTimelineExecutor* GetMainSectionExecutor() const
	{
		for (auto& Pair : ExecutorMap)
		{
			return Pair.Value.Get();
		}

		return nullptr;
	}

	FORCEINLINE FUniversalTimelineExecutor* FindSectionExecutor(const UUniversalTimelineSection* Section)
	{
		if (const TUniquePtr<FUniversalTimelineExecutor>* Found = ExecutorMap.Find(reinterpret_cast<UPTRINT>(Section)))
		{
			return Found->Get();
		}

		return nullptr;
	}

	FORCEINLINE FUniversalTimelineExecutor* GetOrAddSectionExecutor(const FPersistentEvaluationData& PersistentData, const UUniversalTimelineSection* Section)
	{
		if (const TUniquePtr<FUniversalTimelineExecutor>* Found = ExecutorMap.Find(reinterpret_cast<UPTRINT>(Section)))
		{
			return Found->Get();
		}

		return MakeSectionExecutor(PersistentData, Section);
	}

	FUniversalTimelineExecutor* MakeSectionExecutor(const FPersistentEvaluationData& PersistentData, const UUniversalTimelineSection* Section);
};

/**
 * 以Section为Key索引的数据, 每个Section有一个独立的实例, 且每个Section只能有这么一个实例
 * 每个Section只能有一个要注意, 虽然Add和Find的时候都有模板参数, 但是其内部并未进行任何检查
 * 所以这里面同时有Previewer和Executor的逻辑
 */
struct FUniversalTimelineSectionEvalData : IPersistentEvaluationData
{
	bool bIsTickEnabled;
	TUniquePtr<FUniversalTimelineExecutor> Executor;
#if WITH_EDITOR
	TUniquePtr<FUniversalTimelinePreviewer> Previewer;
#endif
};

/**
 * 
 */
USTRUCT()
struct UNIVERSALTIMELINE_API FUniversalTimelineEvalTemplate : public FMovieSceneEvalTemplate
{
	GENERATED_BODY()

	FUniversalTimelineEvalTemplate();

	virtual UScriptStruct& GetScriptStructImpl() const override { return *StaticStruct(); }

	virtual void OnBeginCustomEvaluation(const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;
	virtual void OnEndCustomEvaluation(const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) const override;

	virtual void Evaluate(const FMovieSceneEvaluationOperand& Operand, const FMovieSceneContext& Context, const FPersistentEvaluationData& PersistentData, FMovieSceneExecutionTokens& ExecutionTokens) const override;

	static TUniquePtr<FUniversalTimelineExecutor> MakeSectionExecutor(const FPersistentEvaluationData& PersistentData, const UUniversalTimelineSection* Section, bool& OutEnableTick);
	static FString GetDisplayNameSafe(const UObject* Object);
};

struct FUniversalTimelineSectionTickToken : IMovieSceneExecutionToken
{
	FUniversalTimelineSectionTickToken(FUniversalTimelineExecutor& Executor, const UUniversalTimelineSection* Section)
		: Executor(Executor),
		  Section(Section)
	{
	}

	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override;

	FUniversalTimelineExecutor& Executor;
	const UUniversalTimelineSection* Section;
};

struct FUniversalTimelineSubSectionTickToken : IMovieSceneExecutionToken
{
	FUniversalTimelineSubSectionTickToken(FUniversalTimelineExecutor& Executor, const UUniversalTimelineSubSection* SubSection)
		: Executor(Executor),
		  SubSection(SubSection)
	{
	}

	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override;

	FUniversalTimelineExecutor& Executor;
	const UUniversalTimelineSubSection* SubSection;
};

#if WITH_EDITOR
struct FUniversalTimelineSectionPreviewToken : IMovieSceneExecutionToken
{
	FUniversalTimelineSectionPreviewToken(FUniversalTimelineSectionEvalData& EvalData)
		: EvalData(EvalData)
	{
	}

	virtual void Execute(const FMovieSceneContext& Context, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData, IMovieScenePlayer& Player) override;

	FUniversalTimelineSectionEvalData& EvalData;
};
#endif
