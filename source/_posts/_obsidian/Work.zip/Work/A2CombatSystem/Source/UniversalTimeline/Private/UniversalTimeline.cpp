﻿#include "UniversalTimeline.h"

#define LOCTEXT_NAMESPACE "FUniversalTimelineModule"

void FUniversalTimelineModule::StartupModule()
{
    
}

void FUniversalTimelineModule::ShutdownModule()
{
    
}

#undef LOCTEXT_NAMESPACE
    
IMPLEMENT_MODULE(FUniversalTimelineModule, UniversalTimeline)