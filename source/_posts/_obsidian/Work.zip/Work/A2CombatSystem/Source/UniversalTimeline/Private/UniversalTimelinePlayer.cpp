﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "UniversalTimelinePlayer.h"

#include "LevelSequenceActor.h"
#include "LevelSequencePlayer.h"

FUniversalTimelinePlayerStruct::~FUniversalTimelinePlayerStruct()
{
	if (Owner.IsValid())
	{
		Owner.Get()->ReleaseSequenceActor(SequenceActor.Get());
	}
}

AUniversalTimelinePlayerActor::AUniversalTimelinePlayerActor(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bReplicates = false;
}

void UUniversalTimelinePlayerManager::Initialize(FSubsystemCollectionBase& Collection)
{
	Super::Initialize(Collection);
}

void UUniversalTimelinePlayerManager::Deinitialize()
{
	Super::Deinitialize();
}

FUniversalTimelinePlayer UUniversalTimelinePlayerManager::GetSequencePlayer(const UObject* Owner, ULevelSequence* Sequence, const FMovieSceneSequencePlaybackSettings& Settings)
{
	const UWorld* World = GEngine->GetWorldFromContextObject(Owner, EGetWorldErrorMode::LogAndReturnNull);
	if (!World)
	{
		return FUniversalTimelinePlayer();
	}

	if (!Sequence)
	{
		return FUniversalTimelinePlayer();
	}

	UUniversalTimelinePlayerManager* WorldPlayerManager = World->GetSubsystem<UUniversalTimelinePlayerManager>();
	check(WorldPlayerManager)

	ALevelSequenceActor* Actor = WorldPlayerManager->GetSequenceActor();
	check(Actor);

	Actor->PlaybackSettings = Settings;
	Actor->SequencePlayer->SetPlaybackSettings(Settings);

	Actor->SetSequence(Sequence);
	Actor->InitializePlayer();

	return FUniversalTimelinePlayer(WorldPlayerManager, Actor);
}

ALevelSequenceActor* UUniversalTimelinePlayerManager::GetSequenceActor()
{
	ALevelSequenceActor* OutActor;
	if (IdlingSequenceActor.Dequeue(OutActor))
	{
		return OutActor;
	}

	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;
	SpawnParams.ObjectFlags |= RF_Transient;
	SpawnParams.bAllowDuringConstructionScript = true;

	// Defer construction for autoplay so that BeginPlay() is called
	SpawnParams.bDeferConstruction = true;

	OutActor = GetWorld()->SpawnActor<AUniversalTimelinePlayerActor>(SpawnParams);
	OutActor->FinishSpawning(FTransform::Identity);
	return OutActor;
}

void UUniversalTimelinePlayerManager::ReleaseSequenceActor(ALevelSequenceActor* Actor)
{
	if (!Actor)
	{
		return;
	}

	if (Actor->SequencePlayer)
	{
		Actor->SequencePlayer->State.CustomContext.Reset();
		Actor->SequencePlayer->State.PersistentEntityData.Reset();
		Actor->SequencePlayer->State.PersistentSharedData.Reset();
	}

	IdlingSequenceActor.Enqueue(Actor);
}

void FMovieSceneTimeController_TickWithActor::OnStartPlaying(const FQualifiedFrameTime& InStartTime)
{
	CurrentOffsetSeconds = 0.0;
}

void FMovieSceneTimeController_TickWithActor::OnTick(float DeltaSeconds, float InPlayRate)
{
	if (OwnerActor.IsValid())
	{
		DeltaSeconds = OwnerActor->CalculateDeltaTime(DeltaSeconds);
	}

	CurrentOffsetSeconds += DeltaSeconds * InPlayRate;
}

FFrameTime FMovieSceneTimeController_TickWithActor::OnRequestCurrentTime(const FQualifiedFrameTime& InCurrentTime, float InPlayRate)
{
	TOptional<FQualifiedFrameTime> StartTimeIfPlaying = GetPlaybackStartTime();
	if (!StartTimeIfPlaying.IsSet())
	{
		return InCurrentTime.Time;
	}

	const FFrameTime StartTime = StartTimeIfPlaying->ConvertTo(InCurrentTime.Rate);
	return StartTime + CurrentOffsetSeconds * InCurrentTime.Rate;
}
