﻿using UnrealBuildTool;

public class UniversalTimeline : ModuleRules
{
	public UniversalTimeline(ReadOnlyTargetRules Target) : base(Target)
	{
		PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

		PublicDependencyModuleNames.AddRange(
			new string[]
			{
				"Core",
				"MovieScene",
				"LevelSequence",
				"AnimGraphRuntime",
			}
		);

		PrivateDependencyModuleNames.AddRange(
			new string[]
			{
				"CoreUObject",
				"Engine", 
				"MovieSceneTracks", 
				"GameplayInterface"
			}
		);
	}
}