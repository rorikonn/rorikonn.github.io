﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "IMovieScenePlayer.h"
#include "MovieScene.h"
#include "MovieSceneSection.h"
#include "UniversalTimelineSectionContext.h"
#include "Kismet/KismetSystemLibrary.h"
#include "UniversalTimelineSection.generated.h"

struct FUniversalTimelineSectionContext;
class FUniversalTimelineExecutor;
class FUniversalTimelinePreviewer;

struct IUniversalTimelineSectionOps;

/**
 * 
 */
UCLASS(Abstract)
class UNIVERSALTIMELINE_API UUniversalTimelineSection : public UMovieSceneSection
{
	GENERATED_BODY()

public:
	virtual IUniversalTimelineSectionOps* GetTimelineSectionOps() const
	{
		checkNoEntry();
		return nullptr;
	}

	virtual void PreCompile();
	virtual FMovieSceneEvalTemplatePtr CreateEvalTemplate() const;

	FORCEINLINE const TArray<UMovieSceneTrack*>& GetSiblingTracks() const
	{
		const UMovieSceneTrack* OuterTrack = GetTypedOuter<UMovieSceneTrack>();
		const FGuid BindingGuid = OuterTrack->FindObjectBindingGuid();

		UMovieScene* OuterMovieScene = GetTypedOuter<UMovieScene>();
		if (const FMovieSceneBinding* FoundBinding = OuterMovieScene->FindBinding(BindingGuid))
		{
			return FoundBinding->GetTracks();
		}

		return OuterMovieScene->GetMasterTracks();
	}

	FORCEINLINE FFrameRate GetSequenceFrameRate() const
	{
		return GetTypedOuter<UMovieScene>()->GetTickResolution();
	}

	FORCEINLINE float GetSectionStartTimeSeconds() const
	{
		return GetTypedOuter<UMovieScene>()->GetTickResolution().AsSeconds(GetRange().GetLowerBoundValue());
	}

	FORCEINLINE FFrameTime GetSectionStartTimeFrame() const
	{
		return GetRange().GetLowerBoundValue();
	}

	FORCEINLINE float GetSectionEndTimeSeconds() const
	{
		return GetTypedOuter<UMovieScene>()->GetTickResolution().AsSeconds(GetRange().GetUpperBoundValue());
	}

	FORCEINLINE FFrameTime GetSectionEndTimeFrame() const
	{
		return GetRange().GetUpperBoundValue();
	}


	FORCEINLINE float GetSectionLengthSeconds() const
	{
		return GetTypedOuter<UMovieScene>()->GetTickResolution().AsSeconds(GetRange().Size<FFrameNumber>());
	}

	FORCEINLINE FFrameTime GetSectionLengthTimeFrame() const
	{
		return GetRange().Size<FFrameNumber>();
	}

#if WITH_EDITOR
	virtual FText GetSectionTitle() const;
#endif
};

UCLASS(Abstract)
class UNIVERSALTIMELINE_API UUniversalTimelineSubSection : public UUniversalTimelineSection
{
	GENERATED_BODY()

public:
	const UUniversalTimelineSection* GetMainSection() const;
};

class UNIVERSALTIMELINE_API FUniversalTimelineExecutor
{
public:
	FUniversalTimelineExecutor() = default;
	virtual ~FUniversalTimelineExecutor() = default;

	virtual void Initialize(const UUniversalTimelineSection* InData, TSharedPtr<FUniversalTimelineSectionContext> InContext);

protected:
	friend struct FUniversalTimelineEvalTemplate;
	friend struct FUniversalTimelineSectionTickToken;
	friend struct FUniversalTimelineSubSectionTickToken;
	friend struct FUniversalTimelineTrackEvalData;

	/**
	 * 用来在某些上下文情况下禁用这个Action
	 */
	virtual bool IsEnabled() const;

	/**
	 * Section开始的时候执行
	 */
	virtual void OnSectionStart();

	/**
	 * Section的IsTickEnabled返回ture的话, 就会每帧执行.
	 * OnSectionStart调用的那一帧, 也会调用一次这个OnActionTick
	 */
	virtual void OnSectionTick(float DeltaTime);

	/**
	 * 如果OnSectionStart执行了, 那结束的时候就一定会执行这个
	 * 如果OnSectionStart没有执行, 那这个肯定也不会执行
	 */
	virtual void OnSectionEnd();

	virtual void OnSubSectionStart(const UUniversalTimelineSubSection* SubSection);
	virtual void OnSubSectionTick(const UUniversalTimelineSubSection* SubSection, float DeltaTime);
	virtual void OnSubSectionEnd(const UUniversalTimelineSubSection* SubSection);

	template <typename T>
	typename TEnableIf<TIsDerivedFrom<T, FUniversalTimelineSectionContext>::Value, bool>::Type IsInContext() const
	{
		return TimelineContext.IsValid() && TimelineContext->GetScriptStruct() && TimelineContext->GetScriptStruct()->IsChildOf(T::StaticStruct());
	}

	template <typename T>
	typename TEnableIf<TIsDerivedFrom<T, FUniversalTimelineSectionContext>::Value, T&>::Type GetContext() const
	{
		check(TimelineContext.IsValid());

		return *StaticCast<T*>(TimelineContext.Get());
	}

	template <typename T = UUniversalTimelineSection>
	typename TEnableIf<TIsDerivedFrom<T, UUniversalTimelineSection>::Value, const T*>::Type GetData() const
	{
		return Cast<T>(Data);
	}

	template <typename T = UUniversalTimelineSection>
	typename TEnableIf<TIsDerivedFrom<T, UUniversalTimelineSection>::Value, const T&>::Type GetDataChecked() const
	{
		return *CastChecked<T>(Data);
	}

	FORCEINLINE float GetCurrentTimeSeconds() const
	{
		return FrameRate.AsSeconds(EvaluatingTime);
	}

	FORCEINLINE FFrameTime GetCurrentTimeFrame() const
	{
		return EvaluatingTime;
	}

	FFrameTime EvaluatingTime;
	FFrameRate FrameRate;
	TObjectPtr<const UUniversalTimelineSection> Data;
	TSharedPtr<FUniversalTimelineSectionContext> TimelineContext;

	enum class EExecutorState
	{
		Waiting,
		Running,
		Finished,
	} ExecutorState;
};

class UNIVERSALTIMELINE_API FUniversalTimelinePreviewer
{
public:
	virtual ~FUniversalTimelinePreviewer() = default;

	virtual void Initialize(const UUniversalTimelineSection* InData);

protected:
	friend struct FUniversalTimelineEvalTemplate;
	friend struct FUniversalTimelineSectionPreviewToken;

	virtual void OnPreviewStart(AActor* BoundActor);
	virtual void OnPreviewEnd(AActor* BoundActor);
	virtual void OnPreviewTick(AActor* BoundActor, const FMovieSceneContext& SceneContext, const FMovieSceneEvaluationOperand& Operand, FPersistentEvaluationData& PersistentData,
	                           IMovieScenePlayer& Player);


	template <typename T = UUniversalTimelineSection>
	typename TEnableIf<TIsDerivedFrom<T, UUniversalTimelineSection>::Value, const T*>::Type GetData() const
	{
		return Cast<T>(Data);
	}

	template <typename T = UUniversalTimelineSection>
	typename TEnableIf<TIsDerivedFrom<T, UUniversalTimelineSection>::Value, const T&>::Type GetDataChecked() const
	{
		return *CastChecked<T>(Data);
	}

	TObjectPtr<const UUniversalTimelineSection> Data;
};


struct IUniversalTimelineSectionOps
{
	virtual ~IUniversalTimelineSectionOps() = default;

	virtual UClass* GetClass() = 0;

	virtual TUniquePtr<FUniversalTimelineExecutor> MakeExecutor(const UUniversalTimelineSection*, const FUniversalTimelineSectionContext*) = 0;
	virtual TUniquePtr<FUniversalTimelinePreviewer> MakePreviewer(const UUniversalTimelineSection*) = 0;
	virtual bool IsTickEnabled() = 0;

	virtual bool ShouldRunOnLocal(ENetRole LocalRole) = 0;
	virtual bool ShouldRunOnWorld(const UObject* WorldContextObject) = 0;

	virtual bool IsMainSection() = 0;
	virtual TArray<TSubclassOf<UUniversalTimelineSubSection>> GetSubSections() = 0;
	virtual bool ShouldRunOnContext(const FUniversalTimelineSectionContext* InContext) = 0;

	FORCEINLINE bool IsEnabled(const FUniversalTimelineSectionContext* InContext)
	{
		if (!InContext)
		{
			return false;
		}

		if (!ShouldRunOnContext(InContext))
		{
			return false;
		}

		if (!ShouldRunOnLocal(InContext->GetLocalNetRole()))
		{
			return false;
		}

		if (!ShouldRunOnWorld(InContext->GetWorld()))
		{
			return false;
		}

		return true;
	}
};

template <typename>
struct TUniversalTimelineSectionTypeTraitsBase
{
	enum
	{
		EnableTick = false,

		RunSimulated = true,
		RunAutonomous = true,
		RunAuthority = true,

		RunOnServer = true,
		RunOnClient = true,
	};
};

template <typename DataClass>
struct TUniversalTimelineSectionTypeTraits : TUniversalTimelineSectionTypeTraitsBase<DataClass>
{
	/**
	 * 下面是TypeTraits里面可以实现的拓展
	 *
	 * 1、枚举参数
	 * 上面父类里面的所有枚举参数都可以在这里可选的覆盖
	 * enum
	 * {
	 *	EnableTick = true,
	 * }
	 * 
	 * 2、简单绑定Executor类
	 * using ExecutorClass = CustomExecutor;
	 * 或者
	 * typedef CustomExecutor ExecutorClass;
	 *
	 * 3、不带参的绑定Executor类的函数
	 * TUniquePtr<FUniversalTimelineExecutor> MakeExecutor()
	 * {
	 * 	return MakeUnique<CustomExecutor>();
	 * }
	 *
	 * 4、带参的绑定Executor类的函数
	 * TUniquePtr<FUniversalTimelineExecutor> MakeExecutor(const DataClass* Data, const FUniversalTimelineSectionContext* Context)
	 * {
	 * 	return MakeUnique<CustomExecutor>();
	 * }
	 *
	 * 5、绑定Previewer类
	 * using PreviewerClass = CustomPreviewerClass;
	 * 或者
	 * typedef CustomPreviewerClass PreviewerClass;
	 */
};

template <typename DataClass>
struct TUniversalTimelineSectionOps final : IUniversalTimelineSectionOps
{
	virtual UClass* GetClass() override
	{
		return GetClassImpl();
	}

private:
	template <typename T = DataClass>
	typename TEnableIf<TIsDerivedFrom<T, UObject>::Value, UClass*>::Type GetClassImpl()
	{
		return DataClass::StaticClass();
	}

	template <typename T = DataClass>
	typename TEnableIf<!TIsDerivedFrom<T, UObject>::Value, UClass*>::Type GetClassImpl()
	{
		return nullptr;
	}

public:
	virtual TUniquePtr<FUniversalTimelineExecutor> MakeExecutor(const UUniversalTimelineSection* InData, const FUniversalTimelineSectionContext* Context) override
	{
		return MakeExecutorInternalImplement(InData, Context);
	}

	virtual TUniquePtr<FUniversalTimelinePreviewer> MakePreviewer(const UUniversalTimelineSection* InData) override
	{
		return MakePreviewerInternalImplement(InData);
	}

private:
	// 匹配TypeTraits中, 如下签名的函数
	// TUniquePtr<FUniversalTimelineExecutor> MakeExecutor(const DataClass*)
	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	TUniquePtr<FUniversalTimelineExecutor> MakeExecutorInternalImplement(
		const UUniversalTimelineSection* InData,
		const FUniversalTimelineSectionContext*,
		decltype(std::declval<TypeTraits>().MakeExecutor(std::declval<const DataClass*>()))* = nullptr)
	{
		TypeTraits Traits;
		return Traits.MakeExecutor(Cast<DataClass>(InData));
	}

	// 匹配TypeTraits中, 如下签名的函数
	// TUniquePtr<FUniversalTimelineExecutor> MakeExecutor(const DataClass*, const FUniversalTimelineSectionContext*)
	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	TUniquePtr<FUniversalTimelineExecutor> MakeExecutorInternalImplement(
		const UUniversalTimelineSection* InData,
		const FUniversalTimelineSectionContext* InContext,
		decltype(std::declval<TypeTraits>().MakeExecutor(std::declval<const DataClass*>(), std::declval<const FUniversalTimelineSectionContext*>()))* = nullptr)
	{
		TypeTraits Traits;
		return Traits.MakeExecutor(Cast<DataClass>(InData), InContext);
	}

	// 匹配TypeTraits中, 如下签名的函数
	// TUniquePtr<FUniversalTimelineExecutor> MakeExecutor()
	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	TUniquePtr<FUniversalTimelineExecutor> MakeExecutorInternalImplement(
		const UUniversalTimelineSection*,
		const FUniversalTimelineSectionContext*,
		decltype(std::declval<TypeTraits>().MakeExecutor())* = nullptr)
	{
		TypeTraits Traits;
		return Traits.MakeExecutor();
	}

	// 匹配TypeTraits中, using ExecutorClass = RuntimeClass; 这种类型的声明
	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	TUniquePtr<FUniversalTimelineExecutor> MakeExecutorInternalImplement(
		const UUniversalTimelineSection*,
		const FUniversalTimelineSectionContext*,
		TEnableIf<TIsDerivedFrom<typename TypeTraits::ExecutorClass, FUniversalTimelineExecutor>::Value>* = nullptr)
	{
		return MakeUnique<typename TypeTraits::ExecutorClass>();
	}

	TUniquePtr<FUniversalTimelineExecutor> MakeExecutorInternalImplement(...)
	{
		return TUniquePtr<FUniversalTimelineExecutor>();
	}

	// 匹配TypeTraits中, using PreviewerClass = PreviewerClass; 这种类型的声明
	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	TUniquePtr<FUniversalTimelinePreviewer> MakePreviewerInternalImplement(
		const UUniversalTimelineSection*,
		TEnableIf<TIsDerivedFrom<typename TypeTraits::PreviewerClass, FUniversalTimelinePreviewer>::Value>* = nullptr)
	{
		return MakeUnique<typename TypeTraits::PreviewerClass>();
	}

	TUniquePtr<FUniversalTimelinePreviewer> MakePreviewerInternalImplement(...)
	{
		return TUniquePtr<FUniversalTimelinePreviewer>();
	}

#if WITH_EDITOR

public:
	virtual bool IsMainSection() override
	{
		return IsMainSectionImplement(nullptr);
	}

	virtual TArray<TSubclassOf<UUniversalTimelineSubSection>> GetSubSections() override
	{
		return GetSubSectionsImplement(nullptr);
	}

private:
	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	bool IsMainSectionImplement(
		typename TEnableIf<TIsSame<decltype(std::declval<TypeTraits>().GetSubSections()), TArray<TSubclassOf<UUniversalTimelineSubSection>>>::Value>::Type*
	)
	{
		return true;
	}

	bool IsMainSectionImplement(...)
	{
		return false;
	}

	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	TArray<TSubclassOf<UUniversalTimelineSubSection>> GetSubSectionsImplement(
		typename TEnableIf<TIsSame<decltype(std::declval<TypeTraits>().GetSubSections()), TArray<TSubclassOf<UUniversalTimelineSubSection>>>::Value>::Type*
	)
	{
		TypeTraits Traits;
		return Traits.GetSubSections();
	}

	TArray<TSubclassOf<UUniversalTimelineSubSection>> GetSubSectionsImplement(...)
	{
		return TArray<TSubclassOf<UUniversalTimelineSubSection>>();
	}

public:
	virtual bool ShouldRunOnContext(const FUniversalTimelineSectionContext* InContext) override
	{
		return ShouldRunOnContextImplement(InContext);
	}

private:
	// 匹配TypeTraits中, 如下签名的函数
	// bool ShouldRunOnContext(const FUniversalTimelineSectionContext*)
	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	bool ShouldRunOnContextImplement(
		const FUniversalTimelineSectionContext* InContext,
		decltype(std::declval<TypeTraits>().ShouldRunOnContext(std::declval<const FUniversalTimelineSectionContext*>()))* = nullptr)
	{
		TypeTraits Traits;
		return Traits.ShouldRunOnContext(InContext);
	}

	// 匹配TypeTraits中, using RequiredContext = ContextClass; 这种类型的声明
	template <typename TypeTraits = TUniversalTimelineSectionTypeTraits<DataClass>>
	bool ShouldRunOnContextImplement(
		const FUniversalTimelineSectionContext* InContext,
		TEnableIf<TIsDerivedFrom<typename TypeTraits::RequiredContext, FUniversalTimelineSectionContext>::Value>* = nullptr)
	{
		const UScriptStruct* ContextStruct = InContext ? InContext->GetScriptStruct() : nullptr;
		return ContextStruct && ContextStruct->IsChildOf(TypeTraits::RequiredContext::StaticStruct());
	}

	// 如果没有指定RequiredContext, 默认可以在所有上下文中运行
	bool ShouldRunOnContextImplement(...)
	{
		return true;
	}
#endif

public:
	virtual bool IsTickEnabled() override
	{
		return TUniversalTimelineSectionTypeTraits<DataClass>::EnableTick;
	}

	virtual bool ShouldRunOnLocal(ENetRole LocalRole) override
	{
		switch (LocalRole)
		{
		case ROLE_SimulatedProxy:
			return TUniversalTimelineSectionTypeTraits<DataClass>::RunSimulated;
		case ROLE_AutonomousProxy:
			return TUniversalTimelineSectionTypeTraits<DataClass>::RunAutonomous;
		case ROLE_Authority:
			return TUniversalTimelineSectionTypeTraits<DataClass>::RunAuthority;
		default: ;
		}

		return false;
	}

	virtual bool ShouldRunOnWorld(const UObject* WorldContext) override
	{
#if UE_SERVER
		return TUniversalTimelineSectionTypeTraits<DataClass>::RunOnServer;
#elif !WITH_EDITOR
		return TUniversalTimelineSectionTypeTraits<DataClass>::RunOnClient;
#else
		if (!IsValid(WorldContext))
		{
			return false;
		}

		if (UKismetSystemLibrary::IsStandalone(WorldContext))
		{
			return true;
		}

		if (UKismetSystemLibrary::IsServer(WorldContext))
		{
			return TUniversalTimelineSectionTypeTraits<DataClass>::RunOnServer;
		}

		return TUniversalTimelineSectionTypeTraits<DataClass>::RunOnClient;
#endif
	}
};

#define GENERATED_UNIVERSAL_TIMELINE_BODY() \
public:\
virtual IUniversalTimelineSectionOps* GetTimelineSectionOps() const override \
{ \
	static TUniversalTimelineSectionOps<ThisClass> TimelineSectionOps; \
	return &TimelineSectionOps; \
}

#define BIND_UNIVERSAL_TIMELINE_EXECUTOR(DataClass, RuntimeClass) \
template<> \
struct TUniversalTimelineSectionTypeTraits<DataClass> : TUniversalTimelineSectionTypeTraitsBase<DataClass> { \
	using ExecutorClass = RuntimeClass; \
};
