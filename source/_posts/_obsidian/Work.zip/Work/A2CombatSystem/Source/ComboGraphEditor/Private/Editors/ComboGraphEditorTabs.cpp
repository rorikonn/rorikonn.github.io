﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Editors/ComboGraphEditorTabs.h"

const FName FComboGraphEditorTabs::AssetBrowserID("ComboGraph_AssetBrowser");
const FName FComboGraphEditorTabs::GraphViewportID("ComboGraph_Viewport");
const FName FComboGraphEditorTabs::PropertyDetailsID("ComboGraph_PropertyDetails");
