﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

COMBOGRAPHEDITOR_API DECLARE_LOG_CATEGORY_EXTERN(LogComboGraphEditor, Display, All);

#define CG_EDITOR_LOG(Verbosity, Format, ...) \
{ \
    UE_LOG(LogComboGraphEditor, Verbosity, TEXT("[%llu] %s(%d) - %s"), GFrameCounter, *FString(__FUNCTION__), __LINE__, *FString::Printf(Format, ##__VA_ARGS__)); \
}
