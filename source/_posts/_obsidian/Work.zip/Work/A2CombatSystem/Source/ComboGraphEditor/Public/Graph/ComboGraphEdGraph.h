// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "EdGraph/EdGraph.h"
#include "Graph/ComboGraph.h"
#include "ComboGraphEdGraph.generated.h"

class UComboGraphEdGraphData;
class FComboGraphDebugger;
class UComboGraphEdNodeBase;
class UComboGraphEdNodeConduit;
class UComboGraphNodeDataBase;
class UComboGraphNodeData;
class UComboGraphData;
class UComboGraphAbility;
class UComboGraphEdge;
class UComboGraphEdNode;
class UComboGraphEdNodeEdge;
class UComboGraphEdNodeEntry;

UCLASS()
class COMBOGRAPHEDITOR_API UComboGraphEdGraph : public UEdGraph
{
	GENERATED_BODY()

public:
	/** Shared ref to asset editor, namely to access debugger info and debugged node */
	TSharedPtr<FComboGraphDebugger> Debugger;

	UComboGraphData* GetComboGraphModel() const;

	void RestoreFromEdGraphData(const UComboGraphEdGraphData* EdGraphData);

	virtual void RebuildGraph();
	static void ResolveGraphNodeConnections(UComboGraphNodeDataBase* RuntimeNode, UComboGraphEdNodeBase* NodeBase);
	virtual void SaveGraph();

	/** Goes through each nodes and run a validation pass */
	void ValidateNodes(FCompilerResultsLog* LogResults);

	//~ UObject interface
	virtual bool Modify(bool bAlwaysMarkDirty) override;
	virtual void PostEditUndo() override;
	//~ End UObject interface

	/** Returns all graph nodes that are of node type (not edges) */
	TArray<UComboGraphEdNode*> GetAllNodes() const;

	/** Re-organize graph nodes automatically */
	void AutoArrange(bool bVertical);
	
protected:
	void Clear();

};

UCLASS()
class UComboGraphEdNodeData : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY()
	FComboGraphNodeID NodeID;

	UPROPERTY()
	TSubclassOf<UComboGraphEdNodeBase> NodeClass;

	UPROPERTY()
	FVector2D Position;
};

UCLASS()
class UComboGraphEdNodeEdgeData : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY()
	FComboGraphNodeID FromNodeID;
	
	UPROPERTY()
	FComboGraphNodeID ToNodeID;

	UPROPERTY()
	FVector2D Position;
};

UCLASS()
class UComboGraphEdGraphData : public UObject
{
	GENERATED_BODY()

public:
	UPROPERTY()
	FComboGraphID GraphID;
	
	UPROPERTY(Instanced)
	TArray<UComboGraphEdNodeData*> Nodes;
	
	UPROPERTY(Instanced)
	TArray<UComboGraphEdNodeEdgeData*> Edges;
};

template <>
struct TDataArchiveInfo<UComboGraphEdGraphData> : TDataArchiveInfoBase<UComboGraphEdGraphData>
{
	static FComboGraphID& GetKeyFromData(UComboGraphEdGraphData* Data)
	{
		static FComboGraphID InvalidKey;
		return Data ? Data->GraphID : InvalidKey;
	}

	static FString GetArchiveTableName()
	{
		return TEXT("GraphEditor");
	}

	static FString GetArchiveCategory(const UComboGraphEdGraphData* Data)
	{
		return Data ? Data->GraphID.ToString() : TEXT("Invalid");
	}
};
