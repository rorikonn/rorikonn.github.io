﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphEditorStyle.h"
#include "ContentBrowserDelegates.h"
#include "Graph/ComboGraph.h"
#include "Graph/ComboGraphEdGraph.h"
#include "SComboGraphBrowser.generated.h"

struct FComboGraphBrowserCustomColumn;

class FComboGraphBrowserItem
{
public:
	FComboGraphBrowserItem();
	FComboGraphBrowserItem(UComboGraphData* Data);

	void UpdateCustomColumnValue(TArray<FComboGraphBrowserCustomColumn>& CustomColumns);

	FString GetColumnData(FName ColumnName);
	FText GetColumnDisplayText(FName ColumnName);

	TStrongObjectPtr<UComboGraphData> Data;

	TMap<FName, FString> CachedCustomColumnData;
	TMap<FName, FText> CachedCustomColumnDisplayText;
};

/** Called to get string/text value for a custom column, will get converted as necessary */
DECLARE_DELEGATE_RetVal_TwoParams(FString, FOnGetCustomGraphColumnData, UComboGraphData*, FName);
DECLARE_DELEGATE_RetVal_TwoParams(FText, FOnGetCustomGraphColumnDisplayText, UComboGraphData*, FName);
DECLARE_DELEGATE_RetVal_ThreeParams(bool, FOnSortGraphColumnData, const FString& Lhs, const FString& Rhs, EColumnSortMode::Type SortMode);

struct FComboGraphBrowserCustomColumn
{
	FComboGraphBrowserCustomColumn();
	FComboGraphBrowserCustomColumn(FName InName, const FText& DisplayName, const FText& Tooltip,
	                               const FOnGetCustomGraphColumnData& OnGetDataDelegate,
	                               const FOnGetCustomGraphColumnDisplayText& OnGetDisplayTextDelegate,
	                               const FOnSortGraphColumnData& OnSortColumnData = FOnSortGraphColumnData());

	/** Internal name of the column */
	FName ColumnName;

	/** Display name of the column */
	FText DisplayName;

	/** Tooltip for the column */
	FText TooltipText;

	/** Delegate to get String value for this column, used for sorting and internal use */
	FOnGetCustomGraphColumnData OnGetColumnData;

	/** Delegate to get Text value for this column, used to actually display */
	FOnGetCustomGraphColumnDisplayText OnGetColumnDisplayText;

	/** Delegate to sort column data */
	FOnSortGraphColumnData OnSortColumnData;
};


class SComboGraphBrowserColumnView : public SListView<TSharedPtr<FComboGraphBrowserItem>>
{
};

DECLARE_DELEGATE_ThreeParams(FOnRenameSkillBegin, const TSharedPtr<FComboGraphBrowserItem>&, const FString&, const FSlateRect&)
DECLARE_DELEGATE_FourParams(FOnRenameSkillCommit, const TSharedPtr<FComboGraphBrowserItem>&, const FString&, const FSlateRect&, ETextCommit::Type)
DECLARE_DELEGATE_RetVal_FourParams(bool, FOnVerifyRenameSkillCommit, const TSharedPtr<FComboGraphBrowserItem>&, const FText&, const FSlateRect&, FText&)
DECLARE_DELEGATE_OneParam(FOnSkillItemDestroyed, const TSharedPtr<FComboGraphBrowserItem>&);

class SComboGraphBrowserColumnRow : public SMultiColumnTableRow<TSharedPtr<FComboGraphBrowserItem>>
{
public:
	SLATE_BEGIN_ARGS(SComboGraphBrowserColumnRow)
		{
		}

		/** Data for the asset this item represents */
		SLATE_ARGUMENT(TSharedPtr<FComboGraphBrowserItem>, AssetItem)
		SLATE_EVENT(FOnDragDetected, OnDragDetected)
		/** Delegate for when an asset name has entered a rename state */
		SLATE_EVENT(FOnRenameSkillBegin, OnRenameBegin)
		/** Delegate for when an asset name has been entered for an item that is in a rename state */
		SLATE_EVENT(FOnRenameSkillCommit, OnRenameCommit)
		/** Delegate for when an asset name has been entered for an item to verify the name before commit */
		SLATE_EVENT(FOnVerifyRenameSkillCommit, OnVerifyRenameCommit)
		/** Called when any asset item is destroyed. Used in thumbnail management, though it may be used for more so It is in column items for consistency. */
		SLATE_EVENT(FOnSkillItemDestroyed, OnItemDestroyed)
		/** The string in the title to highlight (used when searching by string) */
		SLATE_ATTRIBUTE(FText, HighlightText)
		/** Delegate to call (if bound) to check if it is valid to get a custom tooltip for this view item */
		SLATE_EVENT(FOnIsAssetValidForCustomToolTip, OnIsAssetValidForCustomToolTip)
		/** Delegate to request a custom tool tip if necessary */
		SLATE_EVENT(FOnGetCustomAssetToolTip, OnGetCustomAssetToolTip)
		/* Delegate to signal when the item is about to show a tooltip */
		SLATE_EVENT(FOnVisualizeAssetToolTip, OnVisualizeAssetToolTip)
		/** Delegate for when an item's tooltip is about to close */
		SLATE_EVENT(FOnAssetToolTipClosing, OnAssetToolTipClosing)
	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTableView);

	virtual TSharedRef<SWidget> GenerateWidgetForColumn(const FName& ColumnName) override;

	virtual FVector2D GetRowSizeForColumn(const FName& InColumnName) const override;

	FText GetColumnText(FName ColumnName) const
	{
		return AssetItem ? AssetItem->GetColumnDisplayText(ColumnName) : FText();
	}

	FText GetColumnTips(FName ColumnName) const
	{
		return AssetItem ? AssetItem->GetColumnDisplayText(ColumnName) : FText();
	}

	TSharedPtr<FComboGraphBrowserItem> AssetItem;
};

class FComboGraphBrowserCommands : public TCommands<FComboGraphBrowserCommands>
{
public:
	FComboGraphBrowserCommands()
		: TCommands(
			TEXT("ComboGraphBrowser"),
			NSLOCTEXT("SComboGraphBrowser", "CommandsContextDesc", "ComboGraphEditor Plugin"),
			NAME_None,
			FComboGraphEditorStyle::GetStyleSetName())
	{
	}

	virtual void RegisterCommands() override;

	TSharedPtr<FUICommandInfo> CreateNew;
	
	TSharedPtr<FUICommandInfo> LoadAll;
	TSharedPtr<FUICommandInfo> SaveAll;
};

class SComboGraphCreator : public SCompoundWidget
{
public:
	SComboGraphCreator();

	SLATE_BEGIN_ARGS(SComboGraphCreator) { ; }
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	bool DoCreation();

protected:
	void Confirm();
	void Cancel();

	bool IsGraphIDValid() const;

	FText OnGetIDText() const;
	void OnIDInputCommit(const FText& NewText, ETextCommit::Type CommitType);

	FText OnGetNameText() const;
	void OnNameInputCommit(const FText& NewText, ETextCommit::Type CommitType);

	FText OnGetDescriptionText() const;
	void OnDescriptionInputCommit(const FText& NewText, ETextCommit::Type CommitType);

	FText OnGetCategoryText() const;
	void OnCategoryInputCommit(const FText& NewText, ETextCommit::Type CommitType);

	FReply OnConfirmClicked();
	FReply OnCancelClicked();

	FText GetIDHeader() const;
	FText GetNameHeader() const;
	FText GetDescHeader() const;
	FText GetCategoryHeader() const;

public:
	uint8 bCreateConfirmed : 1;

private:
	int32 InputID;
	FName InputName;
	FString InputDescription;
	FString InputCategory;

	TWeakPtr<SWindow> ComboGraphCreatorWindow;
};

using FOnComboGraphItemClicked = TSlateDelegates<UComboGraphData*>::FOnMouseButtonClick;
using FOnComboGraphItemDoubleClicked = TSlateDelegates<UComboGraphData*>::FOnMouseButtonClick;

/**
 * 
 */
class SComboGraphBrowser : public SCompoundWidget
{
public:
	SLATE_BEGIN_ARGS(SComboGraphBrowser)
		{
		}

		SLATE_ARGUMENT(TArray<FComboGraphBrowserCustomColumn>, CustomColumns)
		SLATE_EVENT(FOnComboGraphItemDoubleClicked, OnComboGraphDoubleClick)
		SLATE_EVENT(FOnComboGraphItemClicked, OnComboGraphClick)
	SLATE_END_ARGS()

	SComboGraphBrowser();

	void Construct(const FArguments& InArgs);
	TSharedPtr<SComboGraphBrowserColumnView> ConstructColumnView();

	static FString OnGetBrowserColumnData(UComboGraphData* GraphData, FName ColumnName);
	static FText OnGetBrowserColumnDisplayText(UComboGraphData* GraphData, FName ColumnName);
	static bool OnSortIDColumn(const FString& Lhs, const FString& Rhs, EColumnSortMode::Type SortMode);
	static bool OnSortCategoryColumn(const FString& Lhs, const FString& Rhs, EColumnSortMode::Type SortMode);
	
protected:
	TSharedRef<SWidget> ConstructMenuBar();

	// Main menu
	void BindCommands();
	void RegisterMainMenu();
	void RegisterFileMenu();
	void CreateLoadCategorySubMenu(UToolMenu* Menu);
	
	void CreateNew();
	void LoadAll();
	void SaveAll();
	
	void LoadCategoryGraphData(const FString& Category);

	void ResetCategoryFilter();
	void FilterCategoryByClicked(FString Category);
	
	void RebuildContent();

	/** Handler for column view widget creation */
	TSharedRef<ITableRow> MakeColumnViewWidget(const TSharedPtr<FComboGraphBrowserItem> AssetItem, const TSharedRef<STableViewBase>& OwnerTable);

	EColumnSortMode::Type GetColumnSortMode(const FName ColumnId) const;
	EColumnSortPriority::Type GetColumnSortPriority(const FName ColumnId) const;

	/** Handler for when a column header is clicked */
	void OnSortColumnHeader(const EColumnSortPriority::Type SortPriority, const FName& ColumnId, const EColumnSortMode::Type NewSortMode);

	/** Handle dragging an asset */
	FReply OnDraggingAssetItem(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) const;

	/** Handler for clicking an item */
	void OnListMouseButtonClick(const TSharedPtr<FComboGraphBrowserItem> AssetItem) const;

	/** Handler for double clicking an item */
	void OnListMouseButtonDoubleClick(const TSharedPtr<FComboGraphBrowserItem> AssetItem) const;

	/** Create context menu when right click row */
	TSharedPtr<SWidget> OnConstructItemContextMenu() const;

	void SortSourceItems();

	/* Type filter in search box */
	void OnFilterTextChanged(const FText& InSearchText);
	void OnFilterTextCommitted(const FText& InSearchText, ETextCommit::Type CommitInfo);
	void SetSearchBoxText(const FText& InSearchText);

	/* Check if current item has specific text we type in search box*/
	bool IsDataMatched(const TSharedPtr<FComboGraphBrowserItem>& BrowserItem, const FText& InSearchText);

	TSharedPtr<SComboGraphBrowserColumnView> ColumnView;
	TSharedPtr<SHeaderRow> ColumnViewHeader;

	TArray<FComboGraphBrowserCustomColumn> CustomColumns;
	FOnComboGraphItemDoubleClicked OnListMouseDoubleClickDelegate;
	FOnComboGraphItemClicked OnListMouseClickDelegate;

	FName PrimarySortedColumn;
	EColumnSortMode::Type PrimarySortMode;
	FName SecondarySortedColumn;
	EColumnSortMode::Type SecondarySortMode;

	TArray<TSharedPtr<FComboGraphBrowserItem>> FilteredSourceItem;

	TSharedPtr<FUICommandList> BrowserCommands;
	TSharedPtr<FUICommandList> BrowserItemMenuCommands;

	/** Whether to allow dragging of items */
	uint8 bAllowDragging : 1;

	static FName BrowserMainMenuName;
	static FName BrowserFileSubMenuName;

	/* Widget containing the filtering text box */
	TSharedPtr<SSearchBox> FilterTextBoxWidget;
	FText SearchText;
};

UCLASS(Config=EditorPerProjectUserSettings)
class UComboGraphBrowserLocalData : public UObject
{
	GENERATED_BODY()
	
public:
	UPROPERTY(Config)
	TSet<FString> SelectedCategories;
};
