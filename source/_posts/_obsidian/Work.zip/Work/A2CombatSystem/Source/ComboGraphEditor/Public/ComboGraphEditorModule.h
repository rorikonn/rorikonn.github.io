// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "ComboGraphEditorStyle.h"
#include "Modules/ModuleManager.h"

class UComboGraphData;
struct FGraphPanelNodeFactory;
class IAssetTypeActions;


class FComboGraphEditorCommands : public TCommands<FComboGraphEditorCommands>
{
public:
	FComboGraphEditorCommands()
		: TCommands(TEXT("ComboGraphEditor"), NSLOCTEXT("ComboGraphEditorModule", "CommandsContext", "ComboGraphEditor Plugin"),
		            NAME_None, FComboGraphEditorStyle::GetStyleSetName())
	{
	}

	virtual void RegisterCommands() override;
	
	TSharedPtr<FUICommandInfo> OpenEditorWindow;
};

class FComboGraphEditorModule : public IModuleInterface, public IHasMenuExtensibility
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	virtual TSharedPtr<FExtensibilityManager> GetMenuExtensibilityManager() override { return MenuExtensibilityManager; }

protected:
	void RegisterEntry();
	void UnregisterEntry();

	void RegisterFactories();
	void UnregisterFactories();
	
	/** Do real spawn skill editor window. */
	TSharedRef<SDockTab> OnSpawnComboGraphBrowserTab(const FSpawnTabArgs& SpawnTabArgs);

	/** Open combo graph asset editor. */
	void OnComboGraphDoubleClick(UComboGraphData* Graph);

private:
	/** Register panel node factory so that we can unregister during shutdown*/
	TSharedPtr<FGraphPanelNodeFactory> GraphNodeFactory;

	TSharedPtr<FExtensibilityManager> MenuExtensibilityManager;

public:
	COMBOGRAPHEDITOR_API static FName ComboGraphBrowserTabName;
};
