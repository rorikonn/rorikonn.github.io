﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "AssetEditor/ComboGraphDebugger.h"

#include "ComboGraphDelegates.h"
#include "ComboGraphEditorLog.h"
#include "UnrealEdGlobals.h"
#include "AssetEditor/ComboGraphAssetEditor.h"
#include "Editor/UnrealEdEngine.h"
#include "Engine/Selection.h"
#include "Graph/ComboGraph.h"

static void ForEachGameWorld(const TFunction<void(UWorld*)>& Func)
{
	for (const FWorldContext& PieContext : GUnrealEd->GetWorldContexts())
	{
		UWorld* PlayWorld = PieContext.World();
		if (PlayWorld && PlayWorld->IsGameWorld())
		{
			Func(PlayWorld);
		}
	}
}

static bool AreAllGameWorldPaused()
{
	bool bPaused = true;
	ForEachGameWorld([&](const UWorld* World)
	{
		bPaused = bPaused && World->bDebugPauseExecution;
	});
	return bPaused;
}

FComboGraphDebugger::FComboGraphDebugger()
{
	ComboGraphAsset = nullptr;
	bIsPIEActive = false;

	FEditorDelegates::BeginPIE.AddRaw(this, &FComboGraphDebugger::OnBeginPIE);
	FEditorDelegates::EndPIE.AddRaw(this, &FComboGraphDebugger::OnEndPIE);
	FEditorDelegates::PausePIE.AddRaw(this, &FComboGraphDebugger::OnPausePIE);
}

FComboGraphDebugger::~FComboGraphDebugger()
{
	FEditorDelegates::BeginPIE.RemoveAll(this);
	FEditorDelegates::EndPIE.RemoveAll(this);
	FEditorDelegates::PausePIE.RemoveAll(this);
	USelection::SelectObjectEvent.RemoveAll(this);
	FComboGraphDelegates::OnComboGraphStarted.RemoveAll(this);
	FComboGraphDelegates::OnComboGraphEnded.RemoveAll(this);
}

void FComboGraphDebugger::Tick(float DeltaTime)
{
	// CG_EDITOR_LOG(Verbose, TEXT("FComboGraphDebugger Tick"))
}

bool FComboGraphDebugger::IsTickable() const
{
	return IsDebuggerReady();
}

void FComboGraphDebugger::Setup(UComboGraphData* InComboGraphAsset, TSharedRef<FComboGraphAssetEditor> InEditorOwner)
{
	EditorOwner = InEditorOwner;
	ComboGraphAsset = InComboGraphAsset;
	KnownInstances.Reset();
	KnownActors.Reset();

#if WITH_EDITORONLY_DATA
	if (IsPIESimulating())
	{
		OnBeginPIE(GEditor->bIsSimulatingInEditor);
	}
#endif
}

bool FComboGraphDebugger::IsDebuggerReady() const
{
	return bIsPIEActive;
}

bool FComboGraphDebugger::IsDebuggerRunning() const
{
	return ActorInstance.IsValid();
}

UComboGraph* FComboGraphDebugger::GetDebuggedGraphForSelectedActor() const
{
	const AActor* SelectedActor = GetSelectedActor();
	if (!SelectedActor)
	{
		return nullptr;
	}

	UComboGraph* Result = nullptr;
	for (TWeakObjectPtr<UComboGraph> GraphInstance : KnownInstances)
	{
		if (!GraphInstance.IsValid())
		{
			continue;
		}

		const AActor* Avatar = GraphInstance->GetAvatarActor();
		if (Avatar == SelectedActor)
		{
			Result = GraphInstance.Get();
		}
	}

	return Result;
}

AActor* FComboGraphDebugger::GetSelectedActor() const
{
	return ActorInstance.IsValid() ? ActorInstance.Get() : nullptr;
}

void FComboGraphDebugger::OnBeginPIE(const bool bIsSimulating)
{
	bIsPIEActive = true;
	if(EditorOwner.IsValid())
	{
		const TSharedPtr<FComboGraphAssetEditor> EditorOwnerPtr = EditorOwner.Pin();
		EditorOwnerPtr->RegenerateMenusAndToolbars();
		EditorOwnerPtr->DebuggerUpdateGraph(true);
	}

	// remove these delegates first as we can get multiple calls to OnBeginPIE()
	USelection::SelectObjectEvent.RemoveAll(this);
	FComboGraphDelegates::OnComboGraphStarted.RemoveAll(this);
	FComboGraphDelegates::OnComboGraphEnded.RemoveAll(this);

	USelection::SelectObjectEvent.AddRaw(this, &FComboGraphDebugger::OnObjectSelected);
	FComboGraphDelegates::OnComboGraphStarted.AddRaw(this, &FComboGraphDebugger::OnComboGraphStarted);
	FComboGraphDelegates::OnComboGraphEnded.AddRaw(this, &FComboGraphDebugger::OnComboGraphEnded);
}

void FComboGraphDebugger::OnEndPIE(const bool bIsSimulating)
{
	bIsPIEActive = false;
	if (EditorOwner.IsValid())
	{
		const TSharedPtr<FComboGraphAssetEditor> EditorOwnerPtr = EditorOwner.Pin();
		EditorOwnerPtr->RegenerateMenusAndToolbars();
		EditorOwnerPtr->DebuggerUpdateGraph(false);
	}

	USelection::SelectObjectEvent.RemoveAll(this);
	FComboGraphDelegates::OnComboGraphStarted.RemoveAll(this);
	FComboGraphDelegates::OnComboGraphEnded.RemoveAll(this);
}

void FComboGraphDebugger::OnPausePIE(const bool bIsSimulating)
{
#if WITH_EDITORONLY_DATA
	// // We might have paused while executing a sub-tree, so make sure that the editor is showing the correct tree
#endif
}

void FComboGraphDebugger::OnObjectSelected(UObject* Object)
{
	CG_EDITOR_LOG(Verbose, TEXT("FComboGraphDebugger TestDebugger OnObjectSelected %s"), *GetNameSafe(Object))

	if (Object && Object->IsSelected())
	{
		AActor* Actor = Cast<AActor>(Object);
		if (Actor)
		{
			CG_EDITOR_LOG(Verbose, TEXT("FComboGraphDebugger TestDebugger OnObjectSelected Update actor instance %s"), *GetNameSafe(Actor))
			ActorInstance = Actor;
		}
	}
}

void FComboGraphDebugger::OnComboGraphStarted(const UComboGraph& InGraphInstance, const UComboGraphData& InGraphData)
{
	const bool bAssetMatches = ComboGraphAsset && ComboGraphAsset == &InGraphData;
	CG_EDITOR_LOG(Verbose, TEXT("FComboGraphDebugger TestDebugger OnComboGraphStarted %s - %d (Ability: %s)"), *GetNameSafe(&InGraphData), InGraphData.GetUniqueID(), *GetNameSafe(&InGraphInstance))
	CG_EDITOR_LOG(Verbose, TEXT("FComboGraphDebugger TestDebugger OnComboGraphStarted bAssetMatches %s)"), bAssetMatches ? TEXT("true") : TEXT("false"))

	// start debugging if combo graph asset matches, and no other actor was selected
	if (!ActorInstance.IsValid() && bAssetMatches)
	{
		AActor* Avatar = InGraphInstance.GetAvatarActor();

		CG_EDITOR_LOG(Verbose, TEXT("FComboGraphDebugger TestDebugger OnComboGraphStarted SetObjeSetActorBeingDebuggedctBeingDebugged %s"), *GetNameSafe(Avatar))
		ActorInstance = MakeWeakObjectPtr(Avatar);
	}

	// Update known instances if combo graph asset matches
	if (bAssetMatches)
	{
		const TWeakObjectPtr<UComboGraph> OwnerTaskInstance = const_cast<UComboGraph*>(&InGraphInstance);
		if (OwnerTaskInstance.IsValid())
		{
			KnownInstances.AddUnique(OwnerTaskInstance);
		}

		const TWeakObjectPtr<AActor> OwnerActor = InGraphInstance.GetAvatarActor();
		if (OwnerActor.IsValid())
		{
			KnownActors.AddUnique(OwnerActor);
		}
	}
}

void FComboGraphDebugger::OnComboGraphEnded(const UComboGraph& InGraphInstance, const UComboGraphData& InGraphAsset)
{
	CG_EDITOR_LOG(Verbose, TEXT("FComboGraphDebugger TestDebugger OnComboGraphEnded %s (Ability: %s)"), *GetNameSafe(&InGraphAsset), *GetNameSafe(&InGraphInstance))

	const bool bAssetMatches = ComboGraphAsset && ComboGraphAsset == &InGraphAsset;

	// Update known instances if combo graph asset matches
	if (!bAssetMatches)
	{
		return;
	}

	for (int32 Index = KnownInstances.Num() - 1; Index >= 0; Index--)
	{
		const UComboGraph* GraphInstance = KnownInstances[Index].Get();
		if (GraphInstance == nullptr)
		{
			KnownInstances.RemoveAt(Index);
			continue;
		}

		if (GraphInstance == &InGraphInstance)
		{
			KnownInstances.RemoveAt(Index);
		}
	}
}

bool FComboGraphDebugger::IsPlaySessionPaused()
{
	return AreAllGameWorldPaused();
}

bool FComboGraphDebugger::IsPlaySessionRunning()
{
	return !AreAllGameWorldPaused();
}

bool FComboGraphDebugger::IsPIESimulating()
{
	return GEditor->bIsSimulatingInEditor || GEditor->PlayWorld;
}

bool FComboGraphDebugger::IsPIENotSimulating()
{
	return !GEditor->bIsSimulatingInEditor && (GEditor->PlayWorld == nullptr);
}

FString FComboGraphDebugger::GetDebuggedInstanceDesc() const
{
	AActor* Actor = ActorInstance.Get();
	if (Actor)
	{
		return DescribeInstance(*Actor);
	}

	return NSLOCTEXT("ComboGraphAssetEditor", "DebugActorNothingSelected", "No debug object selected").ToString();
}

FString FComboGraphDebugger::GetActorLabel(const AActor* InActor, const bool bIncludeNetModeSuffix, const bool bIncludeSpawnedContext) const
{
	if (!InActor)
	{
		return TEXT_NULL;
	}

	FString Context;
	FString Label = InActor->GetActorLabel();

	if (bIncludeNetModeSuffix)
	{
		// ReSharper disable once CppIncompleteSwitchStatement
		// ReSharper disable once CppDefaultCaseNotHandledInSwitchStatement
		switch (InActor->GetNetMode())
		{
		case ENetMode::NM_Client:
			{
				Context = NSLOCTEXT("BlueprintEditor", "DebugWorldClient", "Client").ToString();

				FWorldContext* WorldContext = GEngine->GetWorldContextFromWorld(InActor->GetWorld());
				if (WorldContext != nullptr && WorldContext->PIEInstance > 1)
				{
					Context += TEXT(" ");
					Context += FText::AsNumber(WorldContext->PIEInstance - 1).ToString();
				}
			}
			break;

		case ENetMode::NM_ListenServer:
		case ENetMode::NM_DedicatedServer:
			Context = NSLOCTEXT("BlueprintEditor", "DebugWorldServer", "Server").ToString();
			break;
		}
	}

	if (bIncludeSpawnedContext)
	{
		if (!Context.IsEmpty())
		{
			Context += TEXT(", ");
		}

		Context += NSLOCTEXT("BlueprintEditor", "DebugObjectSpawned", "spawned").ToString();
	}

	if (!Context.IsEmpty())
	{
		Label = FString::Printf(TEXT("%s (%s)"), *Label, *Context);
	}

	return Label;
}

FString FComboGraphDebugger::DescribeInstance(const AActor& ActorToDescribe) const
{
	return FString::Printf(TEXT("%s"), *GetActorLabel(&ActorToDescribe));
}

void FComboGraphDebugger::OnInstanceSelectedInDropdown(AActor* SelectedActor)
{
	CG_EDITOR_LOG(Verbose, TEXT("FComboGraphDebugger OnInstanceSelectedInDropdown Actor: %s"), *GetNameSafe(SelectedActor))

	if (SelectedActor)
	{
		USelection* SelectedActors = GEditor ? GEditor->GetSelectedActors() : nullptr;
		if (SelectedActors)
		{
			SelectedActors->DeselectAll();
		}

		ActorInstance = SelectedActor;

		if (SelectedActors)
		{
			SelectedActors->Select(SelectedActor);
		}
	}
}

void FComboGraphDebugger::GetMatchingInstances(TArray<UComboGraph*>& MatchingInstances, TArray<AActor*>& MatchingActors)
{
	for (int32 Index = KnownInstances.Num() - 1; Index >= 0; Index--)
	{
		UComboGraph* Graph = KnownInstances[Index].Get();
		if (Graph == nullptr)
		{
			KnownInstances.RemoveAt(Index);
			continue;
		}

		MatchingInstances.Add(Graph);
	}

	for (int32 Index = KnownActors.Num() - 1; Index >= 0; Index--)
	{
		AActor* Actor = KnownActors[Index].Get();
		if (Actor == nullptr)
		{
			KnownActors.RemoveAt(Index);
			continue;
		}

		MatchingActors.Add(Actor);
	}
}
