﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

class UComboGraph;
class UComboGraphNodeDataBase;
class UComboGraphData;

class COMBOGRAPHEDITOR_API FComboGraphDebugger : public FTickableGameObject
{
public:
	FComboGraphDebugger();
	virtual ~FComboGraphDebugger() override;

	//~ Begin FTickableGameObject
	virtual void Tick(float DeltaTime) override;
	virtual bool IsTickable() const override;
	virtual bool IsTickableWhenPaused() const override { return true; }
	virtual bool IsTickableInEditor() const override { return true; }
	virtual TStatId GetStatId() const override { RETURN_QUICK_DECLARE_CYCLE_STAT(FComboGraphEditorTickHelper, STATGROUP_Tickables); }
	//~ End FTickableGameObject

	/** Refresh the debugging information we are displaying (only when paused, as Tick() updates when running) */
	void Setup(UComboGraphData* InComboGraphAsset, TSharedRef<class FComboGraphAssetEditor> InEditorOwner);

	bool IsDebuggerReady() const;
	bool IsDebuggerRunning() const;

	UComboGraph* GetDebuggedGraphForSelectedActor() const;
	AActor* GetSelectedActor() const;

	void OnBeginPIE(const bool bIsSimulating);
	void OnEndPIE(const bool bIsSimulating);
	void OnPausePIE(const bool bIsSimulating);

	void OnObjectSelected(UObject* Object);
	void OnComboGraphStarted(const UComboGraph& InGraphInstance, const UComboGraphData& InGraphData);
	void OnComboGraphEnded(const UComboGraph& InGraphInstance, const UComboGraphData& InGraphAsset);

	static bool IsPlaySessionPaused();
	static bool IsPlaySessionRunning();
	static bool IsPIESimulating();
	static bool IsPIENotSimulating();

	FString GetDebuggedInstanceDesc() const;
	FString GetActorLabel(const AActor* InActor, const bool bIncludeNetModeSuffix = true, const bool bIncludeSpawnedContext = true) const;
	FString DescribeInstance(const AActor& ActorToDescribe) const;
	void OnInstanceSelectedInDropdown(AActor* SelectedActor);
	void GetMatchingInstances(TArray<UComboGraph*>& MatchingInstances, TArray<AActor*>& MatchingActors);

private:

	/** owning editor */
	TWeakPtr<FComboGraphAssetEditor> EditorOwner;

	/** asset for debugging */
	UComboGraphData* ComboGraphAsset;

	/** root node in asset's graph */
	TWeakObjectPtr<UComboGraphNodeDataBase> RootNode;

	/** instance for debugging */
	TWeakObjectPtr<AActor> ActorInstance;

	/** all known ComboGraph task instances, cached for dropdown list */
	TArray<TWeakObjectPtr<UComboGraph>> KnownInstances;

	/** all known ComboGraph owner instances, cached for dropdown list */
	TArray<TWeakObjectPtr<AActor>> KnownActors;

	/** cached PIE state */
	bool bIsPIEActive = false;
};
