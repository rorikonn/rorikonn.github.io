﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Editors/SComboGraphBrowser.h"

#include "ComboGraphEditorModule.h"
#include "Framework/Commands/GenericCommands.h"
#include "Graph/ComboGraphEdGraph.h"
#include "Graph/ComboGraphNodeBase.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"

#define LOCTEXT_NAMESPACE "SComboGraphBrowser"

FName SComboGraphBrowser::BrowserMainMenuName = TEXT("ComboGraphBrowserMainMenu");
FName SComboGraphBrowser::BrowserFileSubMenuName = TEXT("ComboGraphBrowserMainMenu.File");

FComboGraphBrowserItem::FComboGraphBrowserItem()
{
}

FComboGraphBrowserItem::FComboGraphBrowserItem(UComboGraphData* Data)
	: Data(Data)
{
}

void FComboGraphBrowserItem::UpdateCustomColumnValue(TArray<FComboGraphBrowserCustomColumn>& CustomColumns)
{
	for (const FComboGraphBrowserCustomColumn& Column : CustomColumns)
	{
		if (Column.OnGetColumnData.IsBound())
		{
			CachedCustomColumnData.Emplace(Column.ColumnName, Column.OnGetColumnData.Execute(Data.Get(), Column.ColumnName));
		}

		if (Column.OnGetColumnDisplayText.IsBound())
		{
			CachedCustomColumnDisplayText.Emplace(Column.ColumnName, Column.OnGetColumnDisplayText.Execute(Data.Get(), Column.ColumnName));
		}
	}
}

FString FComboGraphBrowserItem::GetColumnData(FName ColumnName)
{
	if (FString* Found = CachedCustomColumnData.Find(ColumnName))
	{
		return *Found;
	}

	return FString();
}

FText FComboGraphBrowserItem::GetColumnDisplayText(FName ColumnName)
{
	if (FText* Found = CachedCustomColumnDisplayText.Find(ColumnName))
	{
		return *Found;
	}

	return FText();
}

FComboGraphBrowserCustomColumn::FComboGraphBrowserCustomColumn()
{
}

FComboGraphBrowserCustomColumn::FComboGraphBrowserCustomColumn(
	FName InName, const FText& DisplayName, const FText& Tooltip, const FOnGetCustomGraphColumnData& OnGetDataDelegate,
	const FOnGetCustomGraphColumnDisplayText& OnGetDisplayTextDelegate, const FOnSortGraphColumnData& OnSortColumnData)
	: ColumnName(InName),
	  DisplayName(DisplayName),
	  TooltipText(Tooltip),
	  OnGetColumnData(OnGetDataDelegate),
	  OnGetColumnDisplayText(OnGetDisplayTextDelegate),
	  OnSortColumnData(OnSortColumnData)
{
}

void SComboGraphBrowserColumnRow::Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTableView)
{
	AssetItem = InArgs._AssetItem;

	SMultiColumnTableRow<TSharedPtr<FComboGraphBrowserItem>>::Construct(
		FSuperRowType::FArguments()
		.Style(FAppStyle::Get(), "TableView.Row")
		.OnDragDetected(InArgs._OnDragDetected),
		InOwnerTableView);
}

TSharedRef<SWidget> SComboGraphBrowserColumnRow::GenerateWidgetForColumn(const FName& ColumnName)
{
	static const FMargin ColumnItemPadding(5.0f, 0.0f);

	return SNew(SBox)
	.Padding(ColumnItemPadding)
	.VAlign(VAlign_Center)
	.HAlign(HAlign_Left)
	[
		SNew(STextBlock)
		.ToolTipText(this, &SComboGraphBrowserColumnRow::GetColumnTips, ColumnName)
		.Text(this, &SComboGraphBrowserColumnRow::GetColumnText, ColumnName)
	];
}

FVector2D SComboGraphBrowserColumnRow::GetRowSizeForColumn(const FName& InColumnName) const
{
	const TSharedRef<SWidget>* ColumnWidget = GetWidgetFromColumnId(InColumnName);

	return ColumnWidget ? (*ColumnWidget)->GetDesiredSize() : FVector2D::ZeroVector;
}

void FComboGraphBrowserCommands::RegisterCommands()
{
	UI_COMMAND(CreateNew, "New Graph ...", "Create new item in combo graph browser", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(LoadAll, "Load All", "Reload all combo graph data include runtime and editor", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(SaveAll, "Save All", "Save all combo graph data include runtime and editor", EUserInterfaceActionType::Button, FInputChord());
}

SComboGraphCreator::SComboGraphCreator()
	: bCreateConfirmed(0),
	  InputID(0),
	  InputName(NAME_None)
{
}

void SComboGraphCreator::Construct(const FArguments& InArgs)
{
	
	ChildSlot
	[
		SNew(SBorder)
		.Visibility(EVisibility::Visible)
		.BorderImage(FAppStyle::GetBrush("Menu.Background"))
		.Padding(FMargin(14.0f, 21.0f, 14.0f, 3.0f))
		[
			SNew(SBox)
			.Visibility(EVisibility::Visible)
			[
				SNew(SVerticalBox) +
				SVerticalBox::Slot()
				.HAlign(HAlign_Fill)
				[
					SNew(SVerticalBox) +
					SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 5.0f)
					[
						SNew(SGridPanel)
						.FillColumn(1, 1.0f)

						// ID label
						+ SGridPanel::Slot(0, 0)
						  .VAlign(VAlign_Center)
						  .Padding(0, 0, 12, 0)
						[
							SNew(STextBlock)
							.Text(this, &SComboGraphCreator::GetIDHeader)
						]

						// ID edit box
						+ SGridPanel::Slot(1, 0)
						  .Padding(0.0f, 3.0f, 12.0f, 3.0f)
						  .VAlign(VAlign_Center)
						[
							SNew(SEditableTextBox)
							.Text(this, &SComboGraphCreator::OnGetIDText)
							.OnTextCommitted(this, &SComboGraphCreator::OnIDInputCommit)
						]
					] +
					SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 5.0f)
					[
						SNew(SGridPanel)
						.FillColumn(1, 1.0f)

						// Name label
						+ SGridPanel::Slot(0, 0)
						  .VAlign(VAlign_Center)
						  .Padding(0, 0, 12, 0)
						[
							SNew(STextBlock)
							.Text(this, &SComboGraphCreator::GetNameHeader)
						]

						// Name edit box
						+ SGridPanel::Slot(1, 0)
						  .Padding(0.0f, 3.0f, 12.0f, 3.0f)
						  .VAlign(VAlign_Center)
						[
							SNew(SEditableTextBox)
							.Text(this, &SComboGraphCreator::OnGetNameText)
							.OnTextCommitted(this, &SComboGraphCreator::OnNameInputCommit)
						]
					] +
					SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 10.0f)
					[
						SNew(SGridPanel)
						.FillColumn(1, 1.0f)

						// Data Category label
						+ SGridPanel::Slot(0, 0)
						  .VAlign(VAlign_Center)
						  .Padding(0, 0, 12, 0)
						[
							SNew(STextBlock)
							.Text(this, &SComboGraphCreator::GetCategoryHeader)
						]

						// Data Category edit box
						+ SGridPanel::Slot(1, 0)
						  .Padding(0.0f, 3.0f, 12.0f, 3.0f)
						  .VAlign(VAlign_Center)
						[
							SNew(SEditableTextBox)
								.Text(this, &SComboGraphCreator::OnGetCategoryText)
								.OnTextCommitted(this, &SComboGraphCreator::OnCategoryInputCommit)
						]
					] +

					// Description label
					SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 1.0f)
					[
						SNew(STextBlock)
						.Text(this, &SComboGraphCreator::GetDescHeader)
					] +
					// Description edit box
					SVerticalBox::Slot()
					.VAlign(VAlign_Fill)
					.Padding(0.0f, 0.0f, 0.0f, 5.0f)
					[
						SNew(SBox)
						.VAlign(VAlign_Fill)
						.HAlign(HAlign_Fill)
						[
							SNew(SMultiLineEditableTextBox)
							.AutoWrapText(true)
							.Text(this, &SComboGraphCreator::OnGetDescriptionText)
							.OnTextCommitted(this, &SComboGraphCreator::OnDescriptionInputCommit)
						]
					]
				] +
				SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Right)
				.VAlign(VAlign_Bottom)
				.Padding(8)
				[
					SNew(SUniformGridPanel)
					.SlotPadding(FAppStyle::GetMargin("StandardDialog.SlotPadding"))
					.MinDesiredSlotWidth(FAppStyle::GetFloat("StandardDialog.MinDesiredSlotWidth"))
					.MinDesiredSlotHeight(FAppStyle::GetFloat("StandardDialog.MinDesiredSlotHeight")) +
					SUniformGridPanel::Slot(0, 0)
					[
						SNew(SButton)
						.HAlign(HAlign_Center)
						.ContentPadding(FAppStyle::GetMargin("StandardDialog.ContentPadding"))
						.OnClicked(this, &SComboGraphCreator::OnConfirmClicked)
						.Text(LOCTEXT("ComboGraphCreatorOK", "OK"))
					] +
					SUniformGridPanel::Slot(1, 0)
					[
						SNew(SButton)
						.HAlign(HAlign_Center)
						.OnClicked(this, &SComboGraphCreator::OnCancelClicked)
						.Text(LOCTEXT("ComboGraphCreatorCancel", "Cancel"))
						.ContentPadding(FAppStyle::GetMargin("StandardDialog.ContentPadding"))
					]
				] // SVerticalBox
			] // SBox
		] // SBorder
	]; // ChildSlot
}

bool SComboGraphCreator::DoCreation()
{
	const TSharedRef<SWindow> Window =
		SNew(SWindow)
		.MinHeight(500.0f)
		.MinWidth(400.0f)
		.ClientSize(FVector2D(400.0f, 500.0f))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.Title(LOCTEXT("ComboGraphCreatorTitle", "Create New Graph"))
		[
			AsShared()
		];

	ComboGraphCreatorWindow = Window;

	GEditor->EditorAddModalWindow(Window);

	return bCreateConfirmed;
}

void SComboGraphCreator::Confirm()
{
	if (!IsGraphIDValid())
	{
		constexpr int32 MaxID = TNumericLimits<int32>::Max() >> 1;
		GEditor->OnModalMessageDialog(
			EAppMsgType::Ok, FText::Format(LOCTEXT("InvalidIDError", "ID is not valid! ID should large than 0 and less than {0}"), FText::AsNumber(MaxID)),
			LOCTEXT("CreateFailedTitle", "Failed"));
		return;
	}

	if (const UComboGraphData* ExistData = FDataArchiveManager::Find<UComboGraphData>(InputID))
	{
		const FString RepeatDataName = ExistData->Name;

		FFormatNamedArguments Args;
		Args.Add(TEXT("RepeatID"), FText::FromString(FString::FromInt(InputID)));
		Args.Add(TEXT("OldDataName"), FText::FromString(RepeatDataName));

		GEditor->OnModalMessageDialog(
			EAppMsgType::Ok, FText::Format(LOCTEXT("InvalidIDError", "ID is not valid! ID-{RepeatID} can not repeat, ExistDataName: {OldDataName}"), Args),
			LOCTEXT("CreateFailedTitle", "Failed"));

		return;
	}

	UComboGraphData* CreatedData = FDataArchiveManager::Add<UComboGraphData>(InputID);
	if (CreatedData)
	{
		CreatedData->ID = InputID;
		CreatedData->Name = InputName.ToString();
		CreatedData->Description = InputDescription;
		CreatedData->Category = InputCategory;
	}
	else
	{
		GEditor->OnModalMessageDialog(EAppMsgType::Ok, LOCTEXT("CreateNewDataFailed", "Create new data failed!"), LOCTEXT("CreateFailedTitle", "Failed"));
		return;
	}

	bCreateConfirmed = true;

	if (ComboGraphCreatorWindow.IsValid())
	{
		ComboGraphCreatorWindow.Pin()->RequestDestroyWindow();
	}
}

void SComboGraphCreator::Cancel()
{
	bCreateConfirmed = false;

	if (ComboGraphCreatorWindow.IsValid())
	{
		ComboGraphCreatorWindow.Pin()->RequestDestroyWindow();
	}
}

bool SComboGraphCreator::IsGraphIDValid() const
{
	return InputID > 0 && InputID < TNumericLimits<int32>::Max() >> 1;
}

FText SComboGraphCreator::OnGetIDText() const
{
	FNumberFormattingOptions NumberFormat;
	NumberFormat.SetUseGrouping(false);
	return FText::AsNumber(InputID, &NumberFormat);
}

void SComboGraphCreator::OnIDInputCommit(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType != ETextCommit::Type::OnCleared)
	{
		if (FCString::IsNumeric(*NewText.ToString()))
		{
			InputID = FCString::Atoi(*NewText.ToString());
		}
	}
}

FText SComboGraphCreator::OnGetNameText() const
{
	return FText::FromName(InputName);
}

void SComboGraphCreator::OnNameInputCommit(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType != ETextCommit::Type::OnCleared)
	{
		InputName = FName(*NewText.ToString());
	}
}

FText SComboGraphCreator::OnGetDescriptionText() const
{
	return FText::FromString(InputDescription);
}

void SComboGraphCreator::OnDescriptionInputCommit(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType != ETextCommit::Type::OnCleared)
	{
		InputDescription = NewText.ToString();
	}
}

FText SComboGraphCreator::OnGetCategoryText() const
{
	return FText::FromString(InputCategory);
}

void SComboGraphCreator::OnCategoryInputCommit(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType != ETextCommit::Type::OnCleared)
	{
		InputCategory = NewText.ToString();
	}
}

FReply SComboGraphCreator::OnConfirmClicked()
{
	Confirm();

	return FReply::Handled();
}

FReply SComboGraphCreator::OnCancelClicked()
{
	Cancel();

	return FReply::Handled();
}

FText SComboGraphCreator::GetIDHeader() const
{
	return LOCTEXT("GraphIDHeader", "ID");
}

FText SComboGraphCreator::GetNameHeader() const
{
	return LOCTEXT("GraphNameHeader", "Name");
}

FText SComboGraphCreator::GetDescHeader() const
{
	return LOCTEXT("GraphDescHeader", "Description");
}

FText SComboGraphCreator::GetCategoryHeader() const
{
	return LOCTEXT("GraphCategoryHeader", "Category");
}

SComboGraphBrowser::SComboGraphBrowser():
	PrimarySortMode(),
	SecondarySortMode(),
	bAllowDragging(false)
{
}

void SComboGraphBrowser::Construct(const FArguments& InArgs)
{
	CustomColumns = InArgs._CustomColumns;
	OnListMouseDoubleClickDelegate = InArgs._OnComboGraphDoubleClick;
	OnListMouseClickDelegate = InArgs._OnComboGraphClick;

	ColumnView = ConstructColumnView();

	ChildSlot
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		  .HAlign(HAlign_Fill)
		  .VAlign(VAlign_Top)
		  .AutoHeight()
		[
			ConstructMenuBar()
		]
		+ SVerticalBox::Slot()
		  .HAlign(HAlign_Fill)
		  .VAlign(VAlign_Top)
		  .AutoHeight()
		[
			SAssignNew(FilterTextBoxWidget, SSearchBox)
			.Visibility(EVisibility::Visible)
			.HintText(LOCTEXT("FilterSearch", "Search..."))
			.ToolTipText(LOCTEXT("FilterSearchHint", "Type here to search (pressing enter selects the results)"))
			.OnTextChanged(this, &SComboGraphBrowser::OnFilterTextChanged)
			.OnTextCommitted(this, &SComboGraphBrowser::OnFilterTextCommitted)
		]
		+ SVerticalBox::Slot()
		[
			ColumnView.ToSharedRef()
		]
	];

	RebuildContent();
}

TSharedPtr<SComboGraphBrowserColumnView> SComboGraphBrowser::ConstructColumnView()
{
	{
		const FName IDColumnName = GET_MEMBER_NAME_CHECKED(UComboGraphData, ID);
		CustomColumns.Emplace(IDColumnName, LOCTEXT("ComboGraphColumnID", "ID"), LOCTEXT("ComboGraphColumnIDToolTips", "Combo Graph ID"),
		                      FOnGetCustomGraphColumnData::CreateStatic(&SComboGraphBrowser::OnGetBrowserColumnData),
		                      FOnGetCustomGraphColumnDisplayText::CreateStatic(&SComboGraphBrowser::OnGetBrowserColumnDisplayText),
		                      FOnSortGraphColumnData::CreateStatic(&SComboGraphBrowser::OnSortIDColumn));

		const FName CategoryName = GET_MEMBER_NAME_CHECKED(UComboGraphData, Category);
		CustomColumns.Emplace(CategoryName, LOCTEXT("ComboGraphColumnCategory", "Category"), LOCTEXT("ComboGraphColumnCategoryToolTips", "Combo Graph Category"),
		                      FOnGetCustomGraphColumnData::CreateStatic(&SComboGraphBrowser::OnGetBrowserColumnData),
		                      FOnGetCustomGraphColumnDisplayText::CreateStatic(&SComboGraphBrowser::OnGetBrowserColumnDisplayText),
		                      FOnSortGraphColumnData::CreateStatic(&SComboGraphBrowser::OnSortCategoryColumn));

		const FName NameColumnName = GET_MEMBER_NAME_CHECKED(UComboGraphData, Name);
		CustomColumns.Emplace(NameColumnName, LOCTEXT("ComboGraphColumnName", "Name"), LOCTEXT("ComboGraphColumnNameToolTips", "Combo Graph Name"),
		                      FOnGetCustomGraphColumnData::CreateStatic(&SComboGraphBrowser::OnGetBrowserColumnData),
		                      FOnGetCustomGraphColumnDisplayText::CreateStatic(&SComboGraphBrowser::OnGetBrowserColumnDisplayText));
	}

	TSharedPtr<SComboGraphBrowserColumnView> View;

	SAssignNew(View, SComboGraphBrowserColumnView)
		.OnMouseButtonClick(this, &SComboGraphBrowser::OnListMouseButtonClick)
		.OnMouseButtonDoubleClick(this, &SComboGraphBrowser::OnListMouseButtonDoubleClick)
		.OnContextMenuOpening(this, &SComboGraphBrowser::OnConstructItemContextMenu)
		.SelectionMode(ESelectionMode::Type::Single)
		.ListItemsSource(&FilteredSourceItem)
		.OnGenerateRow(this, &SComboGraphBrowser::MakeColumnViewWidget)
		.HeaderRow(SAssignNew(ColumnViewHeader, SHeaderRow).ResizeMode(ESplitterResizeMode::FixedSize));

	return View;
}

FString SComboGraphBrowser::OnGetBrowserColumnData(UComboGraphData* GraphData, FName ColumnName)
{
	if (const UStruct* Struct = GraphData ? GraphData->GetClass() : nullptr)
	{
		for (TFieldIterator<FProperty> Property(Struct); Property; ++Property)
		{
			if (Property->GetFName() == ColumnName)
			{
				const void* Value = Property->ContainerPtrToValuePtr<uint8>(GraphData);

				// convert the property to a FJsonValue
				TSharedPtr<FJsonValue> JsonValue = FJsonObjectConverter::UPropertyToJsonValue(*Property, Value);
				if (JsonValue.IsValid())
				{
					return JsonValue->AsString();
				}
			}
		}
	}

	return TEXT("");
}

FText SComboGraphBrowser::OnGetBrowserColumnDisplayText(UComboGraphData* GraphData, FName ColumnName)
{
	return FText::FromString(OnGetBrowserColumnData(GraphData, ColumnName));
}

bool SComboGraphBrowser::OnSortIDColumn(const FString& Lhs, const FString& Rhs, EColumnSortMode::Type SortMode)
{
	const int32 LhsID = FCString::Atoi(*Lhs);
	const int32 RhsID = FCString::Atoi(*Rhs);
	return SortMode == EColumnSortMode::Ascending ? LhsID < RhsID : LhsID > RhsID;
}

bool SComboGraphBrowser::OnSortCategoryColumn(const FString& Lhs, const FString& Rhs, EColumnSortMode::Type SortMode)
{
	return SortMode == EColumnSortMode::Ascending ? Lhs < Rhs : Lhs > Rhs;
}

TSharedRef<SWidget> SComboGraphBrowser::ConstructMenuBar()
{
	FComboGraphEditorModule& EditorModule = FModuleManager::LoadModuleChecked<FComboGraphEditorModule>(UE_MODULE_NAME);

	BindCommands();
	RegisterMainMenu();

	const TSharedPtr<FExtender> Extenders = EditorModule.GetMenuExtensibilityManager()->GetAllExtenders();
	const FToolMenuContext MenuContext(BrowserCommands, Extenders.ToSharedRef());

	// Create the menu bar!
	TSharedRef<SWidget> MenuBarWidget = UToolMenus::Get()->GenerateWidget(BrowserMainMenuName, MenuContext);

	return MenuBarWidget;
}

void SComboGraphBrowser::BindCommands()
{
	BrowserCommands = MakeShared<FUICommandList>();

	BrowserCommands->MapAction(FComboGraphBrowserCommands::Get().CreateNew, FExecuteAction::CreateSP(this, &SComboGraphBrowser::CreateNew));
	BrowserCommands->MapAction(FComboGraphBrowserCommands::Get().LoadAll, FExecuteAction::CreateSP(this, &SComboGraphBrowser::LoadAll));
	BrowserCommands->MapAction(FComboGraphBrowserCommands::Get().SaveAll, FExecuteAction::CreateSP(this, &SComboGraphBrowser::SaveAll));
}

void SComboGraphBrowser::RegisterMainMenu()
{
	UToolMenus* ToolMenus = UToolMenus::Get();
	if (ToolMenus->IsMenuRegistered(BrowserMainMenuName))
	{
		return;
	}

	RegisterFileMenu();

	UToolMenu* MenuBar = ToolMenus->RegisterMenu(BrowserMainMenuName, NAME_None, EMultiBoxType::MenuBar);
	MenuBar->AddSubMenu(
		"MainMenu",
		NAME_None,
		"File",
		LOCTEXT("FileMenu", "File"),
		LOCTEXT("FileMenu_ToolTip", "Open the file menu")
	);
}

void SComboGraphBrowser::RegisterFileMenu()
{
	UToolMenus* ToolMenus = UToolMenus::Get();
	UToolMenu* FileMenu = ToolMenus->RegisterMenu(BrowserFileSubMenuName);

	FToolMenuSection& FileCreateAndSaveSection = FileMenu->AddSection("CreateNewGraph", LOCTEXT("CreateNewLabel", "Create"));
	FileCreateAndSaveSection.AddMenuEntry(FComboGraphBrowserCommands::Get().CreateNew);
	FileCreateAndSaveSection.AddMenuEntry(FComboGraphBrowserCommands::Get().SaveAll);

	FToolMenuSection& FileLoadSection = FileMenu->AddSection("LoadGraph", LOCTEXT("LoadGraph", "Load"));
	FileLoadSection.AddMenuEntry(FComboGraphBrowserCommands::Get().LoadAll);
	FileLoadSection.AddSubMenu(
		"LoadCategory",
		LOCTEXT("LoadCategory", "Load Category"),
		LOCTEXT("LoadCategoryTooltip", "Load selected category"),
		FNewToolMenuDelegate::CreateRaw(this, &SComboGraphBrowser::CreateLoadCategorySubMenu)
	);
}

void SComboGraphBrowser::CreateLoadCategorySubMenu(UToolMenu* Menu)
{
	TArray<FString> Categories = FDataArchiveManager::GetAllCategories<UComboGraphData>();

	FToolMenuSection& Section = Menu->AddSection("FilterBarResetFilters");
	Section.AddMenuEntry(
		"ResetFilters",
		LOCTEXT("FilterListResetFilters", "Reset Filters"),
		LOCTEXT("FilterListResetToolTip", "Resets current filter selection"),
		FSlateIcon(FAppStyle::Get().GetStyleSetName(), "PropertyWindow.DiffersFromDefault"),
		FUIAction(
			FExecuteAction::CreateRaw(this, &SComboGraphBrowser::ResetCategoryFilter),
			FCanExecuteAction::CreateLambda([this]() { return !GetDefault<UComboGraphBrowserLocalData>()->SelectedCategories.IsEmpty(); }))
	);

	FToolMenuSection& FileCreateAndSaveSection = Menu->AddSection("CategoryFilters", LOCTEXT("CategoryFilters", "Category Filters"));
	for (const FString& Category : Categories)
	{
		FileCreateAndSaveSection.AddMenuEntry(
			FName(Category),
			FText::FromString(Category),
			FText::FromString(Category),
			FSlateIcon(),
			FUIAction(
				FExecuteAction::CreateRaw(this, &SComboGraphBrowser::FilterCategoryByClicked, Category),
				FCanExecuteAction(),
				FIsActionChecked::CreateLambda([Category, this]() { return GetDefault<UComboGraphBrowserLocalData>()->SelectedCategories.Contains(Category); })),
			EUserInterfaceActionType::ToggleButton
		);
	}
}

void SComboGraphBrowser::CreateNew()
{
	const TSharedRef<SComboGraphCreator> ComboGraphCreator = SNew(SComboGraphCreator);

	if (ComboGraphCreator->DoCreation())
	{
		RebuildContent();
	}
}

void SComboGraphBrowser::LoadAll()
{
	FDataArchiveManager::Load<UComboGraphData>();
	FDataArchiveManager::Load<UComboGraphNodeDataBase>();
	FDataArchiveManager::Load<UComboGraphEdGraphData>();

	RebuildContent();
}

void SComboGraphBrowser::SaveAll()
{
	FDataArchiveManager::SaveAll<UComboGraphData>();
	FDataArchiveManager::SaveAll<UComboGraphEdGraphData>();
	FDataArchiveManager::SaveAll<UComboGraphNodeDataBase>();
}

void SComboGraphBrowser::ResetCategoryFilter()
{
	GetMutableDefault<UComboGraphBrowserLocalData>()->SelectedCategories.Empty();

	RebuildContent();
}

void SComboGraphBrowser::FilterCategoryByClicked(FString Category)
{
	TSet<FString>& SelectedCategories = GetMutableDefault<UComboGraphBrowserLocalData>()->SelectedCategories;
	if (!SelectedCategories.Contains(Category))
	{
		SelectedCategories.Add(Category);
		LoadCategoryGraphData(MoveTemp(Category));
	}
	else
	{
		SelectedCategories.Remove(Category);
	}

	RebuildContent();
}

void SComboGraphBrowser::LoadCategoryGraphData(const FString& Category)
{
	FDataArchiveManager::LoadCategory<UComboGraphData>(
		Category,
		TDelegate<void(UComboGraphData*)>::CreateLambda([](const UComboGraphData* Data)
		{
			FDataArchiveManager::LoadCategory<UComboGraphNodeDataBase>(Data->ID.ToString());
			FDataArchiveManager::LoadCategory<UComboGraphEdGraphData>(Data->ID.ToString());
		}));
}

void SComboGraphBrowser::RebuildContent()
{
	GetMutableDefault<UComboGraphBrowserLocalData>()->SaveConfig();
	
	FilteredSourceItem.Empty();

	TArray<UComboGraphData*> AllData = FDataArchiveManager::GetAll<UComboGraphData>();
	for (UComboGraphData* GraphData : AllData)
	{
		TSharedPtr<FComboGraphBrowserItem> SourceItem = MakeShared<FComboGraphBrowserItem>(GraphData);
		SourceItem->UpdateCustomColumnValue(CustomColumns);
		if (IsDataMatched(SourceItem, SearchText))
		{
			FilteredSourceItem.Add(SourceItem);
		}
	}

	PrimarySortedColumn = CustomColumns[0].ColumnName;
	PrimarySortMode = EColumnSortMode::Ascending;

	SortSourceItems();

	ColumnViewHeader->ClearColumns();
	for (FComboGraphBrowserCustomColumn& Column : CustomColumns)
	{
		ColumnViewHeader->AddColumn(
			SHeaderRow::Column(Column.ColumnName)
			.FillWidth(300)
			.SortMode(this, &SComboGraphBrowser::GetColumnSortMode, Column.ColumnName)
			.SortPriority(this, &SComboGraphBrowser::GetColumnSortPriority, Column.ColumnName)
			.OnSort(FOnSortModeChanged::CreateSP(this, &SComboGraphBrowser::OnSortColumnHeader))
			.DefaultLabel(Column.DisplayName)
		);
	}

	ColumnView->RequestListRefresh();
}

// ReSharper disable once CppPassValueParameterByConstReference
TSharedRef<ITableRow> SComboGraphBrowser::MakeColumnViewWidget(const TSharedPtr<FComboGraphBrowserItem> AssetItem, const TSharedRef<STableViewBase>& OwnerTable)
{
	if (!ensure(AssetItem.IsValid()))
	{
		return SNew(STableRow<TSharedPtr<FComboGraphBrowserItem>>, OwnerTable)
			.Style(FAppStyle::Get(), "TableView.Row");
	}

	AssetItem->UpdateCustomColumnValue(CustomColumns);

	return
		SNew(SComboGraphBrowserColumnRow, OwnerTable)
		.AssetItem(AssetItem)
		.OnDragDetected(this, &SComboGraphBrowser::OnDraggingAssetItem)
		.Cursor(bAllowDragging ? EMouseCursor::GrabHand : EMouseCursor::Default);
}

EColumnSortMode::Type SComboGraphBrowser::GetColumnSortMode(const FName ColumnId) const
{
	if (ColumnId == PrimarySortedColumn)
	{
		return PrimarySortMode;
	}

	if (ColumnId == SecondarySortedColumn)
	{
		return SecondarySortMode;
	}

	return EColumnSortMode::None;
}

EColumnSortPriority::Type SComboGraphBrowser::GetColumnSortPriority(const FName ColumnId) const
{
	if (ColumnId == PrimarySortedColumn)
	{
		return EColumnSortPriority::Primary;
	}

	if (ColumnId == SecondarySortedColumn)
	{
		return EColumnSortPriority::Secondary;
	}

	return EColumnSortPriority::Max; // No specific priority.
}

void SComboGraphBrowser::OnSortColumnHeader(const EColumnSortPriority::Type SortPriority, const FName& ColumnId, const EColumnSortMode::Type NewSortMode)
{
	if (SortPriority == EColumnSortPriority::Primary)
	{
		PrimarySortedColumn = ColumnId;
		PrimarySortMode = NewSortMode;

		if (ColumnId == SecondarySortedColumn) // Cannot be primary and secondary at the same time.
		{
			SecondarySortedColumn = FName();
			SecondarySortMode = EColumnSortMode::None;
		}
	}
	else if (SortPriority == EColumnSortPriority::Secondary)
	{
		SecondarySortedColumn = ColumnId;
		SecondarySortMode = NewSortMode;
	}

	SortSourceItems();

	ColumnView->RequestListRefresh();
}

FReply SComboGraphBrowser::OnDraggingAssetItem(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) const
{
	return FReply::Unhandled();
}

// ReSharper disable once CppPassValueParameterByConstReference
void SComboGraphBrowser::OnListMouseButtonClick(const TSharedPtr<FComboGraphBrowserItem> AssetItem) const
{
	if (AssetItem.IsValid())
	{
		OnListMouseClickDelegate.ExecuteIfBound(AssetItem->Data.Get());
	}
}

// ReSharper disable once CppPassValueParameterByConstReference
void SComboGraphBrowser::OnListMouseButtonDoubleClick(const TSharedPtr<FComboGraphBrowserItem> AssetItem) const
{
	if (AssetItem.IsValid())
	{
		OnListMouseDoubleClickDelegate.ExecuteIfBound(AssetItem->Data.Get());
	}
}

TSharedPtr<SWidget> SComboGraphBrowser::OnConstructItemContextMenu() const
{
	FMenuBuilder MenuBuilder(true, BrowserItemMenuCommands);

	MenuBuilder.BeginSection("BasicOperations", LOCTEXT("BasicOperationsHeader", "Combo Graph Data Actions"));
	{
		MenuBuilder.AddMenuEntry(FGenericCommands::Get().Delete);
		MenuBuilder.AddMenuEntry(FGenericCommands::Get().Duplicate);
		MenuBuilder.AddMenuEntry(FGenericCommands::Get().Rename);
	}
	MenuBuilder.EndSection();

	return MenuBuilder.MakeWidget();
}

void SComboGraphBrowser::SortSourceItems()
{
	auto Compare = [this](const TSharedPtr<FComboGraphBrowserItem>& Lhs, const TSharedPtr<FComboGraphBrowserItem>& Rhs, const FName& ColumnId, EColumnSortMode::Type SortMode)
	{
		const FString LhsData = Lhs->GetColumnData(ColumnId);
		const FString RhsData = Rhs->GetColumnData(ColumnId);

		const FComboGraphBrowserCustomColumn* FoundColumn = CustomColumns.FindByPredicate([ColumnId](const FComboGraphBrowserCustomColumn& Column)
		{
			return Column.ColumnName == ColumnId;
		});

		if (FoundColumn && FoundColumn->OnSortColumnData.IsBound())
		{
			return FoundColumn->OnSortColumnData.Execute(LhsData, RhsData, SortMode);
		}

		return SortMode == EColumnSortMode::Ascending ? LhsData < RhsData : LhsData > RhsData;
	};

	FilteredSourceItem.Sort([&](const TSharedPtr<FComboGraphBrowserItem>& Lhs, const TSharedPtr<FComboGraphBrowserItem>& Rhs)
	{
		if (Compare(Lhs, Rhs, PrimarySortedColumn, PrimarySortMode))
		{
			return true;
		}

		if (Compare(Rhs, Lhs, PrimarySortedColumn, PrimarySortMode))
		{
			return false;
		}

		return SecondarySortedColumn.IsNone() ? false : Compare(Lhs, Rhs, SecondarySortedColumn, SecondarySortMode);
	});
}

void SComboGraphBrowser::OnFilterTextChanged(const FText& InSearchText)
{
	SetSearchBoxText(InSearchText);
}

void SComboGraphBrowser::OnFilterTextCommitted(const FText& InSearchText, ETextCommit::Type CommitInfo)
{
	SetSearchBoxText(InSearchText);
}

void SComboGraphBrowser::SetSearchBoxText(const FText& InSearchText)
{
	SearchText = InSearchText;
	RebuildContent();
}

bool SComboGraphBrowser::IsDataMatched(const TSharedPtr<FComboGraphBrowserItem>& BrowserItem, const FText& InSearchText)
{
	// Filter category
	const FName CategoryColumnName = GET_MEMBER_NAME_CHECKED(UComboGraphData, Category);
	FString* FoundCategoryValue = BrowserItem.Get()->CachedCustomColumnData.Find(CategoryColumnName);
	if (!FoundCategoryValue)
	{
		return false;
	}

	if (FoundCategoryValue->IsEmpty())
	{
		*FoundCategoryValue = TDataArchiveOps<UComboGraphData>::DefaultCategory();
	}

	if (FoundCategoryValue && !GetDefault<UComboGraphBrowserLocalData>()->SelectedCategories.Contains(*FoundCategoryValue))
	{
		return false;
	}

	if (InSearchText.IsEmpty())
	{
		return true;
	}

	for (const TTuple<FName, FString>& Data : BrowserItem.Get()->CachedCustomColumnData)
	{
		if (Data.Value.Contains(InSearchText.ToString()))
		{
			return true;
		}
	}

	return false;
}

#undef LOCTEXT_NAMESPACE
