// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Graph/Slate/SComboGraphNodeEntry.h"
#include "Widgets/SBoxPanel.h"
#include "SGraphPin.h"
#include "Graph/Nodes/ComboGraphEdNodeEntry.h"
#include "Graph/Slate/SComboGraphConduitOutputPin.h"
#include "Widgets/Text/SInlineEditableTextBlock.h"

/////////////////////////////////////////////////////
// SComboGraphNodeEntry

void SComboGraphNodeEntry::Construct(const FArguments& InArgs, UComboGraphEdNodeEntry* InNode)
{
	GraphNode = InNode;

	SetCursor(EMouseCursor::CardinalCross);

	UpdateGraphNode();
}

void SComboGraphNodeEntry::GetNodeInfoPopups(FNodeInfoContext* Context, TArray<FGraphInformationPopupInfo>& Popups) const
{
}

void SComboGraphNodeEntry::UpdateGraphNode()
{
	InputPins.Empty();
	OutputPins.Empty();

	// Reset variables that are going to be exposed, in case we are refreshing an already setup node.
	RightNodeBox.Reset();
	LeftNodeBox.Reset();

	const FSlateBrush* NodeTypeIcon = GetNameIcon();
	constexpr FLinearColor TitleShadowColor(0.6f, 0.6f, 0.6f);

	TSharedPtr<SErrorText> ErrorText;
	const TSharedPtr<SNodeTitle> NodeTitle = SNew(SNodeTitle, GraphNode);

	ContentScale.Bind(this, &SGraphNode::GetContentScale);
	GetOrAddSlot(ENodeZone::Center)
		.HAlign(HAlign_Center)
		.VAlign(VAlign_Center)
		[
			SNew(SBorder)
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
			.BorderImage(FAppStyle::GetBrush("Graph.StateNode.Body"))
#else
			.BorderImage(FEditorStyle::GetBrush("Graph.StateNode.Body"))
#endif
			.Padding(0)
			.BorderBackgroundColor(this, &SComboGraphNodeEntry::GetBorderBackgroundColor)
			[
				SNew(SOverlay)

				// PIN AREA
				+ SOverlay::Slot()
				  .HAlign(HAlign_Fill)
				  .VAlign(VAlign_Fill)
				[
					SAssignNew(RightNodeBox, SVerticalBox)
				]

				// STATE NAME AREA
				+ SOverlay::Slot()
				  .HAlign(HAlign_Center)
				  .VAlign(VAlign_Center)
				  .Padding(10.0f)
				[
					SNew(SBorder)
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
					.BorderImage(FAppStyle::GetBrush("Graph.StateNode.ColorSpill"))
#else
					.BorderImage( FEditorStyle::GetBrush("Graph.StateNode.ColorSpill") )
#endif
					.BorderBackgroundColor(TitleShadowColor)
					.HAlign(HAlign_Center)
					.VAlign(VAlign_Center)
					.Visibility(EVisibility::SelfHitTestInvisible)
					[
						SNew(SHorizontalBox)
						+ SHorizontalBox::Slot()
						.AutoWidth()
						[
							// POPUP ERROR MESSAGE
							SAssignNew(ErrorText, SErrorText)
							.BackgroundColor(this, &SComboGraphNodeEntry::GetErrorColor)
							.ToolTipText(this, &SComboGraphNodeEntry::GetErrorMsgToolTip)
						]
						+ SHorizontalBox::Slot()
						  .AutoWidth()
						  .VAlign(VAlign_Center)
						[
							SNew(SImage)
							.Image(NodeTypeIcon)
						]
						+ SHorizontalBox::Slot()
						.Padding(FMargin(4.0f, 0.0f, 4.0f, 0.0f))
						[
							SNew(SVerticalBox)
							+ SVerticalBox::Slot()
							.AutoHeight()
							[
								SAssignNew(InlineEditableText, SInlineEditableTextBlock)
								.Style(FAppStyle::Get(), "Graph.StateNode.NodeTitleInlineEditableText")
								.Text(NodeTitle.Get(), &SNodeTitle::GetHeadTitle)
								.OnVerifyTextChanged(this, &SComboGraphNodeEntry::OnVerifyNameTextChanged)
								.OnTextCommitted(this, &SComboGraphNodeEntry::OnNameTextCommited)
								.IsReadOnly(this, &SComboGraphNodeEntry::IsNameReadOnly)
								.IsSelected(this, &SComboGraphNodeEntry::IsSelectedExclusively)
							]
							+ SVerticalBox::Slot()
							.AutoHeight()
							[
								NodeTitle.ToSharedRef()
							]
						]
					]
				]
			]
		];

	ErrorReporting = ErrorText;
	ErrorReporting->SetError(ErrorMsg);
	CreatePinWidgets();
}

void SComboGraphNodeEntry::CreatePinWidgets()
{
	const UComboGraphEdNodeEntry* EntryNode = CastChecked<UComboGraphEdNodeEntry>(GraphNode);

	UEdGraphPin* CurPin = EntryNode->GetOutputPin();
	if (!CurPin->bHidden)
	{
		const TSharedPtr<SGraphPin> NewPin = SNew(SComboGraphConduitOutputPin, CurPin);
		AddPin(NewPin.ToSharedRef());
	}
}

void SComboGraphNodeEntry::AddPin(const TSharedRef<SGraphPin>& PinToAdd)
{
	PinToAdd->SetOwner(SharedThis(this));
	RightNodeBox->AddSlot()
	            .HAlign(HAlign_Fill)
	            .VAlign(VAlign_Fill)
	            .FillHeight(1.0f)
	[
		PinToAdd
	];
	OutputPins.Add(PinToAdd);
}

// ReSharper disable once CppMemberFunctionMayBeStatic
FSlateColor SComboGraphNodeEntry::GetBorderBackgroundColor() const
{
	return FLinearColor(0.08f, 0.08f, 0.08f);
}

// ReSharper disable once CppMemberFunctionMayBeStatic
const FSlateBrush* SComboGraphNodeEntry::GetNameIcon() const
{
#if ENGINE_MAJOR_VERSION == 5 && ENGINE_MINOR_VERSION >= 1
	return FAppStyle::GetBrush(TEXT("Graph.ConduitNode.Icon"));
#else
	return FEditorStyle::GetBrush( TEXT("Graph.ConduitNode.Icon") );
#endif
}
