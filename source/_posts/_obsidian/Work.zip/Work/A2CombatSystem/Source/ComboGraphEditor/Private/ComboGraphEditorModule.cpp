// Copyright 2022 Mickael Daniel. All Rights Reserved.

#include "ComboGraphEditorModule.h"

#include "ComboGraphEditorLog.h"
#include "AssetEditor/ComboGraphAssetEditor.h"
#include "ComboGraphEditorStyle.h"
#include "WorkspaceMenuStructure.h"
#include "WorkspaceMenuStructureModule.h"
#include "Editors/SComboGraphBrowser.h"
#include "Graph/ComboGraphEdGraph.h"
#include "Graph/Factories/ComboGraphPanelNodeFactory.h"

#define LOCTEXT_NAMESPACE "ComboGraphEditorModule"

FName FComboGraphEditorModule::ComboGraphBrowserTabName = TEXT("ComboGraphBrowser");

static FAutoConsoleCommand CCmdOpenGraphBrowser = FAutoConsoleCommand(
	TEXT("cg.OpenGraphBrowser"),
	TEXT("Bring up Combo Graph Browser Tab"),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		FGlobalTabmanager::Get()->TryInvokeTab(FComboGraphEditorModule::ComboGraphBrowserTabName);
	}));

void FComboGraphEditorCommands::RegisterCommands()
{
	UI_COMMAND(OpenEditorWindow, "ComboGraphEditor", "Bring Up ComboGraphBrowser Window", EUserInterfaceActionType::Button, FInputChord());
}

void FComboGraphEditorModule::StartupModule()
{
	CG_EDITOR_LOG(Verbose, TEXT("ComboGraphEditorModule - Startup Module"))

	// Init Commands
	FComboGraphEditorCommands::Register();
	FComboGraphBrowserCommands::Register();

	// Init style
	FComboGraphEditorStyle::Initialize();
	FComboGraphEditorStyle::ReloadTextures();

	// Load editor data
	FDataArchiveManager::Load<UComboGraphEdGraphData>();

	RegisterEntry();
	RegisterFactories();

	MenuExtensibilityManager = MakeShared<FExtensibilityManager>();
}

void FComboGraphEditorModule::ShutdownModule()
{
	// Unregister Commands
	FComboGraphEditorCommands::Unregister();
	FComboGraphBrowserCommands::Unregister();

	// Unregister style
	FComboGraphEditorStyle::Shutdown();

	UnregisterEntry();
	UnregisterFactories();
}

void FComboGraphEditorModule::RegisterEntry()
{
	FGlobalTabmanager::Get()
		->RegisterNomadTabSpawner(ComboGraphBrowserTabName, FOnSpawnTab::CreateRaw(this, &FComboGraphEditorModule::OnSpawnComboGraphBrowserTab))
		.SetDisplayName(LOCTEXT("ComboGraphEditorTitle", "Combo Graph Browser"))
		.SetTooltipText(LOCTEXT("ComboGraphEditorTooltip", "Opend the Combo Graph Browser Tab"))
		.SetGroup(WorkspaceMenu::GetMenuStructure().GetToolsCategory())
		.SetIcon(FSlateIcon(FComboGraphEditorStyle::GetStyleSetName(), "EntryIcon.ComboGraphBrowser"));
}

void FComboGraphEditorModule::UnregisterEntry()
{
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(ComboGraphBrowserTabName);
}

void FComboGraphEditorModule::RegisterFactories()
{
	GraphNodeFactory = MakeShared<FComboGraphNodeFactory>();
	FEdGraphUtilities::RegisterVisualNodeFactory(GraphNodeFactory);
}

void FComboGraphEditorModule::UnregisterFactories()
{
	FEdGraphUtilities::UnregisterVisualNodeFactory(GraphNodeFactory);
	GraphNodeFactory = nullptr;
}

TSharedRef<SDockTab> FComboGraphEditorModule::OnSpawnComboGraphBrowserTab(const FSpawnTabArgs& SpawnTabArgs)
{
	return SNew(SDockTab)
		.TabRole(NomadTab)
		[
			SNew(SComboGraphBrowser)
			.OnComboGraphDoubleClick_Raw(this, &FComboGraphEditorModule::OnComboGraphDoubleClick)
		];
}

void FComboGraphEditorModule::OnComboGraphDoubleClick(UComboGraphData* Graph)
{
	CG_EDITOR_LOG(Verbose, TEXT("Combo Graph OpenAssetEditor ... %s"), *GetNameSafe(Graph))

	if (::IsValid(Graph))
	{
		const TSharedRef<FComboGraphAssetEditor> AssetEditor = MakeShared<FComboGraphAssetEditor>();
		AssetEditor->InitComboGraphEditor(EToolkitMode::Standalone, nullptr, Graph);
	}
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FComboGraphEditorModule, ComboGraphEditor)
