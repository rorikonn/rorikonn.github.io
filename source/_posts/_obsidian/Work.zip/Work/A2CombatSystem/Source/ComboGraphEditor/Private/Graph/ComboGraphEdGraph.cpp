// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Graph/ComboGraphEdGraph.h"

#include "ComboGraphEditorTypes.h"
#include "ComboGraphEditorLog.h"
#include "SGraphNode.h"
#include "SGraphPanel.h"
#include "Graph/ComboGraph.h"
#include "Graph/ComboGraphEdge.h"
#include "Graph/ComboGraphNodeBase.h"
#include "Graph/ComboGraphNode.h"
#include "Graph/ComboGraphSchema.h"
#include "Graph/Nodes/ComboGraphEdNode.h"
#include "Graph/Nodes/ComboGraphEdNodeConduit.h"
#include "Graph/Nodes/ComboGraphEdNodeEdge.h"
#include "Graph/Nodes/ComboGraphEdNodeEntry.h"

UComboGraphData* UComboGraphEdGraph::GetComboGraphModel() const
{
	return CastChecked<UComboGraphData>(GetOuter());
}

void UComboGraphEdGraph::RestoreFromEdGraphData(const UComboGraphEdGraphData* EdGraphData)
{
	const UComboGraphData* ComboGraphModel = GetComboGraphModel();
	check(ComboGraphModel)

	TMap<FComboGraphNodeID, UComboGraphEdNodeBase*> NodesMap;

	TArray<UComboGraphEdNodeEntry*> Entries;
	GetNodesOfClass(Entries);
	check(Entries.Num() == 1);

	NodesMap.Add(FComboGraphNodeID(ComboGraphModel->ID, 0), Entries[0]);

	for (const UComboGraphEdNodeData* NodeData : EdGraphData->Nodes)
	{
		UComboGraphNodeData* RuntimeNode = Cast<UComboGraphNodeData>(FDataArchiveManager::Find<UComboGraphNodeDataBase>(NodeData->NodeID));
		if (!RuntimeNode)
		{
			continue;
		}

		CG_EDITOR_LOG(Verbose, TEXT("RestoreNodeFormData - NewNodeClass: %s, NodeID: %s"), *GetNameSafe(NodeData->NodeClass), *NodeData->NodeID.ToString());
		FComboGraphSchemaAction_NewNode Action;
		Action.NodeTemplate = NewObject<UComboGraphEdNode>(this, NodeData->NodeClass);
		Action.NodeTemplate->RuntimeNode = RuntimeNode;

		UComboGraphEdNodeBase* NewNode = Cast<UComboGraphEdNodeBase>(Action.PerformAction(this, nullptr, NodeData->Position));
		if (IsValid(NewNode))
		{
			NodesMap.Add(NodeData->NodeID, NewNode);
		}
	}

	for (const UComboGraphEdNodeEdgeData* EdgeData : EdGraphData->Edges)
	{
		CG_EDITOR_LOG(Verbose, TEXT("RestoreEdgeFormData - From %s To %s"), *EdgeData->FromNodeID.ToString(), *EdgeData->ToNodeID.ToString());

		const UComboGraphNodeDataBase* FromNode = FDataArchiveManager::Find<UComboGraphNodeDataBase>(EdgeData->FromNodeID);
		const UComboGraphNodeDataBase* ToNode = FDataArchiveManager::Find<UComboGraphNodeDataBase>(EdgeData->ToNodeID);
		if (!IsValid(FromNode) || !IsValid(ToNode))
		{
			FString FailReason;
			if (!FromNode)
			{
				FailReason += FString::Printf(TEXT("FromNode %s"), *EdgeData->FromNodeID.ToString());
				if (!ToNode)
				{
					FailReason += TEXT(" And ");
				}
			}

			if (!ToNode)
			{
				FailReason += FString::Printf(TEXT("To %s"), *EdgeData->ToNodeID.ToString());
			}

			CG_EDITOR_LOG(Warning, TEXT("RestoreEdgeFormData - Failed to find %s"), *FailReason);
			continue;
		}

		UComboGraphEdNodeBase** FromEdNode = NodesMap.Find(EdgeData->FromNodeID);
		UComboGraphEdNodeBase** ToEdNode = NodesMap.Find(EdgeData->ToNodeID);
		if (!FromEdNode || !ToEdNode)
		{
			CG_EDITOR_LOG(Warning, TEXT("RestoreEdgeFormData - Failed to find Restored EdNode"));
		}

		UComboGraphEdge* RuntimeEdge = FromNode->GetEdge(EdgeData->ToNodeID);
		if (!RuntimeEdge)
		{
			CG_EDITOR_LOG(Warning, TEXT("RestoreEdgeFormData - Failed to find Edge From %s To %s"), *EdgeData->FromNodeID.ToString(), *EdgeData->ToNodeID.ToString());
			continue;
		}

		FComboGraphSchemaAction_NewEdge Action;
		Action.NodeTemplate = NewObject<UComboGraphEdNodeEdge>(this);
		Action.NodeTemplate->SetRuntimeEdge(RuntimeEdge);
		UComboGraphEdNodeEdge* NewEdge = Cast<UComboGraphEdNodeEdge>(Action.PerformAction(this, nullptr, EdgeData->Position, false));
		if (IsValid(NewEdge))
		{
			// Always create connections from node A to B, don't allow adding in reverse
			NewEdge->CreateConnections(*FromEdNode, *ToEdNode);
		}
	}
}

void UComboGraphEdGraph::RebuildGraph()
{
	CG_EDITOR_LOG(Verbose, TEXT("UComboGraphEdGraph::RebuildGraph has been called. Nodes Num: %d"), Nodes.Num())

	UComboGraphData* ComboGraphModel = GetComboGraphModel();
	check(ComboGraphModel)

	Clear();

	// 刷新节点ID, 入口节点Index始终为0, 其他节点从1开始顺排
	// 已经存在的节点会保持自己的ID不变, 新加的节点优先使用被删除的ID, 没有的话就从最后一个ID开始往后排
	// 所以我们先需要遍历所有节点, 把已被使用的和原来被使用现在没在用的ID找出来

	// 1. 遍历所有节点, 标记所有被使用了的ID
	TArray<bool> NodeIndexUsages;
	for (UEdGraphNode* CurrentNode : Nodes)
	{
		int32 NodeIndex = 0;
		if (const UComboGraphEdNodeEntry* GraphEntry = Cast<UComboGraphEdNodeEntry>(CurrentNode))
		{
			NodeIndex = GraphEntry->ID.ID;
		}
		else if (const UComboGraphEdNode* GraphNode = Cast<UComboGraphEdNode>(CurrentNode))
		{
			NodeIndex = GraphNode->ID.ID;
		}

		// 新节点在这里的Index还是0, 走下面的逻辑会把0这个ID标记为已被使用, 反正0是预留给入口用的, 所以也不用过滤这种case了
		if (!NodeIndexUsages.IsValidIndex(NodeIndex))
		{
			NodeIndexUsages.SetNumZeroed(NodeIndex + 1);
		}

		NodeIndexUsages[NodeIndex] = true;
	}

	// 2. 找到所有被删除了的ID, 新节点会优先使用掉这些ID
	TArray IdlingIndex = {NodeIndexUsages.Num()};
	for (int32 Index = NodeIndexUsages.Num() - 1; Index >= 0; --Index)
	{
		if (!NodeIndexUsages[Index])
		{
			IdlingIndex.Push(Index);
		}
	}

	// 3. 给新节点标记ID
	for (UEdGraphNode* CurrentNode : Nodes)
	{
		if (UComboGraphEdNodeEntry* GraphEntryNode = Cast<UComboGraphEdNodeEntry>(CurrentNode))
		{
			GraphEntryNode->ID = FComboGraphNodeID(ComboGraphModel->ID, 0);
		}
		else if (UComboGraphEdNode* GraphNode = Cast<UComboGraphEdNode>(CurrentNode))
		{
			GraphNode->ID.Owner = ComboGraphModel->ID;
			if (GraphNode->ID.ID == 0)
			{
				GraphNode->ID.ID = IdlingIndex.Pop();
				if (IdlingIndex.IsEmpty())
				{
					IdlingIndex.Push(GraphNode->ID.ID + 1);
				}
			}
		}
	}

	// 4. 重构ComboGraph, 每个节点处理自己以及自己的子节点链接
	for (UEdGraphNode* CurrentNode : Nodes)
	{
		CG_EDITOR_LOG(Verbose, TEXT("UComboGraphEdGraph::RebuildGraph for node: %s (%s)"), *CurrentNode->GetName(), *CurrentNode->GetClass()->GetName());

		if (UComboGraphEdNodeBase* GraphNode = Cast<UComboGraphEdNodeBase>(CurrentNode))
		{
			GraphNode->RebuildGraph(this, ComboGraphModel);
		}
	}

	TArray<int32> InvalidNodeIndex;
	for (int32 Index = ComboGraphModel->AllNodes.Num() - 1; Index >= 0; --Index)
	{
		FComboGraphNodeReference& Node = ComboGraphModel->AllNodes[Index];
		if (!Node)
		{
			InvalidNodeIndex.Add(Index);
			continue;
		}

		Node->Rename(nullptr, ComboGraphModel, REN_DontCreateRedirectors | REN_DoNotDirty);
	}

	// 移除所有无效的Node数据
	for (const int32 Index : InvalidNodeIndex)
	{
		ComboGraphModel->AllNodes.RemoveAtSwap(Index);
	}

	// 5. 导出编辑器数据
	UComboGraphEdGraphData* EdGraphData = FDataArchiveManager::FindOrAdd<UComboGraphEdGraphData>(ComboGraphModel->ID);
	check(EdGraphData);

	EdGraphData->GraphID = ComboGraphModel->ID;

	TArray<UComboGraphEdNodeEdge*> AllEdges;

	EdGraphData->Nodes.Empty();
	EdGraphData->Edges.Empty();
	for (UEdGraphNode* CurrentNode : Nodes)
	{
		if (const UComboGraphEdNode* GraphNode = Cast<UComboGraphEdNode>(CurrentNode))
		{
			UComboGraphEdNodeData* EdNodeData = NewObject<UComboGraphEdNodeData>(EdGraphData);
			EdNodeData->NodeID = GraphNode->ID;
			EdNodeData->NodeClass = GraphNode->GetClass();
			EdNodeData->Position = FVector2D(CurrentNode->NodePosX, CurrentNode->NodePosY);
			EdGraphData->Nodes.Add(EdNodeData);
		}
		else if (const UComboGraphEdNodeEdge* EdgeNode = Cast<UComboGraphEdNodeEdge>(CurrentNode))
		{
			if (!EdgeNode->RuntimeEdge || !EdgeNode->RuntimeEdge->StartNode || !EdgeNode->RuntimeEdge->EndNode)
			{
				continue;
			}

			UComboGraphEdNodeEdgeData* EdNodeEdgeData = NewObject<UComboGraphEdNodeEdgeData>(EdGraphData);
			EdNodeEdgeData->FromNodeID = EdgeNode->RuntimeEdge->StartNode->ID;
			EdNodeEdgeData->ToNodeID = EdgeNode->RuntimeEdge->EndNode->ID;
			EdNodeEdgeData->Position = FVector2D(CurrentNode->NodePosX, CurrentNode->NodePosY);
			EdGraphData->Edges.Add(EdNodeEdgeData);
		}
	}
}

void UComboGraphEdGraph::ResolveGraphNodeConnections(UComboGraphNodeDataBase* RuntimeNode, UComboGraphEdNodeBase* NodeBase)
{
	for (UEdGraphPin* Pin : NodeBase->Pins)
	{
		if (Pin->Direction != EGPD_Output)
		{
			continue;
		}

		for (const UEdGraphPin* LinkedTo : Pin->LinkedTo)
		{
			UComboGraphNodeDataBase* ChildNode = nullptr;

			// Try to determine child node
			if (const UComboGraphEdNode* OwningNode = Cast<UComboGraphEdNode>(LinkedTo->GetOwningNode()))
			{
				ChildNode = OwningNode->RuntimeNode;
			}
			else if (const UComboGraphEdNodeEdge* OwningEdge = Cast<UComboGraphEdNodeEdge>(LinkedTo->GetOwningNode()))
			{
				if (const UComboGraphEdNode* EndNode = OwningEdge->GetEndNode())
				{
					ChildNode = EndNode->RuntimeNode;
				}
			}

			// Update child / parent nodes for both node and containing ability graph
			if (ChildNode)
			{
				RuntimeNode->ChildrenNodes.Add(FComboGraphNodeReference(ChildNode));
				ChildNode->ParentNodes.Add(RuntimeNode);
			}
		}
	}
}

void UComboGraphEdGraph::SaveGraph()
{
	FDataArchiveManager::Save<UComboGraphNodeDataBase>();
}

void UComboGraphEdGraph::ValidateNodes(FCompilerResultsLog* LogResults)
{
	for (const UEdGraphNode* Node : Nodes)
	{
		Node->ValidateNodeDuringCompilation(*LogResults);
	}
}

bool UComboGraphEdGraph::Modify(const bool bAlwaysMarkDirty)
{
	const bool bWasSaved = Super::Modify(bAlwaysMarkDirty);

	UComboGraphData* ComboGraphModel = GetComboGraphModel();
	if (ComboGraphModel)
	{
		ComboGraphModel->Modify();
	}

	for (UEdGraphNode* Node : Nodes)
	{
		Node->Modify();
	}

	return bWasSaved;
}

void UComboGraphEdGraph::PostEditUndo()
{
	Super::PostEditUndo();

	NotifyGraphChanged();
}

TArray<UComboGraphEdNode*> UComboGraphEdGraph::GetAllNodes() const
{
	TArray<UComboGraphEdNode*> OutNodes;
	for (UEdGraphNode* EdNode : Nodes)
	{
		if (UComboGraphEdNode* Node = Cast<UComboGraphEdNode>(EdNode))
		{
			OutNodes.Add(Node);
		}
	}

	return OutNodes;
}

namespace ACEAutoArrangeHelpers
{
	struct FNodeBoundsInfo
	{
		FVector2D SubGraphBBox;
		TArray<FNodeBoundsInfo> Children;
	};

	UEdGraphPin* FindGraphNodePin(UEdGraphNode* Node, const EEdGraphPinDirection Dir)
	{
		UEdGraphPin* Pin = nullptr;
		for (int32 Idx = 0; Idx < Node->Pins.Num(); Idx++)
		{
			if (Node->Pins[Idx]->Direction == Dir)
			{
				Pin = Node->Pins[Idx];
				break;
			}
		}

		return Pin;
	}

	void AutoArrangeNodesVertically(UComboGraphEdNodeBase* ParentNode, FNodeBoundsInfo& BBoxTree, float PosX, float PosY)
	{
		int32 BBoxIndex = 0;

		if (const UEdGraphPin* Pin = FindGraphNodePin(ParentNode, EGPD_Output))
		{
			SGraphNode::FNodeSet NodeFilter;
			TArray<UEdGraphPin*> TempLinkedTo = Pin->LinkedTo;
			for (int32 Idx = 0; Idx < TempLinkedTo.Num(); Idx++)
			{
				UComboGraphEdNodeBase* GraphNode = Cast<UComboGraphEdNodeBase>(TempLinkedTo[Idx]->GetOwningNode());
				if (GraphNode && BBoxTree.Children.Num() > 0)
				{
					AutoArrangeNodesVertically(GraphNode, BBoxTree.Children[BBoxIndex], PosX, PosY + GraphNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().Y * 2.5f);
					GraphNode->DEPRECATED_NodeWidget.Pin()->MoveTo(FVector2D(BBoxTree.Children[BBoxIndex].SubGraphBBox.X / 2 - GraphNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().X / 2 + PosX, PosY), NodeFilter);
					PosX += BBoxTree.Children[BBoxIndex].SubGraphBBox.X + 20;
					BBoxIndex++;
				}
			}
		}
	}

	void AutoArrangeNodesHorizontally(UComboGraphEdNodeBase* ParentNode, FNodeBoundsInfo& BBoxTree, float PosX, float PosY)
	{
		int32 BBoxIndex = 0;

		if (const UEdGraphPin* Pin = FindGraphNodePin(ParentNode, EGPD_Output))
		{
			SGraphNode::FNodeSet NodeFilter;
			TArray<UEdGraphPin*> TempLinkedTo = Pin->LinkedTo;
			for (int32 Idx = 0; Idx < TempLinkedTo.Num(); Idx++)
			{
				UComboGraphEdNodeBase* GraphNode = Cast<UComboGraphEdNodeBase>(TempLinkedTo[Idx]->GetOwningNode());
				if (GraphNode && BBoxTree.Children.Num() > 0)
				{
					// AutoArrangeNodesVertically(GraphNode, BBoxTree.Children[BBoxIndex], PosX, PosY + GraphNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().Y * 2.5f);
					AutoArrangeNodesHorizontally(GraphNode, BBoxTree.Children[BBoxIndex], PosX + GraphNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().X * 2.5f, PosY);

					// GraphNode->DEPRECATED_NodeWidget.Pin()->MoveTo(FVector2D(BBoxTree.Children[BBoxIndex].SubGraphBBox.X / 2 - GraphNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().X / 2 + PosX, PosY), NodeFilter);
					GraphNode->DEPRECATED_NodeWidget.Pin()->MoveTo(FVector2D(PosX, BBoxTree.Children[BBoxIndex].SubGraphBBox.Y / 2 - GraphNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().Y / 2 + PosY), NodeFilter);

					// PosX += BBoxTree.Children[BBoxIndex].SubGraphBBox.X + 20;
					PosY += BBoxTree.Children[BBoxIndex].SubGraphBBox.Y + 20;
					BBoxIndex++;
				}
			}
		}
	}

	void GetNodeSizeInfo(UComboGraphEdNodeBase* ParentNode, FNodeBoundsInfo& BBoxTree, TArray<UComboGraphEdNodeBase*>& VisitedNodes)
	{
		BBoxTree.SubGraphBBox = ParentNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize();
		float LevelWidth = 0;
		float LevelHeight = 0;

		UEdGraphPin* Pin = FindGraphNodePin(ParentNode, EGPD_Output);
		if (Pin)
		{
			Pin->LinkedTo.Sort(FComboGraphCompareNodeXLocation());
			for (int32 Idx = 0; Idx < Pin->LinkedTo.Num(); Idx++)
			{
				UComboGraphEdNodeBase* GraphNode = Cast<UComboGraphEdNodeBase>(Pin->LinkedTo[Idx]->GetOwningNode());
				if (GraphNode)
				{
					const int32 ChildIdx = BBoxTree.Children.Add(FNodeBoundsInfo());
					FNodeBoundsInfo& ChildBounds = BBoxTree.Children[ChildIdx];

					if (!VisitedNodes.Contains(GraphNode))
					{
						VisitedNodes.AddUnique(GraphNode);
						GetNodeSizeInfo(GraphNode, ChildBounds, VisitedNodes);
					}

					LevelWidth += ChildBounds.SubGraphBBox.X + 20;
					if (ChildBounds.SubGraphBBox.Y > LevelHeight)
					{
						LevelHeight = ChildBounds.SubGraphBBox.Y;
					}
				}
			}

			if (LevelWidth > BBoxTree.SubGraphBBox.X)
			{
				BBoxTree.SubGraphBBox.X = LevelWidth;
			}

			BBoxTree.SubGraphBBox.Y += LevelHeight;
		}
	}
}


void UComboGraphEdGraph::AutoArrange(const bool bVertical)
{
	UComboGraphEdNodeBase* RootNode = nullptr;
	for (int32 Idx = 0; Idx < Nodes.Num(); Idx++)
	{
		RootNode = Cast<UComboGraphEdNodeEntry>(Nodes[Idx]);
		if (RootNode)
		{
			break;
		}
	}

	if (!RootNode)
	{
		return;
	}

	CG_EDITOR_LOG(Verbose, TEXT("UComboGraphEdGraph::AutoArrange Strategy: %s"), bVertical ? TEXT("Vertical") : TEXT("Horizontal"))
	const FScopedTransaction Transaction(NSLOCTEXT("ACEGraph", "ComboGraphEditorAutoArrange", "Combo Graph Editor: Auto Arrange"));

	ACEAutoArrangeHelpers::FNodeBoundsInfo BBoxTree;
	TArray<UComboGraphEdNodeBase*> VisitedNodes;
	ACEAutoArrangeHelpers::GetNodeSizeInfo(RootNode, BBoxTree, VisitedNodes);

	SGraphNode::FNodeSet NodeFilter;
	if (bVertical)
	{
		ACEAutoArrangeHelpers::AutoArrangeNodesVertically(RootNode, BBoxTree, 0, RootNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().Y * 2.5f);

		const float NewRootPosX = BBoxTree.SubGraphBBox.X / 2 - RootNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().X / 2;
		RootNode->DEPRECATED_NodeWidget.Pin()->MoveTo(FVector2D(NewRootPosX, 0), NodeFilter);
	}
	else
	{
		ACEAutoArrangeHelpers::AutoArrangeNodesHorizontally(RootNode, BBoxTree, RootNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().X * 2.5f, 0);

		const float NewRootPosY = BBoxTree.SubGraphBBox.Y / 2 - RootNode->DEPRECATED_NodeWidget.Pin()->GetDesiredSize().Y / 2;
		RootNode->DEPRECATED_NodeWidget.Pin()->MoveTo(FVector2D(0, NewRootPosY), NodeFilter);
	}

	RootNode->DEPRECATED_NodeWidget.Pin()->GetOwnerPanel()->ZoomToFit(/*bOnlySelection=*/ false);
}

void UComboGraphEdGraph::Clear()
{
	UComboGraphData* ComboGraphModel = GetComboGraphModel();
	if (ComboGraphModel)
	{
		ComboGraphModel->ClearGraph();
	}

	for (UEdGraphNode* Node : Nodes)
	{
		if (const UComboGraphEdNode* EdGraphNode = Cast<UComboGraphEdNode>(Node))
		{
			UComboGraphNodeDataBase* GraphNode = EdGraphNode->RuntimeNode;
			if (GraphNode)
			{
				GraphNode->ParentNodes.Reset();
				GraphNode->ChildrenNodes.Reset();
				GraphNode->Edges.Reset();
			}
		}
	}
}
