// Copyright 2022 Mickael Daniel. All Rights Reserved.


#include "Graph/Nodes/ComboGraphEdNodeEntry.h"

#include "ComboGraphEditorTypes.h"
#include "Graph/ComboGraphEdGraph.h"
#include "Graph/ComboGraphNodeEntry.h"

#define LOCTEXT_NAMESPACE "ComboGraphEdNodeEntry"

UComboGraphEdNodeEntry::UComboGraphEdNodeEntry()
{
	bCanRenameNode = false;
}

UComboGraphNodeDataBase* UComboGraphEdNodeEntry::GetRuntimeNode() const
{
	return RuntimeNode;
}

void UComboGraphEdNodeEntry::RebuildGraph(UComboGraphEdGraph* EdGraph, UComboGraphData* Graph)
{
	check(EdGraph);
	check(Graph);
	check(RuntimeNode);
	
	RuntimeNode->ID = ID;

	Graph->EntryNode = RuntimeNode;
	Graph->AllNodes.Add(RuntimeNode.Get());

	UComboGraphEdGraph::ResolveGraphNodeConnections(RuntimeNode, this);
	
	Super::RebuildGraph(EdGraph, Graph);
	
	FDataArchiveManager::Update<UComboGraphNodeDataBase>(RuntimeNode);
}

void UComboGraphEdNodeEntry::AllocateDefaultPins()
{
	CreatePin(EGPD_Output, UComboGraphPinNames::PinCategory_EntryOut, TEXT("Entry"));
}

FText UComboGraphEdNodeEntry::GetNodeTitle(ENodeTitleType::Type TitleType) const
{
	return LOCTEXT("GraphEntryNodeTitle", "Entry");
}

FText UComboGraphEdNodeEntry::GetTooltipText() const
{
	return LOCTEXT("StateEntryNodeTooltip", "Entry point for state machine");
}

#undef LOCTEXT_NAMESPACE
