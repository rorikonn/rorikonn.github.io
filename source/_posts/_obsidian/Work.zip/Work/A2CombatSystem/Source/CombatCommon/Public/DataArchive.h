﻿// 

#pragma once

#include "CoreMinimal.h"
#include "JsonObjectConverter.h"
#include "Interfaces/IPluginManager.h"

class COMBATCOMMON_API FDataArchiveItem
{
public:
	FDataArchiveItem();
	FDataArchiveItem(const TSharedPtr<FJsonValue>& InValue);
	virtual ~FDataArchiveItem();

	virtual bool UStructToArchive(const UStruct* StructDefinition, const void* Struct);
	virtual UObject* ArchiveToUStruct();
	virtual bool AppendTo(UObject*& OutObject);

protected:
	TSharedPtr<FJsonObject> InnerJsonObject;

public:
	operator TSharedPtr<FJsonValueObject>() const;

	template <typename T>
	friend typename TEnableIf<TIsDerivedFrom<T, UObject>::Value, FDataArchiveItem&>::Type operator<<(FDataArchiveItem& ArchiveItem, const T* InObject)
	{
		if (IsValid(InObject))
		{
			ArchiveItem.UStructToArchive(InObject->GetClass(), InObject);
		}

		return ArchiveItem;
	}

	template <typename T>
	friend typename TEnableIf<TIsDerivedFrom<T, UObject>::Value, FDataArchiveItem&>::Type operator>>(FDataArchiveItem& ArchiveItem, T*& OutObject)
	{
		OutObject = Cast<T>(ArchiveItem.ArchiveToUStruct());
		return ArchiveItem;
	}

	template <typename OutDataType>
	bool AppendTo(OutDataType*& OutData)
	{
		const FString ClassName = InnerJsonObject->GetStringField(ObjectClassNameKey);

		if (const UClass* DataClass = FindObject<UClass>(nullptr, *ClassName))
		{
			if (OutData && OutData->GetClass() == DataClass)
			{
				return FJsonObjectConverter::JsonObjectToUStruct(InnerJsonObject.ToSharedRef(), DataClass, OutData);
			}
		}

		return false;
	}

	static const FString ObjectClassNameKey;
};

class COMBATCOMMON_API FDataArchive
{
public:
	inline static const FString ArchiveFileExtension = FString(TEXT(".archive"));

	virtual ~FDataArchive() = default;

	void Empty();

	virtual bool LoadFromFile(FString InPath);
	virtual bool SaveToFile(FString InPath, bool bDoCheckOut = true);
	static bool DeleteFile(const FString& InPath, bool bDoCheckOut = true);

	virtual TSharedPtr<FDataArchiveItem> AllocArchiveItem();

	virtual void PushItem(TSharedPtr<FDataArchiveItem> InArchiveItem);
	virtual TSharedPtr<FDataArchiveItem> PopItem();

protected:
	TArray<TSharedPtr<FDataArchiveItem>> ArchiveItems;

public:
	friend bool operator<<(FDataArchive& Archive, const FString& NamePath);

	friend bool operator>>(const FDataArchive& Archive, const FString& NamePath);

	template <typename T>
	friend typename TEnableIf<TIsDerivedFrom<T, UObject>::Value, FDataArchive&>::Type operator<<(FDataArchive& Archive, const T* InObject)
	{
		if (const TSharedPtr<FDataArchiveItem> ArchiveItem = Archive.AllocArchiveItem())
		{
			*ArchiveItem << InObject;
			Archive.PushItem(ArchiveItem);
		}

		return Archive;
	}

	template <typename T>
	friend typename TEnableIf<TIsDerivedFrom<T, UObject>::Value, FDataArchive&>::Type operator<<(FDataArchive& Archive, const TArray<T*>& InObjectArray)
	{
		for (T* InObject : InObjectArray)
		{
			Archive << static_cast<UObject*>(InObject);
		}

		return Archive;
	}

	template <typename T>
	friend typename TEnableIf<TIsDerivedFrom<T, UObject>::Value, FDataArchive&>::Type operator>>(FDataArchive& Archive, T*& OutObject)
	{
		if (const TSharedPtr<FDataArchiveItem> ArchiveItem = Archive.PopItem())
		{
			*ArchiveItem >> OutObject;
		}

		return Archive;
	}

	template <typename T>
	friend typename TEnableIf<TIsDerivedFrom<T, UObject>::Value, FDataArchive&>::Type operator>>(FDataArchive& Archive, TArray<T*>& OutObjectArray)
	{
		while (const TSharedPtr<FDataArchiveItem> ArchiveItem = Archive.PopItem())
		{
			T* OutObject;
			*ArchiveItem >> OutObject;
			if (::IsValid(OutObject))
			{
				OutObjectArray.Add(OutObject);
			}
		}

		return Archive;
	}
};

template <typename T>
struct TDataArchiveInfoBase
{
	static int32& GetKeyFromData(...)
	{
		static int32 DummyKey = 0;
		return DummyKey;
	}
};

template <typename T>
struct TDataArchiveInfo : TDataArchiveInfoBase<T>
{
};

template <typename T>
struct TDataArchiveOps
{
private:
	using GetKeyRetType = decltype(TDataArchiveInfo<T>::GetKeyFromData(std::declval<T*>()));
	static_assert(TAnd<TIsReferenceType<GetKeyRetType>, TNot<TIsConst<GetKeyRetType>>>::Value, "GetKeyFromData implementation should return non-const key reference");

public:
	using KeyType = typename TRemoveReference<GetKeyRetType>::Type;

	static KeyType& GetKeyFromData(T* Data)
	{
		return TDataArchiveInfo<T>::GetKeyFromData(Data);
	}

	template <typename TInfo = TDataArchiveInfo<T>>
	static typename TEnableIf<TIsSame<decltype(TInfo::GetArchiveTableName()), FString>::Value, FString>::Type GetArchiveTableName(int32)
	{
		return TInfo::GetArchiveTableName();
	}

	static FString GetArchiveTableName(...)
	{
		return DefaultTableName();
	}

	template <typename TInfo = TDataArchiveInfo<T>>
	static typename TEnableIf<TIsSame<decltype(TInfo::GetArchiveCategory(std::declval<T*>())), FString>::Value, FString>::Type GetArchiveCategory(const T* Data)
	{
		return TInfo::GetArchiveCategory(Data);
	}

	static FString GetArchiveCategory(...)
	{
		return DefaultCategory();
	}

	template <typename TInfo = TDataArchiveInfo<T>>
	static void ExecutePostLoad(T* Data, decltype(TInfo::PostLoadData(std::declval<T*>()))* = nullptr)
	{
		return TInfo::OnPostLoadData(Data);
	}

	static void ExecutePostLoad(...)
	{
	}

	template <typename DataClass = T>
	static typename TEnableIf<TIsDerivedFrom<DataClass, UObject>::Value, UStruct*>::Type GetDataStruct()
	{
		return DataClass::StaticClass();
	}

	template <typename DataClass = T>
	static typename TEnableIf<!TIsDerivedFrom<DataClass, UObject>::Value, UStruct*>::Type GetDataStruct()
	{
		return StaticStruct<DataClass>();
	}

	static FString DefaultCategory()
	{
		return TEXT("Default");
	}

	static FString GetArchiveDirectory()
	{
		return IPluginManager::Get().FindPlugin(UE_PLUGIN_NAME)->GetBaseDir() / TEXT("Content/DataArchives") / GetArchiveTableName(0);
	}

	static FString CombineArchiveFileName(const FString& TableName, const FString& Category)
	{
		return FString::Format(TEXT("{0}-{1}{2}"), {TableName, Category, FDataArchive::ArchiveFileExtension});
	}

	static bool SplitArchiveFileName(const FString& FileName, FString* TableName, FString* Category)
	{
		const FString BaseFileName = FPaths::GetBaseFilename(FileName);
		return BaseFileName.Split(TEXT("-"), TableName, Category);
	}

private:
	template <typename DataClass = T>
	static typename TEnableIf<TIsDerivedFrom<DataClass, UObject>::Value, FString>::Type DefaultTableName()
	{
		return DataClass::StaticClass()->GetName();
	}

	template <typename DataClass = T>
	static typename TEnableIf<!TIsDerivedFrom<DataClass, UObject>::Value, FString>::Type DefaultTableName()
	{
		return StaticStruct<DataClass>()->GetName();
	}
};

template <typename T>
struct TEditingDataCollection
{
	using DataOps = TDataArchiveOps<T>;
	using KeyType = typename DataOps::KeyType;

	bool IsEmpty() const
	{
		return OriginDataCategory.IsEmpty();
	}

	void MarkDataEdited(T* InData)
	{
		if (InData)
		{
			if (!OriginDataCategory.Contains(DataOps::GetKeyFromData(InData)))
			{
				OriginDataCategory.Add(DataOps::GetKeyFromData(InData), DataOps::GetArchiveCategory(InData));
			}
			
			EditedDataSet.Add(InData);
		}
	}

	void MarkForAdd(T* InData)
	{
		if (InData)
		{
			if (!OriginDataCategory.Contains(DataOps::GetKeyFromData(InData)))
			{
				OriginDataCategory.Add(DataOps::GetKeyFromData(InData), DataOps::GetArchiveCategory(InData));
			}
			
			AddedDataSet.Add(InData);
		}
	}

	bool GetEditedCategories(TSet<FString>& OutCategories) const
	{
		OutCategories.Empty();

		// 记录所有修改过的原始数据Key到Category的映射 (注意: 这里记录的是修改之前的映射)
		TMap<KeyType, FString> DeletedCategoryMapping = OriginDataCategory;

		// 遍历所有修改后的数据, 如果它的Category和上面记录的原始Category一样, 说明它的Category没有修改过, 就把它从上面的那个映射中移除
		for (const TWeakObjectPtr<T>& EditedData : EditedDataSet)
		{
			if (!EditedData.IsValid())
			{
				continue;
			}

			KeyType& Key = DataOps::GetKeyFromData(EditedData.Get());
			FString Category = DataOps::GetArchiveCategory(EditedData.Get());
			
			// EditedDataSet里面的数据总是认为被修改过
			OutCategories.Add(Category);
			
			const FString* OriginCategory = DeletedCategoryMapping.Find(Key);

			// 如果Category没有变，就从Deleted列表中删除，没有删除的会在后面被标记为修改过的
			if (OriginCategory && *OriginCategory == Category)
			{
				DeletedCategoryMapping.Remove(Key);
			}
		}
		
		for (const TWeakObjectPtr<T>& AddedData : AddedDataSet)
		{
			if (!AddedData.IsValid())
			{
				continue;
			}

			KeyType& Key = DataOps::GetKeyFromData(AddedData.Get());
			FString Category = DataOps::GetArchiveCategory(AddedData.Get());
			const FString* OriginCategory = DeletedCategoryMapping.Find(Key);

			// 新增的数据总是认为被修改过
			OutCategories.Add(Category);

			// 新增的Category从Deleted列表中删除
			if (OriginCategory && *OriginCategory == Category)
			{
				DeletedCategoryMapping.Remove(Key);
			}
		}

		// 原始映射中剩下的部分, 就是有数据被移出来的Category. 和修改后的所有Category的并集就是所有被修改过的Category的列表
		for (const TPair<KeyType, FString>& Deleted : DeletedCategoryMapping)
		{
			OutCategories.Add(Deleted.Value);
		}

		return !OutCategories.IsEmpty();
	}

	TMap<KeyType, FString> OriginDataCategory;
	TArray<TWeakObjectPtr<T>> EditedDataSet;
	TArray<TWeakObjectPtr<T>> AddedDataSet;
};

class IDataArchiveBase
{
public:
	virtual ~IDataArchiveBase() = default;
};

template <typename T>
class TDataArchive : IDataArchiveBase
{
public: 
	using DataOps = TDataArchiveOps<T>;
	using KeyType = typename DataOps::KeyType;

private:
	TMap<KeyType, TStrongObjectPtr<T>> Data;
	TMap<FString, FDataArchive> DataArchives;

public:
	T* Find(KeyType Key)
	{
		TStrongObjectPtr<T>* Found = Data.Find(Key);

		if (!Found)
		{
			return nullptr;
		}

#if !UE_BUILD_SHIPPING
		KeyType DataKey = DataOps::GetKeyFromData(Found->Get());
		if (!ensureMsgf(DataKey == Key, TEXT("DataArchive error, data map key not equal to inner data key")))
		{
			return nullptr;
		}
#endif

		return Found->Get();
	}

	bool Contains(KeyType Key)
	{
		return Data.Contains(Key);
	}

	TArray<T*> GetAll()
	{
		TArray<T*> OutData;
		OutData.Reserve(Data.Num());
		for (const auto& Pair : Data)
		{
			OutData.Add(Pair.Value.Get());
		}

		return MoveTemp(OutData);
	}

	void Load(const TDelegate<void(T*)>& PostLoadDelegate = TDelegate<void(T*)>())
	{
		Data.Empty();
		DataArchives.Empty();

		const FString Path = DataOps::GetArchiveDirectory();
		LoadFromDirectory(Path, PostLoadDelegate);
	}

	void LoadCategory(FString Category = FString(), const TDelegate<void(T*)>& PostLoadDelegate = TDelegate<void(T*)>())
	{
		if (Category.IsEmpty())
		{
			Category = DataOps::DefaultCategory();
		}

		FDataArchive& CategoryArchive = DataArchives.FindOrAdd(Category);

		const FString Path = DataOps::GetArchiveDirectory() / DataOps::CombineArchiveFileName(DataOps::GetArchiveTableName(0), Category);
		CategoryArchive.LoadFromFile(Path);

		TArray<T*> ReadObjects;
		CategoryArchive >> ReadObjects;

		for (T* Object : ReadObjects)
		{
			if (!::IsValid(Object))
			{
				continue;
			}

			KeyType& Key = DataOps::GetKeyFromData(Object);
			Data.FindOrAdd(Key).Reset(Object);

			DataOps::ExecutePostLoad(Object);
			PostLoadDelegate.ExecuteIfBound(Object);
		}
	}

private:
	void LoadFromDirectory(FString Path, const TDelegate<void(T*)>& PostLoadDelegate = TDelegate<void(T*)>())
	{
		FString DirectoryPath;
		if (!Path.EndsWith(TEXT("/")))
		{
			DirectoryPath = FPaths::Combine(Path, TEXT("/"));
		}
		else
		{
			DirectoryPath = Path;
			Path.RemoveFromEnd(TEXT("/"));
		}

		TArray<FString> FileNames;
		IFileManager::Get().FindFiles(FileNames, *DirectoryPath, *FDataArchive::ArchiveFileExtension);

		for (const FString& FileName : FileNames)
		{
			FString Category;
			DataOps::SplitArchiveFileName(FileName, nullptr, &Category);

			LoadCategory(Category);
		}
	}

public:

	
#if WITH_EDITOR
	
	TEditingDataCollection<T> EditingDataCollection;

	TArray<FString> GetAllCategories() const
	{
		TArray<FString> OutCategories;
		DataArchives.GetKeys(OutCategories);

		return MoveTemp(OutCategories);
	}

	void Update(T* Object)
	{
		if (!::IsValid(Object))
		{
			return;
		}

		KeyType& Key = DataOps::GetKeyFromData(Object);
		TStrongObjectPtr<T>& DataPtr = Data.FindOrAdd(Key);
		DataPtr.Reset(Object);
	}

	void MarkDataEdited(T* EditedData)
	{
		EditingDataCollection.MarkDataEdited(EditedData);
	}
	
	template <typename DataType>
	DataType* Add(KeyType Key, UClass* Class = DataType::StaticClass())
	{
		if (!ensure(!Data.Contains(Key)))
		{
			return Find(Key);
		}

		T* NewData = NewObject<T>(GetTransientPackage(), Class, NAME_None, RF_Transient);
		Data.Add(Key, TStrongObjectPtr<T>(NewData));
		
		EditingDataCollection.MarkForAdd(NewData);
		return Cast<DataType>(NewData);
	}

	template <typename U>
	U* FindOrAdd(KeyType Key)
	{
		T* OutData = Find(Key);

		if (!OutData)
		{
			OutData = Add<U>(Key);
			KeyType& KeyRef = DataOps::GetKeyFromData(OutData);
			KeyRef = Key;
		}

#if !UE_BUILD_SHIPPING
		if (!ensureMsgf(DataOps::GetKeyFromData(OutData) == Key, TEXT("DataArchive error, data map key not equal to inner data key")))
		{
			return nullptr;
		}
#endif

		return OutData;
	}

	void Save()
	{
		if (EditingDataCollection.IsEmpty())
		{
			// 没有任何修改过的数据, 跳过保存
			return;
		}

		TSet<FString> EditedCategories;
		if (!EditingDataCollection.GetEditedCategories(EditedCategories))
		{
			// 没有Category发生改变, 跳过保存
			return;
		}

		// 统计所有修改过的Category中的数据
		TMap<FString, TArray<T*>> SaveCache;
		for (const TPair<KeyType, TStrongObjectPtr<T>> Pair : Data)
		{
			if (!Pair.Value.IsValid() || DataOps::GetKeyFromData(Pair.Value.Get()) != Pair.Key)
			{
				continue;
			}

			const FString DataCategory = DataOps::GetArchiveCategory(Pair.Value.Get());
			if (!EditedCategories.Contains(DataCategory))
			{
				continue;
			}

			SaveCache.FindOrAdd(DataCategory).Add(Pair.Value.Get());
		}

		for (const FString& SaveCategory : EditedCategories)
		{
			FString FilePath = DataOps::GetArchiveDirectory() / DataOps::CombineArchiveFileName(DataOps::GetArchiveTableName(0), SaveCategory);

			// 所有被修改过的Category, 如果里面没有数据, 就删除
			if (!SaveCache.Contains(SaveCategory))
			{
				FDataArchive::DeleteFile(FilePath);
			}
			// 重新保存这个Category
			else
			{
				FDataArchive& CategoryArchive = DataArchives.FindOrAdd(SaveCategory);
				CategoryArchive.Empty();
				for (T* SaveData : SaveCache[SaveCategory])
				{
					CategoryArchive << SaveData;
				}

				CategoryArchive.SaveToFile(FilePath);
			}
		}
	}

	void SaveAll()
	{
		for (TPair<FString, FDataArchive>& Pair : DataArchives)
		{
			Pair.Value.Empty();
		}

		for (const auto& Pair : Data)
		{
			if (!Pair.Value.IsValid() || DataOps::GetKeyFromData(Pair.Value.Get()) != Pair.Key)
			{
				continue;
			}

			FDataArchive& Archive = DataArchives.FindOrAdd(DataOps::GetArchiveCategory(Pair.Value.Get()));
			Archive << Pair.Value.Get();
		}

		for (TPair<FString, FDataArchive>& Pair : DataArchives)
		{
			const FString FilePath = DataOps::GetArchiveDirectory() / DataOps::CombineArchiveFileName(DataOps::GetArchiveTableName(0), Pair.Key);
			Pair.Value.SaveToFile(FilePath);
		}
	}

#endif
};


class FDataArchiveManager
{
public:
	COMBATCOMMON_API static FDataArchiveManager& GetInstance();

	template <typename T>
	static TDataArchive<T>& GetArchive()
	{
		const UStruct* Struct = TDataArchiveOps<T>::GetDataStruct();

		if (const TUniquePtr<IDataArchiveBase>* FoundArchive = GetInstance().ArchivesMap.Find(Struct))
		{
			return *reinterpret_cast<TDataArchive<T>*>(FoundArchive->Get());
		}

		TDataArchive<T>* NewArchivePtr = new TDataArchive<T>();
		const TUniquePtr<IDataArchiveBase>& Result = GetInstance().ArchivesMap.Emplace(Struct, reinterpret_cast<IDataArchiveBase*>(NewArchivePtr));
		return *reinterpret_cast<TDataArchive<T>*>(Result.Get());
	}

	template <typename T>
	static void Load(TDelegate<void(T*)> PostLoadDelegate = TDelegate<void(T*)>())
	{
		auto& Archive = GetArchive<T>();
		Archive.Load(PostLoadDelegate);
	}

	template <typename T>
	static void LoadCategory(FString Category = FString(), TDelegate<void(T*)> PostLoadDelegate = TDelegate<void(T*)>())
	{
		auto& Archive = GetArchive<T>();
		Archive.LoadCategory(Category, PostLoadDelegate);
	}

	template <typename T, typename U = T>
	static T* Find(typename TDataArchiveOps<U>::KeyType Key)
	{
		auto& Archive = GetArchive<U>();
		return Cast<T>(Archive.Find(Key));
	}

	template <typename T>
	static bool Contains(typename TDataArchiveOps<T>::KeyType Key)
	{
		auto& Archive = GetArchive<T>();
		return Archive.Contains(Key);
	}

	template <typename T>
	static TArray<T*> GetAll()
	{
		auto& Archive = GetArchive<T>();
		return Archive.GetAll();
	}
	
#if WITH_EDITOR

	template <typename T>
	static void SaveAll()
	{
		auto& Archive = GetArchive<T>();
		Archive.SaveAll();
	}

	/** This function will check all data "Has Been" edited, and use them to OVERRIDE origin data*/
	template <typename T>
	static void Save()
	{
		auto& Archive = GetArchive<T>();
		Archive.Save();
	}

	template <typename T>
	static void Update(T* Object)
	{
		auto& Archive = GetArchive<T>();
		return Archive.Update(Object);
	}

	template <typename T>
	static TArray<FString> GetAllCategories()
	{
		auto& Archive = GetArchive<T>();
		return Archive.GetAllCategories();
	}

	template <typename T>
	static void MarkDataEdited(T* Data)
	{
		auto& Archive = GetArchive<T>();
		return Archive.MarkDataEdited(Data);
	}
	
	template <typename T, typename U = T>
	static U* FindOrAdd(typename TDataArchiveOps<T>::KeyType Key)
	{
		auto& Archive = GetArchive<T>();
		return Archive.template FindOrAdd<U>(Key);
	}

	template <typename T, typename U = T>
	static U* Add(typename TDataArchiveOps<T>::KeyType Key, UClass* Class = U::StaticClass())
	{
		auto& Archive = GetArchive<T>();
		return Archive.template Add<U>(Key, Class);
	}
	
#endif
	

private:
	TMap<const UStruct*, TUniquePtr<IDataArchiveBase>> ArchivesMap;
};
