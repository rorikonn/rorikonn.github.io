﻿// 


#include "..\Public\DataArchive.h"

#include "JsonObjectConverter.h"
#include "SourceControlHelpers.h"
#include "Dom/JsonObject.h"

FDataArchiveItem::FDataArchiveItem()
{
	InnerJsonObject = MakeShared<FJsonObject>();
}

FDataArchiveItem::FDataArchiveItem(const TSharedPtr<FJsonValue>& InValue)
{
	const TSharedPtr<FJsonObject>* JsonObjectPtr;
	if (InValue->TryGetObject(JsonObjectPtr))
	{
		InnerJsonObject = *JsonObjectPtr;
	}
}

FDataArchiveItem::~FDataArchiveItem()
{
	InnerJsonObject.Reset();
}

bool FDataArchiveItem::UStructToArchive(const UStruct* StructDefinition, const void* Struct)
{
	InnerJsonObject->SetStringField(ObjectClassNameKey, StructDefinition->GetPathName());

	return FJsonObjectConverter::UStructToJsonObject(StructDefinition, Struct, InnerJsonObject.ToSharedRef(), 0, 0, nullptr);
}

UObject* FDataArchiveItem::ArchiveToUStruct()
{
	const FString ClassName = InnerJsonObject->GetStringField(ObjectClassNameKey);

	if (const UClass* DataClass = FindObject<UClass>(nullptr, *ClassName))
	{
		UObject* OutObject = StaticAllocateObject(DataClass, GetTransientPackage(), NAME_None, RF_NoFlags, EInternalObjectFlags::None, false);
#if ENGINE_MAJOR_VERSION >= 5
		(*DataClass->ClassConstructor)(FObjectInitializer(OutObject, DataClass->ClassDefaultObject, EObjectInitializerOptions::None));
#else
		(*DataClass->ClassConstructor)(FObjectInitializer(OutObject, DataClass->ClassDefaultObject, false, false));
#endif

		if (FJsonObjectConverter::JsonObjectToUStruct(InnerJsonObject.ToSharedRef(), DataClass, OutObject))
		{
			return OutObject;
		}
	}

	return nullptr;
}

bool FDataArchiveItem::AppendTo(UObject*& OutObject)
{
	const FString ClassName = InnerJsonObject->GetStringField(ObjectClassNameKey);

	if (const UClass* DataClass = FindObject<UClass>(nullptr, *ClassName))
	{
		if (OutObject && OutObject->GetClass() == DataClass)
		{
			return FJsonObjectConverter::JsonObjectToUStruct(InnerJsonObject.ToSharedRef(), DataClass, OutObject);
		}
	}

	return false;
}

FDataArchiveItem::operator TSharedPtr<FJsonValueObject>() const
{
	return MakeShared<FJsonValueObject>(InnerJsonObject);
}

const FString FDataArchiveItem::ObjectClassNameKey(TEXT("_ClassName"));


void FDataArchive::Empty()
{
	ArchiveItems.Empty();
}

bool FDataArchive::LoadFromFile(FString InPath)
{
	FString Result;
	if (FFileHelper::LoadFileToString(Result, *InPath))
	{
		TArray<TSharedPtr<FJsonValue>> ValueArray;
		const TSharedRef<TJsonReader<>> Reader = TJsonReaderFactory<>::Create(Result);
		if (FJsonSerializer::Deserialize(Reader, ValueArray))
		{
			for (TSharedPtr<FJsonValue> Value : ValueArray)
			{
				TSharedPtr<FDataArchiveItem> Item = MakeShared<FDataArchiveItem>(Value);
				ArchiveItems.Add(Item);
			}
		
			return true;
		}
	}

	return false;
}

bool FDataArchive::SaveToFile(FString InPath, bool bDoCheckOut)
{
	TArray<TSharedPtr<FJsonValue>> JsonArray;
	for (TSharedPtr<FDataArchiveItem> Item : ArchiveItems)
	{
		TSharedPtr<FJsonValueObject> ObjectItem = *Item;
		JsonArray.Add(StaticCastSharedPtr<FJsonValue>(ObjectItem));
	}

	FString OutputString;
	const TSharedRef<TJsonWriter<>> Writer = TJsonWriterFactory<>::Create(&OutputString);
	FJsonSerializer::Serialize(JsonArray, Writer);

	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (!PlatformFile.FileExists(*InPath))
	{
		if (const IFileHandle* NewFile = PlatformFile.OpenWrite(*InPath))
		{
			delete NewFile;
		}
	}

	if (bDoCheckOut)
	{
		USourceControlHelpers::CheckOutOrAddFile(InPath);
		USourceControlHelpers::RevertUnchangedFile(InPath);
	}

	// In case if source control is offline
	if (PlatformFile.IsReadOnly(*InPath))
	{
		PlatformFile.SetReadOnly(*InPath, false);
	}
	
	FFileHelper::SaveStringToFile(OutputString, *InPath, FFileHelper::EEncodingOptions::ForceUTF8WithoutBOM, &IFileManager::Get(), FILEWRITE_EvenIfReadOnly | FILEWRITE_NoFail);
	return true;
}

bool FDataArchive::DeleteFile(const FString& InPath, bool bDoCheckOut)
{
	if (bDoCheckOut)
	{
		USourceControlHelpers::MarkFileForDelete(InPath);
	}
	
	IPlatformFile& PlatformFile = FPlatformFileManager::Get().GetPlatformFile();
	if (PlatformFile.FileExists(*InPath))
	{
		return PlatformFile.DeleteFile(*InPath);
	}
	
	return false;
}

TSharedPtr<FDataArchiveItem> FDataArchive::AllocArchiveItem()
{
	return MakeShared<FDataArchiveItem>();
}

void FDataArchive::PushItem(TSharedPtr<FDataArchiveItem> InArchiveItem)
{
	ArchiveItems.Add(InArchiveItem);
}

TSharedPtr<FDataArchiveItem> FDataArchive::PopItem()
{
	if (ArchiveItems.Num() > 0)
	{
		TSharedPtr<FDataArchiveItem> OutArchiveItem = ArchiveItems.Last();
		ArchiveItems.RemoveAt(ArchiveItems.Num() - 1);
		return OutArchiveItem;
	}

	return nullptr;
}

FDataArchiveManager& FDataArchiveManager::GetInstance()
{
	static TOptional<FDataArchiveManager> Instance(InPlace);
	return Instance.GetValue();
}
