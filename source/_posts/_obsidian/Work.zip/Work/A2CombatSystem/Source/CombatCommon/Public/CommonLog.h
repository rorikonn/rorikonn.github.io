﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

class FCommonScreenLogger
{
public:

	static FColor GetOnScreenVerbosityColor(const ELogVerbosity::Type Verbosity)
	{
		return
			Verbosity == ELogVerbosity::Fatal || Verbosity == ELogVerbosity::Error ? FColor::Red :
			Verbosity == ELogVerbosity::Warning ? FColor::Yellow :
			Verbosity == ELogVerbosity::Display || Verbosity == ELogVerbosity::Log ? FColor::Cyan :
			Verbosity == ELogVerbosity::Verbose || Verbosity == ELogVerbosity::VeryVerbose ? FColor::Orange :
			FColor::Cyan;
	}

	static void AddOnScreenDebugMessage(const ELogVerbosity::Type Verbosity, const FString& Message)
	{
		if (GEngine)
		{
			const FColor Color = GetOnScreenVerbosityColor(Verbosity);
			GEngine->AddOnScreenDebugMessage(INDEX_NONE, 5.f, Color, Message);
		}
	}
};

#define COMMON_LOG(CategoryName, Verbosity, Format, ...) \
{ \
UE_LOG(CategoryName, Verbosity, TEXT("[%llu] %s(%d) - %s"), GFrameCounter, *FString(__FUNCTION__), __LINE__, *FString::Printf(Format, ##__VA_ARGS__)); \
}

#define COMMON_CLOG(CategoryName, Condition, Verbosity, Format, ...) \
{ \
UE_CLOG(Condition, CategoryName, Verbosity, TEXT("[%llu] %s(%d) - %s"), GFrameCounter, *FString(__FUNCTION__), __LINE__, *FString::Printf(Format, ##__VA_ARGS__)); \
}

#define COMMON_SLOG(CategoryName, Verbosity, Format, ...) \
{ \
FCommonScreenLogger::AddOnScreenDebugMessage(ELogVerbosity::Verbosity, FString::Printf(Format, ##__VA_ARGS__)); \
COMMON_LOG(CategoryName, Verbosity, Format, ##__VA_ARGS__); \
}
