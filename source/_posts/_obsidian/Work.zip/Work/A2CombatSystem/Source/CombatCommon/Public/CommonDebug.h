﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Kismet/KismetSystemLibrary.h"

#if WITH_EDITORONLY_DATA
#include "CommonDebug.generated.h"

struct FCombatDebugUtility
{
	COMBATCOMMON_API static void DrawDebugSweptSphere(const UWorld* InWorld, FVector const& Start, FVector const& End, float Radius, FColor const& Color, bool bPersistentLines = false, float LifeTime = -1.f,
	                                                  uint8 DepthPriority = 0);
	COMBATCOMMON_API static void DrawDebugSweptBox(const UWorld* InWorld, FVector const& Start, FVector const& End, FRotator const& Orientation, FVector const& HalfSize, FColor const& Color,
	                                               bool bPersistentLines = false, float LifeTime = -1.f, uint8 DepthPriority = 0);

	COMBATCOMMON_API static void DrawDebugLineTraceSingle(const UWorld* World, const FVector& Start, const FVector& End, EDrawDebugTrace::Type DrawDebugType, bool bHit, const FHitResult& OutHit,
	                                                      FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime);
	COMBATCOMMON_API static void DrawDebugLineTraceMulti(const UWorld* World, const FVector& Start, const FVector& End, EDrawDebugTrace::Type DrawDebugType, bool bHit, const TArray<FHitResult>& OutHits,
	                                                     FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime);

	COMBATCOMMON_API static void DrawDebugBoxTraceSingle(const UWorld* World, const FVector& Start, const FVector& End, const FVector& HalfSize, const FRotator& Orientation,
	                                                     EDrawDebugTrace::Type DrawDebugType, bool bHit, const FHitResult& OutHit, FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime);
	COMBATCOMMON_API static void DrawDebugBoxTraceMulti(const UWorld* World, const FVector& Start, const FVector& End, const FVector& HalfSize, const FRotator& Orientation,
	                                                    EDrawDebugTrace::Type DrawDebugType, bool bHit, const TArray<FHitResult>& OutHits, FLinearColor TraceColor, FLinearColor TraceHitColor,
	                                                    float DrawTime);

	COMBATCOMMON_API static void DrawDebugSphereTraceSingle(const UWorld* World, const FVector& Start, const FVector& End, float Radius, EDrawDebugTrace::Type DrawDebugType, bool bHit,
	                                                        const FHitResult& OutHit, FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime);
	COMBATCOMMON_API static void DrawDebugSphereTraceMulti(const UWorld* World, const FVector& Start, const FVector& End, float Radius, EDrawDebugTrace::Type DrawDebugType, bool bHit,
	                                                       const TArray<FHitResult>& OutHits, FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime);

	COMBATCOMMON_API static void DrawDebugCapsuleTraceSingle(const UWorld* World, const FVector& Start, const FVector& End, float Radius, float HalfHeight, EDrawDebugTrace::Type DrawDebugType, bool bHit,
	                                                         const FHitResult& OutHit, FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime);
	COMBATCOMMON_API static void DrawDebugCapsuleTraceMulti(const UWorld* World, const FVector& Start, const FVector& End, const FQuat& Rot, float Radius, float HalfHeight, EDrawDebugTrace::Type DrawDebugType, bool bHit,
	                                                        const TArray<FHitResult>& OutHits, FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime);

	COMBATCOMMON_API static void DrawDebugCylinderTrace(const UWorld* World, const FVector& Center, const FQuat& Rot, float Radius, float HalfHeight, EDrawDebugTrace::Type DrawDebugType, bool bHit,
	                                                    const TArray<FHitResult>& OutHits, FLinearColor TraceColor, FLinearColor TraceHitColor, float DrawTime);

	COMBATCOMMON_API static void DrawDebugCylinder(const UWorld* InWorld, FVector const& Center, float HalfHeight, float Radius, const FQuat& Rotation, FColor const& Color, bool bPersistentLines = false, float LifeTime = -1.f,
	                                               uint8 DepthPriority = 0, float Thickness = 0);
};


UCLASS()
class UCombatCommonWorldDebugSubsystem : public UTickableWorldSubsystem
{
	GENERATED_BODY()

public:
	virtual TStatId GetStatId() const override;
	virtual void Tick(float DeltaTime) override;
};

#endif
