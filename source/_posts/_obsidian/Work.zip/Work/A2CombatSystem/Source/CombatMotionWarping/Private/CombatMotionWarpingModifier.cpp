﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "CombatMotionWarpingModifier.h"

#include "MotionWarpingComponent.h"
#include "Components/CapsuleComponent.h"
#include "GameFramework/Character.h"


void UCombatRootMotionModifier::OnStateChanged(ERootMotionModifierState LastState)
{
	Super::OnStateChanged(LastState);

	if (LastState != ERootMotionModifierState::Active && GetState() == ERootMotionModifierState::Active)
	{
		UpdateWarpTarget();

		// Remember character transform when active used in KeepWorld calculation
		if (CharacterOwner)
		{
			StartCharacterTransform = CharacterOwner->GetActorTransform();
		}
	}
}

FTransform UCombatRootMotionModifier::ProcessRootMotion(const FTransform& InRootMotion, float DeltaSeconds)
{
	if (!IsValid(CharacterOwner) || !WarpTarget.IsSet())
	{
		return InRootMotion;
	}

	FTransform CharacterTransform = CharacterOwner->GetActorTransform();
	if (CharacterOwner->GetCapsuleComponent())
	{
		CharacterTransform.SetLocation(CharacterTransform.GetLocation() - CharacterOwner->GetActorUpVector() * CharacterOwner->GetCapsuleComponent()->GetScaledCapsuleHalfHeight());
	}
	
	const FTransform RootMotionRemain = UMotionWarpingUtilities::ExtractRootMotionFromAnimation(Animation.Get(), PreviousPosition, EndTime);
	const FTransform RootMotionThisFrame = UMotionWarpingUtilities::ExtractRootMotionFromAnimation(Animation.Get(), PreviousPosition, FMath::Min(CurrentPosition, EndTime));

	FTransform FinalRootMotion = InRootMotion;
	if (LocationWarpType == ECombatMotionWarpingType::WarpToTarget)
	{
		ProcessRootMotionLocationWarpToTarget(FinalRootMotion, DeltaSeconds, CharacterTransform, RootMotionRemain, RootMotionThisFrame);
	}
	else if (LocationWarpType == ECombatMotionWarpingType::KeepWorld)
	{
		ProcessRootMotionLocationKeepWorld(FinalRootMotion, DeltaSeconds, CharacterTransform);
	}

	if (RotationWarpType == ECombatMotionWarpingType::WarpToTarget)
	{
		ProcessRootMotionRotation(FinalRootMotion, DeltaSeconds, CharacterTransform, RootMotionRemain, RootMotionThisFrame);
	}


	return FinalRootMotion;
}

void UCombatRootMotionModifier::OnConstruct()
{
}

bool UCombatRootMotionModifier::GetWarpTarget(FTransform& OutTargetTransform)
{
	return false;
}

void UCombatRootMotionModifier::UpdateWarpTarget()
{
	FTransform TargetTransform;
	if (GetWarpTarget(TargetTransform))
	{
		WarpTarget = TargetTransform;
	}
	else
	{
		WarpTarget.Reset();
	}
}

void UCombatRootMotionModifier::ProcessRootMotionLocationWarpToTarget(FTransform& FinalRootMotion, float DeltaSeconds, const FTransform& CharacterTransform,
	const FTransform& RootMotionRemain, const FTransform& RootMotionThisFrame)
{
	const FQuat CurrentRotation = CharacterTransform.GetRotation();
	const FVector CurrentLocation = CharacterTransform.GetLocation();

	FVector TargetLocation = WarpTarget.GetValue().GetLocation();

	// Use skew warp if total root motion translation is not zero
	if (RootMotionRemain.GetTranslation().Length() > KINDA_SMALL_NUMBER)
	{
		const FVector RootMotionDeltaWorldSpace = CharacterOwner->GetMesh()->ConvertLocalRootMotionToWorld(RootMotionThisFrame).GetLocation();
		const FVector CurrentToTargetWorldSpace = TargetLocation - CurrentLocation;
		const FVector RootMotionTotalWorldSpace = CharacterOwner->GetMesh()->ConvertLocalRootMotionToWorld(RootMotionRemain).GetLocation();

		// Create a matrix we can use to put everything into a space looking straight at RootMotionSyncPosition. "forward" should be the axis along which we want to scale. 
		FVector RootMotionDirection = RootMotionTotalWorldSpace.GetSafeNormal(SMALL_NUMBER, FVector::ForwardVector);

		float BestMatchDot = FMath::Abs(FVector::DotProduct(RootMotionDirection, CurrentRotation.GetAxisX()));
		FVector SyncSpaceZAxis = CurrentRotation.GetAxisZ();

		float ZDot = FMath::Abs(FVector::DotProduct(RootMotionDirection, CurrentRotation.GetAxisZ()));
		if (ZDot > BestMatchDot)
		{
			SyncSpaceZAxis = CurrentRotation.GetAxisX();
			BestMatchDot = ZDot;
		}

		float YDot = FMath::Abs(FVector::DotProduct(RootMotionDirection, CurrentRotation.GetAxisY()));
		if (YDot > BestMatchDot)
		{
			SyncSpaceZAxis = CurrentRotation.GetAxisZ();
		}

		FMatrix SyncSpaceToWorld = FRotationMatrix::MakeFromXZ(RootMotionDirection, SyncSpaceZAxis);

		// Put everything into RootSyncSpace.
		const FVector RootMotionDeltaSyncSpace = SyncSpaceToWorld.InverseTransformVector(RootMotionDeltaWorldSpace);
		const FVector CurrentToTargetSyncSpace = SyncSpaceToWorld.InverseTransformVector(CurrentToTargetWorldSpace);
		const FVector CurrentToRootSyncSpace = SyncSpaceToWorld.InverseTransformVector(RootMotionTotalWorldSpace);

		const FVector CurrentToTargetDirectionSyncSpace = CurrentToTargetSyncSpace.GetSafeNormal();
		const FVector CurrentToRootDirectionSyncSpace = CurrentToRootSyncSpace.GetSafeNormal();
		
		// Calculate skew Yaw Angle. 
		const FVector FlatToWorld = CurrentToTargetDirectionSyncSpace.GetSafeNormal2D(UE_SMALL_NUMBER, FVector::ForwardVector);
		const FVector FlatToRoot = CurrentToRootDirectionSyncSpace.GetSafeNormal2D(UE_SMALL_NUMBER, FVector::ForwardVector);
		float AngleAboutZ = FMath::Acos(FVector::DotProduct(FlatToWorld, FlatToRoot));
		float AngleAboutZNorm = FMath::DegreesToRadians(FRotator::NormalizeAxis(FMath::RadiansToDegrees(AngleAboutZ)));
		if (FlatToWorld.Y < 0.0f)
		{
			AngleAboutZNorm *= -1.0f;
		}

		// Calculate Skew Pitch Angle. 
		FVector ToWorldNoY = FVector(CurrentToTargetDirectionSyncSpace.X, 0.0f, CurrentToTargetDirectionSyncSpace.Z);
		ToWorldNoY = ToWorldNoY.GetSafeNormal(UE_SMALL_NUMBER, FVector::ForwardVector);
		FVector ToRootNoY = FVector(CurrentToRootDirectionSyncSpace.X, 0.0f, CurrentToRootDirectionSyncSpace.Z);
		ToRootNoY = ToRootNoY.GetSafeNormal(UE_SMALL_NUMBER, FVector::ForwardVector);
		const float AngleAboutY = FMath::Acos(FVector::DotProduct(ToWorldNoY, ToRootNoY));
		float AngleAboutYNorm = FMath::DegreesToRadians(FRotator::NormalizeAxis(FMath::RadiansToDegrees(AngleAboutY)));
		if (ToWorldNoY.Z < 0.0f)
		{
			AngleAboutYNorm *= -1.0f;
		}

		FVector SkewedRootMotion = FVector::ZeroVector;
		float ProjectedScale = FVector::DotProduct(CurrentToTargetSyncSpace, CurrentToRootDirectionSyncSpace) / CurrentToRootSyncSpace.Size();
		if (ProjectedScale != 0.0f)
		{
			FMatrix ScaleMatrix;
			ScaleMatrix.SetIdentity();
			ScaleMatrix.SetAxis(0, FVector(ProjectedScale, 0.0f, 0.0f));
			ScaleMatrix.SetAxis(1, FVector(0.0f, 1.0f, 0.0f));
			ScaleMatrix.SetAxis(2, FVector(0.0f, 0.0f, 1.0f));

			FMatrix ShearXAlongYMatrix;
			ShearXAlongYMatrix.SetIdentity();
			ShearXAlongYMatrix.SetAxis(0, FVector(1.0f, FMath::Tan(AngleAboutZNorm), 0.0f));
			ShearXAlongYMatrix.SetAxis(1, FVector(0.0f, 1.0f, 0.0f));
			ShearXAlongYMatrix.SetAxis(2, FVector(0.0f, 0.0f, 1.0f));

			FMatrix ShearXAlongZMatrix;
			ShearXAlongZMatrix.SetIdentity();
			ShearXAlongZMatrix.SetAxis(0, FVector(1.0f, 0.0f, FMath::Tan(AngleAboutYNorm)));
			ShearXAlongZMatrix.SetAxis(1, FVector(0.0f, 1.0f, 0.0f));
			ShearXAlongZMatrix.SetAxis(2, FVector(0.0f, 0.0f, 1.0f));

			FMatrix ScaledSkewMatrix = ScaleMatrix * ShearXAlongYMatrix * ShearXAlongZMatrix;

			// Skew and scale the Root motion. 
			SkewedRootMotion = ScaledSkewMatrix.TransformVector(RootMotionDeltaSyncSpace);
		}
		else if (!CurrentToRootSyncSpace.IsZero() && !CurrentToTargetSyncSpace.IsZero() && !RootMotionDeltaSyncSpace.IsZero())
		{
			// Figure out ratio between remaining Root and remaining World. Then project scaled length of current Root onto World.
			const float Scale = CurrentToTargetSyncSpace.Size() / CurrentToRootSyncSpace.Size();
			const float StepTowardTarget = RootMotionDeltaSyncSpace.ProjectOnTo(RootMotionDeltaSyncSpace).Size();
			SkewedRootMotion = CurrentToTargetDirectionSyncSpace * (Scale * StepTowardTarget);
		}

		// Put our result back in world space.  
		FinalRootMotion.SetTranslation(SyncSpaceToWorld.TransformVector(SkewedRootMotion));
	}
	// Use simple warp if total root motion translation is zero
	else
	{
		FVector DeltaTranslation = FVector::ZeroVector;
		const float TimeRemain = EndTime - PreviousPosition;
		const float PercentThisStep = FMath::Clamp(DeltaSeconds / TimeRemain, 0.0f, 1.0f);

		const FVector DeltaTranslationToWarpTarget = TargetLocation - CurrentLocation;
		DeltaTranslation = FMath::Lerp(FVector::ZeroVector, DeltaTranslationToWarpTarget, PercentThisStep);

		FinalRootMotion.SetTranslation(DeltaTranslation);
	}
}

void UCombatRootMotionModifier::ProcessRootMotionLocationKeepWorld(FTransform& FinalRootMotion, float DeltaSeconds, const FTransform& CharacterTransform)
{
	if (!ensure(CharacterOwner))
	{
		return;
	}

	const FTransform RootMotionPrevious = UMotionWarpingUtilities::ExtractRootMotionFromAnimation(Animation.Get(), StartTime, PreviousPosition);
	const FTransform RootMotionDelta = UMotionWarpingUtilities::ExtractRootMotionFromAnimation(Animation.Get(), PreviousPosition, FMath::Min(CurrentPosition, EndTime));

	const FTransform ComponentToWorld = CharacterOwner->GetMesh()->GetComponentTransform();
	const FTransform ActorToWorld = CharacterOwner->GetActorTransform();
	const FTransform ComponentToActor = ComponentToWorld.GetRelativeTransform(ActorToWorld);
	const FTransform WorldSpaceRootMotionPreviousAtStart = FCombatMotionWarpingUtility::ConvertComponentSpaceRootMotionToWorld(StartCharacterTransform, ComponentToActor, RootMotionPrevious);

	const FTransform MovedCharacterTransform = WorldSpaceRootMotionPreviousAtStart * StartCharacterTransform;
	const FTransform WorldSpaceRootMotionDelta = FCombatMotionWarpingUtility::ConvertComponentSpaceRootMotionToWorld(MovedCharacterTransform, ComponentToActor, RootMotionDelta);

	FinalRootMotion.SetTranslation(WorldSpaceRootMotionDelta.GetTranslation());
}

void UCombatRootMotionModifier::ProcessRootMotionRotation(FTransform& FinalRootMotion, float DeltaSeconds, const FTransform& CharacterTransform,
	const FTransform& RootMotionRemain, const FTransform& RootMotionThisFrame)
{
	const float TimeRemain = EndTime - PreviousPosition;
	const float PercentThisStep = FMath::Clamp(DeltaSeconds / TimeRemain, 0.0f, 1.0f);

	const FQuat CurrentRotation = CharacterTransform.GetRotation();
	const FQuat TargetRotation = WarpTarget.GetValue().GetRotation();
	const FQuat FutureRotation = CurrentRotation * RootMotionRemain.GetRotation();
	const FQuat DeltaRotationToWarpTarget = TargetRotation * FutureRotation.Inverse();
	const FQuat DeltaRotation = FQuat::Slerp(FQuat::Identity, DeltaRotationToWarpTarget, PercentThisStep);

	FinalRootMotion.SetRotation(RootMotionThisFrame.GetRotation() * DeltaRotation);
}

FTransform FCombatMotionWarpingUtility::ConvertComponentSpaceRootMotionToWorld(const FTransform& ActorToWorld, const FTransform& ComponentToActor, const FTransform& InRootMotion)
{
	const FTransform ComponentToWorld = ComponentToActor * ActorToWorld;
	const FTransform NewComponentToWorld = InRootMotion * ComponentToWorld;

	const FVector DeltaWorldTranslation = NewComponentToWorld.GetTranslation() - ComponentToWorld.GetTranslation();

	const FQuat NewWorldRotation = ComponentToWorld.GetRotation() * InRootMotion.GetRotation();
	const FQuat DeltaWorldRotation = NewWorldRotation * ComponentToWorld.GetRotation().Inverse();

	return FTransform(DeltaWorldRotation, DeltaWorldTranslation);
}

FTransform FCombatMotionWarpingUtility::ConvertWorldSpaceRootMotionToComponent(const FTransform& ActorToWorld, const FTransform& ComponentToActor, const FTransform& InRootMotion)
{
	const FTransform ComponentToWorld = ComponentToActor * ActorToWorld;
	const FTransform WorldToComponent = ComponentToWorld.Inverse();
	const FTransform NewWorldToComponent = InRootMotion * WorldToComponent;

	const FVector DeltaComponentTranslation = NewWorldToComponent.GetTranslation() - WorldToComponent.GetTranslation();

	const FQuat NewComponentRotation = WorldToComponent.GetRotation() * InRootMotion.GetRotation();
	const FQuat DeltaComponentRotation = NewComponentRotation * WorldToComponent.GetRotation().Inverse();

	return FTransform(DeltaComponentRotation, DeltaComponentTranslation);
}
