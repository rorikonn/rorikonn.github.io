﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "CombatMotionWarpingComponent.h"

#include "CombatMotionWarpingAnimNotifyState.h"
#include "CombatMotionWarpingModifier.h"
#include "MotionWarpingComponent.h"
#include "GameFramework/Character.h"


FCombatRootMotionNetSyncData::FCombatRootMotionNetSyncData(int32 MontageInstanceID, const FRotator& RotationDelta, const FVector& TranslationDelta, float RotateDuration,
                                                           float TranslateDuration)
	: ID(MontageInstanceID),
	  RotationDelta(RotationDelta),
	  TranslationDelta(TranslationDelta),
	  RotateDuration(RotateDuration),
	  RotateTotalDuration(RotateDuration),
	  TranslateDuration(TranslateDuration),
	  TranslateTotalDuration(TranslateDuration)
{
}

void FCombatRootMotionNetSyncData::Reset()
{
	ID = INDEX_NONE;

	ResetRotation();
	ResetTranslation();
}

bool FCombatRootMotionNetSyncData::IsDataMatched(int32 MontageInstanceID) const
{
	return ID != INDEX_NONE && ID == MontageInstanceID;
}

FTransform FCombatRootMotionNetSyncData::Process(const FTransform& LocalRootMotionTransform, const FTransform& SkeletalMeshWorldTransform, float DeltaSeconds)
{
	FTransform AdjustedTransform = LocalRootMotionTransform;
	// TODO(yuhanlu): we set rotation at the beginning and don't blend it

	if (NeedAdjustTranslation())
	{
		const float TranslationSeconds = FMath::Min(DeltaSeconds, TranslateDuration);
		FVector DeltaTranslation = TranslationDelta * (TranslationSeconds / TranslateTotalDuration);
		DeltaTranslation = SkeletalMeshWorldTransform.InverseTransformVector(DeltaTranslation);
		AdjustedTransform.SetLocation(LocalRootMotionTransform.GetLocation() + DeltaTranslation);
		TranslateDuration -= DeltaSeconds;
		if (TranslateDuration <= 0)
		{
			ResetTranslation();
		}
	}

	return AdjustedTransform;
}

bool FCombatRootMotionNetSyncData::NeedAdjustRotation() const
{
	return RotationDelta != FRotator::ZeroRotator && RotateDuration > 0;
}

bool FCombatRootMotionNetSyncData::NeedAdjustTranslation() const
{
	return TranslationDelta != FVector::ZeroVector && TranslateDuration > 0;
}

void FCombatRootMotionNetSyncData::ResetRotation()
{
	RotationDelta = FRotator::ZeroRotator;
	RotateDuration = 0.f;
	RotateTotalDuration = 0.f;
}

void FCombatRootMotionNetSyncData::ResetTranslation()
{
	TranslationDelta = FVector::ZeroVector;
	TranslateDuration = 0.f;
	TranslateTotalDuration = 0.f;
}

UCombatMotionWarpingComponent* UCombatMotionWarpingComponent::GetFromOwner(const AActor* OwnerActor)
{
	return OwnerActor ? OwnerActor->FindComponentByClass<UCombatMotionWarpingComponent>() : nullptr;
}

UCombatMotionWarpingComponent::UCombatMotionWarpingComponent(const FObjectInitializer& ObjectInitializer)
	: Super(ObjectInitializer)
{
	bWantsInitializeComponent = true;
	PrimaryComponentTick.bCanEverTick = true;
	PrimaryComponentTick.TickInterval = 2.0f;
	SetIsReplicatedByDefault(true);
}

void UCombatMotionWarpingComponent::InitializeComponent()
{
	Super::InitializeComponent();

	OnPreUpdate.AddDynamic(this, &UCombatMotionWarpingComponent::UpdateMotionWarping);
}

void UCombatMotionWarpingComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	AActor* OwnerActor = GetOwner();
	const USkeletalMeshComponent* AvatarMesh = nullptr;
	if (const ACharacter* OwnerCharacter = Cast<ACharacter>(OwnerActor))
	{
		AvatarMesh = OwnerCharacter->GetMesh();
	}
	else if (OwnerActor)
	{
		AvatarMesh = OwnerActor->FindComponentByClass<USkeletalMeshComponent>();
	}

	UAnimInstance* AnimInstance = AvatarMesh ? AvatarMesh->GetAnimInstance() : nullptr;
	if (!AnimInstance)
	{
		return;
	}

	TArray<int32> InvalidatedWarpTargets;
	for (const TPair<int32, FCombatTarget>& WarpTarget : MontageWarpTarget)
	{
		if (!AnimInstance->GetMontageInstanceForID(WarpTarget.Key))
		{
			InvalidatedWarpTargets.Add(WarpTarget.Key);
		}
	}

	for (const int32 InvalidatedMontage : InvalidatedWarpTargets)
	{
		MontageWarpTarget.Remove(InvalidatedMontage);
	}
}

int32 UCombatMotionWarpingComponent::SyncRootMotionInitialTransform(const FTransform& TargetTransform, float RotatorDuration, float TranslationDuration, const UAnimMontage* Montage)
{
	if (!CharacterOwner.IsValid())
	{
		return INDEX_NONE;
	}

	if (RotatorDuration == 0)
	{
		CharacterOwner->SetActorRotation(TargetTransform.GetRotation());
	}
	if (TranslationDuration == 0)
	{
		CharacterOwner->SetActorLocation(TargetTransform.GetLocation());
	}

	const FTransform CurrentTransform = GetOwner()->GetActorTransform();
	const FTransform DeltaTransform = CurrentTransform.GetRelativeTransform(TargetTransform);
	if (DeltaTransform.Equals(FTransform::Identity))
	{
		RootMotionSyncData.Reset();
		return INDEX_NONE;
	}

	if (Montage && Montage->HasRootMotion())
	{
		SyncMontageRootMotionInitialTransform(Montage, DeltaTransform.Rotator(), DeltaTransform.GetTranslation(), RotatorDuration, TranslationDuration);
	}
	else
	{
		SyncRootMotionSourceInitialTransform();
	}

	return RootMotionSyncData.ID;
}

FTransform UCombatMotionWarpingComponent::ProcessRootMotionNetSync(int32 MontageInstanceID, const FTransform& LocalRootMotionTransform, float DeltaSeconds)
{
	if (CharacterOwner.IsValid() && RootMotionSyncData.IsDataMatched(MontageInstanceID))
	{
		if (const USkeletalMeshComponent* MeshComponent = CharacterOwner->GetMesh())
		{
			const FTransform MeshTransform = MeshComponent->GetComponentTransform();
			return RootMotionSyncData.Process(LocalRootMotionTransform, MeshTransform, DeltaSeconds);
		}
	}

	return LocalRootMotionTransform;
}

void UCombatMotionWarpingComponent::UpdateMotionWarping(UMotionWarpingComponent* MotionWarpingComponent)
{
	if (!ensureAlways(CharacterOwner.IsValid()))
	{
		return;
	}

	const FAnimMontageInstance* RootMotionMontageInstance = CharacterOwner->GetRootMotionAnimMontageInstance();
	UAnimMontage* Montage = RootMotionMontageInstance ? ToRawPtr(RootMotionMontageInstance->Montage) : nullptr;
	if (!Montage)
	{
		return;
	}

	const float PreviousPosition = RootMotionMontageInstance->GetPreviousPosition();

	// Loop over notifies directly in the montage, looking for Motion Warping windows
	for (const FAnimNotifyEvent& NotifyEvent : Montage->Notifies)
	{
		if (!NotifyEvent.bEnabled)
		{
			continue;
		}

		if (const UCombatMotionWarpingAnimNotifyState* AnimNotifyState = NotifyEvent.NotifyStateClass ? Cast<UCombatMotionWarpingAnimNotifyState>(NotifyEvent.NotifyStateClass) : nullptr)
		{
			float StartTime = FMath::IsNearlyZero(NotifyEvent.GetTriggerTime(), 1e-4f) ? 0 : NotifyEvent.GetTriggerTime();
			StartTime = FMath::Clamp(StartTime, 0.f, Montage->GetPlayLength());
			const float EndTime = FMath::Clamp(NotifyEvent.GetEndTriggerTime(), 0.f, Montage->GetPlayLength());

			if (PreviousPosition >= StartTime && PreviousPosition < EndTime)
			{
				const TArray<URootMotionModifier*>& AllModifiers = MotionWarpingComponent->GetModifiers();
				const int32 MontageInstanceID = RootMotionMontageInstance->GetInstanceID();

				URootMotionModifier* const* FoundModifier = AllModifiers.FindByPredicate([&Montage, &NotifyEvent](const URootMotionModifier* Item)
				{
					return Item->GetAnimation() == Montage && Item->GetNotifyState() == NotifyEvent.NotifyStateClass;
				});

				if (FoundModifier)
				{
					UCombatRootMotionModifier* Modifier = Cast<UCombatRootMotionModifier>(*FoundModifier);
					if (Modifier && Modifier->MontageInstanceID != MontageInstanceID)
					{
						Modifier->SetState(ERootMotionModifierState::MarkedForRemoval);
						FoundModifier = nullptr;
					}
				}

				if (!FoundModifier)
				{
					UCombatRootMotionModifier* Modifier = AnimNotifyState->GetRootMotionModifier(this, MontageInstanceID);

					if (IsValid(Modifier))
					{
						Modifier->CharacterOwner = CharacterOwner.Get();
						Modifier->MontageInstanceID = MontageInstanceID;
						Modifier->Animation = Montage;
						Modifier->StartTime = StartTime;
						Modifier->EndTime = EndTime;
						Modifier->SetNotifyState(NotifyEvent.NotifyStateClass);
						Modifier->OnConstruct();
						MotionWarpingComponent->AddModifier(Modifier);
					}
				}
			}
		}
	}
}

void UCombatMotionWarpingComponent::UpdateMontageWarpTarget(int32 MontageInstanceID, const FCombatTarget& Target)
{
	FCombatTarget& TargetRef = MontageWarpTarget.FindOrAdd(MontageInstanceID);
	TargetRef = Target;
}

void UCombatMotionWarpingComponent::RemoveMontageWarpTarget(int32 MontageInstanceID)
{
	MontageWarpTarget.Remove(MontageInstanceID);
}

FCombatTarget UCombatMotionWarpingComponent::GetMontageWarpTarget(int32 MontageInstanceID)
{
	const FCombatTarget* TargetPtr = MontageWarpTarget.Find(MontageInstanceID);
	return TargetPtr ? *TargetPtr : FCombatTarget();
}

UAnimInstance* UCombatMotionWarpingComponent::GetAnimInstance() const
{
	if (CharacterOwner.IsValid())
	{
		if (const USkeletalMeshComponent* MeshComponent = CharacterOwner->GetMesh())
		{
			return MeshComponent->GetAnimInstance();
		}
	}

	return nullptr;
}

void UCombatMotionWarpingComponent::SyncMontageRootMotionInitialTransform(const UAnimMontage* Montage, const FRotator& AdjustRotator, const FVector& AdjustTranslation, float RotatorDuration,
                                                                          float TranslationDuration)
{
	if (!Montage || !GetAnimInstance())
	{
		return;
	}

	const FAnimMontageInstance* ActivatingMontageInstance = GetAnimInstance()->GetActiveInstanceForMontage(Montage);
	if (!ActivatingMontageInstance)
	{
		return;
	}

	const float PlayRate = GetAnimInstance()->Montage_GetPlayRate(Montage);
	if (PlayRate <= 0)
	{
		return;
	}

	const float MontageLength = Montage->GetPlayLength() / PlayRate;
	RotatorDuration = FMath::Min(RotatorDuration, MontageLength);
	TranslationDuration = FMath::Min(TranslationDuration, MontageLength);

	const int32 MontageInstanceID = ActivatingMontageInstance->GetInstanceID();
	RootMotionSyncData = FCombatRootMotionNetSyncData(MontageInstanceID, AdjustRotator, AdjustTranslation, RotatorDuration, TranslationDuration);
}

void UCombatMotionWarpingComponent::SyncRootMotionSourceInitialTransform()
{
	RootMotionSyncData.Reset();
}
