﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "RootMotionModifier.h"
#include "CombatMotionWarpingModifier.generated.h"


UENUM()
enum class ECombatMotionWarpingType : uint8
{
	/** Use raw animation data. */
	KeepLocal,
	/**
	 * Keep world space translation/rotation unchanged, world space translation/rotation data are calculated based on actor transform at warp window start time.
	 */
	KeepWorld,
	/** Warp translation/rotation to target. */
	WarpToTarget,
};

UCLASS(HideDropdown)
class COMBATMOTIONWARPING_API UCombatRootMotionModifier : public URootMotionModifier
{
	GENERATED_BODY()

public:
	virtual void OnStateChanged(ERootMotionModifierState LastState) override;
	virtual FTransform ProcessRootMotion(const FTransform& InRootMotion, float DeltaSeconds) override;

	virtual void OnConstruct();

protected:
	virtual bool GetWarpTarget(FTransform& OutTargetTransform);
	virtual void UpdateWarpTarget();

	virtual void ProcessRootMotionLocationWarpToTarget(FTransform& FinalRootMotion, float DeltaSeconds, const FTransform& CharacterTransform, const FTransform& RootMotionRemain,
	                                                   const FTransform& RootMotionThisFrame);
	virtual void ProcessRootMotionLocationKeepWorld(FTransform& FinalRootMotion, float DeltaSeconds, const FTransform& CharacterTransform);
	virtual void ProcessRootMotionRotation(FTransform& FinalRootMotion, float DeltaSeconds, const FTransform& CharacterTransform, const FTransform& RootMotionRemain,
	                                       const FTransform& RootMotionThisFrame);

public:
	UPROPERTY(Transient)
	ACharacter* CharacterOwner;

	UPROPERTY(Transient)
	int32 MontageInstanceID;

	UPROPERTY()
	ECombatMotionWarpingType LocationWarpType;

	UPROPERTY()
	ECombatMotionWarpingType RotationWarpType;

protected:
	TOptional<FTransform> WarpTarget;
	FTransform StartCharacterTransform;
};


/**
 * 
 */
class COMBATMOTIONWARPING_API FCombatMotionWarpingUtility
{
public:
	static FTransform ConvertComponentSpaceRootMotionToWorld(const FTransform& ActorToWorld, const FTransform& ComponentToActor, const FTransform& InRootMotion);
	static FTransform ConvertWorldSpaceRootMotionToComponent(const FTransform& ActorToWorld, const FTransform& ComponentToActor, const FTransform& InRootMotion);
};
