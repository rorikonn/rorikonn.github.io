﻿#pragma once

#include "CoreMinimal.h"
#include "Modules/ModuleManager.h"

COMBATMOTIONWARPING_API DECLARE_LOG_CATEGORY_EXTERN(LogCombatMotionWarping, Display, All);

#define MW_RUNTIME_LOG(Verbosity, Format, ...) COMMON_LOG(LogCombatMotionWarping, Verbosity, Format, ##__VA_ARGS__)
#define MW_RUNTIME_CLOG(Condition, Verbosity, Format, ...) COMMON_CLOG(LogCombatMotionWarping, Condition, Verbosity, Format, ##__VA_ARGS__)
#define MW_RUNTIME_SLOG(Verbosity, Format, ...) COMMON_SLOG(LogCombatMotionWarping, Verbosity, Format, ##__VA_ARGS__)