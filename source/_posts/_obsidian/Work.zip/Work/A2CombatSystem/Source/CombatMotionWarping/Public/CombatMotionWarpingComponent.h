﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatTarget.h"
#include "MotionWarpingComponent.h"
#include "Components/ActorComponent.h"
#include "CombatMotionWarpingComponent.generated.h"


USTRUCT(BlueprintType)
struct FCombatRootMotionNetSyncData
{
	GENERATED_BODY()

	FCombatRootMotionNetSyncData() = default;

	FCombatRootMotionNetSyncData(int32 MontageInstanceID, const FRotator& RotationDelta, const FVector& TranslationDelta, float RotateDuration, float TranslateDuration);

	void Reset();
	bool IsDataMatched(int32 MontageInstanceID) const;
	FTransform Process(const FTransform& LocalRootMotionTransform, const FTransform& SkeletalMeshWorldTransform, float DeltaSeconds);

private:
	bool NeedAdjustRotation() const;
	bool NeedAdjustTranslation() const;
	void ResetRotation();
	void ResetTranslation();

public:
	UPROPERTY()
	int32 ID = INDEX_NONE;

private:
	UPROPERTY()
	FRotator RotationDelta = FRotator();

	UPROPERTY()
	FVector TranslationDelta = FVector();

	UPROPERTY()
	float RotateDuration = 0.f;

	UPROPERTY()
	float RotateTotalDuration = 0.f;

	UPROPERTY()
	float TranslateDuration = 0.f;

	UPROPERTY()
	float TranslateTotalDuration = 0.f;
};

class UMotionWarpingComponent;

UCLASS(ClassGroup=(Custom), meta=(BlueprintSpawnableComponent))
class COMBATMOTIONWARPING_API UCombatMotionWarpingComponent : public UMotionWarpingComponent
{
	GENERATED_BODY()

public:
	static UCombatMotionWarpingComponent* GetFromOwner(const AActor* OwnerActor);
	UCombatMotionWarpingComponent(const FObjectInitializer& ObjectInitializer);

	virtual void InitializeComponent() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

	/**
	 * 同步客户端和服务器播放RootMotion的起始位置
	 * @param TargetTransform 校正的目标位置
	 * @param RotatorDuration 期望的旋转校正时长
	 * @param TranslationDuration 期望的位移校正时长
	 * @param Montage 如果是在有RootMotion的动画过程中校正，需要传入这个Montage
	 * @return 如果传入了一个有RootMotion的Montage，则返回Montage的InstanceID，其他情况将返回RootMotionSourceID
	 */
	int32 SyncRootMotionInitialTransform(const FTransform& TargetTransform, float RotatorDuration, float TranslationDuration, const UAnimMontage* Montage = nullptr);
	FTransform ProcessRootMotionNetSync(int32 MontageInstanceID, const FTransform& LocalRootMotionTransform, float DeltaSeconds);

	UFUNCTION()
	void UpdateMotionWarping(UMotionWarpingComponent* MotionWarpingComponent);

	void UpdateMontageWarpTarget(int32 MontageInstanceID, const FCombatTarget& Target);
	void RemoveMontageWarpTarget(int32 MontageInstanceID);
	FCombatTarget GetMontageWarpTarget(int32 MontageInstanceID);

protected:
	UAnimInstance* GetAnimInstance() const;

	/*
	 * 如果这次同步需要在一个有RootMotion的动画的过程中触发，用这个方法来开始校正
	 */
	void SyncMontageRootMotionInitialTransform(const UAnimMontage* Montage, const FRotator& AdjustRotator, const FVector& AdjustTranslation, float RotatorDuration, float TranslationDuration);

	/*
	 * 如果这次同步没有动画或动画没有RootMotion，则用Root Motion Source来完成校正，使用下面这个方法
	 */
	void SyncRootMotionSourceInitialTransform();

private:
	TMap<int32, FCombatTarget> MontageWarpTarget;
	FCombatRootMotionNetSyncData RootMotionSyncData;
};
