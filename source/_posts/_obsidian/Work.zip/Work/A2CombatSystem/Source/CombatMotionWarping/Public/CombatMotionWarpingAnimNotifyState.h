﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "CombatMotionWarpingModifier.h"
#include "Animation/AnimNotifies/AnimNotifyState.h"
#include "UObject/Object.h"
#include "CombatMotionWarpingAnimNotifyState.generated.h"

class UCombatMotionWarpingComponent;
/**
 * 
 */
UCLASS()
class COMBATMOTIONWARPING_API UCombatMotionWarpingAnimNotifyState : public UAnimNotifyState
{
	GENERATED_BODY()

public:
	virtual UCombatRootMotionModifier* GetRootMotionModifier(UCombatMotionWarpingComponent* Component, int32 MontageInstanceID) const PURE_VIRTUAL(UCombatMotionWarpingAnimNotifyState::GetRootMotionModifier, return nullptr;);
};
