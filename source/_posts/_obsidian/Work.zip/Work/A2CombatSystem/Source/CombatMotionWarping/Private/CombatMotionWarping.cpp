﻿

#include "CombatMotionWarping.h"


DEFINE_LOG_CATEGORY(LogCombatMotionWarping)

IMPLEMENT_MODULE(FDefaultModuleImpl, CombatMotionWarping)