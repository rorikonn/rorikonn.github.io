﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ContentBrowserDelegates.h"
#include "EnhancedAbilityEditorStyle.h"

struct FSkillBrowserCustomColumn;

class UEnhancedSkillData;

class FSkillBrowserItem
{
public:
	FSkillBrowserItem();
	FSkillBrowserItem(UEnhancedSkillData* Data);

	void UpdateCustomColumnValue(TArray<FSkillBrowserCustomColumn>& CustomColumns);

	FString GetColumnData(FName ColumnName);
	FText GetColumnDisplayText(FName ColumnName);

	TStrongObjectPtr<UEnhancedSkillData> Data;
	TMap<FName, FString> CachedCustomColumnData;
	TMap<FName, FText> CachedCustomColumnDisplayText;
};

/** Called to get string/text value for a custom column, will get converted as necessary */
DECLARE_DELEGATE_RetVal_TwoParams(FString, FOnGetCustomGraphColumnData, UEnhancedSkillData*, FName);
DECLARE_DELEGATE_RetVal_TwoParams(FText, FOnGetCustomGraphColumnDisplayText, UEnhancedSkillData*, FName);
DECLARE_DELEGATE_RetVal_ThreeParams(bool, FOnSortGraphColumnData, const FString& Lhs, const FString& Rhs, EColumnSortMode::Type SortMode);

struct FSkillBrowserCustomColumn
{
	FSkillBrowserCustomColumn();
	FSkillBrowserCustomColumn(FName InName, const FText& DisplayName, const FText& Tooltip,
	                          const FOnGetCustomGraphColumnData& OnGetDataDelegate,
	                          const FOnGetCustomGraphColumnDisplayText& OnGetDisplayTextDelegate,
	                          const FOnSortGraphColumnData& OnSortColumnData = FOnSortGraphColumnData());

	/** Internal name of the column */
	FName ColumnName;

	/** Display name of the column */
	FText DisplayName;

	/** Tooltip for the column */
	FText TooltipText;

	/** Delegate to get String value for this column, used for sorting and internal use */
	FOnGetCustomGraphColumnData OnGetColumnData;

	/** Delegate to get Text value for this column, used to actually display */
	FOnGetCustomGraphColumnDisplayText OnGetColumnDisplayText;

	/** Delegate to sort column data */
	FOnSortGraphColumnData OnSortColumnData;
};


class SSkillBrowserColumnView : public SListView<TSharedPtr<FSkillBrowserItem>>
{
};

DECLARE_DELEGATE_ThreeParams(FOnRenameSkillBegin, const TSharedPtr<FSkillBrowserItem>&, const FString&, const FSlateRect&)
DECLARE_DELEGATE_FourParams(FOnRenameSkillCommit, const TSharedPtr<FSkillBrowserItem>&, const FString&, const FSlateRect&, ETextCommit::Type)
DECLARE_DELEGATE_RetVal_FourParams(bool, FOnVerifyRenameSkillCommit, const TSharedPtr<FSkillBrowserItem>&, const FText&, const FSlateRect&, FText&)
DECLARE_DELEGATE_OneParam(FOnSkillItemDestroyed, const TSharedPtr<FSkillBrowserItem>&);

class SSkillBrowserColumnRow : public SMultiColumnTableRow<TSharedPtr<FSkillBrowserItem>>
{
public:
	SLATE_BEGIN_ARGS(SSkillBrowserColumnRow)
		{
		}

		/** Data for the asset this item represents */
		SLATE_ARGUMENT(TSharedPtr<FSkillBrowserItem>, AssetItem)
		SLATE_EVENT(FOnDragDetected, OnDragDetected)
		/** Delegate for when an asset name has entered a rename state */
		SLATE_EVENT(FOnRenameSkillBegin, OnRenameBegin)
		/** Delegate for when an asset name has been entered for an item that is in a rename state */
		SLATE_EVENT(FOnRenameSkillCommit, OnRenameCommit)
		/** Delegate for when an asset name has been entered for an item to verify the name before commit */
		SLATE_EVENT(FOnVerifyRenameSkillCommit, OnVerifyRenameCommit)
		/** Called when any asset item is destroyed. Used in thumbnail management, though it may be used for more so It is in column items for consistency. */
		SLATE_EVENT(FOnSkillItemDestroyed, OnItemDestroyed)
		/** The string in the title to highlight (used when searching by string) */
		SLATE_ATTRIBUTE(FText, HighlightText)
		/** Delegate to call (if bound) to check if it is valid to get a custom tooltip for this view item */
		SLATE_EVENT(FOnIsAssetValidForCustomToolTip, OnIsAssetValidForCustomToolTip)
		/** Delegate to request a custom tool tip if necessary */
		SLATE_EVENT(FOnGetCustomAssetToolTip, OnGetCustomAssetToolTip)
		/* Delegate to signal when the item is about to show a tooltip */
		SLATE_EVENT(FOnVisualizeAssetToolTip, OnVisualizeAssetToolTip)
		/** Delegate for when an item's tooltip is about to close */
		SLATE_EVENT(FOnAssetToolTipClosing, OnAssetToolTipClosing)
	SLATE_END_ARGS()

	/** Constructs this widget with InArgs */
	void Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTableView);

	virtual TSharedRef<SWidget> GenerateWidgetForColumn(const FName& ColumnName) override;

	virtual FVector2D GetRowSizeForColumn(const FName& InColumnName) const override;

	FText GetColumnText(FName ColumnName) const
	{
		return AssetItem ? AssetItem->GetColumnDisplayText(ColumnName) : FText();
	}

	FText GetColumnTips(FName ColumnName) const
	{
		return AssetItem ? AssetItem->GetColumnDisplayText(ColumnName) : FText();
	}

	TSharedPtr<FSkillBrowserItem> AssetItem;
};

class FSkillBrowserCommands : public TCommands<FSkillBrowserCommands>
{
public:
	FSkillBrowserCommands()
		: TCommands(
			TEXT("SkillBrowser"),
			NSLOCTEXT("SSkillBrowser", "CommandsContextDesc", "SkillEditor Plugin"),
			NAME_None,
			FEnhancedAbilityEditorStyle::GetStyleSetName())
	{
	}

	virtual void RegisterCommands() override;

	TSharedPtr<FUICommandInfo> CreateNew;

	TSharedPtr<FUICommandInfo> LoadAll;
	TSharedPtr<FUICommandInfo> SaveAll;
};

class SSkillCreator : public SCompoundWidget
{
public:
	SSkillCreator();

	SLATE_BEGIN_ARGS(SSkillCreator) { ; }
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	bool DoCreation();

protected:
	void Confirm();
	void Cancel();

	bool IsGraphIDValid() const;

	FText OnGetIDText() const;
	void OnIDInputCommit(const FText& NewText, ETextCommit::Type CommitType);

	FText OnGetNameText() const;
	void OnNameInputCommit(const FText& NewText, ETextCommit::Type CommitType);

	FText OnGetDescriptionText() const;
	void OnDescriptionInputCommit(const FText& NewText, ETextCommit::Type CommitType);

	FText OnGetCategoryText() const;
	void OnCategoryInputCommit(const FText& NewText, ETextCommit::Type CommitType);

	FReply OnConfirmClicked();
	FReply OnCancelClicked();

	FText GetIDHeader() const;
	FText GetNameHeader() const;
	FText GetDescHeader() const;
	FText GetCategoryHeader() const;

public:
	uint8 bCreateConfirmed : 1;

private:
	int32 InputID;
	FName InputName;
	FString InputDescription;
	FString InputCategory;

	TWeakPtr<SWindow> SkillCreatorWindow;
};

using FOnSkillItemClicked = TSlateDelegates<UEnhancedSkillData*>::FOnMouseButtonClick;
using FOnSkillItemDoubleClicked = TSlateDelegates<UEnhancedSkillData*>::FOnMouseButtonClick;

/**
 * 
 */
class SSkillBrowser : public SCompoundWidget, public FNotifyHook
{
public:
	SLATE_BEGIN_ARGS(SSkillBrowser)
		{
		}

		SLATE_ARGUMENT(TArray<FSkillBrowserCustomColumn>, CustomColumns)
		SLATE_EVENT(FOnSkillItemDoubleClicked, OnSkillDoubleClick)
		SLATE_EVENT(FOnSkillItemClicked, OnSkillClick)
	SLATE_END_ARGS()

	SSkillBrowser();

	void Construct(const FArguments& InArgs);
	TSharedPtr<SSkillBrowserColumnView> ConstructColumnView();

	static FString OnGetBrowserColumnData(UEnhancedSkillData* GraphData, FName ColumnName);
	static FText OnGetBrowserColumnDisplayText(UEnhancedSkillData* GraphData, FName ColumnName);
	static bool OnSortIDColumn(const FString& Lhs, const FString& Rhs, EColumnSortMode::Type SortMode);

protected:
	TSharedRef<SWidget> ConstructMenuBar();

	// Main menu
	void BindCommands();
	void RegisterMainMenu();
	void RegisterFileMenu();

	void CreateNew();
	void LoadAll();
	void SaveAll();

	void RebuildContent();

	/** Handler for column view widget creation */
	TSharedRef<ITableRow> MakeColumnViewWidget(const TSharedPtr<FSkillBrowserItem> AssetItem, const TSharedRef<STableViewBase>& OwnerTable);

	EColumnSortMode::Type GetColumnSortMode(const FName ColumnId) const;
	EColumnSortPriority::Type GetColumnSortPriority(const FName ColumnId) const;

	/** Handler for when a column header is clicked */
	void OnSortColumnHeader(const EColumnSortPriority::Type SortPriority, const FName& ColumnId, const EColumnSortMode::Type NewSortMode);

	/** Handle dragging an asset */
	FReply OnDraggingAssetItem(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) const;

	/** Handler for clicking an item */
	void OnListMouseButtonClick(const TSharedPtr<FSkillBrowserItem> AssetItem) const;

	/** Handler for double clicking an item */
	void OnListMouseButtonDoubleClick(const TSharedPtr<FSkillBrowserItem> AssetItem) const;

	/** Create context menu when right click row */
	TSharedPtr<SWidget> OnConstructItemContextMenu() const;

	void SortSourceItems();

	/* Type filter in search box */
	void OnFilterTextChanged(const FText& InSearchText);
	void OnFilterTextCommitted(const FText& InSearchText, ETextCommit::Type CommitInfo);
	void SetSearchBoxText(const FText& InSearchText);

	/* Check if current item has specific text we type in search box*/
	bool IsDataMatched(const TSharedPtr<FSkillBrowserItem>& BrowserItem, const FText& InSearchText);
	
	TSharedPtr<IDetailsView> PropertyDetailsWidget;
	TSharedPtr<SSkillBrowserColumnView> ColumnView;
	TSharedPtr<SHeaderRow> ColumnViewHeader;

	TArray<FSkillBrowserCustomColumn> CustomColumns;
	FOnSkillItemDoubleClicked OnListMouseDoubleClickDelegate;
	FOnSkillItemClicked OnListMouseClickDelegate;

	FName PrimarySortedColumn;
	EColumnSortMode::Type PrimarySortMode;
	FName SecondarySortedColumn;
	EColumnSortMode::Type SecondarySortMode;

	TArray<TSharedPtr<FSkillBrowserItem>> FilteredSourceItem;

	TSharedPtr<FUICommandList> BrowserCommands;
	TSharedPtr<FUICommandList> BrowserItemMenuCommands;

	/** Whether to allow dragging of items */
	uint8 bAllowDragging : 1;

	static FName BrowserMainMenuName;
	static FName BrowserFileSubMenuName;

	/* Widget containing the filtering text box */
	TSharedPtr<SSearchBox> FilterTextBoxWidget;
	FText SearchText;
};
