﻿// Copyright 2023 Tencent. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"
#include "EnhancedAbilityEditorStyle.h"
#include "Modules/ModuleManager.h"
#include "Toolkits/AssetEditorToolkit.h"

class UEnhancedSkillData;
struct FGraphPanelNodeFactory;
class IAssetTypeActions;
class UEnhancedAbilityData;


class FEnhancedAbilityEditorCommands : public TCommands<FEnhancedAbilityEditorCommands>
{
public:
	FEnhancedAbilityEditorCommands()
		: TCommands(TEXT("EnhancedAbilityEditor"), NSLOCTEXT("EnhancedAbilityEditorModule", "CommandsContext", "EnhancedAbilityEditor Plugin"),
		            NAME_None, FEnhancedAbilityEditorStyle::GetStyleSetName())
	{
	}

	virtual void RegisterCommands() override;

	TSharedPtr<FUICommandInfo> OpenEditorWindow;
};

class FEnhancedAbilityEditorModule : public IModuleInterface, public IHasMenuExtensibility
{
public:
	/** IModuleInterface implementation */
	virtual void StartupModule() override;
	virtual void ShutdownModule() override;

	virtual TSharedPtr<FExtensibilityManager> GetMenuExtensibilityManager() override { return MenuExtensibilityManager; }

protected:
	// Initialize Ability Asset Editor Entry
	void RegisterEntry();
	void UnregisterEntry();
	
	// Initialize graph panel visual factories
	void RegisterFactories();
	void UnregisterFactories();

	void RegisterDetailCustomizations();
	void UnregisterDetailCustomizations();
	
	TSharedRef<SDockTab> OnSpawnSkillBrowserTab(const FSpawnTabArgs& SpawnTabArgs);
	void OnSkillBrowserDoubleClick(UEnhancedSkillData* Skill);

private:
	/** Register panel node factory so that we can unregister during shutdown*/
	TSharedPtr<FGraphPanelNodeFactory> GraphNodeFactory;

	TSharedPtr<FExtensibilityManager> MenuExtensibilityManager;

public:
	ENHANCEDABILITYEDITOR_API static FName SkillBrowserTabName;
};
