﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "EnhancedSkillIDCustomization.h"

#include "DetailWidgetRow.h"
#include "PropertyCustomizationHelpers.h"
#include "Skill/EnhancedSkillTypes.h"
#include "Widgets/Input/SSearchBox.h"

TSharedRef<IPropertyTypeCustomization> FEnhancedSkillIDCustomization::MakeInstance()
{
	return MakeShared<FEnhancedSkillIDCustomization>();
}

void FEnhancedSkillIDCustomization::CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	TSharedPtr<IPropertyHandle> IDPropertyHandle = PropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FSkillID, ID));\
	auto GetIDTextLambda = [IDPropertyHandle]()
	{
		int32 IDValue;
		const FPropertyAccess::Result GetValueResult = IDPropertyHandle->GetValue(IDValue);
		if (GetValueResult == FPropertyAccess::Result::Success)
		{
			return FText::AsNumber(IDValue);
		}
		return FText();
	};

	HeaderRow
		.NameContent()[PropertyHandle->CreatePropertyNameWidget()]
		.ValueContent()[IDPropertyHandle->CreatePropertyValueWidget()];
	// .ValueContent()
	// [
	// 	SAssignNew(ValueContextWidget, SHorizontalBox)
	// 	+ SHorizontalBox::Slot()
	// 	.FillWidth(1.0f)
	// 	[
	// 		SNew(SEditableTextBox)
	// 		.Text(GetIDTextLambda)
	// 		.IsReadOnly(true)
	// 	]
	// 	+ SHorizontalBox::Slot()
	// 	  .AutoWidth()
	// 	  .HAlign(HAlign_Center)
	// 	  .VAlign(VAlign_Center)
	// 	  .Padding(2.0f, 1.0f)
	// 	[
	// 		PropertyCustomizationHelpers::MakeBrowseButton(
	// 			FSimpleDelegate::CreateSP(this, &FEnhancedSkillIDCustomization::BrowseSkillID, ValueContextWidget, IDPropertyHandle)
	// 		)
	// 	]
	// ];
}

void FEnhancedSkillIDCustomization::CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
}

// ReSharper disable once CppPassValueParameterByConstReference
void FEnhancedSkillIDCustomization::BrowseSkillID(TSharedRef<SWidget> ParentWidget, TSharedPtr<IPropertyHandle> IDPropertyHandle) const
{
	const TSharedRef<SWidget> SelectorWidget = SNew(SEnhancedSkillIDSelector)
		.OnSelected(SEnhancedSkillIDSelector::FSkillIDSelected::CreateLambda([IDPropertyHandle](int32 ID)
		{
			IDPropertyHandle->SetValue(ID);
		}));

	FSlateApplication::Get().PushMenu(
		ParentWidget,
		FWidgetPath(),
		SelectorWidget,
		FSlateApplication::Get().GetCursorPos(),
		FPopupTransitionEffect(FPopupTransitionEffect::TypeInPopup)
	);
}

void SEnhancedSkillIDSelector::Construct(const FArguments& InArgs)
{
	SNew(SBorder)
	.BorderImage(FAppStyle::GetBrush(TEXT("Menu.Background")))
	.Padding(5);
	// .Content()
	// [
	// 	SNew(SVerticalBox)
	// 	+ SVerticalBox::Slot()
	// 	  .AutoHeight()
	// 	  .Padding(0.0f, 1.0f)
	// 	[
	// 		SNew(SSearchBox)
	// 		// .OnTextChanged(this, &SGLAvatarIDChooser::HandleSearchTextChanged)
	// 	]
	// 	+ SVerticalBox::Slot()
	// 	  .AutoHeight()
	// 	  .MaxHeight(512)
	// 	[
	// 		SNew(SBox)
	// 		.WidthOverride(256)
	// 		.Content()
	// 		[
	// 			SNew(SListView<TSharedPtr<int32>>)
	// 			.ListItemsSource(&SEnhancedSkillIDSelector::GetSelectableSkillList)
	// 		]
	// 	]
	// ]
}
