﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Misc/TextFilterExpressionEvaluator.h"

/**
 * 
 */
struct FEnhancedSkillIDCustomization : IPropertyTypeCustomization
{
	static TSharedRef<IPropertyTypeCustomization> MakeInstance();

	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> PropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& CustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) override;

	void BrowseSkillID(TSharedRef<SWidget> ParentWidget, TSharedPtr<IPropertyHandle> IDPropertyHandle) const;
};


class SEnhancedSkillIDSelector : public SCompoundWidget
{
public:
	DECLARE_DELEGATE_OneParam(FSkillIDSelected, int32);
	
	TSharedPtr<SWidget> SearchBox;
	TSharedPtr<FTextFilterExpressionEvaluator> TextFilterPtr;

	SLATE_BEGIN_ARGS(SEnhancedSkillIDSelector){}
		SLATE_ARGUMENT(FSkillIDSelected, OnSelected)
	SLATE_END_ARGS()

	void Construct(const FArguments& InArgs);

	const TArray<TSharedPtr<int32>>* GetSelectableSkillList();
};
