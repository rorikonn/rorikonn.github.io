﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "Editors/SSkillBrowser.h"

#include "EnhancedAbilityEditorModule.h"
#include "JsonObjectConverter.h"
#include "Framework/Commands/GenericCommands.h"
#include "Skill/EnhancedSkill.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Widgets/Input/SSearchBox.h"
#include "Widgets/Layout/SGridPanel.h"
#include "Widgets/Layout/SUniformGridPanel.h"

#define LOCTEXT_NAMESPACE "SSkillBrowser"

FName SSkillBrowser::BrowserMainMenuName = TEXT("SkillBrowserMainMenu");
FName SSkillBrowser::BrowserFileSubMenuName = TEXT("SkillBrowserMainMenu.File");

FSkillBrowserItem::FSkillBrowserItem()
{
}

FSkillBrowserItem::FSkillBrowserItem(UEnhancedSkillData* Data)
	: Data(Data)
{
}

void FSkillBrowserItem::UpdateCustomColumnValue(TArray<FSkillBrowserCustomColumn>& CustomColumns)
{
	for (const FSkillBrowserCustomColumn& Column : CustomColumns)
	{
		if (Column.OnGetColumnData.IsBound())
		{
			CachedCustomColumnData.Emplace(Column.ColumnName, Column.OnGetColumnData.Execute(Data.Get(), Column.ColumnName));
		}

		if (Column.OnGetColumnDisplayText.IsBound())
		{
			CachedCustomColumnDisplayText.Emplace(Column.ColumnName, Column.OnGetColumnDisplayText.Execute(Data.Get(), Column.ColumnName));
		}
	}
}

FString FSkillBrowserItem::GetColumnData(FName ColumnName)
{
	if (FString* Found = CachedCustomColumnData.Find(ColumnName))
	{
		return *Found;
	}

	return FString();
}

FText FSkillBrowserItem::GetColumnDisplayText(FName ColumnName)
{
	if (FText* Found = CachedCustomColumnDisplayText.Find(ColumnName))
	{
		return *Found;
	}

	return FText();
}

FSkillBrowserCustomColumn::FSkillBrowserCustomColumn()
{
}

FSkillBrowserCustomColumn::FSkillBrowserCustomColumn(
	FName InName, const FText& DisplayName, const FText& Tooltip, const FOnGetCustomGraphColumnData& OnGetDataDelegate,
	const FOnGetCustomGraphColumnDisplayText& OnGetDisplayTextDelegate, const FOnSortGraphColumnData& OnSortColumnData)
	: ColumnName(InName),
	  DisplayName(DisplayName),
	  TooltipText(Tooltip),
	  OnGetColumnData(OnGetDataDelegate),
	  OnGetColumnDisplayText(OnGetDisplayTextDelegate),
	  OnSortColumnData(OnSortColumnData)
{
}

void SSkillBrowserColumnRow::Construct(const FArguments& InArgs, const TSharedRef<STableViewBase>& InOwnerTableView)
{
	AssetItem = InArgs._AssetItem;

	SMultiColumnTableRow<TSharedPtr<FSkillBrowserItem>>::Construct(
		FSuperRowType::FArguments()
		.Style(FAppStyle::Get(), "TableView.Row")
		.OnDragDetected(InArgs._OnDragDetected),
		InOwnerTableView);
}

TSharedRef<SWidget> SSkillBrowserColumnRow::GenerateWidgetForColumn(const FName& ColumnName)
{
	static const FMargin ColumnItemPadding(5.0f, 0.0f);

	return SNew(SBox)
	.Padding(ColumnItemPadding)
	.VAlign(VAlign_Center)
	.HAlign(HAlign_Left)
	[
		SNew(STextBlock)
		.ToolTipText(this, &SSkillBrowserColumnRow::GetColumnTips, ColumnName)
		.Text(this, &SSkillBrowserColumnRow::GetColumnText, ColumnName)
	];
}

FVector2D SSkillBrowserColumnRow::GetRowSizeForColumn(const FName& InColumnName) const
{
	const TSharedRef<SWidget>* ColumnWidget = GetWidgetFromColumnId(InColumnName);

	return ColumnWidget ? (*ColumnWidget)->GetDesiredSize() : FVector2D::ZeroVector;
}

void FSkillBrowserCommands::RegisterCommands()
{
	UI_COMMAND(CreateNew, "New Graph ...", "Create new item in combo graph browser", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(LoadAll, "Load All", "Reload all combo graph data include runtime and editor", EUserInterfaceActionType::Button, FInputChord());
	UI_COMMAND(SaveAll, "Save All", "Save all combo graph data include runtime and editor", EUserInterfaceActionType::Button, FInputChord());
}

SSkillCreator::SSkillCreator()
	: bCreateConfirmed(0),
	  InputID(0),
	  InputName(NAME_None)
{
}

void SSkillCreator::Construct(const FArguments& InArgs)
{
	ChildSlot
	[
		SNew(SBorder)
		.Visibility(EVisibility::Visible)
		.BorderImage(FAppStyle::GetBrush("Menu.Background"))
		.Padding(FMargin(14.0f, 21.0f, 14.0f, 3.0f))
		[
			SNew(SBox)
			.Visibility(EVisibility::Visible)
			[
				SNew(SVerticalBox) +
				SVerticalBox::Slot()
				.HAlign(HAlign_Fill)
				[
					SNew(SVerticalBox) +
					SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 5.0f)
					[
						SNew(SGridPanel)
						.FillColumn(1, 1.0f)

						// ID label
						+ SGridPanel::Slot(0, 0)
						  .VAlign(VAlign_Center)
						  .Padding(0, 0, 12, 0)
						[
							SNew(STextBlock)
							.Text(this, &SSkillCreator::GetIDHeader)
						]

						// ID edit box
						+ SGridPanel::Slot(1, 0)
						  .Padding(0.0f, 3.0f, 12.0f, 3.0f)
						  .VAlign(VAlign_Center)
						[
							SNew(SEditableTextBox)
							.Text(this, &SSkillCreator::OnGetIDText)
							.OnTextCommitted(this, &SSkillCreator::OnIDInputCommit)
						]
					] +
					SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 5.0f)
					[
						SNew(SGridPanel)
						.FillColumn(1, 1.0f)

						// Name label
						+ SGridPanel::Slot(0, 0)
						  .VAlign(VAlign_Center)
						  .Padding(0, 0, 12, 0)
						[
							SNew(STextBlock)
							.Text(this, &SSkillCreator::GetNameHeader)
						]

						// Name edit box
						+ SGridPanel::Slot(1, 0)
						  .Padding(0.0f, 3.0f, 12.0f, 3.0f)
						  .VAlign(VAlign_Center)
						[
							SNew(SEditableTextBox)
							.Text(this, &SSkillCreator::OnGetNameText)
							.OnTextCommitted(this, &SSkillCreator::OnNameInputCommit)
						]
					] +
					SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 10.0f)
					[
						SNew(SGridPanel)
						.FillColumn(1, 1.0f)

						// Data Category label
						+ SGridPanel::Slot(0, 0)
						  .VAlign(VAlign_Center)
						  .Padding(0, 0, 12, 0)
						[
							SNew(STextBlock)
							.Text(this, &SSkillCreator::GetCategoryHeader)
						]

						// Data Category edit box
						+ SGridPanel::Slot(1, 0)
						  .Padding(0.0f, 3.0f, 12.0f, 3.0f)
						  .VAlign(VAlign_Center)
						[
							SNew(SEditableTextBox)
								.Text(this, &SSkillCreator::OnGetCategoryText)
								.OnTextCommitted(this, &SSkillCreator::OnCategoryInputCommit)
						]
					] +

					// Description label
					SVerticalBox::Slot()
					.AutoHeight()
					.Padding(0.0f, 0.0f, 0.0f, 1.0f)
					[
						SNew(STextBlock)
						.Text(this, &SSkillCreator::GetDescHeader)
					] +
					// Description edit box
					SVerticalBox::Slot()
					.VAlign(VAlign_Fill)
					.Padding(0.0f, 0.0f, 0.0f, 5.0f)
					[
						SNew(SBox)
						.VAlign(VAlign_Fill)
						.HAlign(HAlign_Fill)
						[
							SNew(SMultiLineEditableTextBox)
							.AutoWrapText(true)
							.Text(this, &SSkillCreator::OnGetDescriptionText)
							.OnTextCommitted(this, &SSkillCreator::OnDescriptionInputCommit)
						]
					]
				] +
				SVerticalBox::Slot()
				.AutoHeight()
				.HAlign(HAlign_Right)
				.VAlign(VAlign_Bottom)
				.Padding(8)
				[
					SNew(SUniformGridPanel)
					.SlotPadding(FAppStyle::GetMargin("StandardDialog.SlotPadding"))
					.MinDesiredSlotWidth(FAppStyle::GetFloat("StandardDialog.MinDesiredSlotWidth"))
					.MinDesiredSlotHeight(FAppStyle::GetFloat("StandardDialog.MinDesiredSlotHeight")) +
					SUniformGridPanel::Slot(0, 0)
					[
						SNew(SButton)
						.HAlign(HAlign_Center)
						.ContentPadding(FAppStyle::GetMargin("StandardDialog.ContentPadding"))
						.OnClicked(this, &SSkillCreator::OnConfirmClicked)
						.Text(LOCTEXT("SkillCreatorOK", "OK"))
					] +
					SUniformGridPanel::Slot(1, 0)
					[
						SNew(SButton)
						.HAlign(HAlign_Center)
						.OnClicked(this, &SSkillCreator::OnCancelClicked)
						.Text(LOCTEXT("SkillCreatorCancel", "Cancel"))
						.ContentPadding(FAppStyle::GetMargin("StandardDialog.ContentPadding"))
					]
				] // SVerticalBox
			] // SBox
		] // SBorder
	]; // ChildSlot
}

bool SSkillCreator::DoCreation()
{
	const TSharedRef<SWindow> Window =
		SNew(SWindow)
		.MinHeight(500.0f)
		.MinWidth(400.0f)
		.ClientSize(FVector2D(400.0f, 500.0f))
		.SupportsMaximize(false)
		.SupportsMinimize(false)
		.Title(LOCTEXT("SkillCreatorTitle", "Create New Graph"))
		[
			AsShared()
		];

	SkillCreatorWindow = Window;

	GEditor->EditorAddModalWindow(Window);

	return bCreateConfirmed;
}

void SSkillCreator::Confirm()
{
	if (!IsGraphIDValid())
	{
		constexpr int32 MaxID = TNumericLimits<int32>::Max() >> 1;
		GEditor->OnModalMessageDialog(
			EAppMsgType::Ok, FText::Format(LOCTEXT("InvalidIDError", "ID is not valid! ID should large than 0 and less than {0}"), FText::AsNumber(MaxID)),
			LOCTEXT("CreateFailedTitle", "Failed"));
		return;
	}

	if (const UEnhancedSkillData* ExistData = FDataArchiveManager::Find<UEnhancedSkillData>(InputID))
	{
		const FString RepeatDataName = ExistData->Name;

		FFormatNamedArguments Args;
		Args.Add(TEXT("RepeatID"), FText::FromString(FString::FromInt(InputID)));
		Args.Add(TEXT("OldDataName"), FText::FromString(RepeatDataName));

		GEditor->OnModalMessageDialog(
			EAppMsgType::Ok, FText::Format(LOCTEXT("InvalidIDError", "ID is not valid! ID-{RepeatID} can not repeat, ExistDataName: {OldDataName}"), Args),
			LOCTEXT("CreateFailedTitle", "Failed"));

		return;
	}

	UEnhancedSkillData* CreatedData = FDataArchiveManager::Add<UEnhancedSkillData>(InputID);
	if (CreatedData)
	{
		CreatedData->ID = InputID;
		CreatedData->Name = InputName.ToString();
		CreatedData->Description = InputDescription;
		CreatedData->Category = InputCategory;
	}
	else
	{
		GEditor->OnModalMessageDialog(EAppMsgType::Ok, LOCTEXT("CreateNewDataFailed", "Create new data failed!"), LOCTEXT("CreateFailedTitle", "Failed"));
		return;
	}

	bCreateConfirmed = true;

	if (SkillCreatorWindow.IsValid())
	{
		SkillCreatorWindow.Pin()->RequestDestroyWindow();
	}
}

void SSkillCreator::Cancel()
{
	bCreateConfirmed = false;

	if (SkillCreatorWindow.IsValid())
	{
		SkillCreatorWindow.Pin()->RequestDestroyWindow();
	}
}

bool SSkillCreator::IsGraphIDValid() const
{
	return InputID > 0 && InputID < TNumericLimits<int32>::Max() >> 1;
}

FText SSkillCreator::OnGetIDText() const
{
	FNumberFormattingOptions NumberFormat;
	NumberFormat.SetUseGrouping(false);
	return FText::AsNumber(InputID, &NumberFormat);
}

void SSkillCreator::OnIDInputCommit(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType != ETextCommit::Type::OnCleared)
	{
		if (FCString::IsNumeric(*NewText.ToString()))
		{
			InputID = FCString::Atoi(*NewText.ToString());
		}
	}
}

FText SSkillCreator::OnGetNameText() const
{
	return FText::FromName(InputName);
}

void SSkillCreator::OnNameInputCommit(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType != ETextCommit::Type::OnCleared)
	{
		InputName = FName(*NewText.ToString());
	}
}

FText SSkillCreator::OnGetDescriptionText() const
{
	return FText::FromString(InputDescription);
}

void SSkillCreator::OnDescriptionInputCommit(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType != ETextCommit::Type::OnCleared)
	{
		InputDescription = NewText.ToString();
	}
}

FText SSkillCreator::OnGetCategoryText() const
{
	return FText::FromString(InputCategory);
}

void SSkillCreator::OnCategoryInputCommit(const FText& NewText, ETextCommit::Type CommitType)
{
	if (CommitType != ETextCommit::Type::OnCleared)
	{
		InputCategory = NewText.ToString();
	}
}

FReply SSkillCreator::OnConfirmClicked()
{
	Confirm();

	return FReply::Handled();
}

FReply SSkillCreator::OnCancelClicked()
{
	Cancel();

	return FReply::Handled();
}

FText SSkillCreator::GetIDHeader() const
{
	return LOCTEXT("GraphIDHeader", "ID");
}

FText SSkillCreator::GetNameHeader() const
{
	return LOCTEXT("GraphNameHeader", "Name");
}

FText SSkillCreator::GetDescHeader() const
{
	return LOCTEXT("GraphDescHeader", "Description");
}

FText SSkillCreator::GetCategoryHeader() const
{
	return LOCTEXT("GraphCategoryHeader", "Category");
}

SSkillBrowser::SSkillBrowser():
	PrimarySortMode(),
	SecondarySortMode(),
	bAllowDragging(false)
{
}

void SSkillBrowser::Construct(const FArguments& InArgs)
{
	CustomColumns = InArgs._CustomColumns;
	OnListMouseDoubleClickDelegate = InArgs._OnSkillDoubleClick;
	OnListMouseClickDelegate = InArgs._OnSkillClick;

	ColumnView = ConstructColumnView();

	FDetailsViewArgs Args;
	Args.bUpdatesFromSelection = false;
	Args.bLockable = false;
	Args.bAllowSearch = true;
	Args.NameAreaSettings = FDetailsViewArgs::ActorsUseNameArea;
	Args.bHideSelectionTip = true;
	Args.NotifyHook = this;
	Args.DefaultsOnlyVisibility = EEditDefaultsOnlyNodeVisibility::Show;

	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyDetailsWidget = PropertyModule.CreateDetailView(Args);
	PropertyDetailsWidget->SetVisibility(EVisibility::Visible);

	ChildSlot
	[
		SNew(SVerticalBox)
		+ SVerticalBox::Slot()
		  .HAlign(HAlign_Fill)
		  .VAlign(VAlign_Top)
		  .AutoHeight()
		[
			ConstructMenuBar()
		]
		+ SVerticalBox::Slot()
		  .HAlign(HAlign_Fill)
		  .VAlign(VAlign_Fill)
		[
			SNew(SHorizontalBox)
			+ SHorizontalBox::Slot()
			  .VAlign(VAlign_Fill)
			  .HAlign(HAlign_Fill)
			  .FillWidth(1.0f)
			[
				SNew(SVerticalBox)
				+ SVerticalBox::Slot()
				  .HAlign(HAlign_Fill)
				  .VAlign(VAlign_Top)
				  .AutoHeight()
				[
					SAssignNew(FilterTextBoxWidget, SSearchBox)
					.Visibility(EVisibility::Visible)
					.HintText(LOCTEXT("FilterSearch", "Search..."))
					.ToolTipText(LOCTEXT("FilterSearchHint", "Type here to search (pressing enter selects the results)"))
					.OnTextChanged(this, &SSkillBrowser::OnFilterTextChanged)
					.OnTextCommitted(this, &SSkillBrowser::OnFilterTextCommitted)
				]
				+ SVerticalBox::Slot()
				[
					ColumnView.ToSharedRef()
				]
			]
			+ SHorizontalBox::Slot()
			  .HAlign(HAlign_Right)
			  .VAlign(VAlign_Fill)
			  .AutoWidth()
			[
				PropertyDetailsWidget.ToSharedRef()
			]
		]
	];

	RebuildContent();
}

TSharedPtr<SSkillBrowserColumnView> SSkillBrowser::ConstructColumnView()
{
	{
		const FName IDColumnName = GET_MEMBER_NAME_CHECKED(UEnhancedSkillData, ID);
		CustomColumns.Emplace(IDColumnName, LOCTEXT("SkillColumnID", "ID"), LOCTEXT("SkillColumnIDToolTips", "Skill ID"),
		                      FOnGetCustomGraphColumnData::CreateStatic(&SSkillBrowser::OnGetBrowserColumnData),
		                      FOnGetCustomGraphColumnDisplayText::CreateStatic(&SSkillBrowser::OnGetBrowserColumnDisplayText),
		                      FOnSortGraphColumnData::CreateStatic(&SSkillBrowser::OnSortIDColumn));

		const FName NameColumnName = GET_MEMBER_NAME_CHECKED(UEnhancedSkillData, Name);
		CustomColumns.Emplace(NameColumnName, LOCTEXT("SkillColumnName", "Name"), LOCTEXT("SkillColumnNameToolTips", "Skill Name"),
		                      FOnGetCustomGraphColumnData::CreateStatic(&SSkillBrowser::OnGetBrowserColumnData),
		                      FOnGetCustomGraphColumnDisplayText::CreateStatic(&SSkillBrowser::OnGetBrowserColumnDisplayText));
	}

	TSharedPtr<SSkillBrowserColumnView> View;

	SAssignNew(View, SSkillBrowserColumnView)
		.OnMouseButtonClick(this, &SSkillBrowser::OnListMouseButtonClick)
		.OnMouseButtonDoubleClick(this, &SSkillBrowser::OnListMouseButtonDoubleClick)
		.OnContextMenuOpening(this, &SSkillBrowser::OnConstructItemContextMenu)
		.SelectionMode(ESelectionMode::Type::Single)
		.ListItemsSource(&FilteredSourceItem)
		.OnGenerateRow(this, &SSkillBrowser::MakeColumnViewWidget)
		.HeaderRow(SAssignNew(ColumnViewHeader, SHeaderRow).ResizeMode(ESplitterResizeMode::FixedSize));

	return View;
}

FString SSkillBrowser::OnGetBrowserColumnData(UEnhancedSkillData* GraphData, FName ColumnName)
{
	if (const UStruct* Struct = GraphData ? GraphData->GetClass() : nullptr)
	{
		for (TFieldIterator<FProperty> Property(Struct); Property; ++Property)
		{
			if (Property->GetFName() == ColumnName)
			{
				const void* Value = Property->ContainerPtrToValuePtr<uint8>(GraphData);

				// convert the property to a FJsonValue
				TSharedPtr<FJsonValue> JsonValue = FJsonObjectConverter::UPropertyToJsonValue(*Property, Value);
				if (JsonValue.IsValid())
				{
					return JsonValue->AsString();
				}
			}
		}
	}

	return TEXT("");
}

FText SSkillBrowser::OnGetBrowserColumnDisplayText(UEnhancedSkillData* GraphData, FName ColumnName)
{
	return FText::FromString(OnGetBrowserColumnData(GraphData, ColumnName));
}

bool SSkillBrowser::OnSortIDColumn(const FString& Lhs, const FString& Rhs, EColumnSortMode::Type SortMode)
{
	const int32 LhsID = FCString::Atoi(*Lhs);
	const int32 RhsID = FCString::Atoi(*Rhs);
	return SortMode == EColumnSortMode::Ascending ? LhsID < RhsID : LhsID > RhsID;
}

TSharedRef<SWidget> SSkillBrowser::ConstructMenuBar()
{
	FEnhancedAbilityEditorModule& EditorModule = FModuleManager::LoadModuleChecked<FEnhancedAbilityEditorModule>(UE_MODULE_NAME);

	BindCommands();
	RegisterMainMenu();

	const TSharedPtr<FExtender> Extenders = EditorModule.GetMenuExtensibilityManager()->GetAllExtenders();
	const FToolMenuContext MenuContext(BrowserCommands, Extenders.ToSharedRef());

	// Create the menu bar!
	TSharedRef<SWidget> MenuBarWidget = UToolMenus::Get()->GenerateWidget(BrowserMainMenuName, MenuContext);

	return MenuBarWidget;
}

void SSkillBrowser::BindCommands()
{
	BrowserCommands = MakeShared<FUICommandList>();

	BrowserCommands->MapAction(FSkillBrowserCommands::Get().CreateNew, FExecuteAction::CreateSP(this, &SSkillBrowser::CreateNew));
	BrowserCommands->MapAction(FSkillBrowserCommands::Get().LoadAll, FExecuteAction::CreateSP(this, &SSkillBrowser::LoadAll));
	BrowserCommands->MapAction(FSkillBrowserCommands::Get().SaveAll, FExecuteAction::CreateSP(this, &SSkillBrowser::SaveAll));
}

void SSkillBrowser::RegisterMainMenu()
{
	UToolMenus* ToolMenus = UToolMenus::Get();
	if (ToolMenus->IsMenuRegistered(BrowserMainMenuName))
	{
		return;
	}

	RegisterFileMenu();

	UToolMenu* MenuBar = ToolMenus->RegisterMenu(BrowserMainMenuName, NAME_None, EMultiBoxType::MenuBar);
	MenuBar->AddSubMenu(
		"MainMenu",
		NAME_None,
		"File",
		LOCTEXT("FileMenu", "File"),
		LOCTEXT("FileMenu_ToolTip", "Open the file menu")
	);
}

void SSkillBrowser::RegisterFileMenu()
{
	UToolMenus* ToolMenus = UToolMenus::Get();
	UToolMenu* FileMenu = ToolMenus->RegisterMenu(BrowserFileSubMenuName);

	FToolMenuSection& FileLoadAndSaveSection = FileMenu->AddSection("CreateNewGraph", LOCTEXT("CreateNewLabel", "Create"));
	FileLoadAndSaveSection.AddMenuEntry(FSkillBrowserCommands::Get().CreateNew);
	FileLoadAndSaveSection.AddMenuEntry(FSkillBrowserCommands::Get().LoadAll);
	FileLoadAndSaveSection.AddMenuEntry(FSkillBrowserCommands::Get().SaveAll);
}

void SSkillBrowser::CreateNew()
{
	const TSharedRef<SSkillCreator> SkillCreator = SNew(SSkillCreator);

	if (SkillCreator->DoCreation())
	{
		RebuildContent();
	}
}

void SSkillBrowser::LoadAll()
{
	FDataArchiveManager::Load<UEnhancedSkillData>();
}

void SSkillBrowser::SaveAll()
{
	FDataArchiveManager::SaveAll<UEnhancedSkillData>();
}

void SSkillBrowser::RebuildContent()
{
	FilteredSourceItem.Empty();

	TArray<UEnhancedSkillData*> AllData = FDataArchiveManager::GetAll<UEnhancedSkillData>();
	for (UEnhancedSkillData* GraphData : AllData)
	{
		TSharedPtr<FSkillBrowserItem> SourceItem = MakeShared<FSkillBrowserItem>(GraphData);
		SourceItem->UpdateCustomColumnValue(CustomColumns);
		if (IsDataMatched(SourceItem, SearchText))
		{
			FilteredSourceItem.Add(SourceItem);
		}
	}

	PrimarySortedColumn = CustomColumns[0].ColumnName;
	PrimarySortMode = EColumnSortMode::Ascending;

	SortSourceItems();

	ColumnViewHeader->ClearColumns();
	for (FSkillBrowserCustomColumn& Column : CustomColumns)
	{
		ColumnViewHeader->AddColumn(
			SHeaderRow::Column(Column.ColumnName)
			.FillWidth(300)
			.SortMode(this, &SSkillBrowser::GetColumnSortMode, Column.ColumnName)
			.SortPriority(this, &SSkillBrowser::GetColumnSortPriority, Column.ColumnName)
			.OnSort(FOnSortModeChanged::CreateSP(this, &SSkillBrowser::OnSortColumnHeader))
			.DefaultLabel(Column.DisplayName)
		);
	}

	ColumnView->RequestListRefresh();
}

// ReSharper disable once CppPassValueParameterByConstReference
TSharedRef<ITableRow> SSkillBrowser::MakeColumnViewWidget(const TSharedPtr<FSkillBrowserItem> AssetItem, const TSharedRef<STableViewBase>& OwnerTable)
{
	if (!ensure(AssetItem.IsValid()))
	{
		return SNew(STableRow<TSharedPtr<FSkillBrowserItem>>, OwnerTable)
			.Style(FAppStyle::Get(), "TableView.Row");
	}

	AssetItem->UpdateCustomColumnValue(CustomColumns);

	return
		SNew(SSkillBrowserColumnRow, OwnerTable)
		.AssetItem(AssetItem)
		.OnDragDetected(this, &SSkillBrowser::OnDraggingAssetItem)
		.Cursor(bAllowDragging ? EMouseCursor::GrabHand : EMouseCursor::Default);
}

EColumnSortMode::Type SSkillBrowser::GetColumnSortMode(const FName ColumnId) const
{
	if (ColumnId == PrimarySortedColumn)
	{
		return PrimarySortMode;
	}

	if (ColumnId == SecondarySortedColumn)
	{
		return SecondarySortMode;
	}

	return EColumnSortMode::None;
}

EColumnSortPriority::Type SSkillBrowser::GetColumnSortPriority(const FName ColumnId) const
{
	if (ColumnId == PrimarySortedColumn)
	{
		return EColumnSortPriority::Primary;
	}

	if (ColumnId == SecondarySortedColumn)
	{
		return EColumnSortPriority::Secondary;
	}

	return EColumnSortPriority::Max; // No specific priority.
}

void SSkillBrowser::OnSortColumnHeader(const EColumnSortPriority::Type SortPriority, const FName& ColumnId, const EColumnSortMode::Type NewSortMode)
{
	if (SortPriority == EColumnSortPriority::Primary)
	{
		PrimarySortedColumn = ColumnId;
		PrimarySortMode = NewSortMode;

		if (ColumnId == SecondarySortedColumn) // Cannot be primary and secondary at the same time.
		{
			SecondarySortedColumn = FName();
			SecondarySortMode = EColumnSortMode::None;
		}
	}
	else if (SortPriority == EColumnSortPriority::Secondary)
	{
		SecondarySortedColumn = ColumnId;
		SecondarySortMode = NewSortMode;
	}

	SortSourceItems();

	ColumnView->RequestListRefresh();
}

FReply SSkillBrowser::OnDraggingAssetItem(const FGeometry& MyGeometry, const FPointerEvent& MouseEvent) const
{
	return FReply::Unhandled();
}

// ReSharper disable once CppPassValueParameterByConstReference
void SSkillBrowser::OnListMouseButtonClick(const TSharedPtr<FSkillBrowserItem> AssetItem) const
{
	if (AssetItem.IsValid())
	{
		PropertyDetailsWidget->SetObject(AssetItem->Data.Get());

		OnListMouseClickDelegate.ExecuteIfBound(AssetItem->Data.Get());
	}
}

// ReSharper disable once CppPassValueParameterByConstReference
void SSkillBrowser::OnListMouseButtonDoubleClick(const TSharedPtr<FSkillBrowserItem> AssetItem) const
{
	if (AssetItem.IsValid())
	{
		OnListMouseDoubleClickDelegate.ExecuteIfBound(AssetItem->Data.Get());
	}
}

TSharedPtr<SWidget> SSkillBrowser::OnConstructItemContextMenu() const
{
	FMenuBuilder MenuBuilder(true, BrowserItemMenuCommands);

	MenuBuilder.BeginSection("BasicOperations", LOCTEXT("BasicOperationsHeader", "Skill Data Actions"));
	{
		MenuBuilder.AddMenuEntry(FGenericCommands::Get().Delete);
		MenuBuilder.AddMenuEntry(FGenericCommands::Get().Duplicate);
		MenuBuilder.AddMenuEntry(FGenericCommands::Get().Rename);
	}
	MenuBuilder.EndSection();

	return MenuBuilder.MakeWidget();
}

void SSkillBrowser::SortSourceItems()
{
	auto Compare = [this](const TSharedPtr<FSkillBrowserItem>& Lhs, const TSharedPtr<FSkillBrowserItem>& Rhs, const FName& ColumnId, EColumnSortMode::Type SortMode)
	{
		const FString LhsData = Lhs->GetColumnData(ColumnId);
		const FString RhsData = Rhs->GetColumnData(ColumnId);

		const FSkillBrowserCustomColumn* FoundColumn = CustomColumns.FindByPredicate([ColumnId](const FSkillBrowserCustomColumn& Column)
		{
			return Column.ColumnName == ColumnId;
		});

		if (FoundColumn && FoundColumn->OnSortColumnData.IsBound())
		{
			return FoundColumn->OnSortColumnData.Execute(LhsData, RhsData, SortMode);
		}

		return SortMode == EColumnSortMode::Ascending ? LhsData < RhsData : LhsData > RhsData;
	};

	FilteredSourceItem.Sort([&](const TSharedPtr<FSkillBrowserItem>& Lhs, const TSharedPtr<FSkillBrowserItem>& Rhs)
	{
		if (Compare(Lhs, Rhs, PrimarySortedColumn, PrimarySortMode))
		{
			return true;
		}

		if (Compare(Rhs, Lhs, PrimarySortedColumn, PrimarySortMode))
		{
			return false;
		}

		return SecondarySortedColumn.IsNone() ? false : Compare(Lhs, Rhs, SecondarySortedColumn, SecondarySortMode);
	});
}

void SSkillBrowser::OnFilterTextChanged(const FText& InSearchText)
{
	SetSearchBoxText(InSearchText);
}

void SSkillBrowser::OnFilterTextCommitted(const FText& InSearchText, ETextCommit::Type CommitInfo)
{
	SetSearchBoxText(InSearchText);
}

void SSkillBrowser::SetSearchBoxText(const FText& InSearchText)
{
	SearchText = InSearchText;
	RebuildContent();
}

bool SSkillBrowser::IsDataMatched(const TSharedPtr<FSkillBrowserItem>& BrowserItem, const FText& InSearchText)
{
	if (InSearchText.IsEmpty())
	{
		return true;
	}

	for (const TTuple<FName, FString>& Data : BrowserItem.Get()->CachedCustomColumnData)
	{
		if (Data.Value.Contains(InSearchText.ToString()))
		{
			return true;
		}
	}
	return false;
}

#undef LOCTEXT_NAMESPACE
