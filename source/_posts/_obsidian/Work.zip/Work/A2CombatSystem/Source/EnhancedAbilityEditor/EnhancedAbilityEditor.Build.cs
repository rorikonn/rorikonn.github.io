﻿using UnrealBuildTool;

public class EnhancedAbilityEditor : ModuleRules
{
    public EnhancedAbilityEditor(ReadOnlyTargetRules Target) : base(Target)
    {
        PCHUsage = ModuleRules.PCHUsageMode.UseExplicitOrSharedPCHs;

        PublicDependencyModuleNames.AddRange(
            new string[]
            {
                "Core",
                "Json",
                "JsonUtilities",
                "AssetTools",
                "ToolMenus",
                "GameplayAbilitiesEditor",
                "GraphEditor",
                "EnhancedAbility",
                "EnhancedInput",
                "InputCore",
                "Persona",
                "CombatCommon"
            }
        );


        PrivateDependencyModuleNames.AddRange(
            new string[]
            {
                "CoreUObject",
                "Engine",
                "Slate",
                "SlateCore",
                "UnrealEd",
                "GameplayAbilities",
                "BlueprintGraph",
                "Kismet",
                "EditorStyle",
                "AnimGraphRuntime",
                "AnimGraph",
                "Projects",
                "MessageLog",
                "ApplicationCore", 
                "WorkspaceMenuStructure", 
                "Sequencer",
                "MovieScene", 
                "UniversalTimeline",
                "UniversalTimelineEditor",
                "AnimationBlueprintLibrary", 
            }
        );
    }
}