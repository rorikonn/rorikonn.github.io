﻿// Copyright 2022 Mickael Daniel. All Rights Reserved.

#pragma once

#include "CoreMinimal.h"

ENHANCEDABILITYEDITOR_API DECLARE_LOG_CATEGORY_EXTERN(LogEnhancedAbilityEditor, Display, All);

#define CA_EDITOR_LOG(Verbosity, Format, ...) \
{ \
UE_LOG(LogEnhancedAbilityEditor, Verbosity, Format, ##__VA_ARGS__); \
}
