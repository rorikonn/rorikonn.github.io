﻿//


#include "EnhancedAbilityEditorModule.h"

#include "EnhancedAbilityEditorLog.h"
#include "UniversalTimelineEditor.h"
#include "WorkspaceMenuStructure.h"
#include "WorkspaceMenuStructureModule.h"
#include "Details\EnhancedSkillIDCustomization.h"
#include "SkillGraph/Factories/SkillGraphNodeFactory.h"
#include "Editors/SSkillBrowser.h"
#include "Skill/EnhancedSkillTypes.h"


#define LOCTEXT_NAMESPACE "FEnhancedAbilityEditorModule"

FName FEnhancedAbilityEditorModule::SkillBrowserTabName = TEXT("SkillBrowser");

static FAutoConsoleCommand CCmdOpenGraphBrowser = FAutoConsoleCommand(
	TEXT("ea.OpenSkillBrowser"),
	TEXT("Bring up Skill Browser Tab"),
	FConsoleCommandDelegate::CreateLambda([]()
	{
		FGlobalTabmanager::Get()->TryInvokeTab(FEnhancedAbilityEditorModule::SkillBrowserTabName);
	}));

void FEnhancedAbilityEditorCommands::RegisterCommands()
{
	UI_COMMAND(OpenEditorWindow, "SkillBrowser", "Bring Up EnhancedAbilityEditor Window", EUserInterfaceActionType::Button, FInputChord());
}

void FEnhancedAbilityEditorModule::StartupModule()
{
	CA_EDITOR_LOG(Verbose, TEXT("EnhancedAbilityEditorModule - Startup Module"))

	// Init Commands
	FEnhancedAbilityEditorCommands::Register();
	FSkillBrowserCommands::Register();

	// Init Style
	FEnhancedAbilityEditorStyle::Initialize();
	FEnhancedAbilityEditorStyle::ReloadTextures();

	RegisterEntry();
	RegisterFactories();
	RegisterDetailCustomizations();

	MenuExtensibilityManager = MakeShared<FExtensibilityManager>();

	FUniversalTimelineEditorModule::Get().RegisterTrackSubMenuIcon(
		TEXT("Skill Action"), FSlateIcon(FEnhancedAbilityEditorStyle::GetStyleSetName(), TEXT("TrackEntryMenuIcon.SkillAction")));
}

void FEnhancedAbilityEditorModule::ShutdownModule()
{
	UnregisterEntry();
	UnregisterFactories();
	UnregisterDetailCustomizations();

	FEnhancedAbilityEditorStyle::Shutdown();

	FEnhancedAbilityEditorCommands::Unregister();
	FSkillBrowserCommands::Unregister();

	FUniversalTimelineEditorModule::Get().UnregisterTrackSubMenuIcon(TEXT("Skill Action"));
}

void FEnhancedAbilityEditorModule::RegisterEntry()
{
	// Register Editor Entry
	FGlobalTabmanager::Get()
		->RegisterNomadTabSpawner(SkillBrowserTabName, FOnSpawnTab::CreateRaw(this, &FEnhancedAbilityEditorModule::OnSpawnSkillBrowserTab))
		.SetDisplayName(LOCTEXT("SkillBrowserTitle", "Skill Browser"))
		.SetTooltipText(LOCTEXT("SkillBrowserTooltip", "Opend the Skill Browser Tab"))
		.SetGroup(WorkspaceMenu::GetMenuStructure().GetToolsCategory())
		.SetIcon(FSlateIcon(FEnhancedAbilityEditorStyle::GetStyleSetName(), "EntryIcon.SkillBrowser"));
}

void FEnhancedAbilityEditorModule::UnregisterEntry()
{
	FGlobalTabmanager::Get()->UnregisterNomadTabSpawner(SkillBrowserTabName);
}

void FEnhancedAbilityEditorModule::RegisterFactories()
{
	GraphNodeFactory = MakeShared<FSkillGraphNodeFactory>();
	FEdGraphUtilities::RegisterVisualNodeFactory(GraphNodeFactory);
}

void FEnhancedAbilityEditorModule::UnregisterFactories()
{
	FEdGraphUtilities::UnregisterVisualNodeFactory(GraphNodeFactory);
	GraphNodeFactory = nullptr;
}

void FEnhancedAbilityEditorModule::RegisterDetailCustomizations()
{
	// import the PropertyEditor module...
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");

	PropertyModule.RegisterCustomPropertyTypeLayout(FSkillID::StaticStruct()->GetFName(), FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FEnhancedSkillIDCustomization::MakeInstance));

	PropertyModule.NotifyCustomizationModuleChanged();
}

void FEnhancedAbilityEditorModule::UnregisterDetailCustomizations()
{
	if (FModuleManager::Get().IsModuleLoaded("PropertyEditor"))
	{
		// unregister properties when the module is shutdown
		FPropertyEditorModule& PropertyModule = FModuleManager::GetModuleChecked<FPropertyEditorModule>("PropertyEditor");
		PropertyModule.UnregisterCustomPropertyTypeLayout(FSkillID::StaticStruct()->GetFName());

		PropertyModule.NotifyCustomizationModuleChanged();
	}
}

TSharedRef<SDockTab> FEnhancedAbilityEditorModule::OnSpawnSkillBrowserTab(const FSpawnTabArgs& SpawnTabArgs)
{
	return SNew(SDockTab)
		.TabRole(NomadTab)
		[
			SNew(SSkillBrowser)
			.OnSkillDoubleClick_Raw(this, &FEnhancedAbilityEditorModule::OnSkillBrowserDoubleClick)
		];
}

void FEnhancedAbilityEditorModule::OnSkillBrowserDoubleClick(UEnhancedSkillData* Skill)
{
}

#undef LOCTEXT_NAMESPACE

IMPLEMENT_MODULE(FEnhancedAbilityEditorModule, EnhancedAbilityEditor)
