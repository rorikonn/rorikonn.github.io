﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ExpressionDefinition.h"

#include "ExpressionInstruction.generated.h"

struct FExpressionAtom;
struct FExpressionContext;

UENUM()
enum class EExpressionInstruction : uint8
{
	Move,
	MoveTo,
	Jump,
	JumpZero,
	Pop,
	Peek,
	PushVariable,
	PushString,
	PushConst,
	Cast,
	Add,
	Sub,
	Mul,
	Div,
	Mod,
	Greater,
	Less,
	GreaterEqual,
	LessEqual,
	Equal,
	NotEqual,
	Negative,
	Or,
	And,
	Not,
	Print,
	CallFunction,
	Return,
	Max,
};

extern EXPRESSIONRUNTIME_API int32 LatestInstructionVersion();

USTRUCT(meta=(IgnoreDataWrapperGen))
struct FExpressionInstructionBuffer
{
	GENERATED_BODY()

	struct FHeader
	{
		uint8 Version;
		uint8 HeaderSize;
		uint16 BuildInBlockSize;
		int32 StringBufferOffset;
	};

	struct FInstructionHeader
	{
		uint8 Type;
		uint16 Size;
		int32 Next;
	};

	inline static const int32 HeaderSize = FMath::Max(StaticCast<uint32>(sizeof(FHeader)), VarAlignment);
	inline static const int32 InstructionHeaderSize = FMath::Max(StaticCast<uint32>(sizeof(FInstructionHeader)), VarAlignment);

	UPROPERTY()
	TArray<uint8> Buffer;

	FExpressionInstructionBuffer()
	{
		Reset();
	}

	FExpressionInstructionBuffer(TArray<uint8> InBuffer)
		: Buffer(MoveTemp(InBuffer))
	{
	}

	void Reset()
	{
		Buffer.Empty(4096);
	}

#if ENABLE_EXPRESSION_COMPILER
	void TryInitializeHeader()
	{
		if (Buffer.IsEmpty())
		{
			Buffer.AddZeroed(HeaderSize);
			FHeader* HeaderPtr = reinterpret_cast<FHeader*>(Buffer.GetData());
			HeaderPtr->Version = LatestInstructionVersion();
			HeaderPtr->HeaderSize = HeaderSize;
		}
	}

	void SetBuildInVarSize(int32 Size)
	{
		TryInitializeHeader();
		FHeader* HeaderPtr = reinterpret_cast<FHeader*>(Buffer.GetData());
		HeaderPtr->BuildInBlockSize = Size;
	}

	void SetStringBufferOffset(int32 Offset)
	{
		TryInitializeHeader();
		FHeader* HeaderPtr = reinterpret_cast<FHeader*>(Buffer.GetData());
		HeaderPtr->StringBufferOffset = Offset;
	}

	int32 BufferTop()
	{
		TryInitializeHeader();
		return Buffer.Num();
	}

	uint8* AddInstruction(EExpressionInstruction Instruction)
	{
		TryInitializeHeader();
		Buffer.AddZeroed(InstructionHeaderSize);

		const FInstructionHeader Header = {StaticCast<uint8>(Instruction), StaticCast<uint16>(InstructionHeaderSize), Buffer.Num()};
		uint8* HeaderAddress = &Buffer.GetData()[Buffer.Num() - InstructionHeaderSize];
		FMemory::Memcpy(HeaderAddress, &Header, sizeof(FInstructionHeader));

		UE_LOG(LogExpressionCompiler, Log, TEXT("push instruction [%d]{%s, %d, %d}"), Buffer.Num() - InstructionHeaderSize,
		       *StaticEnum<EExpressionInstruction>()->GetNameByValue(Header.Type).ToString(), Header.Size, Header.Next);

		return HeaderAddress;
	}

	uint8* AddInstruction(EExpressionInstruction Instruction, const void* DataPtr, uint32 DataSize)
	{
		TryInitializeHeader();
		const uint32 AlignedDataSize = FMath::Max(DataSize, VarAlignment);
		Buffer.AddZeroed(InstructionHeaderSize + AlignedDataSize);

		const FInstructionHeader Header = {StaticCast<uint8>(Instruction), StaticCast<uint16>(InstructionHeaderSize + AlignedDataSize), Buffer.Num()};
		uint8* HeaderAddress = &Buffer.GetData()[Buffer.Num() - InstructionHeaderSize - AlignedDataSize];
		FMemory::Memcpy(HeaderAddress, &Header, sizeof(FInstructionHeader));

		uint8* DataAddress = &Buffer.GetData()[Buffer.Num() - AlignedDataSize];
		FMemory::Memcpy(DataAddress, DataPtr, DataSize);

		UE_LOG(LogExpressionCompiler, Log, TEXT("push instruction [%d]{%s, %d, %d}, data:[%d]"), Buffer.Num() - InstructionHeaderSize - AlignedDataSize,
		       *StaticEnum<EExpressionInstruction>()->GetNameByValue(Header.Type).ToString(), Header.Size, Header.Next, Buffer.Num() - AlignedDataSize);

		return HeaderAddress;
	}

	template <typename Type>
	uint8* AddInstruction(EExpressionInstruction Instruction, Type& Data)
	{
		TryInitializeHeader();
		const uint32 AlignedDataSize = FMath::Max(StaticCast<uint32>(sizeof(Type)), VarAlignment);
		Buffer.AddZeroed(InstructionHeaderSize + AlignedDataSize);

		const FInstructionHeader Header = {StaticCast<uint8>(Instruction), StaticCast<uint16>(InstructionHeaderSize + AlignedDataSize), Buffer.Num()};
		uint8* HeaderAddress = &Buffer.GetData()[Buffer.Num() - InstructionHeaderSize - AlignedDataSize];
		FMemory::Memcpy(HeaderAddress, &Header, sizeof(FInstructionHeader));

		uint8* DataAddress = &Buffer.GetData()[Buffer.Num() - AlignedDataSize];
		FMemory::Memcpy(DataAddress, &Data, sizeof(Type));

		UE_LOG(LogExpressionCompiler, Log, TEXT("push instruction [%d]{%s, %d, %d}, data:[%d]"), Buffer.Num() - InstructionHeaderSize - AlignedDataSize,
		       *StaticEnum<EExpressionInstruction>()->GetNameByValue(Header.Type).ToString(), Header.Size, Header.Next, Buffer.Num() - AlignedDataSize);

		return HeaderAddress;
	}
#endif
};

struct FExpressionExecutor
{
	using FHeader = FExpressionInstructionBuffer::FHeader;
	using FInstructionHeader = FExpressionInstructionBuffer::FInstructionHeader;
	inline static const int32 InstructionHeaderSize = FMath::Max(StaticCast<uint32>(sizeof(FInstructionHeader)), VarAlignment);
	
	FExpressionExecutor(const uint8* Buffer, int32 BufferLength)
		: Buffer(Buffer),
		  BufferLength(BufferLength),
		  Header(*reinterpret_cast<const FHeader*>(Buffer))
	{
		Reset();
	}

	FExpressionContext* GetContext() const
	{
		return ExprContext;
	}

	void Reset(FExpressionContext* InExprContext = nullptr)
	{
		CurrentInstruction = Header.HeaderSize;
		ExprContext = InExprContext;
		RetValue.Empty();
	}

	template <typename T>
	bool GetRetValue(T& Value)
	{
		if (RetValue.GetType() == TVariantTraits<T>::GetType())
		{
			Value = RetValue.GetValue<T>();
			return true;
		}

		return false;
	}

	static void ExecuteExpression(FExpressionExecutor& Executor, FExpressionExecutionStack& Stack);

private:
	friend struct FPrintInstruction;
	friend struct FReturnInstruction;
	friend struct FJumpZeroInstruction;
	friend struct FPushStringInstruction;
	friend struct FCallFunctionInstruction;
	
	FExpressionContext* ExprContext;

	const uint8* Buffer;
	int32 BufferLength;

	const FHeader& Header;

	int32 CurrentInstruction;
	FVariant RetValue;

	bool IsValidInstructionAddress(int32 Address) const
	{
		return Address >= 0 && Address < Header.StringBufferOffset;
	}

	bool IsValidStringOffset(int32 StringOffset) const
	{
		return StringOffset >= 0 && Header.StringBufferOffset + StringOffset < BufferLength;
	}

	void Seek(int32 Address)
	{
		CurrentInstruction = Address;
	}

	bool ReadInstruction(FInstructionHeader& OutHeader, const void*& OutDataPtr)
	{
		if (CurrentInstruction + InstructionHeaderSize - 1 < Header.StringBufferOffset)
		{
			const FInstructionHeader* HeaderPtr = reinterpret_cast<const FInstructionHeader*>(&Buffer[CurrentInstruction]);
			OutHeader = *HeaderPtr;

			if (IsValidInstructionAddress(CurrentInstruction + InstructionHeaderSize))
			{
				OutDataPtr = &Buffer[CurrentInstruction + InstructionHeaderSize];
			}

			CurrentInstruction = OutHeader.Next;

			UE_LOG(LogExpression, Log, TEXT("Read Instruction %s next: %d"), *StaticEnum<EExpressionInstruction>()->GetNameByValue(OutHeader.Type).ToString(), OutHeader.Next);

			return true;
		}

		return false;
	}

	bool ReadString(int32 StringOffset, FString& OutString) const
	{
		if (IsValidStringOffset(StringOffset))
		{
			const int32 CharNum = *reinterpret_cast<const int32*>(&Buffer[Header.StringBufferOffset + StringOffset]);
			const uint8* CharPtr = &Buffer[Header.StringBufferOffset + StringOffset + sizeof(int32)];
			OutString = BytesToString(CharPtr, CharNum);
			return true;
		}

		return false;
	}

	template <typename T>
	void Return(T Value)
	{
		RetValue = Value;
		Return();
	}

	void Return()
	{
		CurrentInstruction = Header.StringBufferOffset;
	}
};

DECLARE_DELEGATE_ThreeParams(FInstructionExecutFunc, const void*, FExpressionExecutor&, FExpressionExecutionStack&);

extern EXPRESSIONRUNTIME_API TArray<FInstructionExecutFunc>& GetInstructionSet(int32 Version);

struct IExpressionInstruction
{
	virtual ~IExpressionInstruction() = default;

#if ENABLE_EXPRESSION_COMPILER
	struct FSerializer
	{
		// Serialize
		FExpressionInstructionBuffer& InstructionBuffer;
		TMap<FString, int32> LabelAddress;
		TArray<uint8> StringBuffer;
		TMap<FString, int32> ConstStringMap;

		FSerializer(FExpressionInstructionBuffer& OutBuffer)
			: InstructionBuffer(OutBuffer)
		{
		}

		void AddLabel(FString Label)
		{
			ensure(!LabelAddress.Contains(Label));

			LabelAddress.Emplace(Label, InstructionBuffer.BufferTop());
		}

		int32 GetLabelAddress(const FString& Label)
		{
			const int32* Address = LabelAddress.Find(Label);
			check(Address != nullptr);
			return *Address;
		}

		int32 AddString(const FString& String)
		{
			if (const int32* Offset = ConstStringMap.Find(String))
			{
				return *Offset;
			}

			const int32 StringOffset = StringBuffer.Num();

			const int32 CharNum = String.Len();
			StringBuffer.AddZeroed(CharNum + sizeof(int32));
			FMemory::Memcpy(&StringBuffer.GetData()[StringOffset], &CharNum, sizeof(int32));
			StringToBytes(String, &StringBuffer.GetData()[StringOffset + sizeof(int32)], CharNum);
			ConstStringMap.Add(String, StringOffset);
			return StringOffset;
		}
	};

	static void Serialize(TArray<IExpressionInstruction*> InstructionSet, FSerializer& Serializer)
	{
		if (InstructionSet.IsEmpty())
		{
			return;
		}

		for (IExpressionInstruction* Instruction : InstructionSet)
		{
			Instruction->Serialize(Serializer);
		}

		for (IExpressionInstruction* Instruction : InstructionSet)
		{
			Instruction->PostSerialize(Serializer);
		}

		Serializer.InstructionBuffer.SetStringBufferOffset(Serializer.InstructionBuffer.Buffer.Num());
		Serializer.InstructionBuffer.Buffer.Append(Serializer.StringBuffer);
	}

	virtual void Serialize(FSerializer& Serializer) = 0;
	virtual void PostSerialize(FSerializer& Serializer) = 0;
#endif
};

struct FBuildInInfo : IExpressionInstruction
{
	FBuildInInfo(int32 VarSize)
		: VarSize(VarSize)
	{
	}

	int32 VarSize;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.SetBuildInVarSize(VarSize);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif
};

struct LabelInstruction : IExpressionInstruction
{
	LabelInstruction(const FString& Label)
		: Label(Label)
	{
	}

	FString Label;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.AddLabel(Label);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif
};

// Move stack top forward, or back if negative
struct FMoveInstruction : IExpressionInstruction
{
	FMoveInstruction(int32 Step)
	{
		Data.Step = Step;
	}

	struct FData
	{
		int32 Step;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Move, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);
		Stack.Move(DataPtr->Step);
	}
};

// Move stack to given address
struct FMoveToInstruction : IExpressionInstruction
{
	FMoveToInstruction(int32 Address)
	{
		Data.Address = Address;
	}

	struct FData
	{
		int32 Address;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::MoveTo, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	// ReSharper disable once CppParameterMayBeConstPtrOrRef
	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);
		Stack.MoveTo(DataPtr->Address);
	}
};

struct FJumpInstruction : IExpressionInstruction
{
	FJumpInstruction(const FString& Label)
		: Label(Label),
		  HeaderPtr(nullptr)
	{
	}

	FString Label;

	uint8* HeaderPtr;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		HeaderPtr = Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Jump);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
		FExpressionInstructionBuffer::FInstructionHeader* Header = reinterpret_cast<FExpressionInstructionBuffer::FInstructionHeader*>(HeaderPtr);
		Header->Next = Serializer.GetLabelAddress(Label);
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
	}
};

struct FJumpZeroInstruction : IExpressionInstruction
{
	FJumpZeroInstruction(int32 ValueSize, const FString& Label)
		: Label(Label),
		  HeaderPtr(nullptr)
	{
		Data.ValueSize = ValueSize;
	}

	FString Label;
	uint8* HeaderPtr;

	struct FData
	{
		int32 ValueSize;
		int32 Address;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	static bool ValueTypeAllowed(EVarType ValueType)
	{
		return ValueType == EVarType::Bool || ValueType == EVarType::Int || ValueType == EVarType::Float || ValueType == EVarType::Target;
	}

	virtual void Serialize(FSerializer& Serializer) override
	{
		HeaderPtr = Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::JumpZero, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
		FData* DataPtr = reinterpret_cast<FData*>(HeaderPtr + FExpressionInstructionBuffer::InstructionHeaderSize);
		DataPtr->Address = Serializer.GetLabelAddress(Label);
	}
#endif

	static uint8* GetZeroBlock()
	{
		static uint8 Ret[256];
		FMemory::Memzero(Ret, 256);
		return Ret;
	}

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const void* ValuePtr = Stack.Pop(DataPtr->ValueSize);

		static uint8* ZeroBlock = GetZeroBlock();
		if (!FMemory::Memcmp(ValuePtr, ZeroBlock, DataPtr->ValueSize))
		{
			Executor.Seek(DataPtr->Address);
		}
	}
};

// Pop stack value of [Size] and copy to target [Addr] 
struct FPopInstruction : IExpressionInstruction
{
	FPopInstruction(int32 Size, int32 Addr)
	{
		Data.Size = Size;
		Data.Addr = Addr;
	}

	struct FData
	{
		int32 Size;
		int32 Addr;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Pop, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const void* ValuePtr = Stack.Pop(DataPtr->Size);
		void* DestPtr = Stack.Find(DataPtr->Addr);
		FMemory::Memcpy(DestPtr, ValuePtr, DataPtr->Size);
	}
};

// Peek stack value of [Size] and copy to target [Addr] 
struct FPeekInstruction : IExpressionInstruction
{
	FPeekInstruction(int32 Size, int32 Addr)
	{
		Data.Size = Size;
		Data.Addr = Addr;
	}

	struct FData
	{
		int32 Size;
		int32 Addr;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Peek, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	// ReSharper disable once CppParameterMayBeConstPtrOrRef
	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		void* ValuePtr;
		Stack.Peek(DataPtr->Size, ValuePtr);

		void* DestPtr = Stack.Find(DataPtr->Addr);

		FMemory::Memcpy(DestPtr, ValuePtr, DataPtr->Size);
	}
};

struct FPushVariableInstruction : IExpressionInstruction
{
	FPushVariableInstruction(int32 Size, int32 Addr)
	{
		Data.Size = Size;
		Data.Addr = Addr;
	}

	struct FData
	{
		int32 Size;
		int32 Addr;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::PushVariable, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const void* ValuePtr = Stack.Find(DataPtr->Addr);
		Stack.Push(ValuePtr, DataPtr->Size);
	}
};

struct FPushConstInstruction : IExpressionInstruction
{
	FPushConstInstruction(const TArray<uint8>& Data)
		: Data(Data)
	{
	}

	TArray<uint8> Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::PushConst, Data.GetData(), Data.Num());
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const uint8* DataPtr = StaticCast<const uint8*>(InData);
		const FExpressionInstructionBuffer::FInstructionHeader* Header = reinterpret_cast<const FExpressionInstructionBuffer::FInstructionHeader*>(DataPtr -
			FExpressionInstructionBuffer::InstructionHeaderSize);

		UE_LOG(LogExpression, Verbose, TEXT("  --Read data in int %u"), *DataPtr)
		const int32 DataSize = Header->Size - FExpressionInstructionBuffer::InstructionHeaderSize;
		Stack.Push(InData, DataSize);
	}
};

struct FPushStringInstruction : IExpressionInstruction
{
	FPushStringInstruction(const FString& Value)
		: Value(Value)
	{
		Data.StringOffset = 0;
	}

	FString Value;

	struct FData
	{
		int32 StringOffset;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		const int32 StringOffset = Serializer.AddString(Value);
		Data.StringOffset = StringOffset;
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::PushString, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	// ReSharper disable once CppParameterMayBeConstPtrOrRef
	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = StaticCast<const FData*>(InData);

		FString String;
		Executor.ReadString(DataPtr->StringOffset, String);
		Stack.PushString(String);
	}
};

struct FCastInstruction : IExpressionInstruction
{
	FCastInstruction(int32 Address, EVarType FromType, EVarType ToType)
	{
		Data.Address = Address;
		Data.FromType = FromType;
		Data.ToType = ToType;
	}

	struct FData
	{
		int32 Address;
		EVarType FromType;
		EVarType ToType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Cast, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		void* Origin = Stack.Find(DataPtr->Address);
		switch (DataPtr->FromType)
		{
		case EVarType::Int:
			{
				int32 Value = *StaticCast<int32*>(Origin);
				switch (DataPtr->ToType)
				{
				case EVarType::Float:
					{
						const float CastValue = StaticCast<float>(Value);
						FMemory::Memcpy(Origin, &CastValue, sizeof(float));
					}
					break;
				case EVarType::Bool:
					{
						const bool CastValue = Value != 0;
						FMemory::Memcpy(Origin, &CastValue, sizeof(bool));
					}
					break;
				case EVarType::EventRole:
					{
						// 
					}
					break;
				default:
					checkNoEntry();
				}
			}
			break;
		case EVarType::Float:
			{
				float Value = *StaticCast<float*>(Origin);
				switch (DataPtr->ToType)
				{
				case EVarType::Int:
					{
						const int32 CastValue = StaticCast<int32>(Value);
						FMemory::Memcpy(Origin, &CastValue, sizeof(int32));
					}
					break;
				case EVarType::Bool:
					{
						const bool CastValue = FMath::IsNearlyEqual(Value, 0.0f);
						FMemory::Memcpy(Origin, &CastValue, sizeof(bool));
					}
					break;
				default:
					checkNoEntry();
				}
			}
			break;
		case EVarType::EventRole:
			{
				float Value = *StaticCast<int*>(Origin);
				switch (DataPtr->ToType)
				{
				case EVarType::Int:
					{
						//
					}
				default:
					checkNoEntry();
				}
			}
			break;
		default:
			checkNoEntry();
			break;
		}
	}
};

struct FAddInstruction : IExpressionInstruction
{
	FAddInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Add, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const int32 Result = LhsValue + RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const float Result = LhsValue + RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		case EVarType::String:
			{
				const FString& RhsValue = Stack.PopString();
				const FString& LhsValue = Stack.PopString();
				const FString Result = LhsValue + RhsValue;
				Stack.PushString(Result);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FSubInstruction : IExpressionInstruction
{
	FSubInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Sub, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const int32 Result = LhsValue - RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const float Result = LhsValue - RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FMulInstruction : IExpressionInstruction
{
	FMulInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Mul, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const int32 Result = LhsValue * RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const float Result = LhsValue * RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FDivInstruction : IExpressionInstruction
{
	FDivInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Div, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const int32 Result = LhsValue / RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const float Result = LhsValue * RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FModInstruction : IExpressionInstruction
{
	FModInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Mod, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const int32 Result = LhsValue % RhsValue;
				Stack.Push(&Result, VarSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FGreaterInstruction : IExpressionInstruction
{
	FGreaterInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Greater, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		static const int32 RetSize = VarTypeSize(EVarType::Bool);
		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const bool Result = LhsValue > RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const bool Result = LhsValue > RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FLessInstruction : IExpressionInstruction
{
	FLessInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Less, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		static const int32 RetSize = VarTypeSize(EVarType::Bool);
		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const bool Result = LhsValue < RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const bool Result = LhsValue < RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FGreaterEqualInstruction : IExpressionInstruction
{
	FGreaterEqualInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::GreaterEqual, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		static const int32 RetSize = VarTypeSize(EVarType::Bool);
		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const bool Result = LhsValue >= RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const bool Result = LhsValue >= RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FLessEqualInstruction : IExpressionInstruction
{
	FLessEqualInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::LessEqual, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		static const int32 RetSize = VarTypeSize(EVarType::Bool);
		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const bool Result = LhsValue <= RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const bool Result = LhsValue <= RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FEqualInstruction : IExpressionInstruction
{
	FEqualInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Equal, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		static const int32 RetSize = VarTypeSize(EVarType::Bool);
		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const bool Result = LhsValue == RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const bool Result = LhsValue == RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		case EVarType::Bool:
			{
				const bool RhsValue = *Stack.Pop<bool>(VarSize);
				const bool LhsValue = *Stack.Pop<bool>(VarSize);
				const bool Result = LhsValue == RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FNotEqualInstruction : IExpressionInstruction
{
	FNotEqualInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::NotEqual, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		static const int32 RetSize = VarTypeSize(EVarType::Bool);
		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 RhsValue = *Stack.Pop<int32>(VarSize);
				const int32 LhsValue = *Stack.Pop<int32>(VarSize);
				const bool Result = LhsValue != RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		case EVarType::Float:
			{
				const float RhsValue = *Stack.Pop<float>(VarSize);
				const float LhsValue = *Stack.Pop<float>(VarSize);
				const bool Result = LhsValue != RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		case EVarType::Bool:
			{
				const bool RhsValue = *Stack.Pop<bool>(VarSize);
				const bool LhsValue = *Stack.Pop<bool>(VarSize);
				const bool Result = LhsValue != RhsValue;
				Stack.Push(&Result, RetSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FNegativeInstruction : IExpressionInstruction
{
	FNegativeInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Negative, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		const int32 VarSize = VarTypeSize(DataPtr->ValueType);
		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			{
				const int32 Value = *Stack.Pop<int32>(VarSize);
				const int32 Result = -Value;
				Stack.Push(&Result, VarSize);
			}
			break;
		case EVarType::Float:
			{
				const float Value = *Stack.Pop<float>(VarSize);
				const float Result = -Value;
				Stack.Push(&Result, VarSize);
			}
			break;
		default:
			checkNoEntry();
		}
	}
};

struct FOrInstruction : IExpressionInstruction
{
	FOrInstruction()
	{
	}

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Or);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		static const int32 VarSize = VarTypeSize(EVarType::Bool);
		const bool RhsValue = *Stack.Pop<bool>(VarSize);
		const bool LhsValue = *Stack.Pop<bool>(VarSize);
		const bool Result = LhsValue || RhsValue;
		Stack.Push(&Result, VarSize);
	}
};

struct FAndInstruction : IExpressionInstruction
{
	FAndInstruction()
	{
	}

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::And);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		static const int32 VarSize = VarTypeSize(EVarType::Bool);
		const bool RhsValue = *Stack.Pop<bool>(VarSize);
		const bool LhsValue = *Stack.Pop<bool>(VarSize);
		const bool Result = LhsValue && RhsValue;
		Stack.Push(&Result, VarSize);
	}
};

struct FNotInstruction : IExpressionInstruction
{
	FNotInstruction()
	{
	}

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Not);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const int32 VarSize = VarTypeSize(EVarType::Bool);
		const bool Value = *Stack.Pop<bool>(VarSize);
		const bool Result = !Value;
		Stack.Push(&Result, VarSize);
	}
};

struct FPrintInstruction : IExpressionInstruction
{
	FPrintInstruction(const FString& FmtString, const TArray<EVarType>& Params)
		: FmtString(FmtString),
		  Params(Params)
	{
	}

	FString FmtString;
	TArray<EVarType> Params;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		constexpr int32 IntSize = sizeof(int32);
		TArray<uint8> Buffer;
		Buffer.AddZeroed(IntSize * 2 + Params.Num());

		const int32 StringOffset = Serializer.AddString(FmtString);
		uint8* StringOffsetPtr = Buffer.GetData();
		FMemory::Memcpy(StringOffsetPtr, &StringOffset, IntSize);

		const int32 ParamNum = Params.Num();
		uint8* ParamNumPtr = &Buffer.GetData()[IntSize];
		FMemory::Memcpy(ParamNumPtr, &ParamNum, IntSize);

		for (int32 Index = 0; Index < Params.Num(); ++Index)
		{
			uint8* ParamPtr = &Buffer.GetData()[IntSize * 2 + Index];
			const uint8 ParamType = StaticCast<uint8>(Params[Index]);
			FMemory::Memcpy(ParamPtr, &ParamType, sizeof(uint8));
		}

		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Print, Buffer.GetData(), Buffer.Num());
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	// ReSharper disable once CppParameterMayBeConstPtrOrRef
	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack);
};

#define EXPRESSION_CONCAT_IMPL(l, r) l ## r
#define EXPRESSION_CONCAT(l, r) EXPRESSION_CONCAT_IMPL(l, r)

// Macro used to count VA_ARGS number, reference to: https://sf-zhou.github.io/programming/cpp_macro_number_of_arguments.html
#define EXPRESSION_FIRST(first, ...) first
#define EXPRESSION_SECOND(first, second, ...) second
#define EXPRESSION_IS_PROBE(...) EXPRESSION_SECOND(__VA_ARGS__, 0)
#define EXPRESSION_PROBE() ~, 1
#define EXPRESSION_NOT(x) EXPRESSION_IS_PROBE(EXPRESSION_CONCAT(EXPRESSION_NOT_, x))
#define EXPRESSION_NOT_0 EXPRESSION_PROBE()
#define EXPRESSION_BOOL(x) EXPRESSION_NOT(EXPRESSION_NOT(x))
#define EXPRESSION_HAS_ARGS(...) EXPRESSION_BOOL(EXPRESSION_FIRST(EXPRESSION_END_OF_ARGUMENTS_ __VA_ARGS__)())
#define EXPRESSION_END_OF_ARGUMENTS_() 0

#define EXPRESSION_IF_ELSE(condition) _EXPRESSION_IF_ELSE(EXPRESSION_BOOL(condition))
#define _EXPRESSION_IF_ELSE(condition) EXPRESSION_CONCAT(EXPRESSION_IF_, condition)
#define EXPRESSION_IF_1(...) __VA_ARGS__ EXPRESSION_IF_1_ELSE
#define EXPRESSION_IF_0(...) EXPRESSION_IF_0_ELSE
#define EXPRESSION_IF_1_ELSE(...)
#define EXPRESSION_IF_0_ELSE(...) __VA_ARGS__

#define EXPRESSION_TENTH(_1, _2, _3, _4, _5, _6, _7, _8, _9, N, ...) N
#define EXPRESSION_ARG_COUNT(...)               \
EXPRESSION_IF_ELSE(EXPRESSION_HAS_ARGS(__VA_ARGS__)) \
(EXPRESSION_TENTH(__VA_ARGS__, 9, 8, 7, 6, 5, 4, 3, 2, 1, 0))(0)

#define EXPRESSION_ARG_LIST_0(...)
#define EXPRESSION_ARG_LIST_1(Arg, ...) Arg
#define EXPRESSION_ARG_LIST_2(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_1(__VA_ARGS__)
#define EXPRESSION_ARG_LIST_3(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_2(__VA_ARGS__)
#define EXPRESSION_ARG_LIST_4(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_3(__VA_ARGS__)
#define EXPRESSION_ARG_LIST_5(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_4(__VA_ARGS__)
#define EXPRESSION_ARG_LIST_6(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_5(__VA_ARGS__)
#define EXPRESSION_ARG_LIST_7(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_6(__VA_ARGS__)
#define EXPRESSION_ARG_LIST_8(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_7(__VA_ARGS__)
#define EXPRESSION_ARG_LIST_9(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_8(__VA_ARGS__)
#define EXPRESSION_ARG_LIST_10(Arg, ...) EXPRESSION_ARG_LIST_1(Arg) , EXPRESSION_ARG_LIST_9(__VA_ARGS__)

#define EXPRESSION_ARG_LIST_IMPL(...) \
		EXPRESSION_CONCAT(EXPRESSION_ARG_LIST_, EXPRESSION_ARG_COUNT(__VA_ARGS__))(__VA_ARGS__)
#define EXPRESSION_ARG_LIST(...) \
		EXPRESSION_ARG_LIST_IMPL(__VA_ARGS__)


#define REGISTER_EXPRESSION_ATOM(FuncName, RetType, AtomClassName, ...) \
	static TExprAtomSingleton<AtomClassName> ExprAtom##FuncName##Tmpl(RetType, {__VA_ARGS__}); \
	FExpressionFunctionTable::FRegister FuncName##Register(TEXT(#FuncName), ExprAtom##FuncName##Tmpl.GetAtomInstance());

#define REGISTER_CONTEXT_EXPRESSION_ATOM(ContextName, FuncName, RetType, AtomClassName, ...) \
	static TExprAtomSingleton<AtomClassName> ExprAtom##FuncName##Tmpl(RetType, {__VA_ARGS__}); \
	FExpressionFunctionTable::FRegister FuncName##Register(TEXT(#ContextName), TEXT(#FuncName), ExprAtom##FuncName##Tmpl.GetAtomInstance());

#define SIMPLE_DECLARE_EXPRESSION_ATOM(AtomClassName) \
	struct AtomClassName : public FSceneExprAtom\
	{ \
		virtual void ExecInScene(FSceneExprCtx& Context) const override; \
	} 


struct FExpressionFunctionExecutor
{
	FExpressionFunctionExecutor(const FExpressionAtom* InAtom)
		: StaticAtom(InAtom){}
	
	const FExpressionAtom* StaticAtom;
};

struct FExpressionFuncDefine
{
	FExpressionFuncDefine(const FExpressionAtom* InAtom)
		: Executor(InAtom)	
	
	{
	}

#if ENABLE_EXPRESSION_COMPILER
	FString ContextName;
#endif
	FExpressionFunctionExecutor Executor;
};

extern EXPRESSIONRUNTIME_API TMap<FString, FExpressionFuncDefine>& GetFuncDecalMap();

struct FExpressionFunctionTable
{
	struct FRegister
	{
		FRegister(FString FuncName, const FExpressionAtom* Atom)
			: FRegister(FString(), MoveTemp(FuncName), Atom)
		{
		}

		
		FRegister(FString ContextName, FString FuncName, const FExpressionAtom* Atom)
		{
			TMap<FString, FExpressionFuncDefine>& FuncDecalMap = GetFuncDecalMap();
			if (ensure(!FuncDecalMap.Contains(FuncName)))
			{
				FuncDef = &FuncDecalMap.Emplace(FuncName, FExpressionFuncDefine(Atom));
#if ENABLE_EXPRESSION_COMPILER
				FuncDef->ContextName = MoveTemp(ContextName);
#endif
			}
			else
			{
				FuncDef = nullptr;
			}
		}

		FExpressionFuncDefine* FuncDef;
	};

#if ENABLE_EXPRESSION_COMPILER
	static bool EXPRESSIONRUNTIME_API GetFunctionDeclaration(const FString& FuncName, EVarType& OutRetType, TArray<EVarType>& OutParams, FString& OutContext);

	static bool ParamTypeMatch(EVarType Required, EVarType Given)
	{
		if (Required == EVarType::Int || Required == EVarType::Float)
		{
			return Given == EVarType::Int || Given == EVarType::Float;
		}

		return Required == Given;
	}
#endif

	static bool ExecuteFunction(const FString& FuncName, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack);
};

struct FCallFunctionInstruction : IExpressionInstruction
{
	FCallFunctionInstruction(const FString& FunctionName)
		: FunctionName(FunctionName)
	{
		Data.FuncNameStrIndex = 0;
	}

	FString FunctionName;

	struct FData
	{
		int32 FuncNameStrIndex;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Data.FuncNameStrIndex = Serializer.AddString(FunctionName);
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::CallFunction, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		FString FuncName;
		if (Executor.ReadString(DataPtr->FuncNameStrIndex, FuncName))
		{
			UE_LOG(LogExpression, Verbose, TEXT("  --Read Function %s"), *FuncName)
			FExpressionFunctionTable::ExecuteFunction(MoveTemp(FuncName), Executor, Stack);
		}
		else
		{
			checkNoEntry();
		}
	}
};

struct FReturnInstruction : IExpressionInstruction
{
	FReturnInstruction(EVarType ValueType)
	{
		Data.ValueType = ValueType;
	}

	struct FData
	{
		EVarType ValueType;
	} Data;

#if ENABLE_EXPRESSION_COMPILER
	virtual void Serialize(FSerializer& Serializer) override
	{
		Serializer.InstructionBuffer.AddInstruction(EExpressionInstruction::Return, Data);
	}

	virtual void PostSerialize(FSerializer& Serializer) override
	{
	}
#endif

	static void Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
	{
		const FData* DataPtr = static_cast<const FData*>(InData);

		switch (DataPtr->ValueType)
		{
		case EVarType::Int:
			Executor.Return(Stack.PopInt());
			break;
		case EVarType::Bool:
			Executor.Return(Stack.PopBool());
			break;
		case EVarType::Float:
			Executor.Return(Stack.PopFloat());
			break;
		default:
			Executor.Return();
		}
	}
};

inline void FExpressionExecutor::ExecuteExpression(FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
{
	const FExpressionInstructionBuffer::FHeader CodeHeader = Executor.Header;
	Stack.Reset(CodeHeader.BuildInBlockSize);

	TArray<FInstructionExecutFunc>& InstructionSet = GetInstructionSet(CodeHeader.Version);

	FExpressionInstructionBuffer::FInstructionHeader Header;
	const void* DataPtr;

	while (Executor.ReadInstruction(Header, DataPtr))
	{
		if (ensure(InstructionSet.IsValidIndex(Header.Type)))
		{
			InstructionSet[Header.Type].Execute(DataPtr, Executor, Stack);
		}
	}
}

inline void ExecuteExpression(FExpressionExecutor& Executor)
{
	FExpressionExecutionStack Stack;
	FExpressionExecutor::ExecuteExpression(Executor, Stack);
}

inline void ExecuteExpression(const uint8* Buffer, int32 BufferLength, FExpressionContext& Context)
{
	FExpressionExecutor Executor(Buffer, BufferLength);
	Executor.Reset(&Context);
	ExecuteExpression(Executor);
}

template <typename Type>
bool ExecuteExpressionReturn(Type &Ret, const uint8* Buffer, int32 BufferLength, FExpressionContext& Context)
{
	FExpressionExecutor Executor(Buffer, BufferLength);
	Executor.Reset(&Context);
	ExecuteExpression(Executor);
	return Executor.GetRetValue(Ret);
}
