﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "ExpressionInstruction.h"

#include "ExprRuntime/ExprAtomDef.h"
#include "ExprRuntime/ExprDef.h"
#include "Kismet/KismetSystemLibrary.h"

TArray<TArray<FInstructionExecutFunc>>& GetInstructionSetMap()
{
	static TArray<TArray<FInstructionExecutFunc>> GMap =
	{
		// Version 0
		{
			{FInstructionExecutFunc::CreateStatic(&FMoveInstruction::Execute)}, // Move,
			{FInstructionExecutFunc::CreateStatic(&FMoveToInstruction::Execute)}, // MoveTo,
			{FInstructionExecutFunc::CreateStatic(&FJumpInstruction::Execute)}, // Jump,
			{FInstructionExecutFunc::CreateStatic(&FJumpZeroInstruction::Execute)}, // JumpZero,
			{FInstructionExecutFunc::CreateStatic(&FPopInstruction::Execute)}, // Pop,
			{FInstructionExecutFunc::CreateStatic(&FPeekInstruction::Execute)}, // Peek,
			{FInstructionExecutFunc::CreateStatic(&FPushVariableInstruction::Execute)}, // PushVariable,
			{FInstructionExecutFunc::CreateStatic(&FPushStringInstruction::Execute)}, // PushString,
			{FInstructionExecutFunc::CreateStatic(&FPushConstInstruction::Execute)}, // PushConst,
			{FInstructionExecutFunc::CreateStatic(&FCastInstruction::Execute)}, // Cast,
			{FInstructionExecutFunc::CreateStatic(&FAddInstruction::Execute)}, // Add,
			{FInstructionExecutFunc::CreateStatic(&FSubInstruction::Execute)}, // Sub,
			{FInstructionExecutFunc::CreateStatic(&FMulInstruction::Execute)}, // Mul,
			{FInstructionExecutFunc::CreateStatic(&FDivInstruction::Execute)}, // Div,
			{FInstructionExecutFunc::CreateStatic(&FModInstruction::Execute)}, // Mod,
			{FInstructionExecutFunc::CreateStatic(&FGreaterInstruction::Execute)}, // Greater,
			{FInstructionExecutFunc::CreateStatic(&FLessInstruction::Execute)}, // Less,
			{FInstructionExecutFunc::CreateStatic(&FGreaterEqualInstruction::Execute)}, // GreaterEqual,
			{FInstructionExecutFunc::CreateStatic(&FLessEqualInstruction::Execute)}, // LessEqual,
			{FInstructionExecutFunc::CreateStatic(&FEqualInstruction::Execute)}, // Equal,
			{FInstructionExecutFunc::CreateStatic(&FNotEqualInstruction::Execute)}, // NotEqual,
			{FInstructionExecutFunc::CreateStatic(&FNegativeInstruction::Execute)}, // Negative,
			{FInstructionExecutFunc::CreateStatic(&FOrInstruction::Execute)}, // Or,
			{FInstructionExecutFunc::CreateStatic(&FAndInstruction::Execute)}, // And,
			{FInstructionExecutFunc::CreateStatic(&FNotInstruction::Execute)}, // Not,
			{FInstructionExecutFunc::CreateStatic(&FPrintInstruction::Execute)}, // Print,
			{FInstructionExecutFunc::CreateStatic(&FCallFunctionInstruction::Execute)}, // CallFunction,
			{FInstructionExecutFunc::CreateStatic(&FReturnInstruction::Execute)}, // Return,
		},
	};

	return GMap;
}

TArray<FInstructionExecutFunc>& GetInstructionSet(int32 Version)
{
	TArray<TArray<FInstructionExecutFunc>>& Map = GetInstructionSetMap();

	UE_LOG(LogExpression, Log, TEXT("Get instruction set version %d"), Version);

#if UE_SERVER
	if (!Map.IsValidIndex(Version))
	{
		UE_LOG(LogExpression, Error, TEXT("Version %d invalid"), Version);

		return Map[0];
	}
#else
	check(Map.IsValidIndex(Version));
#endif
	return Map[Version];
}

int32 LatestInstructionVersion()
{
	const TArray<TArray<FInstructionExecutFunc>>& Map = GetInstructionSetMap();
	ensure(Map.Num() <= 256);
	return Map.Num() - 1;
}

// ReSharper disable once CppParameterMayBeConstPtrOrRef
void FPrintInstruction::Execute(const void* InData, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
{
	const uint8* DataPtr = StaticCast<const uint8*>(InData);
	constexpr int32 IntSize = sizeof(int32);

	const int32 FmtStringOffset = *reinterpret_cast<const int32*>(DataPtr);
	const int32 ParamNum = *reinterpret_cast<const int32*>(DataPtr + IntSize);

	FStringFormatOrderedArguments Args;
	Args.SetNumZeroed(ParamNum);
	for (int32 Index = ParamNum - 1; Index >= 0; --Index)
	{
		const uint8 ParamType = *(DataPtr + IntSize * 2 + Index);
		switch (StaticCast<EVarType>(ParamType))
		{
		case EVarType::Int:
			{
				Args[Index] = Stack.PopInt();
			}
			break;
		case EVarType::Bool:
			{
				const bool Value = Stack.PopBool();
				Args[Index] = Value ? TEXT("true") : TEXT("false");
			}
			break;
		case EVarType::Float:
			{
				Args[Index] = Stack.PopFloat();
			}
			break;
		case EVarType::String:
			{
				const FString& ArgString = Stack.PopString();
				Args[Index] = ArgString;
			}
			break;
		case EVarType::Target:
			{
				// const FCombatTargetingResult& ArgTarget = Stack.PopTarget();
				// Args[Index] = ArgTarget.ToString();
			}
			break;
		case EVarType::Actor:
			{
				TWeakObjectPtr<AActor> ArgActor = Stack.PopActor();
				Args[Index] = ArgActor.IsValid() ? FString(TEXT("null")) : ArgActor->GetName();
			}
			break;
		default:
			{
				Args.RemoveAt(Index);
				checkNoEntry();
			}
		}
	}

	FString FmtString;
	Executor.ReadString(FmtStringOffset, FmtString);

	if (Executor.ExprContext && GWorld)
	{
		UKismetSystemLibrary::PrintString(GWorld, FString::Format(*FmtString, Args));
	}
}

#if ENABLE_EXPRESSION_COMPILER
bool FExpressionFunctionTable::GetFunctionDeclaration(const FString& FuncName, EVarType& OutRetType, TArray<EVarType>& OutParams, FString& OutContext)
{
	TMap<FString, FExpressionFuncDefine>& FuncDecalMap = GetFuncDecalMap();

	const FExpressionFuncDefine* Func = FuncDecalMap.Find(FuncName);
	if (Func == nullptr)
	{
		return false;
	}

	check(Func->Executor.StaticAtom)
	check(Func->Executor.StaticAtom->GetParamsLayout())
	
	OutRetType = Func->Executor.StaticAtom->GetParamsLayout()->GetRetType();
	OutParams = Func->Executor.StaticAtom->GetParamsLayout()->GetArgTypes();
	OutContext = Func->ContextName;
	return true;
}
#endif

bool FExpressionFunctionTable::ExecuteFunction(const FString& FuncName, FExpressionExecutor& Executor, FExpressionExecutionStack& Stack)
{
	TMap<FString, FExpressionFuncDefine>& FuncDecalMap = GetFuncDecalMap();
	const FExpressionFuncDefine* Func = FuncDecalMap.Find(FuncName);
	if (Func == nullptr)
	{
		return false;
	}

	FExpressionContext* ExprContext = Executor.GetContext();
	if(!ensureMsgf(ExprContext, TEXT("Expression Must Has A Valid ExpressionContext")))
	{
		return false;
	}

	check(Func->Executor.StaticAtom);

	ExprContext->ExecAtom(*Func->Executor.StaticAtom, Stack);
	return true;
	
}

TMap<FString, FExpressionFuncDefine>& GetFuncDecalMap()
{
	static TMap<FString, FExpressionFuncDefine> FuncDecalMap = TMap<FString, FExpressionFuncDefine>();
	return FuncDecalMap;
}
