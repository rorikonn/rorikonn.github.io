﻿//

#pragma once
#include "ExpressionDefinition.h"

struct FExprAtomParamsLayout;
struct FExpressionAtom;
struct FEventContext;
struct FSegmentContext;


struct EXPRESSIONRUNTIME_API FExpressionContextActor
{
	virtual ~FExpressionContextActor() = default;

	FExpressionContextActor()
	{
	}

	FExpressionContextActor(AActor* Actor)
	{
		ActorPtr = Actor;
	}

	virtual UWorld* GetWorld() const
	{
		return GetActor() ? GetActor()->GetWorld() : nullptr;
	}

	AActor* GetActor() const
	{
		if (ActorPtr.IsValid())
		{
			return ActorPtr.Get();
		}

		return nullptr;
	}

	template <typename ParamType>
	typename TEnableIf<TIsSame<ParamType, float>::Value, void>::Type WriteParam(FName Name, ParamType Value)
	{
		FloatParams.Emplace(Name, Value);
	}

	template <typename ParamType>
	typename TEnableIf<TIsSame<ParamType, float>::Value, bool>::Type ReadParam(FName Name, ParamType& OutValue)
	{
		if (float* Found = FloatParams.Find(Name))
		{
			OutValue = *Found;
			return true;
		}

		return false;
	}

	template <typename ParamType>
	typename TEnableIf<TIsSame<ParamType, int32>::Value, void>::Type WriteParam(FName Name, ParamType Value)
	{
		IntParams.Emplace(Name, Value);
	}

	template <typename ParamType>
	typename TEnableIf<TIsSame<ParamType, int32>::Value, bool>::Type ReadParam(FName Name, ParamType& OutValue)
	{
		if (int32* Found = IntParams.Find(Name))
		{
			OutValue = *Found;
			return true;
		}

		return false;
	}

	template <typename ParamType>
	typename TEnableIf<TIsDerivedFrom<ParamType, AActor>::Value, void>::Type WriteParam(FName Name, ParamType* Value)
	{
		ActorParams.Emplace(Name, TWeakObjectPtr<AActor>(Value));
	}

	template <typename ParamType>
	typename TEnableIf<TIsSame<ParamType, AActor*>::Value, bool>::Type ReadParam(FName Name, ParamType& OutValue)
	{
		if (const TWeakObjectPtr<AActor>* Found = ActorParams.Find(Name))
		{
			if (Found->IsValid())
			{
				OutValue = Found->Get();
			}

			return true;
		}

		return false;
	}

	TWeakObjectPtr<AActor> ActorPtr;

	TMap<FName, float> FloatParams;
	TMap<FName, int32> IntParams;
	TMap<FName, TWeakObjectPtr<AActor>> ActorParams;
};

typedef TArray<FExpressionContextActor> FExpressionContextActors;

struct EXPRESSIONRUNTIME_API FExpressionContext
{
	virtual ~FExpressionContext() = default;

	FExpressionContext(){}

	void Exec(const FExpressionAtom& Atom);
	virtual void ExecImpl(const FExpressionAtom& Atom);
	
	virtual FSegmentContext* GetSegmentContext() const { return nullptr;}
	virtual FEventContext* GetEventContext() const { return nullptr;}
	
	void ExecAtom(const FExpressionAtom& Atom, FExpressionExecutionStack& Stack);

private:
	bool BuildAtomArgs(const FExpressionAtom& Atom, FExpressionExecutionStack& Stack, const FExprAtomParamsLayout& ParamsLayout) const;
	bool ReadAtomRet(const FExpressionAtom& Atom, FExpressionExecutionStack& Stack, const FExprAtomParamsLayout& ParamsLayout) const;
};

struct FExprAtomParamsLayout
{
	FExprAtomParamsLayout()
		: RetType(EVarType::Void), HasInit(false)
	{
		
	}

	FExprAtomParamsLayout(const TArray<EVarType>& InArgTypes, EVarType InRetType)
		: ArgTypes(InArgTypes), RetType(InRetType), HasInit(true)
	{
		
	}

	bool IsValid() const { return HasInit; }
	const TArray<EVarType>& GetArgTypes() const { return ArgTypes;}
	const EVarType GetRetType() const { return RetType;}
	
protected:
	TArray<EVarType> ArgTypes;
	EVarType RetType;
	bool HasInit;
};
