﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"

#define ENABLE_EXPRESSION_COMPILER WITH_EDITOR

EXPRESSIONRUNTIME_API DECLARE_LOG_CATEGORY_EXTERN(LogExpression, Warning, All);
EXPRESSIONRUNTIME_API DECLARE_LOG_CATEGORY_EXTERN(LogExpressionCompiler, Log, All);

constexpr uint32 VarAlignment = 8;

enum class EVarType : uint8
{
	Void,
	Int,
	Bool,
	Float,
	String,
	Target,
	Actor,
	EventRole,
	Max,
};

constexpr uint8 VarMax = static_cast<uint8>(EVarType::Max);

inline constexpr int32 VarTypeMaxSize = 8;

inline int32 VarTypeSize(EVarType VarType)
{
	static int32 VarSize[VarMax] =
	{
		8, 8, 8, 8, 8, 8, 8, 8,
	};

	return VarSize[StaticCast<uint8>(VarType)];
}

inline EVarType VarTypeUpCast(EVarType Lhs, EVarType Rhs)
{
	static EVarType CastMap[VarMax][VarMax] =
	{
		{EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void},
		{EVarType::Void, EVarType::Int, EVarType::Void, EVarType::Float, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void},
		{EVarType::Void, EVarType::Void, EVarType::Bool, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void},
		{EVarType::Void, EVarType::Float, EVarType::Void, EVarType::Float, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void},
		{EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::String, EVarType::Void, EVarType::Void, EVarType::Void},
		{EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Target, EVarType::Void, EVarType::Void},
		{EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Actor, EVarType::Void},
		{EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Void, EVarType::Actor, EVarType::EventRole},
	};

	return CastMap[StaticCast<uint8>(Lhs)][StaticCast<uint8>(Rhs)];
}

inline bool VarTypeCanCast(EVarType From, EVarType To)
{
	static bool CastMap[VarMax][VarMax] =
	{
		{true, false, false, false, false, false, false, false},
		{false, true, true, true, false, false, false, true},
		{false, false, true, false, false, false, false, false},
		{false, true, true, true, false, false, false, false},
		{false, false, false, false, true, false, false, false},
		{false, false, false, false, false, true, false, false},
		{false, false, false, false, false, false, true, false},
		{false, true, false, false, false, false, false, true},
	};

	return CastMap[StaticCast<uint8>(From)][StaticCast<uint8>(To)];
}

enum class EExprRoleType : uint8
{
	ERoleInvalid,
	ERoleSource,
	ERoleTarget,
	ERoleDecorator,

	ERoleCount,
};

namespace GLExpressionCompiler
{
	constexpr int32 InstructionVersion = 1;

	inline FString VarTypeName(EVarType VarType)
	{
		switch (VarType)
		{
		case EVarType::Void:
			return TEXT("void");
		case EVarType::Int:
			return TEXT("int");
		case EVarType::Bool:
			return TEXT("bool");
		case EVarType::Float:
			return TEXT("float");
		case EVarType::String:
			return TEXT("string");
		case EVarType::Target:
			return TEXT("target");
		case EVarType::Actor:
			return TEXT("actor");
		case EVarType::EventRole:
			return TEXT("EventRole");
		default:
			return TEXT("unknown");
		}
	}

	enum EMathOperator
	{
		EMath_Add,
		EMath_Sub,
		EMath_Mul,
		EMath_Div,
		EMath_Mod,
	};

	inline FString MathOperatorName(EMathOperator Operator)
	{
		switch (Operator)
		{
		case EMath_Add:
			return TEXT("+");
		case EMath_Sub:
			return TEXT("-");
		case EMath_Mul:
			return TEXT("*");
		case EMath_Div:
			return TEXT("/");
		case EMath_Mod:
			return TEXT("%");
		}

		return TEXT("?");
	}

	enum ECompareOperator
	{
		ECompare_Greater,
		ECompare_Less,
		ECompare_GreaterEqual,
		ECompare_LessEqual,
		ECompare_Equal,
		ECompare_NotEqual,
	};

	inline FString CompareOperatorName(ECompareOperator Operator)
	{
		switch (Operator)
		{
		case ECompare_Greater:
			return TEXT(">");
		case ECompare_Less:
			return TEXT("<");
		case ECompare_GreaterEqual:
			return TEXT(">=");
		case ECompare_LessEqual:
			return TEXT("<=");
		case ECompare_Equal:
			return TEXT("==");
		case ECompare_NotEqual:
			return TEXT("!=");
		}

		return TEXT("?");
	}

	inline int32 PackVariableAddress(int32 Address, bool bIsBuildIn)
	{
		ensure(Address >= 0);
		if (bIsBuildIn)
		{
			return -1 * Address - 1;
		}
		else
		{
			return Address;
		}
	}

	inline int32 UnpackVariableAddress(int32 Address, int32 BuildInOffset)
	{
		if(Address < 0)
		{
			return -1 * Address - 1;
		}
		else
		{
			return BuildInOffset + Address;
		}
	}
}

struct FExpressionExecutionStack
{
	inline static constexpr int32 MaxStackSize = 512;
	int32 TopIndex = 0;
	int32 BuildInOffset = 0;
	uint8 Buffer[MaxStackSize];

	TArray<FString> StringTable;
	TArray<TWeakObjectPtr<AActor>> ActorTable;

	FORCEINLINE TArray<FString>& GetStringTable() 
	{
		return StringTable;
	}
	
	FORCEINLINE TArray<TWeakObjectPtr<AActor>>& GetActorTable() 
	{
		return ActorTable;
	}

	void Reset(int32 BuildInVarSize)
	{
		BuildInOffset = BuildInVarSize;
		TopIndex = BuildInOffset;

#if UE_SERVER
		if ((SIZE_T)BuildInVarSize > MaxStackSize)
		{
			FMemory::Memzero(Buffer, MaxStackSize);	
		}
		else
		{
			FMemory::Memzero(Buffer, BuildInVarSize);  
		}
#else
		FMemory::Memzero(Buffer, BuildInVarSize);
#endif
	}

	void Move(int32 Step)
	{
		TopIndex += Step;
	}

	void MoveTo(int32 Addr)
	{
		const int32 RealAddress = GLExpressionCompiler::UnpackVariableAddress(Addr, BuildInOffset);
		TopIndex = RealAddress;
	}

	void *PopRawData(EVarType VarType)
	{
		TopIndex -= VarTypeSize(VarType);
		return &Buffer[TopIndex];
	}

	template <typename T = void>
	T* Pop(int32 Size)
	{
		TopIndex -= Size;
		return reinterpret_cast<T*>(&Buffer[TopIndex]);
	}

	int32 PopInt()
	{
		TopIndex -= VarTypeSize(EVarType::Int);
		return *reinterpret_cast<int32*>(&Buffer[TopIndex]);
	}

	float PopFloat()
	{
		TopIndex -= VarTypeSize(EVarType::Float);
		return *reinterpret_cast<float*>(&Buffer[TopIndex]);
	}

	bool PopBool()
	{
		TopIndex -= VarTypeSize(EVarType::Bool);
		return *reinterpret_cast<bool*>(&Buffer[TopIndex]);
	}

	const FString& PopString()
	{
		TopIndex -= VarTypeSize(EVarType::String);
		const int32 StringIndex = *reinterpret_cast<int32*>(&Buffer[TopIndex]);
		check(StringTable.IsValidIndex(StringIndex));
		return StringTable[StringIndex];
	}

	const TWeakObjectPtr<AActor>& PopActor()
	{
		TopIndex -= VarTypeSize(EVarType::Actor);
		const int32 ActorIndex = *reinterpret_cast<int32*>(&Buffer[TopIndex]);
		check(ActorTable.IsValidIndex(ActorIndex));
		return ActorTable[ActorIndex];
	}

	void Peek(int32 Size, void*& OutPtr)
	{
		OutPtr = &Buffer[TopIndex - Size];
	}

	template <typename T = void>
	typename TEnableIf<TIsSame<T, void>::Value, void>::Type Push(const T* DataPtr, int32 Size)
	{
		if (TopIndex + Size >= MaxStackSize)
		{
			UE_LOG(LogExpression, Error, TEXT("Expression stack overflow"))
			checkNoEntry();
		}

		void* DestPtr = &Buffer[TopIndex];
		TopIndex += Size;

		FMemory::Memcpy(DestPtr, DataPtr, Size);
	}

	template <typename T = void>
	typename TEnableIf<!TIsSame<T, void>::Value, void>::Type Push(const T* DataPtr, int32 Size)
	{
		if (TopIndex + Size >= MaxStackSize)
		{
			UE_LOG(LogExpression, Error, TEXT("Expression stack overflow"))
			checkNoEntry();
		}

		void* DestPtr = &Buffer[TopIndex];
		TopIndex += Size;

		FMemory::Memzero(DestPtr, Size);
		FMemory::Memcpy(DestPtr, DataPtr, sizeof(T));
	}

	void PushString(FString String)
	{
		const int32 StringIndex = StringTable.Add(MoveTemp(String));
		Push(&StringIndex, VarTypeSize(EVarType::String));
	}

	void PushActor(TWeakObjectPtr<AActor> Actor)
	{
		const int32 ActorIndex = ActorTable.Add(MoveTemp(Actor));
		Push(&ActorIndex, VarTypeSize(EVarType::Actor));
	}

	template <typename T = void>
	T* Find(int32 Addr)
	{
		const int32 RealAddress = GLExpressionCompiler::UnpackVariableAddress(Addr, BuildInOffset);
		return reinterpret_cast<T*>(&Buffer[RealAddress]);
	}
};

struct FExpressionVarValue
{
	FExpressionVarValue()
		: VarBuff{0}
	{}
	
	template<typename T>
	T* GetValuePtr()
	{
		return reinterpret_cast<T*>(VarBuff);
	}

	template<typename T>
	const T& GetValueRef()
	{
		return reinterpret_cast<T&>(VarBuff);
	}

	const void* GetBuffer() const
	{
		return VarBuff;
	}

	void SetValue(EVarType ValType, const void* Val)
	{
		FMemory::Memzero(VarBuff, VarTypeMaxSize);
		int32 ValSize = VarTypeMaxSize;
		
		switch (ValType)
		{
		case EVarType::Bool:
			ValSize = sizeof(bool);
			break;
		default:
			ValSize = VarTypeSize(ValType);
			break;
		}
		
		FMemory::Memcpy(VarBuff, Val, ValSize);	
	}

protected:
	uint8 VarBuff[VarTypeMaxSize];
};
