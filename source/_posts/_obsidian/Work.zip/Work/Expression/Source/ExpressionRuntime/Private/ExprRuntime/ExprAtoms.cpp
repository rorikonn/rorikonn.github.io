﻿#include "ExprRuntime/ExprAtoms.h"
#include "ExpressionInstruction.h"

REGISTER_EXPRESSION_ATOM(RandomRange, EVarType::Int, AtomRandomRange, EVarType::Int, EVarType::Int);
void AtomRandomRange::ExecCommon(FExpressionContext& Context) const
{
	const int32 Max = GetArgRefAt<int32>(0);
	const int32 Min = GetArgRefAt<int32>(1);
	
	int32 Result = FMath::RandRange(Min, Max);
	ReturnVal(EVarType::Int, &Result);
}
