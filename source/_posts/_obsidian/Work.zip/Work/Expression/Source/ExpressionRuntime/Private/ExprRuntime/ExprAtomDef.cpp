﻿
#include "ExprRuntime/ExprAtomDef.h"

const FExpressionAtomValue& EmptyExpressionAtomValue()
{
	static FExpressionAtomValue EmptyValue;
	return EmptyValue;
}

void FExpressionAtom::ExecCommon(FExpressionContext& Context) const
{
	ensureAlwaysMsgf(0, TEXT("this default base function should NOT be called, please check you newly-added Atom, make sure you has selected correct FExpressionContext OR FSceneExprCtx"));
}
