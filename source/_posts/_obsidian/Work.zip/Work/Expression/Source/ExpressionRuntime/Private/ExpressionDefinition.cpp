﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "ExpressionDefinition.h"

DEFINE_LOG_CATEGORY(LogExpression);
DEFINE_LOG_CATEGORY(LogExpressionCompiler);
