﻿#pragma once
#include "ExprAtomDef.h"

struct AtomRandomRange : public FExpressionAtom
{
	virtual void ExecCommon(FExpressionContext& Context) const override;
};

