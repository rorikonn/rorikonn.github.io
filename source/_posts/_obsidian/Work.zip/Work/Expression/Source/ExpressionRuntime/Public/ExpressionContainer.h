﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ExpressionInstruction.h"
#include "ExpressionContainer.generated.h"

/**
 * 
 */
USTRUCT(meta=(IgnoreDataWrapperGen))
struct EXPRESSIONRUNTIME_API FExpressionContainer
{
	GENERATED_BODY()

	UPROPERTY()
	FExpressionInstructionBuffer InstructionBuffer;

#if WITH_EDITORONLY_DATA
	UPROPERTY(EditAnywhere)
	FString Code;

	UPROPERTY(Transient, EditAnywhere)
	bool Dirty;
#endif
};
