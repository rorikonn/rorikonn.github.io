﻿#include "ExprRuntime/ExprDef.h"

#include "ExprRuntime/ExprAtomDef.h"

void FExpressionContext::Exec(const FExpressionAtom& Atom)
{
	return ExecImpl(Atom);
}

void FExpressionContext::ExecImpl(const FExpressionAtom& Atom)
{
	Atom.ExecCommon(*this);
}

void FExpressionContext::ExecAtom(const FExpressionAtom& Atom, FExpressionExecutionStack& Stack)
{
	const FExprAtomParamsLayout* Layout = Atom.GetParamsLayout();
	check(Layout && Layout->IsValid())

	BuildAtomArgs(Atom, Stack, *Layout);

	Exec(Atom);

	ReadAtomRet(Atom, Stack, *Layout);
}

bool FExpressionContext::BuildAtomArgs(const FExpressionAtom& Atom, FExpressionExecutionStack& Stack, const FExprAtomParamsLayout& ParamsLayout) const
{
	FExpressionAtomParams& Params = FExpressionAtomParams::GetInstance();
	Params.Reset();
	Params.AttachStack(Stack);
	
	const TArray<EVarType>& ArgTypes = ParamsLayout.GetArgTypes();

	if(ArgTypes.Num() > 0)
	{
		Params.ArgsRef().AddUninitialized(ArgTypes.Num());
		for(int32 i = ArgTypes.Num() - 1; i >= 0; --i)
		{
			const EVarType& VarType = ArgTypes[i];
			FExpressionAtomValue& Value = Params.ArgsRef()[i];
			Value.SetValue(VarType, Stack.PopRawData(VarType));
		}	
	}
	
	return true;
}

bool FExpressionContext::ReadAtomRet(const FExpressionAtom& Atom, FExpressionExecutionStack& Stack, const FExprAtomParamsLayout& ParamsLayout) const
{
	FExpressionAtomParams& Params = FExpressionAtomParams::GetInstance();
	const EVarType RetType = ParamsLayout.GetRetType();
	
	if(RetType != EVarType::Void)
	{
		if(!ensureAlwaysMsgf(Params.HasReturnedVal(), TEXT("Atom hasn't returned value %s, please check you newly-added Atom"), *GLExpressionCompiler::VarTypeName(RetType)))
		{
			Stack.Push(&EmptyExpressionAtomValue(), VarTypeSize(RetType));
		}
		else
		{
			Stack.Push(Params.RetRef().GetBuffer(), VarTypeSize(RetType));
		}
	}

	return true;
}
