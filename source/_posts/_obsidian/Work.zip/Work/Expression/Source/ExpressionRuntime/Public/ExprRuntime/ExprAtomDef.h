﻿#pragma once
#include "ExprDef.h"

struct FExprAtomParamsLayout;
struct FSceneExprAtom;

struct EXPRESSIONRUNTIME_API FExpressionAtomValue : public FExpressionVarValue
{

};

EXPRESSIONRUNTIME_API const FExpressionAtomValue& EmptyExpressionAtomValue();

struct EXPRESSIONRUNTIME_API FExpressionAtomParams
{
	void Reset()
	{
		HasReturned = false;
		InputVals.Empty();
		AttachedStack = nullptr;
	}

	void AttachStack(FExpressionExecutionStack& Stack)
	{
		AttachedStack = &Stack;
	}
	
	FExpressionAtomValue& RetRef()
	{
		return OutputVal;
	}

	void SetReturnVal(EVarType ValType, const void* Val) 
	{
		OutputVal.SetValue(ValType, Val);
		ensureAlways(!HasReturned);
		
		HasReturned = true;
	}

	bool HasReturnedVal() const
	{
		return HasReturned;
	}
	
	TArray<FExpressionAtomValue>& ArgsRef()
	{
		return InputVals;
	}

	// notice the following Explicit Specialiazation about FString && AActor
	template<typename T>
	const T* GetArgPtrAt(int32 Idx) 
	{
		if(Idx >= 0 && Idx < InputVals.Num())
		{
			return InputVals[Idx].GetValuePtr<T>();
		}

		return nullptr;
	}
	
	// notice the following Explicit Specialiazation about FString && AActor
	template<typename T>
	const T& GetArgRefAt(int32 Idx) 
	{
		if(Idx >= 0 && Idx < InputVals.Num())
		{
			return InputVals[Idx].GetValueRef<T>();
		}

		return *(StaticCast<const T*>(EmptyExpressionAtomValue().GetBuffer()));
	}
	
	static FExpressionAtomParams& GetInstance()
	{
		static FExpressionAtomParams Params;
		return Params;
	}

	FExpressionAtomParams()
		: AttachedStack(nullptr),
		  HasReturned(false)
	{
	}

	FExpressionExecutionStack* AttachedStack;
	
private:
	bool HasReturned;
	FExpressionAtomValue OutputVal;
	TArray<FExpressionAtomValue> InputVals;
};

template<>
inline const FString* FExpressionAtomParams::GetArgPtrAt<FString>(int32 Idx)
{
	check(AttachedStack)
	if(Idx >= 0 && Idx < InputVals.Num())
	{
		const int32 StringIdx = InputVals[Idx].GetValueRef<int32>();
		if(StringIdx >= 0 && StringIdx < AttachedStack->GetStringTable().Num())
		{
			return &AttachedStack->GetStringTable()[StringIdx];
		}
	}

	return nullptr;
}

template<>
inline const TWeakObjectPtr<AActor>* FExpressionAtomParams::GetArgPtrAt<TWeakObjectPtr<AActor>>(int32 Idx)
{
	check(AttachedStack)
	
	if(Idx >= 0 && Idx < InputVals.Num())
	{
		const int32 ActorIdx = InputVals[Idx].GetValueRef<int32>();
		if(ActorIdx >= 0 && ActorIdx < AttachedStack->GetActorTable().Num())
		{
			return &AttachedStack->GetActorTable()[ActorIdx];
		}
	}

	return nullptr;
}

template<>
inline const AActor* FExpressionAtomParams::GetArgPtrAt<AActor>(int32 Idx)
{
	if(const TWeakObjectPtr<AActor>* Actor = FExpressionAtomParams::GetArgPtrAt<TWeakObjectPtr<AActor>>(Idx))
	{
		return Actor->Get();
	}

	return nullptr;
}

template<>
inline const FString& FExpressionAtomParams::GetArgRefAt<FString>(int32 Idx)
{
	if(const FString* V = GetArgPtrAt<FString>(Idx))
	{
		return *V;
	}

	static FString EmptyString;
	return EmptyString;
}

template<>
inline const TWeakObjectPtr<AActor>& FExpressionAtomParams::GetArgRefAt<TWeakObjectPtr<AActor>>(int32 Idx)
{
	if(const TWeakObjectPtr<AActor>* V = GetArgPtrAt<TWeakObjectPtr<AActor>>(Idx))
	{
		return *V;
	}

	static TWeakObjectPtr<AActor> EmptyActor;
	return EmptyActor;
}

struct EXPRESSIONRUNTIME_API FExpressionAtom
{
	FExpressionAtom()
		: ParamsLayout(nullptr)
	{
	}

	FExpressionAtom(const FExprAtomParamsLayout* InLayout)
		: ParamsLayout(InLayout)
	{
	}
	
	virtual ~FExpressionAtom()
	{
		
	}

	virtual const FSceneExprAtom* GetSceneAtom() const { return nullptr;}

	virtual void ExecCommon(FExpressionContext& Context) const;

	void SetParamsLayout(const FExprAtomParamsLayout& InLayout)
	{
		ParamsLayout = &InLayout;
	}
	const FExprAtomParamsLayout* GetParamsLayout() const
	{
		return ParamsLayout;
	}

protected:
	template<typename T>
	const T* GetArgPtrAt(int32 Idx) const 
	{
		return FExpressionAtomParams::GetInstance().GetArgPtrAt<T>(Idx);
	}
	
	template<typename T>
	const T& GetArgRefAt(int32 Idx) const
	{
		return FExpressionAtomParams::GetInstance().GetArgRefAt<T>(Idx);
	}

	void ReturnVal(EVarType VarType, void* Var) const
	{
		FExpressionAtomParams& Params = FExpressionAtomParams::GetInstance();
		
		check(Var && Params.AttachedStack)
		if(VarType == EVarType::Actor)
		{
			AActor** ActorPtr = StaticCast<AActor**>(Var);
			TWeakObjectPtr<AActor> Actor = TWeakObjectPtr<AActor>(StaticCast<AActor*>(*ActorPtr));
			const int32 ActorIndex = Params.AttachedStack->GetActorTable().Add(Actor);

			Params.SetReturnVal(EVarType::Actor, &ActorIndex);
			return;
		}

		if(VarType == EVarType::String)
		{
			FString& String = *(StaticCast<FString*>(Var));
			const int32 StringIndex = Params.AttachedStack->GetStringTable().Add(MoveTemp(String));

			Params.SetReturnVal(EVarType::String, &StringIndex);
			return;
		}
		
		Params.SetReturnVal(VarType, Var);
	}

private:
	const FExprAtomParamsLayout* ParamsLayout;
};

template<typename T>
struct TExprAtomSingleton : public FExprAtomParamsLayout
{

	TExprAtomSingleton(EVarType InRetType, TArray<EVarType> InArgTypes)
		: FExprAtomParamsLayout(InArgTypes, InRetType)
	{
		AtomInst.SetParamsLayout(*this);
	}
	
	const T* GetAtomInstance()
	{
		return &AtomInst;
	}
	
	T AtomInst;
};
