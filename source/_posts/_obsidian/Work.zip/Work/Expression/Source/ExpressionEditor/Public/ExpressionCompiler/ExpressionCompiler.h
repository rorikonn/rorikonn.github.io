// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "ExpressionContainer.h"
#include "ExpressionDefinition.h"
#include "ExpressionInstruction.h"

#if PLATFORM_WINDOWS
#include "Windows/AllowWindowsPlatformTypes.h"
#include "Windows/PreWindowsApi.h"
#include "windows.h"
#include "fileapi.h"
#include "Windows/PostWindowsApi.h"
// ReSharper disable once CppUnusedIncludeDirective
#include "Windows/HideWindowsPlatformTypes.h"
#endif

#if PLATFORM_LINUX
#define EXTERN_C extern "C"
#endif

using namespace GLExpressionCompiler;

struct FVarDeclaration
{
	FVarDeclaration(EVarType VarType, const FString& VarName, int32 Address, int32 BlockIndex)
		: VarType(VarType),
		  VarName(VarName),
		  Address(Address),
		  BlockIndex(BlockIndex)
	{
	}

	EVarType VarType;
	FString VarName;
	int32 Address;
	int32 BlockIndex;
};

struct FAutoDestroyInstructionSet : TArray<IExpressionInstruction*>
{
	~FAutoDestroyInstructionSet()
	{
		for (int32 Index = 0; Index < Num(); ++Index)
		{
			delete GetData()[Index];
		}
	}

	void SafeEmpty()
	{
		for (int32 Index = 0; Index < Num(); ++Index)
		{
			delete GetData()[Index];
		}

		Empty();
	}
};

class FGLExpressionCompiler;

struct FExpressionKeywordRegisterInfo
{
	FExpressionKeywordRegisterInfo(FName InFuncName, bool InPushVarName)
		: CallFunctionName(InFuncName), PushVarName(InPushVarName)
	{
	}
	
	FName CallFunctionName;
	bool PushVarName;
};

#define EXPRESSION_CONTEXT_REGISTER_KEYWORD_FUNC(KeyWordName, FunctionName) \
	FExpressionKeywordRegisterInfo KeyWordName##Info(FName(TEXT(#FunctionName)), false); \
	KeyWord2Function.Add({FName(TEXT(#KeyWordName)), KeyWordName##Info})

#define EXPRESSION_CONTEXT_REGISTER_KEYWORD_FUNC_PUSH(KeyWordName, FunctionName) \
	FExpressionKeywordRegisterInfo KeyWordName##Info(FName(TEXT(#FunctionName)), true); \
	KeyWord2Function.Add({FName(TEXT(#KeyWordName)), KeyWordName##Info})
	
#define EXPRESSION_CONTEXT_REGISTER_KEYWORD_VAR(KeyWordName, VarValue, VarType) \
	KeyWord2##VarType.Add(FName(TEXT(#KeyWordName)), StaticCast<VarType>(VarValue))

class EXPRESSIONEDITOR_API FExpressionCompileContextBase
{
public:
	FExpressionCompileContextBase();
	virtual ~FExpressionCompileContextBase() = default;
	virtual FName GetContextName() { return NAME_None; }
	virtual bool MatchContext(const FString& InName) { return InName.IsEmpty(); }
	virtual void Reset() { ; }

	/**
	 * Executed before PushVariable real compile logic happens.
	 * Used to convert a variable read instruction to a context value reading instruction
	 * @return true if this VarName is used as a context keyword and the real PushVariable compile should be skipped 
	 */
	virtual bool PrePushVariableCompile(FGLExpressionCompiler* Compiler, FString VarName);

	/**
	 * Check is the given VarName is a keyword in this context
	 */
	virtual bool IsKeyWord(FString VarName);

protected:
	TMap<FName, FExpressionKeywordRegisterInfo> KeyWord2Function;
	TMap<FName, int> KeyWord2int;

private:
	static TMap<FName, FExpressionCompileContextBase*>& GetCompileContextMap();

public:
	static void Register(FName ContextName, FExpressionCompileContextBase* Context);
	static FExpressionCompileContextBase* Get(FName ContextName);

	struct FRegister
	{
		FRegister(FExpressionCompileContextBase* Context)
		{
			Register(Context->GetContextName(), Context);
		}
	};
};

#define IMPLEMENT_EXPRESSION_CONTEXT(ContextName, ParentContext) \
	virtual FName GetContextName() override { return TEXT(#ContextName); } \
	virtual bool MatchContext(const FString& InName) override { if (InName == TEXT(#ContextName)) return true; return ParentContext::MatchContext(InName); }

#define REGISTER_EXPRESSION_CONTEXT(ContextClass) \
	FExpressionCompileContextBase::FRegister ContextClass##ContextRegister(new ContextClass());

#ifndef EXTERN_C
#define EXTERN_C    extern "C"
#endif

EXTERN_C int parse_code(FILE* input_file);

/**
 * 
 */
class FGLExpressionCompiler
{
public:
	TArray<FExpressionCompileContextBase*> CompileContextArray;

	FAutoDestroyInstructionSet InstructionSet;
	int32 CurStackAddr;

	// Declaration info after DeclareVar and before FinishVarDeclaration
	EVarType DeclaringVarType;
	// Declaration info after DeclareVar and before FinishVarDeclaration
	TArray<FString> DeclaringVariable;
	// Pushing value stack, let operator know with type of variable to process
	TArray<EVarType> PushingValueType;
	// Block stack address cache, used to drop all variable after a block
	TArray<int32> BlockStartAddress;
	TArray<int32> BlockIndex;

	TSet<FString> Labels;

	bool bDeclaringBuildInVar;
	int32 BuildInVarSize;
	TMap<FString, FVarDeclaration> BuildInVarDecls;
	TMap<FString, FVarDeclaration> VarDeclarations;

	TStringBuilder<2048> Log;
	TStringBuilder<256> Error;

#define ELSE_IF_LABEL(Index) FString::Printf(TEXT("ELSE_IF_%d"), Index)
#define END_IF_LABEL(Index) FString::Printf(TEXT("END_IF_%d"), Index)
#define BEGIN_WHILE_LABEL(Index) FString::Printf(TEXT("BEG_WHILE_%d"), Index)
#define END_WHILE_LABEL(Index) FString::Printf(TEXT("END_WHILE_%d"), Index)

	FGLExpressionCompiler()
	{
		Reset(TArray<FExpressionCompileContextBase*>());
	}

	void Reset(const TArray<FExpressionCompileContextBase*>& InContextArray)
	{
		CompileContextArray = InContextArray;
		InstructionSet.SafeEmpty();
		CurStackAddr = 0;

		DeclaringVarType = EVarType::Void;
		DeclaringVariable.Empty();
		PushingValueType.Empty();
		BlockStartAddress.Empty();
		BlockIndex.Empty();
		BlockIndex.Add(0);

		Labels.Empty();

		bDeclaringBuildInVar = false;
		BuildInVarDecls.Empty();
		VarDeclarations.Empty();

		Log.Reset();
		Error.Reset();
	}

	void Compile(FILE* FilePtr)
	{
		parse_code(FilePtr);
	}

	void Serialize(FExpressionInstructionBuffer* OutInstructionBuffer = nullptr) const
	{
		static FExpressionInstructionBuffer GInstructionBuffer;
		if (!OutInstructionBuffer)
		{
			OutInstructionBuffer = &GInstructionBuffer;
		}

		IExpressionInstruction::FSerializer Serializer(*OutInstructionBuffer);
		IExpressionInstruction::Serialize(InstructionSet, Serializer);
	}

	void StmtEnsure()
	{
		if (!PushingValueType.IsEmpty())
		{
			AppendError(TEXT("system error [stmt error] pushing type cache is not empty"));
		}

		if (!DeclaringVariable.IsEmpty())
		{
			AppendError(TEXT("system error [stmt error] declaring variable cache is not empty"));
		}
	}

	void DeclareBuildInVar(EVarType VarType, FString VarName)
	{
		if (!bDeclaringBuildInVar)
		{
			ensure(BuildInVarDecls.IsEmpty());
			ensure(CurStackAddr == 0);
			bDeclaringBuildInVar = true;
		}

		const FVarDeclaration* ExistDecl = BuildInVarDecls.Find(VarName);

		if (ExistDecl)
		{
			AppendError(TEXT("redeclaration of build in var ‘%s %s’, previous declared as '%s %s'"), *VarTypeName(VarType), *VarName, *VarTypeName(ExistDecl->VarType), *ExistDecl->VarName);
			return;
		}

		FVarDeclaration Declaration(VarType, VarName, CurStackAddr, 0);

		// Remember current stack address and move stack address [size] forward
		const int32 VarSize = VarTypeSize(VarType);
		BuildInVarDecls.Emplace(VarName, Declaration);

		CurStackAddr += VarSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		AppendLog(TEXT("declare build in var '%s %s'[%d]"), *VarTypeName(VarType), *VarName, Declaration.Address);
	}

	void FinishBuildInDecl()
	{
		BuildInVarSize = 0;
		for (const auto& Pair : BuildInVarDecls)
		{
			BuildInVarSize += VarTypeSize(Pair.Value.VarType);
		}

		InstructionSet.Add(new FBuildInInfo(BuildInVarSize));
		bDeclaringBuildInVar = false;
		CurStackAddr = 0;
	}

	void DeclareVar(EVarType VarType, FString VarName)
	{
		ProcessInputString(VarName);

		for (FExpressionCompileContextBase* CompileContext : CompileContextArray)
		{
			if (CompileContext->IsKeyWord(VarName))
			{
				AppendError(TEXT("variable name %s is used as expression keyword"), *VarName);
				return;
			}
		}

		ensure(DeclaringVarType == EVarType::Void);
		ensure(DeclaringVariable.IsEmpty());
		DeclaringVarType = VarType;

		AddVarDeclaration(VarType, VarName);
	}

	void RepeatDecl(FString VarName)
	{
		ProcessInputString(VarName);

		for (FExpressionCompileContextBase* CompileContext : CompileContextArray)
		{
			if (CompileContext->IsKeyWord(VarName))
			{
				AppendError(TEXT("variable name %s is used as expression keyword"), *VarName);
				return;
			}
		}

		ensure(DeclaringVarType != EVarType::Void);
		ensure(!DeclaringVariable.IsEmpty());

		AddVarDeclaration(DeclaringVarType, VarName);
	}

	void FinishVarDeclaration()
	{
		DeclaringVarType = EVarType::Void;
		DeclaringVariable.Empty();
	}

	void AssignVar(FString VarName, bool Peek = false)
	{
		ProcessInputString(VarName);

		// Pop value on stack top and copy to variable address
		bool bIsBuildInVar = false;
		const FVarDeclaration* ExistDecl = VarDeclarations.Find(VarName);

		if (!ExistDecl)
		{
			bIsBuildInVar = true;
			ExistDecl = BuildInVarDecls.Find(VarName);
			if (ExistDecl && !bDeclaringBuildInVar)
			{
				AppendError(TEXT("build in variable %s is read only"), *VarName);
				return;
			}
		}

		if (!ExistDecl)
		{
			AppendError(TEXT("undefined variable %s"), *VarName);
			return;
		}

		const int32 VarSize = VarTypeSize(ExistDecl->VarType);

		// Check stack address, should contains at lease target variable and pop value (VarSize * 2)
		if (!bDeclaringBuildInVar && CurStackAddr < ExistDecl->Address + VarSize * 2)
		{
			AppendError(TEXT("system error [stack address error] when assign variable '%s %s'"), *VarTypeName(ExistDecl->VarType), *VarName);
			return;
		}

		if (PushingValueType.Num() < 1)
		{
			AppendError(TEXT("system error [pushing type record error] when assign variable '%s %s'"), *VarTypeName(ExistDecl->VarType), *VarName);
			return;
		}

		const EVarType ValueType = PushingValueType.Top();
		const int32 ValueAddress = CurStackAddr - VarSize;
		const int32 VariableAddress = ExistDecl->Address;
		if (ValueType != ExistDecl->VarType)
		{
			if (!bIsBuildInVar && VarTypeCanCast(ValueType, ExistDecl->VarType))
			{
				InstructionSet.Add(new FCastInstruction(ValueAddress, ValueType, ExistDecl->VarType));
				AppendLog(TEXT("cast value %s -> %s at [%d], stack top [%d]"), *VarTypeName(ValueType), *VarTypeName(ExistDecl->VarType), ValueAddress, CurStackAddr);
			}
			else
			{
				AppendError(TEXT("type not match when assign most recent pushed value %s to var '%s %s'"), *VarTypeName(ValueType), *VarTypeName(ExistDecl->VarType), *VarName);
				return;
			}
		}

		const int32 PackedVarAddress = PackVariableAddress(ExistDecl->Address, bIsBuildInVar);
		if (Peek)
		{
			InstructionSet.Add(new FPeekInstruction(VarSize, PackedVarAddress));
		}
		else
		{
			InstructionSet.Add(new FPopInstruction(VarSize, PackedVarAddress));
			CurStackAddr -= VarSize;
			PushingValueType.RemoveAt(PushingValueType.Num() - 1);
		}

		const FString Operation = Peek ? FString(TEXT("peek")) : FString(TEXT("pop"));
		AppendLog(TEXT("%s value from [%d:%d] and assgin to %s '%s %s'[%d] , stack top [%d]"), *Operation, ValueAddress, VarSize, bIsBuildInVar ? TEXT("build in var") : TEXT(""),
		          *VarTypeName(ExistDecl->VarType), *VarName, VariableAddress, CurStackAddr);
	}

	void AssignDeclaration()
	{
		for (int32 Index = 0; Index < DeclaringVariable.Num(); ++Index)
		{
			AssignVar(DeclaringVariable[Index], Index != DeclaringVariable.Num() - 1);
		}

		FinishVarDeclaration();
	}

	void PushVariable(FString VarName)
	{
		ProcessInputString(VarName);

		for (FExpressionCompileContextBase* CompileContext : CompileContextArray)
		{
			if (CompileContext->PrePushVariableCompile(this, VarName))
			{
				return;
			}
		}

		bool bIsBuildInVar = false;
		const FVarDeclaration* ExistDecl = VarDeclarations.Find(VarName);

		if (!ExistDecl)
		{
			ExistDecl = BuildInVarDecls.Find(VarName);
			bIsBuildInVar = true;
		}

		if (!ExistDecl)
		{
			AppendError(TEXT("undefined variable %s"), *VarName);
			return;
		}

		const int32 VarSize = VarTypeSize(ExistDecl->VarType);
		const int32 ValueAddress = CurStackAddr;
		const int32 VarAddress = PackVariableAddress(ExistDecl->Address, bIsBuildInVar);

		// Check stack address, should contains variable value
		if (!bIsBuildInVar && CurStackAddr < ExistDecl->Address + VarSize)
		{
			AppendError(TEXT("system error when push variable %s"), *VarName);
			return;
		}
		else if (bIsBuildInVar && BuildInVarSize < ExistDecl->Address + VarSize)
		{
			AppendError(TEXT("system error when push build in variable %s"), *VarName);
			return;
		}

		InstructionSet.Add(new FPushVariableInstruction(VarSize, VarAddress));
		CurStackAddr += VarSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		PushingValueType.Add(ExistDecl->VarType);

		AppendLog(TEXT("push variable '%s %s'[%d] to [%d] , stack top [%d]"), *VarTypeName(ExistDecl->VarType), *VarName, ExistDecl->Address, ValueAddress, CurStackAddr);
	}

	void PushValue(EVarType ValueType, const FString& ValueString)
	{
		switch (ValueType)
		{
		case EVarType::Int:
			PushIntValue(FCString::Atoi(*ValueString));
			break;
		case EVarType::Float:
			PushFloatValue(FCString::Atof(*ValueString));
			break;
		case EVarType::Bool:
			PushBoolValue(FCString::ToBool(*ValueString));
			break;
		case EVarType::String:
			PushStringValue(ValueString);
			break;
		case EVarType::Target:
			break;
		default:
			AppendError(TEXT("trying to push unknown type value '%s %s'"), *VarTypeName(ValueType), *ValueString);
			break;
		}
	}

	void PopValue()
	{
		if (PushingValueType.Num() < 1)
		{
			AppendError(TEXT("system error [pushing type record error] when pop value"));
			return;
		}

		const EVarType ValueType = PushingValueType.Pop();
		const int32 ValueSize = VarTypeSize(ValueType);

		if (CurStackAddr < ValueSize)
		{
			AppendError(TEXT("system error when pop value"));
			return;
		}

		const int32 ValueAddress = CurStackAddr - ValueSize;
		CurStackAddr -= ValueSize;

		// When call function ret type is void, executor will not push any value into stack,
		// but call function compile unit will still push void type into PushingValueType stack and move stack address forward
		// this allows the PopValue compile unit does not need to care about the function ret value type
		// so we only need to pop the PushingValueType stack and move stack address when compile
		// but not need to do any 'REAL' instruction when execute
		if (ValueType != EVarType::Void)
		{
			InstructionSet.Add(new FPopInstruction(ValueSize, -1));
			AppendLog(TEXT("pop value %s size: %d at [%d], stack top [%d]"), *VarTypeName(ValueType), ValueSize, ValueAddress, CurStackAddr);
		}
	}

	void PushIntValue(int32 Value)
	{
		const int32 VarSize = VarTypeSize(EVarType::Int);
		TArray<uint8> Data;
		Data.AddZeroed(VarSize);
		FMemory::Memcpy(Data.GetData(), &Value, sizeof(int32));

		const int32 ValueAddress = CurStackAddr;
		InstructionSet.Add(new FPushConstInstruction(Data));
		CurStackAddr += VarSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		PushingValueType.Add(EVarType::Int);

		AppendLog(TEXT("push int %d to [%d], stack top [%d]"), Value, ValueAddress, CurStackAddr);
	}

	void PushBoolValue(bool Value)
	{
		const int32 VarSize = VarTypeSize(EVarType::Bool);
		TArray<uint8> Data;
		Data.AddZeroed(VarSize);
		FMemory::Memcpy(Data.GetData(), &Value, sizeof(bool));

		const int32 ValueAddress = CurStackAddr;
		InstructionSet.Add(new FPushConstInstruction(Data));
		CurStackAddr += VarSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		PushingValueType.Add(EVarType::Bool);

		AppendLog(TEXT("push bool %s to [%b], stack top [%d]"), Value ? TEXT("true") : TEXT("false"), ValueAddress, CurStackAddr);
	}

	void PushFloatValue(float Value)
	{
		const int32 VarSize = VarTypeSize(EVarType::Float);
		TArray<uint8> Data;
		Data.AddZeroed(VarSize);
		FMemory::Memcpy(Data.GetData(), &Value, sizeof(float));

		const int32 ValueAddress = CurStackAddr;
		InstructionSet.Add(new FPushConstInstruction(Data));
		CurStackAddr += VarSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		PushingValueType.Add(EVarType::Float);

		AppendLog(TEXT("push float %f to [%d], stack top [%d]"), Value, ValueAddress, CurStackAddr);
	}

	void PushStringValue(FString Value)
	{
		ProcessInputString(Value);

		const int32 VarSize = VarTypeSize(EVarType::String);

		const int32 ValueAddress = CurStackAddr;
		InstructionSet.Add(new FPushStringInstruction(Value));
		CurStackAddr += VarSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		PushingValueType.Add(EVarType::String);

		AppendLog(TEXT("push string %s to [%d], stack top [%d]"), *Value, ValueAddress, CurStackAddr);
	}

	void PushTargetValue(int32 TargetIndex)
	{
		const int32 VarSize = VarTypeSize(EVarType::Target);
		TArray<uint8> Data;
		Data.AddZeroed(VarSize);
		FMemory::Memcpy(Data.GetData(), &TargetIndex, sizeof(int32));

		const int32 ValueAddress = CurStackAddr;
		InstructionSet.Add(new FPushConstInstruction(Data));
		CurStackAddr += VarSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		PushingValueType.Add(EVarType::Target);

		AppendLog(TEXT("push target %d to [%d], stack top [%d]"), TargetIndex, ValueAddress, CurStackAddr);
	}

	void Add()
	{
		MathOperator(EMath_Add);
	}

	void Sub()
	{
		MathOperator(EMath_Sub);
	}

	void Mul()
	{
		MathOperator(EMath_Mul);
	}

	void Div()
	{
		MathOperator(EMath_Div);
	}

	void Mod()
	{
		MathOperator(EMath_Mod);
	}

	void MathOperator(EMathOperator Operator)
	{
		const FString OperatorName = MathOperatorName(Operator);

		if (PushingValueType.Num() < 2)
		{
			AppendError(TEXT("system error [pushing type record error] execute %s operator"), *OperatorName);
			return;
		}


		const EVarType RhsType = PushingValueType.Pop();
		const EVarType LhsType = PushingValueType.Pop();
		const EVarType CastType = LhsType == RhsType ? RhsType : VarTypeUpCast(LhsType, RhsType);

		if (CastType == EVarType::Void
			|| !(VarTypeSize(LhsType) == VarTypeSize(CastType) && VarTypeSize(RhsType) == VarTypeSize(CastType))
			|| (Operator == EMath_Add && (CastType != EVarType::Int && CastType != EVarType::Float && CastType != EVarType::String))
			|| (Operator == EMath_Sub && (CastType != EVarType::Int && CastType != EVarType::Float))
			|| (Operator == EMath_Mul && (CastType != EVarType::Int && CastType != EVarType::Float))
			|| (Operator == EMath_Div && (CastType != EVarType::Int && CastType != EVarType::Float))
			|| (Operator == EMath_Mod && (CastType != EVarType::Int))
		)
		{
			AppendError(TEXT("invalid operator %s %s %s"), *VarTypeName(LhsType), *OperatorName, *VarTypeName(RhsType));
			return;
		}

		const int32 VarSize = VarTypeSize(CastType);

		// Check stack address, should contains at lease target variable and pop value (VarSize * 2)
		if (CurStackAddr < VarSize * 2)
		{
			AppendError(TEXT("system error [stack address error] when execute %s operator"), *OperatorName);
			return;
		}

		const int32 LhsValueAddress = CurStackAddr - VarSize * 2;
		const int32 RhsValueAddress = CurStackAddr - VarSize;
		const int32 ResultAddress = CurStackAddr - VarSize * 2;

		int32 CastNumber = 0;
		if (LhsType != CastType)
		{
			InstructionSet.Add(new FCastInstruction(LhsValueAddress, LhsType, CastType));
			AppendLog(TEXT("cast value %s -> %s at [%d], stack top [%d]"), *VarTypeName(LhsType), *VarTypeName(CastType), LhsValueAddress, CurStackAddr);
			++CastNumber;
		}
		if (RhsType != CastType)
		{
			InstructionSet.Add(new FCastInstruction(RhsValueAddress, RhsType, CastType));
			AppendLog(TEXT("cast value %s -> %s at [%d], stack top [%d]"), *VarTypeName(RhsType), *VarTypeName(CastType), RhsValueAddress, CurStackAddr);
			++CastNumber;
		}

		if (CastNumber > 1)
		{
			AppendError(TEXT("system error [type cast error] cast more than once when execute %s operator"), *OperatorName);
			return;
		}

		switch (Operator)
		{
		case EMath_Add:
			InstructionSet.Add(new FAddInstruction(CastType));
			break;
		case EMath_Sub:
			InstructionSet.Add(new FSubInstruction(CastType));
			break;
		case EMath_Mul:
			InstructionSet.Add(new FMulInstruction(CastType));
			break;
		case EMath_Div:
			InstructionSet.Add(new FDivInstruction(CastType));
			break;
		case EMath_Mod:
			InstructionSet.Add(new FModInstruction(CastType));
			break;
		}

		// Pop 2 value and push 1 value
		CurStackAddr -= VarSize;
		PushingValueType.Push(CastType);

		AppendLog(TEXT("%s [%d] %s [%d] -> [%d], stack top [%d]"), *VarTypeName(LhsType), LhsValueAddress, *OperatorName, RhsValueAddress, ResultAddress, CurStackAddr);
	}

	void Greater()
	{
		CompareOperator(ECompare_Greater);
	}

	void Less()
	{
		CompareOperator(ECompare_Less);
	}

	void GreaterEqual()
	{
		CompareOperator(ECompare_GreaterEqual);
	}

	void LessEqual()
	{
		CompareOperator(ECompare_LessEqual);
	}

	void Equal()
	{
		CompareOperator(ECompare_Equal);
	}

	void NotEqual()
	{
		CompareOperator(ECompare_NotEqual);
	}

	void CompareOperator(ECompareOperator Operator)
	{
		const FString OperatorName = CompareOperatorName(Operator);

		if (PushingValueType.Num() < 2)
		{
			AppendError(TEXT("system error [pushing type record error] execute %s operator"), *OperatorName);
			return;
		}

		const EVarType RhsType = PushingValueType.Pop();
		const EVarType LhsType = PushingValueType.Pop();
		const EVarType CastType = LhsType == RhsType ? RhsType : VarTypeUpCast(LhsType, RhsType);

		if (CastType == EVarType::Void)
		{
			AppendError(TEXT("invalid operator %s %s %s"), *VarTypeName(LhsType), *OperatorName, *VarTypeName(RhsType));
			return;
		}

		const int32 VarSize = VarTypeSize(CastType);

		// Check stack address, should contains at lease target variable and pop value (VarSize * 2)
		if (CurStackAddr < VarSize * 2)
		{
			AppendError(TEXT("system error [stack address error] when execute %s operator"), *OperatorName);
			return;
		}

		const int32 LhsValueAddress = CurStackAddr - VarSize * 2;
		const int32 RhsValueAddress = CurStackAddr - VarSize;
		const int32 ResultAddress = CurStackAddr - VarSize * 2;

		int32 CastNumber = 0;
		if (LhsType != CastType)
		{
			InstructionSet.Add(new FCastInstruction(LhsValueAddress, LhsType, CastType));
			AppendLog(TEXT("cast value %s -> %s at [%d], stack top [%d]"), *VarTypeName(LhsType), *VarTypeName(CastType), LhsValueAddress, CurStackAddr);
			++CastNumber;
		}
		if (RhsType != CastType)
		{
			InstructionSet.Add(new FCastInstruction(RhsValueAddress, RhsType, CastType));
			AppendLog(TEXT("cast value %s -> %s at [%d], stack top [%d]"), *VarTypeName(RhsType), *VarTypeName(CastType), RhsValueAddress, CurStackAddr);
			++CastNumber;
		}

		if (CastNumber > 1)
		{
			AppendError(TEXT("system error [type cast error] cast more than once when execute %s operator"), *OperatorName);
			return;
		}

		switch (Operator)
		{
		case ECompare_Greater:
			InstructionSet.Add(new FGreaterInstruction(CastType));
			break;
		case ECompare_Less:
			InstructionSet.Add(new FLessInstruction(CastType));
			break;
		case ECompare_GreaterEqual:
			InstructionSet.Add(new FGreaterEqualInstruction(CastType));
			break;
		case ECompare_LessEqual:
			InstructionSet.Add(new FLessEqualInstruction(CastType));
			break;
		case ECompare_Equal:
			InstructionSet.Add(new FEqualInstruction(CastType));
			break;
		case ECompare_NotEqual:
			InstructionSet.Add(new FNotEqualInstruction(CastType));
			break;
		}

		// Pop 2 value and push 1 boolean
		CurStackAddr -= VarSize * 2;
		CurStackAddr += VarTypeSize(EVarType::Bool);
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		PushingValueType.Push(EVarType::Bool);

		AppendLog(TEXT("%s [%d] %s [%d] -> [%d], stack top [%d]"), *VarTypeName(LhsType), LhsValueAddress, *OperatorName, RhsValueAddress, ResultAddress, CurStackAddr);
	}

	void Negative()
	{
		if (PushingValueType.Num() < 1)
		{
			AppendError(TEXT("system error [pushing type record error] execute 'neg' operator"));
			return;
		}

		const EVarType ValueType = PushingValueType.Top();

		if (ValueType != EVarType::Int && ValueType != EVarType::Float)
		{
			AppendError(TEXT("invalid operator -%s"), *VarTypeName(ValueType));
			return;
		}

		const int32 VarSize = VarTypeSize(ValueType);
		// Check stack address, should contains at lease target variable and pop value (VarSize * 2)
		if (CurStackAddr < VarSize)
		{
			AppendError(TEXT("system error [stack address error] when execute 'neg' operator"));
			return;
		}

		const int32 ValueAddress = CurStackAddr - VarSize;
		InstructionSet.Add(new FNegativeInstruction(ValueType));

		// Stack address don't need to move, pop 1 push 1

		AppendLog(TEXT("'neg' %s [%d], stack top [%d]"), *VarTypeName(ValueType), ValueAddress, CurStackAddr);
	}

	void Or()
	{
		if (PushingValueType.Num() < 2)
		{
			AppendError(TEXT("system error [pushing type record error] execute || operator"));
			return;
		}

		const EVarType LhsType = PushingValueType[PushingValueType.Num() - 2];
		const EVarType RhsType = PushingValueType[PushingValueType.Num() - 1];

		if (LhsType != RhsType || LhsType != EVarType::Bool)
		{
			AppendError(TEXT("invalid operator %s || %s"), *VarTypeName(LhsType), *VarTypeName(RhsType));
			return;
		}

		const int32 VarSize = VarTypeSize(LhsType);

		// Check stack address, should contains at lease target variable and pop value (VarSize * 2)
		if (CurStackAddr < VarSize * 2)
		{
			AppendError(TEXT("system error [stack address error] when execute || operator"));
			return;
		}

		const int32 LhsValueAddress = CurStackAddr - VarSize * 2;
		const int32 RhsValueAddress = CurStackAddr - VarSize;
		const int32 ResultAddress = CurStackAddr - VarSize * 2;

		InstructionSet.Add(new FOrInstruction());

		// Pop 2 push 1
		CurStackAddr -= VarSize;
		PushingValueType.RemoveAt(PushingValueType.Num() - 1);

		AppendLog(TEXT("[%d] || [%d] -> [%d], stack top [%d]"), LhsValueAddress, RhsValueAddress, ResultAddress, CurStackAddr);
	}

	void And()
	{
		if (PushingValueType.Num() < 2)
		{
			AppendError(TEXT("system error [pushing type record error] execute && operator"));
			return;
		}

		const EVarType LhsType = PushingValueType[PushingValueType.Num() - 2];
		const EVarType RhsType = PushingValueType[PushingValueType.Num() - 1];

		if (LhsType != RhsType || LhsType != EVarType::Bool)
		{
			AppendError(TEXT("invalid operator %s && %s"), *VarTypeName(LhsType), *VarTypeName(RhsType));
			return;
		}

		const int32 VarSize = VarTypeSize(LhsType);

		// Check stack address, should contains at lease target variable and pop value (VarSize * 2)
		if (CurStackAddr < VarSize * 2)
		{
			AppendError(TEXT("system error [stack address error] when execute && operator"));
			return;
		}

		const int32 LhsValueAddress = CurStackAddr - VarSize * 2;
		const int32 RhsValueAddress = CurStackAddr - VarSize;
		const int32 ResultAddress = CurStackAddr - VarSize * 2;

		InstructionSet.Add(new FAndInstruction());

		// Pop 2 push 1
		CurStackAddr -= VarSize;
		PushingValueType.RemoveAt(PushingValueType.Num() - 1);

		AppendLog(TEXT("[%d] && [%d] -> [%d], stack top [%d]"), LhsValueAddress, RhsValueAddress, ResultAddress, CurStackAddr);
	}

	void Not()
	{
		if (PushingValueType.Num() < 1)
		{
			AppendError(TEXT("system error [pushing type record error] execute ! operator"));
			return;
		}

		const EVarType ValueType = PushingValueType[PushingValueType.Num() - 1];

		if (ValueType != EVarType::Bool)
		{
			AppendError(TEXT("invalid operator !%s"), *VarTypeName(ValueType));
			return;
		}

		const int32 VarSize = VarTypeSize(ValueType);
		// Check stack address, should contains at lease target variable and pop value (VarSize * 2)
		if (CurStackAddr < VarSize)
		{
			AppendError(TEXT("system error [stack address error] when execute ! operator"));
			return;
		}

		const int32 ValueAddress = CurStackAddr - VarSize;
		InstructionSet.Add(new FNotInstruction());

		// Stack address don't need to move, pop 1 push 1

		AppendLog(TEXT("![%d], stack top [%d]"), *VarTypeName(ValueType), ValueAddress, CurStackAddr);
	}

	void BeginBlock(int32 Index)
	{
		BlockIndex.Push(Index);
		BlockStartAddress.Push(CurStackAddr);
		AppendLog(TEXT("block start at [%d], stack top [%d]"), BlockStartAddress.Top(), CurStackAddr);
	}

	void EndBlock(int32 Index)
	{
		if (BlockIndex.IsEmpty() || Index != BlockIndex.Top())
		{
			AppendError(TEXT("system error [block index error], end block %d is not most recent begin block"), Index);
			return;
		}

		if (BlockStartAddress.IsEmpty())
		{
			AppendError(TEXT("system error [block address error], end block %d when block address cache is empty"), Index);
			return;
		}

		const int32 CurrentIndex = BlockIndex.Pop();
		VarDeclarations = VarDeclarations.FilterByPredicate([CurrentIndex](const TPair<FString, FVarDeclaration>& Pair)
		{
			ensure(Pair.Value.BlockIndex <= CurrentIndex);
			return Pair.Value.BlockIndex != CurrentIndex;
		});

		const int32 StartAddress = BlockStartAddress.Pop();
		InstructionSet.Add(new FMoveToInstruction(StartAddress));
		CurStackAddr = StartAddress;
		AppendLog(TEXT("block end, move stack top to [%d], stack top [%d]"), StartAddress, CurStackAddr);
	}

	void BeginIf(int32 Index)
	{
		AppendLog(TEXT("begin_if_%d"), Index);
	}

	void IfThen(int32 Index)
	{
		if (PushingValueType.Num() < 1)
		{
			AppendError(TEXT("system error [pushing type record error] execute if then"));
			return;
		}

		const EVarType ValueType = PushingValueType.Pop();
		if (!FJumpZeroInstruction::ValueTypeAllowed(ValueType))
		{
			AppendError(TEXT("system error [value type error] type %s can't used as if then param"), *VarTypeName(ValueType));
			return;
		}

		const int32 VarSize = VarTypeSize(ValueType);
		// Check stack address, should contains at lease target variable and pop value (VarSize * 2)
		if (CurStackAddr < VarSize)
		{
			AppendError(TEXT("system error [stack address error] when execute if then"));
			return;
		}

		InstructionSet.Add(new FJumpZeroInstruction(VarSize, ELSE_IF_LABEL(Index)));
		CurStackAddr -= VarSize;

		AppendLog(TEXT("then, jump to else_if_%d if expr is false, stack top [%d]"), Index, CurStackAddr);
	}

	void EndThen(int32 Index)
	{
		InstructionSet.Add(new FJumpInstruction(END_IF_LABEL(Index)));
		AppendLog(TEXT("end then, jump to end_if_%d, stack top [%d]"), Index, CurStackAddr);

		if (Labels.Contains(ELSE_IF_LABEL(Index)))
		{
			AppendError(TEXT("system error [label repeat] %s"), *ELSE_IF_LABEL(Index));
			return;
		}

		Labels.Add(ELSE_IF_LABEL(Index));
		InstructionSet.Add(new LabelInstruction(ELSE_IF_LABEL(Index)));
		AppendLog(TEXT("label else_if_%d, stack top [%d]"), Index, CurStackAddr);
	}

	void EndIf(int32 Index)
	{
		if (Labels.Contains(END_IF_LABEL(Index)))
		{
			AppendError(TEXT("system error [label repeat] %s"), *END_IF_LABEL(Index));
			return;
		}

		Labels.Add(END_IF_LABEL(Index));
		InstructionSet.Add(new LabelInstruction(END_IF_LABEL(Index)));
		AppendLog(TEXT("label end_if_%d, stack top [%d]"), Index, CurStackAddr);
	}

	void Print(FString Fmt)
	{
		ProcessInputString(Fmt);

		const TArray<EVarType> ParamTypes = PushingValueType;

		FString LogString = FString::Format(TEXT("print \" {0} \""), {Fmt});
		while (!PushingValueType.IsEmpty())
		{
			const EVarType ParamType = PushingValueType.Pop();
			LogString.Appendf(TEXT(", %s"), *VarTypeName(ParamType));
		}

		InstructionSet.Add(new FPrintInstruction(Fmt, ParamTypes));

		AppendLog(LogString);
	}

	void CallFunction(const FString& FunctionName)
	{
		EVarType RetType = EVarType::Void;
		TArray<EVarType> Params;
		FString ContextName;
		if (!FExpressionFunctionTable::GetFunctionDeclaration(FunctionName, RetType, Params, ContextName))
		{
			AppendError(TEXT("undefined function %s"), *FunctionName);
			return;
		}

		bool bSupported = false;
		for (FExpressionCompileContextBase* Context : CompileContextArray)
		{
			bSupported |= Context->MatchContext(ContextName);
			if (bSupported)
			{
				break;
			}
		}

		if (!bSupported)
		{
			AppendError(TEXT("function %s not supported in current context"), *FunctionName);
			return;
		}

		if (PushingValueType.Num() < Params.Num())
		{
			AppendError(TEXT("call function %s failed, params number doesn't match, given %d, requires %d "), *FunctionName, PushingValueType.Num(), Params.Num());
			return;
		}

		for (int32 Index = Params.Num() - 1; Index >= 0; --Index)
		{
			const EVarType ParamType = Params[Index];
			const EVarType GivenType = PushingValueType.Pop();
			
			const int32 ValueSize = VarTypeSize(ParamType);
			const int32 ValueAddress = CurStackAddr - ValueSize;

			if (GivenType != ParamType)
			{
				if (VarTypeCanCast(GivenType, ParamType))
				{
					InstructionSet.Add(new FCastInstruction(ValueAddress, GivenType, ParamType));
				}
				else
				{
					AppendError(TEXT("call function %s failed, %d params type doesn't match, given %s, requires %s "), *FunctionName, Index + 1, *VarTypeName(GivenType), *VarTypeName(ParamType));
					return;
				}
			}

			CurStackAddr -= ValueSize;
			AppendLog(TEXT("call function %s, pop %d param %s, size: %d at [%d], stack top [%d]"), *FunctionName, Index + 1, *VarTypeName(ParamType), ValueSize, ValueAddress, CurStackAddr);
		}

		// When ret type is void, executor will not push any value into stack,
		// but we still need to record to pushing type cache when compile,
		// to simplify pop_value logic when call function is a standalone statement.

		const int32 ValueSize = VarTypeSize(RetType);
		const int32 ValueAddress = CurStackAddr;
		PushingValueType.Push(RetType);
		CurStackAddr += ValueSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		AppendLog(TEXT("call function %s, push ret value %s size: %d at [%d], stack top [%d]"), *FunctionName, *VarTypeName(RetType), ValueSize, ValueAddress, CurStackAddr);

		InstructionSet.Add(new FCallFunctionInstruction(FunctionName));
	}

	void ExpressionReturn()
	{
		EVarType RetType = EVarType::Void;
		if (PushingValueType.Num() > 0)
		{
			ensure(PushingValueType.Num() == 1);
			RetType = PushingValueType.Pop();
		}

		if (RetType != EVarType::Void && RetType != EVarType::Bool && RetType != EVarType::Float && RetType != EVarType::Int)
		{
			AppendError(TEXT("expression return type %s is not supported"), *VarTypeName(RetType));
			return;
		}

		InstructionSet.Add(new FReturnInstruction(RetType));

		AppendLog(TEXT("expression return with type %s"), *VarTypeName(RetType));
	}

	template <typename FmtType, typename... Types>
	void AppendLog(const FmtType& Fmt, Types... FormatArgs)
	{
		Log.Appendf(Fmt, Forward<Types>(FormatArgs)...);
		Log.AppendChar('\n');

		UE_LOG(LogExpressionCompiler, Log, TEXT("%s\n"), *FString::Printf(Fmt, Forward<Types>(FormatArgs)...));
	}

	void AppendLog(const FString& LogStr)
	{
		Log.Append(*LogStr);
		Log.AppendChar('\n');

		UE_LOG(LogExpressionCompiler, Log, TEXT("%s\n"), *LogStr);
	}

	template <typename FmtType, typename... Types>
	void AppendError(const FmtType& Fmt, Types... FormatArgs)
	{
		Error.Appendf(Fmt, Forward<Types>(FormatArgs)...);
		Error.AppendChar('\n');

		UE_LOG(LogExpressionCompiler, Error, TEXT("%s\n"), *FString::Printf(Fmt, Forward<Types>(FormatArgs)...));
	}

	void AppendError(const FString& ErrorStr)
	{
		Error.Append(*ErrorStr);
		Error.AppendChar('\n');

		UE_LOG(LogExpressionCompiler, Error, TEXT("%s\n"), *ErrorStr);
	}

	bool HasErrors(FString* OutError = nullptr) const
	{
		if (Error.Len() > 0)
		{
			if (OutError)
			{
				*OutError = Error.ToString();
			}

			return true;
		}

		return false;
	}

private:
	void AddVarDeclaration(EVarType VarType, FString VarName)
	{
		const FVarDeclaration* ExistDecl = VarDeclarations.Find(VarName);

		if (!ExistDecl)
		{
			ExistDecl = BuildInVarDecls.Find(VarName);
		}

		if (ExistDecl)
		{
			AppendError(TEXT("redeclaration of ‘%s %s’, previous declared as '%s %s'"), *VarTypeName(VarType), *VarName, *VarTypeName(ExistDecl->VarType), *ExistDecl->VarName);
			return;
		}

		FVarDeclaration Declaration(VarType, VarName, CurStackAddr, BlockIndex.Top());

		// Remember current stack address and move stack address [size] forward
		const int32 VarSize = VarTypeSize(VarType);
		VarDeclarations.Emplace(VarName, Declaration);
		InstructionSet.Add(new FMoveInstruction(VarSize));
		DeclaringVariable.Add(VarName);

		CurStackAddr += VarSize;
		if (CurStackAddr >= FExpressionExecutionStack::MaxStackSize)
		{
			AppendError(TEXT("stack over flow"));
			return;
		}

		AppendLog(TEXT("declare '%s %s'[%d], stack top [%d]"), *VarTypeName(VarType), *VarName, Declaration.Address, CurStackAddr);
	}

	void ProcessInputString(FString& String)
	{
		if (String.StartsWith(TEXT("\"")) && String.EndsWith(TEXT("\"")))
		{
			String.RemoveAt(String.Len() - 1);
			String.RemoveAt(0);
		}
	}
};

struct FCompilingCode
{
	bool bIsValid;
	FILE* FilePtr;

	FCompilingCode(const TCHAR* Code)
	{
		// Temp file folder is only available in windows
#if PLATFORM_WINDOWS
		static char Buffer[1024] = {0};
		if (Buffer[0] == 0)
		{
			GetTempPathA(sizeof Buffer, Buffer);
		}
#elif PLATFORM_LINUX
		static char Buffer[] = "/var/temp";
#else
		static char Buffer[] = "";
		checkNoEntry();
#endif

		const FString TempFolderPath(Buffer);
		const FString TempFilePath = FPaths::Combine(TempFolderPath, TEXT("A2GlowExpressionCompilerCache"));

		// Empty file if exists
		if (Code)
		{
#if PLATFORM_WINDOWS
			if (_wfopen_s(&FilePtr, ToCStr(TempFilePath), TEXT("w")) == 0)
			{
				fprintf_s(FilePtr, "%%program\n%ls\n%%program", Code);
				fclose(FilePtr);
			}
#elif PLATFORM_LINUX
			if((FilePtr = fopen((const char*)ToCStr(TempFilePath), "w")) != NULL)
			{
				fclose(FilePtr);
			}
#endif
		}

#if PLATFORM_WINDOWS
		bIsValid = _wfopen_s(&FilePtr, ToCStr(TempFilePath), TEXT("r")) == 0;
#elif PLATFORM_LINUX
		bIsValid = ((FilePtr = fopen((const char*)ToCStr(TempFilePath), "r")) != NULL);
#else
		bIsValid = false;
#endif
	}

	~FCompilingCode()
	{
		fclose(FilePtr);
	}
};


int32 EXPRESSIONEDITOR_API CompileExpression(TArray<FExpressionCompileContextBase*> CompileContextArray, FExpressionInstructionBuffer& Buffer, const TCHAR* Code = nullptr, FString* OutError = nullptr);
int32 EXPRESSIONEDITOR_API CompileExpression(FExpressionContainer& Container, FName ContextName = NAME_None, FString* OutError = nullptr);
