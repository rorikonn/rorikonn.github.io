﻿// Copyright Epic Games, Inc. All Rights Reserved.

#include "ExpressionEditor.h"

#include "ExpressionContainer.h"
#include "ExpressionCompiler/ExpressionContainerCustomization.h"

#define LOCTEXT_NAMESPACE "FExpressionEditorModule"

void FExpressionEditorModule::StartupModule()
{
	// This code will execute after your module is loaded into memory; the exact timing is specified in the .uplugin file per-module
	RegisterPropertyEditorCustomization();
}

void FExpressionEditorModule::ShutdownModule()
{
	// This function may be called during shutdown to clean up your module.  For modules that support dynamic reloading,
	// we call this function before unloading the module.
}

void FExpressionEditorModule::RegisterPropertyEditorCustomization() const
{
	// Register the details customizer
	FPropertyEditorModule& PropertyModule = FModuleManager::LoadModuleChecked<FPropertyEditorModule>("PropertyEditor");
	PropertyModule.RegisterCustomPropertyTypeLayout(StaticStruct<FExpressionContainer>()->GetFName(), FOnGetPropertyTypeCustomizationInstance::CreateStatic(&FExpressionContainerCustomization::MakeInstance));
}

#undef LOCTEXT_NAMESPACE
	
IMPLEMENT_MODULE(FExpressionEditorModule, ExpressionEditor)