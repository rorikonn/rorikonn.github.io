﻿// Fill out your copyright notice in the Description page of Project Settings.

#include "ExpressionCompiler/ExpressionCompiler.h"
#include "Misc/AutomationTest.h"
IMPLEMENT_SIMPLE_AUTOMATION_TEST(FExpressionRetValueTest, "Expression.RetValue", EAutomationTestFlags::EditorContext | EAutomationTestFlags::ProductFilter);

bool FExpressionRetValueTest::RunTest(const FString& Parameters)
{
	const FString CodeRetInt =
		TEXT(
			"int a = 12;"
			"int b = a + 3;"
			"return b;"
		);

	FExpressionInstructionBuffer Buffer;
	if (CompileExpression(TArray<FExpressionCompileContextBase*>(), Buffer, *CodeRetInt))
	{
		return false;
	}
	
	{
		FExpressionExecutor Executor(Buffer.Buffer.GetData(), Buffer.Buffer.Num());
		ExecuteExpression(Executor);

		int32 RetVal = 0;
		if (!Executor.GetRetValue(RetVal))
		{
			return false;
		}

		AddInfo(FString::Printf(TEXT("Ret int test result %d"), RetVal));

		if (RetVal != 15)
		{
			return false;
		}
	}
	
	const FString CodeRetBool =
		TEXT(
			"int a = 12;"
			"int b = a + 3;"
			"return b == 15;"
		);

	Buffer.Reset();
	if (CompileExpression(TArray<FExpressionCompileContextBase*>(), Buffer, *CodeRetBool))
	{
		return false;
	}
	
	{
		FExpressionExecutor Executor(Buffer.Buffer.GetData(), Buffer.Buffer.Num());
		ExecuteExpression(Executor);
		bool RetVal = false;
		if (!Executor.GetRetValue(RetVal))
		{
			return false;
		}
		
		AddInfo(FString::Printf(TEXT("Ret bool test result %s"), RetVal ? TEXT("true") : TEXT("false")));

		if (!RetVal)
		{
			return false;
		}
	}
	
	const FString CodeRetFloat =
		TEXT(
			"float a = 12.0;"
			"float b = a + 3.0;"
			"return b;"
		);

	Buffer.Reset();
	if (CompileExpression(TArray<FExpressionCompileContextBase*>(), Buffer, *CodeRetFloat))
	{
		return false;
	}
	
	{
		FExpressionExecutor Executor(Buffer.Buffer.GetData(), Buffer.Buffer.Num());
		ExecuteExpression(Executor);
		float RetVal = 0.0f;
		if (!Executor.GetRetValue(RetVal))
		{
			return false;
		}
		
		AddInfo(FString::Printf(TEXT("Ret float test result %f"), RetVal));

		if (!FMath::IsNearlyEqual(RetVal, 15.0f))
		{
			return false;
		}
	}

	return true;
}
