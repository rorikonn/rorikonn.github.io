﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "ExpressionCompiler/ExpressionCompiler.h"

extern FGLExpressionCompiler ExpressionCompiler;

FExpressionCompileContextBase::FExpressionCompileContextBase()
{
	//EXPRESSION_CONTEXT_REGISTER_KEYWORD_VAR(EventSource, EExprRoleType::ERoleSource, int); 
	//EXPRESSION_CONTEXT_REGISTER_KEYWORD_VAR(EventTarget, EExprRoleType::ERoleTarget, int);
	
	EXPRESSION_CONTEXT_REGISTER_KEYWORD_FUNC(EventSource, EventSource);
	EXPRESSION_CONTEXT_REGISTER_KEYWORD_FUNC(EventTarget, EventTarget);
}

bool FExpressionCompileContextBase::PrePushVariableCompile(FGLExpressionCompiler* Compiler, FString VarName)
{
	if(KeyWord2int.Contains(FName(VarName)))
	{
		const int VarValue = KeyWord2int[FName(VarName)];
		Compiler->PushIntValue(VarValue);
		return true;
	}
	
	if(KeyWord2Function.Contains(FName(VarName)))
	{
		FExpressionKeywordRegisterInfo &RegisterInfo = KeyWord2Function[FName(VarName)];
		if(RegisterInfo.PushVarName)
		{
			Compiler->PushStringValue(VarName);
		}
		Compiler->CallFunction(RegisterInfo.CallFunctionName.ToString());
		return true;
	}
	
	return false;
}

bool FExpressionCompileContextBase::IsKeyWord(FString VarName)
{
	return KeyWord2Function.Contains(FName(VarName))
		|| KeyWord2int.Contains(FName(VarName));
}

TMap<FName, FExpressionCompileContextBase*>& FExpressionCompileContextBase::GetCompileContextMap()
{
	static struct FAutoDestroyContextMap : TMap<FName, FExpressionCompileContextBase*>
	{
		~FAutoDestroyContextMap()
		{
			for (TIterator Iter = CreateIterator(); Iter; ++Iter)
			{
				const TTuple<FName, FExpressionCompileContextBase*> Pair = *Iter;
				delete Pair.Value;
			}
		}
	} ContextMap;

	return ContextMap;
}

void FExpressionCompileContextBase::Register(FName ContextName, FExpressionCompileContextBase* Context)
{
	check(!GetCompileContextMap().Contains(ContextName));
	GetCompileContextMap().Add(ContextName, Context);
}

FExpressionCompileContextBase* FExpressionCompileContextBase::Get(FName ContextName)
{
	if (FExpressionCompileContextBase** FoundContext = GetCompileContextMap().Find(ContextName))
	{
		return *FoundContext;
	}

	return nullptr;
}

int32 CompileExpression(TArray<FExpressionCompileContextBase*> CompileContextArray, FExpressionInstructionBuffer& Buffer, const TCHAR* Code, FString* OutError)
{
	const FCompilingCode CodeCache(Code);

	int32 ErrorNum = 0;
	if (CodeCache.bIsValid)
	{
		static FExpressionCompileContextBase BaseContext;
		if (CompileContextArray.IsEmpty())
		{
			CompileContextArray.Add(&BaseContext);
		}
		
		ExpressionCompiler.Reset(CompileContextArray);
		ExpressionCompiler.Compile(CodeCache.FilePtr);

		if (ExpressionCompiler.HasErrors(OutError))
		{
			++ErrorNum;
		}

		if (ErrorNum == 0)
		{
			Buffer.Reset();
			ExpressionCompiler.Serialize(&Buffer);
		}
	}
	else
	{
		++ErrorNum;
		*OutError = TEXT("Create temp code file failed.");
	}

	return ErrorNum;
}

int32 CompileExpression(FExpressionContainer& Container, FName ContextName, FString* OutError)
{
	TArray<FExpressionCompileContextBase*> ContextArray;
	if (FExpressionCompileContextBase* Context = FExpressionCompileContextBase::Get(ContextName))
	{
		ContextArray.Add(Context);
	}
	
	return CompileExpression(MoveTemp(ContextArray), Container.InstructionBuffer, *Container.Code, OutError);
}
