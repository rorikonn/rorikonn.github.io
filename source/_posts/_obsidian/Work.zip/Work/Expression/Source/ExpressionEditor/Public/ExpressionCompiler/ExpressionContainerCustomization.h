﻿// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"


class FExpressionContainerCustomization : public IPropertyTypeCustomization
{
public:
	static TSharedRef<IPropertyTypeCustomization> MakeInstance();
	virtual void CustomizeHeader(TSharedRef<IPropertyHandle> StructPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils) override;
	virtual void CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils) override;

private:
	EVisibility GetCompileIconVisibility(const TSharedPtr<IPropertyHandle> DirtyPropertyHandle) const;
	FText GetCodeText(const TSharedPtr<IPropertyHandle> CodePropertyHandle) const;
	
	static void OnCodeChanged(const FText& Text, const TSharedPtr<IPropertyHandle> DirtyPropertyHandle);
	static void OnCodeCommit(const FText& Text, ETextCommit::Type CommitType, const TSharedPtr<IPropertyHandle> CodePropertyHandle);
	static FReply OnCompile(TSharedRef<IPropertyHandle> StructPropertyHandle);
};
