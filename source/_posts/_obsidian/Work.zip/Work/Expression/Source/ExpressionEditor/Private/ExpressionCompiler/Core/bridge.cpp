﻿//

#include "ExpressionCompiler/ExpressionCompiler.h"

#ifdef PLATFORM_LINUX
#define EXTERN_C extern "C"
#endif

FGLExpressionCompiler ExpressionCompiler = FGLExpressionCompiler();

EXTERN_C void out_compile_info(const char* buf);
EXTERN_C void out_compile_error(const char* buf);

EXTERN_C void stmt_ensure();

EXTERN_C void decl_var_int(const char* var_name);
EXTERN_C void decl_var_bool(const char* var_name);
EXTERN_C void decl_var_float(const char* var_name);
EXTERN_C void decl_var_string(const char* var_name);
EXTERN_C void decl_var_target(const char* var_name);
EXTERN_C void decl_var_repeat(const char* var_name);
EXTERN_C void decl_var_finish();

EXTERN_C void assign_var(const char* var_name);
EXTERN_C void assign_decl();

EXTERN_C void push_value_var(const char* var_name);
EXTERN_C void push_value_int(const char* value_str);
EXTERN_C void push_value_float(const char* value_str);
EXTERN_C void push_value_bool(const char* value_str);
EXTERN_C void push_value_string(const char* value_str);

EXTERN_C void pop_value();

EXTERN_C void add_value();
EXTERN_C void sub_value();
EXTERN_C void mul_value();
EXTERN_C void div_value();
EXTERN_C void mod_value();
EXTERN_C void cmpgt_value();
EXTERN_C void cmplt_value();
EXTERN_C void cmpge_value();
EXTERN_C void cmple_value();
EXTERN_C void cmpeq_value();
EXTERN_C void cmpne_value();
EXTERN_C void or_value();
EXTERN_C void and_value();
EXTERN_C void neg_value();
EXTERN_C void not_value();

EXTERN_C void start_block(int idx);
EXTERN_C void end_block(int idx);

EXTERN_C void _if(int idx);
EXTERN_C void _then(int idx);
EXTERN_C void _end_then(int idx);
EXTERN_C void _end_if(int idx);

EXTERN_C void print(const char* fmt);

EXTERN_C void call_function(const char* function_name);

EXTERN_C void expression_return();


void out_compile_info(const char* buf)
{
	ExpressionCompiler.AppendLog(FString(buf));
}

void out_compile_error(const char* buf)
{
	ExpressionCompiler.AppendError(FString(buf));
}

void stmt_ensure()
{
	ExpressionCompiler.StmtEnsure();
}

void decl_var_int(const char* var_name)
{
	ExpressionCompiler.DeclareVar(EVarType::Int, var_name);
}

void decl_var_bool(const char* var_name)
{
	ExpressionCompiler.DeclareVar(EVarType::Bool, var_name);
}

void decl_var_float(const char* var_name)
{
	ExpressionCompiler.DeclareVar(EVarType::Float, var_name);
}

void decl_var_string(const char* var_name)
{
	ExpressionCompiler.DeclareVar(EVarType::String, var_name);
}

void decl_var_target(const char* var_name)
{
	ExpressionCompiler.DeclareVar(EVarType::Target, var_name);
}

void decl_var_repeat(const char* var_name)
{
	ExpressionCompiler.RepeatDecl(var_name);
}

void decl_var_finish()
{
	ExpressionCompiler.FinishVarDeclaration();
}

void assign_var(const char* var_name)
{
	ExpressionCompiler.AssignVar(var_name);
}

void assign_decl()
{
	ExpressionCompiler.AssignDeclaration();
}

void push_value_var(const char* var_name)
{
	ExpressionCompiler.PushVariable(var_name);
}

void push_value_int(const char* value_str)
{
	ExpressionCompiler.PushValue(EVarType::Int, value_str);
}

void push_value_float(const char* value_str)
{
	ExpressionCompiler.PushValue(EVarType::Float, value_str);
}

void push_value_bool(const char* value_str)
{
	ExpressionCompiler.PushValue(EVarType::Bool, value_str);
}

void push_value_string(const char* value_str)
{
	ExpressionCompiler.PushValue(EVarType::String, value_str);
}

void pop_value()
{
	ExpressionCompiler.PopValue();
}

void add_value()
{
	ExpressionCompiler.Add();
}

void sub_value()
{
	ExpressionCompiler.Sub();
}

void mul_value()
{
	ExpressionCompiler.Mul();
}

void div_value()
{
	ExpressionCompiler.Div();
}

void mod_value()
{
	ExpressionCompiler.Mod();
}

void cmpgt_value()
{
	ExpressionCompiler.Greater();
}

void cmplt_value()
{
	ExpressionCompiler.Less();
}

void cmpge_value()
{
	ExpressionCompiler.GreaterEqual();
}

void cmple_value()
{
	ExpressionCompiler.LessEqual();
}

void cmpeq_value()
{
	ExpressionCompiler.Equal();
}

void cmpne_value()
{
	ExpressionCompiler.NotEqual();
}

void or_value()
{
	ExpressionCompiler.Or();
}

void and_value()
{
	ExpressionCompiler.And();
}

void neg_value()
{
	ExpressionCompiler.Negative();
}

void not_value()
{
	ExpressionCompiler.Not();
}

void start_block(int idx)
{
	ExpressionCompiler.BeginBlock(idx);
}

void end_block(int idx)
{
	ExpressionCompiler.EndBlock(idx);
}

void _if(int idx)
{
	ExpressionCompiler.BeginIf(idx);
}

void _then(int idx)
{
	ExpressionCompiler.IfThen(idx);
}

void _end_then(int idx)
{
	ExpressionCompiler.EndThen(idx);
}

void _end_if(int idx)
{
	ExpressionCompiler.EndIf(idx);
}

void print(const char* fmt)
{
	ExpressionCompiler.Print(fmt);
}

void call_function(const char* function_name)
{
	ExpressionCompiler.CallFunction(function_name);
}

void expression_return()
{
	ExpressionCompiler.ExpressionReturn();
}
