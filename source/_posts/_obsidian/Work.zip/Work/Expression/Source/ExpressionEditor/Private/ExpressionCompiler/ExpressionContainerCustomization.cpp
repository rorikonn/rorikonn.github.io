﻿// Fill out your copyright notice in the Description page of Project Settings.


#include "ExpressionCompiler/ExpressionContainerCustomization.h"

#include "DetailWidgetRow.h"
#include "Editor.h"
#include "IDetailChildrenBuilder.h"
#include "ExpressionCompiler/ExpressionCompiler.h"
#include "ExpressionRuntime/Public/ExpressionContainer.h"
#include "Widgets/Input/SMultiLineEditableTextBox.h"
#include "Widgets/Layout/SScrollBox.h"


TSharedRef<IPropertyTypeCustomization> FExpressionContainerCustomization::MakeInstance()
{
	return MakeShared<FExpressionContainerCustomization>();
}

void FExpressionContainerCustomization::CustomizeHeader(TSharedRef<IPropertyHandle> StructPropertyHandle, FDetailWidgetRow& HeaderRow, IPropertyTypeCustomizationUtils& StructCustomizationUtils)
{
	const TSharedPtr<IPropertyHandle> DirtyPropertyHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FExpressionContainer, Dirty));

	HeaderRow
		.NameContent()
		[
			StructPropertyHandle->CreatePropertyNameWidget()
		]
		.ValueContent()
		[
			SNew(SButton)
			.ContentPadding(2.0f)
			.OnClicked(FOnClicked::CreateStatic(&FExpressionContainerCustomization::OnCompile, StructPropertyHandle))
			.Content()
			[
				SNew(SHorizontalBox)
				+ SHorizontalBox::Slot()
				  .HAlign(HAlign_Center)
				  .VAlign(VAlign_Center)
				  .Padding(4.0f, 0.0f)
				  .AutoWidth()
				[
					SNew(STextBlock)
					.Text(NSLOCTEXT("FExpressionContainerCustomization", "CompileButtonContent", "Compile"))
				]
				+ SHorizontalBox::Slot()
				  .HAlign(HAlign_Right)
				  .VAlign(VAlign_Center)
				  .AutoWidth()
				[
					SNew(SImage)
					.Visibility(this, &FExpressionContainerCustomization::GetCompileIconVisibility, DirtyPropertyHandle)
					.Image(FAppStyle::GetBrush("AnimSlotManager.Warning"))
				]
			]
		];
}

void FExpressionContainerCustomization::CustomizeChildren(TSharedRef<IPropertyHandle> PropertyHandle, IDetailChildrenBuilder& ChildBuilder, IPropertyTypeCustomizationUtils& CustomizationUtils)
{
	const TSharedPtr<IPropertyHandle> CodePropertyHandle = PropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FExpressionContainer, Code));
	const TSharedPtr<IPropertyHandle> DirtyPropertyHandle = PropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FExpressionContainer, Dirty));

	IDetailPropertyRow& PropertyRow = ChildBuilder.AddProperty(CodePropertyHandle.ToSharedRef());
	PropertyRow.CustomWidget()
	           .ValueContent()
	           .HAlign(HAlign_Fill)
	           .VAlign(VAlign_Fill)
	[
		SNew(SBox)
		.HAlign(HAlign_Fill)
		.MinDesiredHeight(150.0f)
		[
			SNew(SMultiLineEditableTextBox)
			.Padding(FMargin(5.0f, 0.0f))
			.Text(this, &FExpressionContainerCustomization::GetCodeText, CodePropertyHandle)
			.OnTextChanged(FOnTextChanged::CreateStatic(&FExpressionContainerCustomization::OnCodeChanged, DirtyPropertyHandle))
			.OnTextCommitted(FOnTextCommitted::CreateStatic(&FExpressionContainerCustomization::OnCodeCommit, CodePropertyHandle))
		]
	];
}

EVisibility FExpressionContainerCustomization::GetCompileIconVisibility(const TSharedPtr<IPropertyHandle> DirtyPropertyHandle) const
{
	bool Dirty;
	DirtyPropertyHandle->GetValue(Dirty);
	return Dirty ? EVisibility::Visible : EVisibility::Hidden;
}

FText FExpressionContainerCustomization::GetCodeText(const TSharedPtr<IPropertyHandle> CodePropertyHandle) const
{
	FString CodeString;
	CodePropertyHandle->GetValue(CodeString);
	return FText::FromString(CodeString);
}

void FExpressionContainerCustomization::OnCodeChanged(const FText& Text, const TSharedPtr<IPropertyHandle> DirtyPropertyHandle)
{
	DirtyPropertyHandle->SetValue(true);
}

void FExpressionContainerCustomization::OnCodeCommit(const FText& Text, ETextCommit::Type CommitType, const TSharedPtr<IPropertyHandle> CodePropertyHandle)
{
	CodePropertyHandle->SetValue(Text.ToString());
}

FReply FExpressionContainerCustomization::OnCompile(TSharedRef<IPropertyHandle> StructPropertyHandle)
{
	TArray<UObject*> Objects;
	StructPropertyHandle->GetOuterObjects(Objects);
	if (Objects.Num() == 0)
	{
		if (UObject* Owner = StructPropertyHandle->GetProperty()->GetOwner<UObject>())
		{
			Objects.Add(Owner);
		}
	}
	if (Objects.Num() == 1)
	{
		FString ErrorStr;
		int32 ErrorCode = 0;
		FExpressionContainer* ExpressionContainer = reinterpret_cast<FExpressionContainer*>(StructPropertyHandle->GetValueBaseAddress(reinterpret_cast<uint8*>(Objects[0])));
		
		const FString ExpressionContext = StructPropertyHandle->GetMetaData(TEXT("ExpressionContext"));

		TArray<FString> ContextNameArray;
		ExpressionContext.ParseIntoArray(ContextNameArray,TEXT("|"));

		TArray<FExpressionCompileContextBase*> CompileContextArray;
		for (int32 Index = ContextNameArray.Num() - 1; Index >= 0; --Index)
		{
			const FName ContextName = FName(ContextNameArray[Index], FNAME_Find);
			if (FExpressionCompileContextBase* CurrentContext = FExpressionCompileContextBase::Get(ContextName))
			{
				CompileContextArray.Add(CurrentContext);
			}
			else
			{
				ErrorCode = -1;
				ErrorStr = FString::Printf(TEXT("Compile expression failed! can not find context %s"), *ContextName.ToString());
			}
		}

		if (ErrorCode == 0)
		{
			ErrorCode = CompileExpression(MoveTemp(CompileContextArray), ExpressionContainer->InstructionBuffer, *ExpressionContainer->Code, &ErrorStr);
		}

		if (ErrorCode == 0)
		{
			const TSharedPtr<IPropertyHandle> DirtyPropertyHandle = StructPropertyHandle->GetChildHandle(GET_MEMBER_NAME_CHECKED(FExpressionContainer, Dirty));
			DirtyPropertyHandle->SetValue(false);
		}
		else
		{
			GEditor->OnModalMessageDialog(
				EAppMsgType::Ok,
				FText::FromString(FString::Format(TEXT("Compile expression failed!\n{0}"), {ErrorStr})),
				NSLOCTEXT("CompileExpression", "ExpressionCompileError", "Expression Compile Error"));
		}
	}

	return FReply::Handled();
}
